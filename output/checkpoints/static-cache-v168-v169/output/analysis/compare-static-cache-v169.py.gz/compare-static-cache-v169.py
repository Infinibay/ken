"""Require closed public captures and compare lossless API behavior, no labels."""
from pathlib import Path
import hashlib
import json
import statistics
import numpy as np

w = Path.cwd()
baseline = w / 'output/development/public-default-v155-original'
candidate = w / 'output/development/public-static-cache-v169-original'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def load(root):
    lock = json.loads((root / 'lock.json').read_text())
    registration = json.loads((root / 'capture/registration.json').read_text())
    assert registration['status'] == lock['closed_status']
    assert registration['lock_sha256'] == sha(root / 'lock.json')
    answers, timings, per_repo = {}, [], {}
    for repo, pins in registration['closed'].items():
        for name, digest in pins.items():
            assert sha(root / 'capture' / repo / name) == digest
        for line in (root / 'capture' / repo / 'answers.jsonl').read_text().splitlines():
            answer = json.loads(line)
            assert answer['id'] not in answers
            answers[answer['id']] = answer
        perf = json.loads((root / 'capture' / repo / 'performance.json').read_text())
        assert perf['providers'] == ['CPUExecutionProvider'] and not perf['heavy_imports']
        assert perf['source_receipt'] == lock['source_receipt']
        ms = [t['ms'] for t in perf['timings']]
        assert len(ms) > 0 and all(t > 0 for t in ms)
        timings.extend(ms)
        rss = perf['peak_rss_native'] * (1024 if perf['rss_unit'] == 'KiB' else 1)
        per_repo[repo] = {'queries': len(ms), 'indexed_files': perf['indexed_files'],
            'p50_ms': statistics.median(ms), 'p95_ms': float(np.percentile(ms, 95)),
            'max_ms': max(ms), 'peak_rss_bytes': rss,
            'server_cpu_total_ms': perf['server_cpu_total_ms']}
    assert len(answers) == len(timings) == lock['queries'] == 200
    return answers, {'p50_ms': statistics.median(timings),
        'p95_ms': float(np.percentile(timings, 95)), 'max_ms': max(timings),
        'peak_rss_bytes': max(v['peak_rss_bytes'] for v in per_repo.values()),
        'server_cpu_total_ms': sum(v['server_cpu_total_ms'] for v in per_repo.values()),
        'per_repo': per_repo}, registration

old, old_perf, old_reg = load(baseline)
new, new_perf, new_reg = load(candidate)
assert old.keys() == new.keys()
orders_changed = [q for q in old if old[q]['units'] != new[q]['units']]
responses_changed = [q for q in old if old[q]['public_response'] != new[q]['public_response']]
assert not orders_changed, orders_changed
assert not responses_changed, responses_changed
receipt = {'scope': 'Actual complete original200 MCP API; labels not read. Byte-equivalent decoded public DTOs inherit baseline191/197, not independent validation.',
    'queries': len(old), 'changed_orders': orders_changed, 'changed_public_responses': responses_changed,
    'baseline_capture_registration_sha256': sha(baseline / 'capture/registration.json'),
    'candidate_capture_registration_sha256': sha(candidate / 'capture/registration.json'),
    'baseline': old_perf, 'candidate': new_perf,
    'performance_limit': 'Separate historical runs, not randomized paired causal comparison. CPU totals include warmup and transport lifecycle; per-query CPU not measured.',
    'new_symbol_stress': 'NOT rerun in this capture; no new quality or performance claim for those200.',
    'independent_acceptance': 'Untouched fresh reserve remains closed; previous balanced200 still177/198 on frozen145.'}
out = candidate / 'lossless-comparison.json'
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['queries', 'changed_orders', 'changed_public_responses']}))
print(json.dumps({'baseline': {k:v for k,v in old_perf.items() if k!='per_repo'}, 'candidate': {k:v for k,v in new_perf.items() if k!='per_repo'}}))
