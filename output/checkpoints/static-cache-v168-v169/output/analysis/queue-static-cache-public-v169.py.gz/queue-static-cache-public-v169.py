from pathlib import Path
import json,subprocess,time,os,hashlib
w=Path.cwd();out=w/'output/development/public-static-cache-v169-original';lock=json.loads((out/'lock.json').read_text());status=Path('/private/tmp/ken-static-cache-v169-suite-exit')
while not status.exists():time.sleep(15)
if status.read_text().strip()!='0':raise ValueError('fullsuite failed; public benchmark not run')
env={**os.environ,'PYTHONPATH':str(Path(lock['engine_root'])/'src'),'PYTHONDONTWRITEBYTECODE':'1'}
with (out/'capture.log').open('w') as log:subprocess.run([str(w/'.venv-model-runtime/bin/python'),'experiments/search-engine/public_default_mcp_run.py','--lock',str(out/'lock.json'),'--output',str(out/'capture')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Original200full public CPU capture closed, no reference grading',flush=True)
