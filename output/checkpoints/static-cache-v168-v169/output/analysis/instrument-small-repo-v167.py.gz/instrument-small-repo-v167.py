from pathlib import Path
import json,time,resource
from ken.retrieval.best_resources import default_resources
from ken.retrieval.best_search import prepare_best,search_best
from ken.retrieval.connections import project_connection
from ken.retrieval.model import SearchRequest
w=Path.cwd();root=Path('/private/tmp/ken-public-default-v143/repos/attrs');cases=list(map(json.loads,(w/'output/development/verifiable-pieces-v98-public/cases.jsonl').read_text().splitlines()));c=next(c for c in cases if c['repo_id']=='attrs' and c['target_kind']=='symbol');request=SearchRequest(c['query'],piece_kind='symbol',max_chars=1000000);r=default_resources();records=[]
with project_connection(root) as conn:
 prepare_best(conn,root);search_best(conn,root,request);orig=r.words.embed_passages;neural=r.neural.score;current={};seen=set()
 def measured(texts):
  before=time.perf_counter();result=orig(texts);elapsed=(time.perf_counter()-before)*1000;short=[t for t in texts if len(t)<=128 and not any(ch.isspace() for ch in t)];current.setdefault('static_calls',[]).append({'texts':len(texts),'cacheable':len(short),'seen_before':sum(t in seen for t in short),'ms':elapsed});seen.update(short);return result
 def measured_neural(q,texts):
  result,details=neural(q,texts);current['neural']={'pairs':len(result),**details};return result,details
 r.words.embed_passages=measured;r.neural.score=measured_neural
 for repeat in range(3):
  current={'repeat':repeat};before=time.perf_counter();response=search_best(conn,root,request);current['total_ms']=(time.perf_counter()-before)*1000;records.append(current)
receipt={'scope':'boundary instrumentation, one public query3repeats, no p95claim, unchanged model behavior','id':c['id'],'rows':records,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(w/'output/analysis/installed-small-repo-profile-v167/boundaries.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
