"""Locate warm default CPU costs, not an acceptance latency benchmark."""
from pathlib import Path
import cProfile,pstats,json,time,sys,resource
from ken.retrieval.connections import project_connection
from ken.retrieval.best_search import search_best,prepare_best
from ken.retrieval.model import SearchRequest
import ken
w=Path('/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace');root=Path('/private/tmp/ken-public-default-v143/repos/attrs');cases=list(map(json.loads,(w/'output/development/verifiable-pieces-v98-public/cases.jsonl').read_text().splitlines()));case=next(c for c in cases if c['repo_id']=='attrs' and c['target_kind']=='symbol');req=SearchRequest(case['query'],target='symbol',piece_kind=case['target_kind'],limit=10,max_chars=1000000);out=w/'output/analysis/installed-small-repo-profile-v167';out.mkdir(exist_ok=False)
with project_connection(root) as conn:
 setup=prepare_best(conn,root);warm=search_best(conn,root,req);prof=cProfile.Profile();result=prof.runcall(search_best,conn,root,req);assert result.to_dict()==warm.to_dict();prof.dump_stats(out/'search.pstats')
 with (out/'cumulative.txt').open('w') as stream:pstats.Stats(prof,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(45)
receipt={'scope':'warm installed default component profiling only; cProfile instrumentation overhead, not p95/acceptance','package':ken.__file__,'source_commit':'dce44af3ea42c3aefa3b98820778a5adb28c87ec','public_case_id':case['id'],'query':case['query'],'setup':setup,'result_order_stable':True,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'private_source_or_references':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
