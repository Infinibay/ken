"""Original200 model portfolio only. Never opens additional or private acceptance refs."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
w=Path(__file__).resolve().parents[2];root=w/'output/development/generic-model-candidates-v140-141';lockpath=root/'lock.json';lock=json.loads(lockpath.read_text());caller=w/'output/frozen/generic-cpu-caller-v140/generic_piece_cpu_run.py'
for variant in ('native_mean','piece_mean'):
    engine=Path(lock['variants'][variant]['engine_root']);env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(engine/'src')+':'+str(engine/'experiments/search-engine')}
    with (root/(variant+'.log')).open('w') as log:
        subprocess.run([str(w/'.venv-model-runtime/bin/python'),str(caller),'--workspace',str(w),'--lock',str(lockpath),'--output',str(root/variant),'--variant',variant],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    reg=json.loads((root/variant/'registration.json').read_text())
    if reg['status']!='ALL original-development outputs closed without Gold':raise ValueError('unclosed original200 candidate')
    print(variant+' old200 capture closed',flush=True)
# Old references were already exposed; keep their exact pins and full denominator.
sys.path.insert(0,str(w/'experiments/search-engine'))
from unseen_piece_score import evaluate_identity
cases=[json.loads(line) for line in Path(lock['public_cases']).read_text().splitlines()];refs=[]
for path,expected in lock['reference_pins'].items():
    data=Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('original exposed reference changed')
    refs += [json.loads(line) for line in data.decode().splitlines()]
summary={'scope':lock['scope'],'lock_sha256':hashlib.sha256(lockpath.read_bytes()).hexdigest(),'new200or_private_acceptance_opened':False,'variants':{}}
for variant in ('native_mean','piece_mean'):
    answers=[]
    for path in (root/variant).glob('*/answers.jsonl'):answers += [json.loads(line) for line in path.read_text().splitlines()]
    result,outcomes=evaluate_identity(cases,answers,refs);summary['variants'][variant]=result
    (root/(variant+'-old200-outcomes.jsonl')).write_text(''.join(json.dumps(row,sort_keys=True)+'\n' for row in outcomes))
    print(json.dumps({'variant':variant,'top1':result['top1']['count'],'top10':result['recall10']['count'],'queries':result['queries']}),flush=True)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
