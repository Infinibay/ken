from pathlib import Path
import hashlib,json,shutil
source=Path('/Users/andres/.codex/worktrees/compact-default-output/ken');dest=Path(__file__).resolve().parents[2]/'output/frozen/public-default-cpu-v145';dest.mkdir(exist_ok=False)
shutil.copytree(source/'src',dest/'src',ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copyfile(source/'pyproject.toml',dest/'pyproject.toml')
files={p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for path in (dest/'src',dest/'pyproject.toml') for p in (path.rglob('*') if path.is_dir() else (path,)) if p.is_file()}
receipt={'scope':'Actual production CLI/MCP defaults, generic models, before independent Gold','files':dict(sorted(files.items())),'tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()};payload=json.dumps(receipt,indent=2).encode();(dest/'SOURCE-MANIFEST.json').write_bytes(payload);print(json.dumps({'root':str(dest),'source_receipt':hashlib.sha256(payload).hexdigest()}))
