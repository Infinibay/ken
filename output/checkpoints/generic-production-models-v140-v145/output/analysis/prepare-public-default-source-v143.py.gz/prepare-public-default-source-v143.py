"""Source-only migration into normal project stores; no query or reference read."""
from pathlib import Path
import hashlib,json,os,sqlite3,time
import numpy as np
from ken.db import connect,init_schema
from ken.embedder.contextual_onnx import ContextEncoder,code_context_model
from ken.embedder.model2vec_backend import RegisteredStaticEncoder
from ken.retrieval.indexing import index_project
from ken.retrieval.profile import potion_profile
from ken.retrieval.candidates import owner_passages
from ken.retrieval.context_preparation import ContextVectorCache,prepare_context
from ken.retrieval.piece_catalog import SourceCatalog,entity_id
from ken.retrieval.storage import generation
w=Path(__file__).resolve().parents[2];out=w/'output/development/public-default-source-v143';out.mkdir(exist_ok=True)
roots={k:Path(v) for k,v in json.loads((w/'experiments/search-engine/datasets/roots-development.json').read_text()).items()}
base=w/'output/analysis/c-source-reindex-v66c';views=w/'output/analysis/context-views-source7-v69'
reg=json.loads((base/'registration.json').read_text());vr=json.loads((views/'registration.json').read_text());receipts=json.loads((w/'output/analysis/verifiable-pieces-catalog-v98/receipt.json').read_text())
static=next(r for r in json.loads((w/'output/models/static-comparison-registration.json').read_text()) if r['model_id']=='minishlab/potion-code-16M-v2');words=RegisteredStaticEncoder(Path(static['root']),static)
contextreg=json.loads((w/'output/models/cpu-context-registration-v42.json').read_text());encoder=ContextEncoder(code_context_model(),snapshot=Path(contextreg['root']))
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt={'scope':'Source-only normal production project/index/cache preparation, no public queries or Gold; exact old source vectors reused by content and model identity','script_sha256':sha(__file__),'context_model':encoder.spec.key,'repos':{}}
for repo in ('ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest'):
 started=time.perf_counter();root=Path('/private/tmp/ken-public-default-v143/repos')/repo;root.mkdir(parents=True,exist_ok=True);project=root/'.ken';project.mkdir(exist_ok=True)
 source=sqlite3.connect(f'file:{base/"indices"/(repo+".db")}?mode=ro',uri=True);target=sqlite3.connect(project/'ken.db');source.backup(target);target.close();source.close();conn=connect(project/'ken.db');init_schema(conn)
 files=[Path(r[0]) for r in conn.execute('SELECT path FROM ci_files ORDER BY path')]
 for path in files:
  original=roots[repo]/path;target=root/path;target.parent.mkdir(parents=True,exist_ok=True);
  if not target.exists():os.link(original,target)
  if sha(target)!=reg['source_repos'][repo]['file_hashes'][path.as_posix()]:raise ValueError('source closure mismatch')
 (project/'meta.json').write_text(json.dumps({'version':1,'project_root':str(root)}))
 index_project(conn,root,files,profile=potion_profile(),encoders={'identity':words,'behavior':words})
 catalog=SourceCatalog(root,owner_passages(conn));inventory=''.join(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n' for row in catalog.source_inventory())
 if hashlib.sha256(inventory.encode()).hexdigest()!=receipts['repos'][repo]['inventory_sha256']:raise ValueError('source inventory differs')
 oldpath=base/'context'/(repo+'.db');viewdb=views/(repo+'-source.db');viewnpy=views/(repo+'-vectors.npy')
 if sha(oldpath)!=reg['context_repos'][repo]['context_index_sha256'] or sha(viewdb)!=vr['source_repos'][repo]['source_db_sha256'] or sha(viewnpy)!=vr['source_repos'][repo]['vectors_sha256']:raise ValueError('source vector artifact changed')
 old=sqlite3.connect(f'file:{oldpath}?mode=ro',uri=True);vd=sqlite3.connect(f'file:{viewdb}?mode=ro',uri=True);matrix=np.load(viewnpy,mmap_mode='r',allow_pickle=False)
 cachepath=project/'search-context'
 with ContextVectorCache(cachepath,encoder.spec) as cache:
  cache.put_many((text,np.frombuffer(vector,dtype=np.float32)) for text,vector in old.execute('SELECT text,vector FROM vectors'))
  cache.put_many((text,matrix[i]) for i,text in vd.execute('SELECT vector_index,text FROM texts'))
  cache_count=cache.count()
 runtime=prepare_context(catalog,generation(conn),encoder,cachepath)
 old_rows={json.dumps(json.loads(entity),ensure_ascii=False,sort_keys=True,separators=(',',':')):(digest,np.frombuffer(vector,dtype=np.float32)) for entity,digest,vector in old.execute('SELECT o.entity,o.source_hash,v.vector FROM owners o JOIN vectors v ON o.text_hash=v.hash')}
 for i,key in enumerate(runtime.vectors.owners):
  digest,value=old_rows[entity_id(key)]
  if digest!=runtime.vectors.source_hashes[i] or not np.array_equal(value,runtime.vectors.matrix[i]):raise ValueError('full source vector differs')
 vrows={(json.dumps(json.loads(entity),ensure_ascii=False,sort_keys=True,separators=(',',':')),view):(digest,i) for entity,digest,view,i in vd.execute('SELECT entity,source_hash,view,vector_index FROM owners')}
 for i,key in enumerate(runtime.vectors.owners):
  for view in ('contract','implementation'):
   digest,j=vrows[(entity_id(key),view)]
   if digest!=runtime.vectors.source_hashes[i] or not np.array_equal(matrix[j],runtime.source_views.matrix[runtime.source_views.rows[view][i]]):raise ValueError('source view vector differs')
 receipt['repos'][repo]={'root':str(root),'indexed_files':len(files),'owners':len(catalog.owners),'cache_unique_texts':cache_count,'generation':generation(conn),'source_inventory_sha256':hashlib.sha256(inventory.encode()).hexdigest(),'all_full_and_view_vectors_bit_equal':True,'ms':(time.perf_counter()-started)*1000}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'repo':repo,'closed':True,'files':len(files),'owners':len(catalog.owners)}),flush=True)
 old.close();vd.close();conn.close();del catalog,runtime,matrix,old_rows,vrows
