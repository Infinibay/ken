import numpy as np
import pytest
import query_clause_coverage as m


def test_clause_split_retains_conditions_and_negation():
    assert m.query_clauses('reads a value, rejects null and preserves the cause') == ('reads a value', 'rejects null', 'preserves the cause')


def test_quoted_code_and_brackets_stay_intact():
    text = 'compares `a and b`, accepts "x,y" and calls f(x, y)'
    assert m.query_clauses(text) == ('compares `a and b`', 'accepts "x,y"', 'calls f(x, y)')


def test_bounded_groups_keep_all_clauses_in_original_order():
    parts = m.query_clauses('a, b, c, d, e, f, g, h, i')
    assert len(parts) == 4
    assert ', '.join(parts) == 'a, b, c, d, e, f, g, h, i'


def test_unsplit_empty_and_unbalanced_input():
    assert m.query_clauses('simple lookup') == ('simple lookup',)
    assert m.query_clauses('') == ('',)
    assert m.query_clauses('checks `x and y') == ('checks `x and y',)


def test_features_keep_view_and_candidate_alignment():
    # Whole query points left, two clauses one left and one right.
    q = np.array([[1., 0.], [1., 0.], [0., 1.]])
    views = [np.eye(2), np.array([[.6,.8],[.8,.6]]), np.array([[0.,1.],[1.,0.]])]
    got = m.coverage_features(q, views)
    assert got.shape == (2, 12)
    np.testing.assert_allclose(got[0], [1.,.5,0.,1., .6,.7,.6,.8, 0.,.5,0.,1.])
    np.testing.assert_allclose(got[1], [0.,.5,0.,1., .8,.7,.6,.8, 1.,.5,0.,1.])


def test_bad_or_nonfinite_vectors_fail_instead_of_fabricating_score():
    for q, v in [(np.ones((1,2)), [np.ones((2,2))]*3), (np.full((2,2),np.nan), [np.ones((2,2))]*3)]:
        with pytest.raises(ValueError):
            m.coverage_features(q,v)
