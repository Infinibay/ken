"""Bounded conjunctive query coverage; research-only, no source encodes."""
import re
import numpy as np

FEATURES = tuple(f'{view}_{stat}' for view in ('full','contract','implementation') for stat in ('whole','mean','min','max'))


def query_clauses(text: str) -> tuple[str, ...]:
    # A small scanner keeps code literals and nested arguments atomic.
    boundaries = []
    quote = None
    stack = []
    i = 0
    while i < len(text):
        c = text[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                quote = None
        elif c in "`\"'":
            # An apostrophe inside a word is not the start of a code literal.
            if c != "'" or not (i and text[i-1].isalnum()):
                quote = c
        elif c in '([{':
            stack.append(c)
        elif c in ')]}':
            if stack:
                stack.pop()
        elif not stack:
            size = 1 if c in ',;' else 0
            if not size:
                match = re.match(r'\s+(?:and|but|while|whereas)\s+', text[i:], re.I)
                size = len(match[0]) if match else 0
            if size:
                boundaries.append((i, i+size))
                i += size
                continue
        i += 1
    pieces = []
    start = 0
    for a, b in boundaries:
        if text[start:a].strip():
            pieces.append(text[start:a].strip())
        start = b
    if text[start:].strip():
        pieces.append(text[start:].strip())
    if not pieces:
        return (text,)
    if len(pieces) <= 4:
        return tuple(pieces)
    groups = []
    start = 0
    for remaining in range(4, 0, -1):
        size = (len(pieces)-start+remaining-1)//remaining
        groups.append(', '.join(pieces[start:start+size]))
        start += size
    return tuple(groups)


def coverage_features(query_vectors: np.ndarray, views: list[np.ndarray]) -> np.ndarray:
    q = np.asarray(query_vectors, dtype=np.float64)
    if q.ndim != 2 or len(q) < 2 or len(views) != 3 or not np.isfinite(q).all():
        raise ValueError('whole query and at least one finite clause vector required')
    output = []
    n = None
    for view in views:
        d = np.asarray(view, dtype=np.float64)
        if (d.ndim != 2 or d.shape[1] != q.shape[1] or not np.isfinite(d).all()
                or (n is not None and len(d) != n)):
            raise ValueError('finite aligned source matrices required')
        n = len(d)
        scores = d @ q.T
        clauses = scores[:,1:]
        output.extend([scores[:,0], clauses.mean(axis=1), clauses.min(axis=1), clauses.max(axis=1)])
    return np.column_stack(output)
