import pytest
import source_purpose as m

@pytest.mark.parametrize('query', ['Find the serialization regression that preserves order.', '¿Qué prueba comprueba el redondeo?', 'Where is a converter tested with a custom field?', 'How is the cancellation token tested?', '¿Dónde se prueba la conversión con un valor vacío?'])
def test_explicit_requests_for_test_implementation(query):
    assert m.source_purpose(query) == 'tests'

@pytest.mark.parametrize('query', ['Where does the test runner convert failures?', 'Find the method that checks whether a test exists.', 'Which factory creates a test descriptor?', 'Where does the parser reject invalid input?'])
def test_test_domain_mentions_do_not_request_regression(query):
    assert m.source_purpose(query) == 'implementation'

@pytest.mark.parametrize('query', ['Find the test helper that builds temporary records.', 'Which test fixture creates a fake server?'])
def test_requested_test_support_is_separate_from_test_entry(query):
    assert m.source_purpose(query) == 'test_helper'


def test_empty_partition_keeps_candidates_and_ties_stable():
    cues=[{'test_entry':True,'test_helper':False}]*3
    assert m.preferred(cues,'implementation')==[False]*3
    assert m.preferred(cues,'tests')==[True]*3
