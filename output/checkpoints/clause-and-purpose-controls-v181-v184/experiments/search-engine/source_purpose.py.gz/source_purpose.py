"""Fixed source responsibility control, research-only, no benchmark labels."""
import re
from ken.retrieval.intent import interpret
from ken.retrieval.model import SearchRequest


def source_purpose(query):
    lower=query.casefold().lstrip('¿')
    if re.match(r'^(?:which|what|find|show|locate|qué|que|busca|localiza)\s+(?:the\s+|a\s+|el\s+|la\s+)?(?:test(?:ing)?\s+(?:helper|fixture|utility|support)|fixture\s+for\s+tests?)\b',lower):
        return 'test_helper'
    passive = (re.match(r'^(?:where|how)\b',lower) and re.search(r'\b(?:is|are|was|were)\b.{0,100}\btested\b',lower)
               or re.match(r'^(?:dónde|donde|cómo|como)\b',lower) and re.search(r'\bse\s+(?:prueba|prueban|testea|testean)\b',lower))
    if passive:
        return 'tests'
    purpose=interpret(SearchRequest(query)).purpose
    # A finite verb before a test noun makes that noun the action's object.
    # 'factory creates a test' requests a factory, not a regression.
    if purpose=='tests':
        noun=re.search(r'\b(?:tests?|pruebas?|regressions?|regresi[oó]n(?:es)?)\b',lower)
        prefix=lower[:noun.start()] if noun else lower
        verbs=r'\b(?:creates?|builds?|converts?|processes?|runs?|loads?|reads?|writes?|executes?|receives?|returns?|checks?|uses?|handles?|contains?|supports?|rejects?|accepts?|selects?|chooses?|applies?|dispatches?|resolves?|reports?|crea|construye|convierte|procesa|ejecuta|devuelve|contiene|rechaza|acepta)\b'
        if re.search(verbs,prefix):
            return 'implementation'
    return purpose


def preferred(cues,purpose):
    entries=[c['test_entry'] for c in cues]
    helpers=[c['test_helper'] for c in cues]
    if purpose=='tests':
        return entries if any(entries) else helpers
    if purpose=='test_helper':
        return helpers
    if purpose=='implementation':
        return [not(entry or helper) for entry,helper in zip(entries,helpers,strict=True)]
    return [False]*len(cues)
