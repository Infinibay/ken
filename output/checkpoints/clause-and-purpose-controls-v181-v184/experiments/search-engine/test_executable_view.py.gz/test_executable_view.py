from types import SimpleNamespace
import executable_view as m


def test_contract_cannot_supply_executable_evidence():
    d=SimpleNamespace(entity=SimpleNamespace(path='lib/x.py',qualname='lookup'),fields={'signature':'def lookup(x):','executable':'    return data[x]','documentation':'unrelated promised behavior','comments':'# unrelated'})
    assert m.executable_view(d) == 'symbol lib/x.py lookup\ndef lookup(x):\nImplementation:\n    return data[x]'


def test_large_owner_is_bounded_without_partial_physical_lines():
    d=SimpleNamespace(entity=SimpleNamespace(path='x.py',qualname='work'),fields={'signature':'def work():','executable':'\n'.join('    x = '+str(i) for i in range(100))})
    text=m.executable_view(d)
    assert text.endswith('    x = 63')
    assert len(text.splitlines())==67


def test_character_budget_excludes_whole_oversized_line():
    d=SimpleNamespace(entity=SimpleNamespace(path='x.py',qualname='work'),fields={'signature':'def work():','executable':'    ok()\n'+'x'*13000+'\n    later()'})
    text=m.executable_view(d)
    assert text.endswith('    ok()') and len(text)<=12000
