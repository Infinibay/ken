"""U182 query-clause attention on exact current code cards; no labels."""
import sys,json,hashlib,os,subprocess,time,resource
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from query_clause_coverage import query_clauses
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.piece_cards import build_card,card_text
from ken.retrieval.model import EntityKey

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def origins():
 source=Path(os.environ['PYTHONPATH']).resolve();result={}
 for name,m in tuple(sys.modules.items()):
  if (name=='ken' or name.startswith('ken.')) and getattr(m,'__file__',None):
   p=Path(m.__file__).resolve();assert p.is_relative_to(source);result[name]={'path':str(p),'sha256':sha(p)}
 return result
w=Path.cwd();previous=w/'output/development/source-syntax-evidence-v162b';reg=json.loads((previous/'registration.json').read_text());assert reg['status']=='ALL250source syntax public observations closed without Gold';out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
 rec={'scope':'U182 existingFP32Ettin68M perclause attention, EXPOSED250currentpool, no labels','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/query_clause_coverage.py'),'protocol_sha256':sha('output/analysis/clause-crossencoder-v182-protocol.md'),'previous_registration_sha256':sha(previous/'registration.json'),'features':['mean','min','max','std'],'closed':{},'origins_at_registration':origins()};(out/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']};(out/'registration.json').write_text(json.dumps(rec,indent=2));print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250clause attention observations closed without labels';rec['origins_at_close']=origins();(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
assert sha(previous/repo/'observations.jsonl')==reg['closed'][repo]['observations.jsonl'];r=default_resources();root=Path('/private/tmp/ken-public-default-v143/repos')/repo;origins0=origins();observations=[];matrix=[];qids=[]
prior={o['id']:o for o in rows(w/'output/development/current-document-prior-v158'/repo/'observations.jsonl')}
with project_connection(root) as conn:
 catalog=SourceCatalog(root,owner_passages(conn))
 for old in rows(previous/repo/'observations.jsonl'):
  query=old['expanded_query'];clauses=query_clauses(query);texts=[];hashes=[]
  for u in old['units']:
   key=EntityKey(path=u['path'],**u['entity']);data=(root/key.path).read_bytes();digest=hashlib.sha256(data).hexdigest();assert digest==catalog.hashes[key.path];hashes.append(digest);texts.append(card_text(build_card(key,'symbol',[key],query,catalog)))
  assert [sha256 for sha256 in map(lambda t:hashlib.sha256(t.encode()).hexdigest(),texts)]==prior[old['id']]['input_hashes']
  start=time.perf_counter();raw,details=r.neural.score(query,texts);assert np.allclose(raw,old['raw_scores'],rtol=0,atol=1e-5)
  clause_scores=[]
  for clause in clauses:
   values=raw if clause==query else r.neural.score(clause,texts)[0];clause_scores.append(values)
  values=np.asarray(clause_scores,dtype=np.float64).T;x=np.column_stack([values.mean(axis=1),values.min(axis=1),values.max(axis=1),values.std(axis=1)]);matrix.append(x);qids.extend([old['id']]*len(x));observations.append({'id':old['id'],'repo_id':repo,'query':old['query'],'expanded_query':query,'clauses':clauses,'units':old['units'],'raw_scores':raw,'clause_scores':clause_scores,'input_hashes':prior[old['id']]['input_hashes'],'source_hashes':hashes,'observer_ms':(time.perf_counter()-start)*1000,'details':details});print(json.dumps({'id':old['id']}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(matrix),qid=np.array(qids));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'queries':len(observations),'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'observer_p50_ms':float(np.median([o['observer_ms'] for o in observations])),'observer_p95_ms':float(np.percentile([o['observer_ms'] for o in observations],95)),'scope':'whole+clause crossencoder only, not complete search','origins_at_registration':origins0,'origins_at_close':origins()},indent=2))
