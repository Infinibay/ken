# U182: verify conditions with the EXISTING cross-encoder

Exposed development only. T181CLS coverage rejected:90/195minimum,161/195residual;
raw existing169/195. Hypothesis: sentence vectors do not verify each condition;
reusing Ettin68M query-document attention per clause may supply that information.
No new checkpoint/weights/quantization, no candidate/source/input-card changes.

Same predeclared clause scanner181; use currentP162bexpandedquery and rebuild
original64line card; assert all2500raw scores equal158current capture within1e-5.
Capture per-clause scores for all250symbol queries/current10candidate pools,
without labels; whole-query scores unchanged. Record literal card hashes, source
hashes, imported origins, CPU provider, latency, peakRSS. Freeze ALLbeforeGold.

Fixed U1: rank by mean clause logit. Fixed U2: fourfeature standardized additive
linear residual to raw whole-query logits: mean/min/max/std of clause logits.
Pairwise logistic L2=1/effective trainingqueries,8leave-repository-out folds;
training-only normalization. No rolefeatures, tuning, rescaling sweep or cherry
picking. Empty/no split query uses wholequery once. No extra global source encode.
Preserve non-symbol150orders and40qualifiedexact from public172. All400denoms,
strict canonical identity,197/195Recall10, gatesold>=180new>=180. Runtime gate
requires new actual MCP CPU/RAM run if accuracy passes; timings here OBSERVERonly.
Reserve closed. Negative results retained. No release.
