"""Fixed responsibility ordering. Predictions all closed before exposed grading."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,'experiments/search-engine')
from source_purpose import source_purpose,preferred
from verifiable_grading import identity_hit
from fit_score_calibration import summarize
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest
w=Path.cwd();rows=lambda p:list(map(json.loads,Path(p).read_text().splitlines()));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();cap=w/'output/development/operational-evidence-v160';reg=json.loads((cap/'registration.json').read_text());assert reg['status']=='ALL250operational public source observations closed without Gold';out=w/'output/development/source-purpose-v183';out.mkdir(exist_ok=False)
registration={'scope':'V183fixed requested source responsibility, EXPOSED400, no fitting/private inputs','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/source_purpose.py'),'protocol_sha256':sha('output/analysis/source-purpose-v183-protocol.md'),'cue_registration_sha256':sha(cap/'registration.json'),'status':'registered before grading'};(out/'registration.json').write_text(json.dumps(registration,indent=2));cases={};baseline={}
for name in ['original','symbols']:
 root=w/'output/development'/('public-qualified-locator-v172-'+name);lock=json.loads((root/'lock.json').read_text())
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if name=='original' else 'new_symbol200','query_kind':c.get('query_style',c.get('query_kind','unspecified'))}
 for f in (root/'capture').glob('*/answers.jsonl'):
  for o in rows(f):baseline[o['id']]=o
exact={o['id']:o for o in rows(w/'output/development/qualified-exact-diagnostic-v172/observations.jsonl')};obs={}
for repo,pins in reg['closed'].items():
 assert sha(cap/repo/'observations.jsonl')==pins['observations.jsonl']
 for o in rows(cap/repo/'observations.jsonl'):obs[o['id']]=o
orders=[]
for q,c in cases.items():
 units=baseline[q]['units'];purpose=source_purpose(c['query']);flags=[]
 if q in obs and exact[q]['units'] is None:
  o=obs[q];assert units==o['units'];flags=preferred(o['source_cues'],purpose);named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(units)),key=lambda i:(-int(named is not None and units[i]['path']==named),-int(flags[i]),-o['raw_scores'][i],i));units=[units[i] for i in order]
 orders.append({'id':q,'units':units,'source_purpose':purpose,'eligibility':flags})
(out/'orders.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in orders));registration.update(status='ALL400predictions closed before grading',orders_sha256=sha(out/'orders.jsonl'));(out/'registration.json').write_text(json.dumps(registration,indent=2))
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
 for p,d in c['exposed_gold_pins'].items():
  assert sha(p)==d;gold.update({o['id']:o for o in rows(p)})
assert set(cases)==set(baseline)==set(gold) and len(cases)==400;outcomes=[]
for o in orders:
 q=o['id'];c=cases[q];units=o['units'];hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))})
summary=summarize(outcomes);(out/'outcomes.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(out/'summary.json').write_text(json.dumps(summary,indent=2));registration['status']='ALL400fixed purpose control graded, no private inputs';(out/'registration.json').write_text(json.dumps(registration,indent=2));print(json.dumps(summary['cohort'],indent=2))
