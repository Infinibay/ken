# V183: respect requested source responsibility before similarity

Exposed development only. This differs from rejected K156 learned Potion-role
posterior (legacy193pool), R165TFIDF (omitted flags), and N160 learned source cues.
A deterministic requested-responsibility partition on current195pool, no fitting:
- existing intent tests => test entry if any, otherwise test helper if any;
- passive request where/how something is tested => tests;
- explicitly requested test helper/fixture => test helper if any;
- usage => no preference;
- otherwise implementation => neither test entry nor test helper if any.
Prefer eligible candidates lexicographically, then existing raw neural logits.
Keep ALL10identities; empty preferred role falls back to unchanged neural order.
Exact locators and non-symbol outputs preserve current172orders. No exclusions,
labels, model, or numeric weights. Generic passive-role recognition tested first
on synthetic requests, before evaluating. Current160cues reused, no new model call.
All400 strict outcomes reported. No gold-derived role oracle. Reserve remains
closed. Reject if misses >=20new or old<180; record all losses and ambiguous intent.
No further regex/priority tuning on this control's measured errors.
