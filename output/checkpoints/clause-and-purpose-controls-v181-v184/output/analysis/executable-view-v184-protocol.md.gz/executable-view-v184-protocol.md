# W184: cross-attention to OWNED EXECUTABLE source, not extra syntax prose

Registered before capture. Motivation: caller/docstring vs actual helper
confusion. P162 syntax view was role+documentation+selectedsyntaxfacts+rawcard;
L158 queryfree document-prior subtraction rejected. This is different: one
query-independent code-only projection of the same owner regions, using existing
OwnerDescription. Keep path, qualname, signature, first64nonblank executable
lines, up12000characters (whole lines). No documentation/comments, generated
facts, translated code, query-conditioned selection or new source encoder.
The existing lexical executable split is NOT a compiler or nested-call analysis;
record exact projection bytes and source provenance, do not claim it proves behavior.

Capture existing68M scores against all250current symbol10pools. Scores for
original cards already closed158used as baseline, all2500input hashes checked
against rebuild before W capture. ALLobservations before exposedGold.
Fixed W1 code-only logits; W2 equal mean W1+original logits. No fitting/sweeps,
no opportunistic composition with other controls; exact locators/non-symbol150
preserve actual172. All400strict outcomes, old>=180/197,new>=180/195, no pool loss.
Observer CPU/RAM recorded, not final search latency. No reserve or release.
