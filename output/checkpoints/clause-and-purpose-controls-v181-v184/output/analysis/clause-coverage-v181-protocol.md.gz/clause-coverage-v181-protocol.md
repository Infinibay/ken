# T181: conjunctive retrieval coverage (EXPOSED development only)

Registered before capture or fitting. Motivation: raw reranker169/195 new vs
public159/195;31 raw misses include26present. Whole-query vectors may hide one
missing operational condition. Reuse existing CodeRank CLS vectors, not token
MaxSim (Q164 rejected). No new model, encoder weights, candidate pool or source view.

Two fixed controls, no hyperparameter search:
T1 rank current symbol10pool by minimum clause cosine to implementation view.
T2 standardized12feature additive linear residual to existing neural logits:
per full/contract/implementation view, whole-query cosine + clause mean/min/max.
Pairwise logistic, fixed L2=1/effective training queries, leave-one-repository-out.
Training normalization from training rows only; no held repo labels for fitting.
Other150non-symbol queries preserve actual publicv172order. Exact qualified
locators preserve publicv172 bypass. No role oracle, hand-labelled features,
query IDs/repository names/paths as learned features or further weight sweeps.

Query decomposition: split commas/semicolon and standalone and/but/while/whereas
outside quotes/backticks/brackets; preserve negative words and every text token.
Up to4contiguous balanced clause groups, no text deletion. Whole query separate.
For Spanish use already public-expandedEnglish query (same as existing neural).
Nondecomposable query uses itself. Uniform clause weight, minimum no probability.

Capture250symbol queries from currentP162b10pools; source hash and imported file
origins recorded; prepare existing vectors only (source encoding prohibited).
Close all observations before opening exposed gold pins from147manifest.
Grade all400unchanged IDs: old200 and new200 separately, strict canonical identity.
Target old>=180/197 and new>=180/195; preserve current197/195Recall10. No promotion
without actual full defaultMCP replay with CPU/RAM. No private reserve access.
Observer time reports query encoding + matrix scoring, not end-to-end search.
Negative results preserved. This is repeated exposed development, not acceptance.
