"""All200 public-v172 errors; already exposed references only, no scoring change."""
from pathlib import Path
import json,hashlib,sys
from collections import Counter
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
w=Path.cwd();rows=lambda p:list(map(json.loads,Path(p).read_text().splitlines()));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=w/'output/development/public-qualified-locator-v172-symbols';lock=json.loads((root/'lock.json').read_text());cases={c['id']:c for c in rows(lock['public_cases'])};answers={o['id']:o for p in (root/'capture').glob('*/answers.jsonl') for o in rows(p)};raw={o['id']:o for o in rows(w/'output/development/locator-composition-v173/S1_raw_current-orders.jsonl')};cues={o['id']:o for p in (w/'output/development/operational-evidence-v160').glob('*/observations.jsonl') for o in rows(p)};m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
 for p,d in c['exposed_gold_pins'].items():
  assert sha(p)==d;gold.update({o['id']:o for o in rows(p)})
assert len(cases)==len(answers)==200 and cases.keys()<=raw.keys()
records=[];totals=Counter();categories=Counter()
for q,c in cases.items():
 hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));units=answers[q]['units'];rawunits=raw[q]['units'];final=hit(units[0]);neural=hit(rawunits[0]);recall=any(map(hit,units));totals.update({'queries':1,'public_top1':final,'raw_top1':neural,'recall10':recall,'fusion_loss':neural and not final,'fusion_gain':final and not neural})
 if final:continue
 good=next((u for u in units if hit(u)),None);winner=units[0];r='missing' if good is None else 'different_file'
 lookup={json.dumps(u,sort_keys=True):cue for u,cue in zip(cues[q]['units'],cues[q]['source_cues'])} if q in cues else {};wc=lookup.get(json.dumps(winner,sort_keys=True));gc=lookup.get(json.dumps(good,sort_keys=True)) if good else None
 if good:
  a=winner['entity']['qualname'];b=good['entity']['qualname']
  if winner['path']==good['path']:r='lexical_parent_child' if a.startswith(b+'.') or b.startswith(a+'.') else 'same_file_other_operation'
  if wc and gc and wc['test_entry']!=gc['test_entry']:r='test_entry_vs_other'
 categories.update([r]);records.append({'id':q,'repo_id':c['repo_id'],'query':c['query'],'category':r,'correct_public_rank':next((i+1 for i,u in enumerate(units) if hit(u)),None),'correct_raw_rank':next((i+1 for i,u in enumerate(rawunits) if hit(u)),None),'fusion_lost_raw_hit':neural,'winner':winner,'raw_winner':rawunits[0],'acceptable_present':good,'expected':gold[q]['acceptable_units'],'winner_cues':wc,'correct_cues':gc})
result={'scope':'Exposed development, descriptive grouping, not causal or independent validation','source_captures':[str(root)],'totals':dict(totals),'public_miss_categories':dict(categories),'misses':records};out=w/'output/analysis/new200-errors-v181.json';out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='misses'},indent=2))
for r in records:print(r['id'],r['category'],'public',r['correct_public_rank'],'raw',r['correct_raw_rank'],r['winner']['entity']['qualname'],'->',r['acceptable_present']['entity']['qualname'] if r['acceptable_present'] else 'ABSENT')
