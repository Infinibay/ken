"""Two fixed T181 controls; all400exposed, leave-repository-out, no reserve."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,'experiments/search-engine')
from query_clause_coverage import FEATURES
from linear_decision_training import pairwise_examples,fit_head
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
w=Path.cwd();cap=w/'output/development/clause-coverage-v181';p=cap/'registration.json';reg=json.loads(p.read_text());assert reg['status']=='ALL250clause coverage observations closed without labels';out=w/'output/development/clause-coverage-fit-v181';out.mkdir(exist_ok=False)
registration={'scope':'EXPOSED400only T1minimum implementation cosine, T2twelvefeature standardized residual, fixedL2=1/effective trainingqueries, LORO, no HPO','capture_registration_sha256':sha(p),'protocol_sha256':sha('output/analysis/clause-coverage-v181-protocol.md'),'producer_sha256':sha(__file__),'training_sha256':sha('experiments/search-engine/linear_decision_training.py'),'status':'registered before exposed labels','folds':[]};(out/'registration.json').write_text(json.dumps(registration,indent=2));obs={};x=[];qids=[];repos=[];groups={};start=0;logits=[]
for repo,pins in reg['closed'].items():
    for f,d in pins.items():assert sha(cap/repo/f)==d
    data=np.load(cap/repo/'features.npz',allow_pickle=False);assert data['features'].tolist()==list(FEATURES)
    for o in rows(cap/repo/'observations.jsonl'):
        q=o['id'];assert q not in obs;obs[q]=o;n=len(o['units']);x.append(data['x'][data['qid']==q]);qids.extend([q]*n);repos.extend([repo]*n);logits.extend(o['raw_scores']);groups[q]=np.arange(start,start+n);start+=n
assert len(obs)==250;x=np.concatenate(x);assert x.shape==(start,12) and np.isfinite(x).all();qids,repos,logits=map(np.asarray,(qids,repos,logits));cases={};baseline={}
for name in ['original','symbols']:
    root=w/'output/development'/('public-qualified-locator-v172-'+name);lock=json.loads((root/'lock.json').read_text())
    for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if name=='original' else 'new_symbol200','query_kind':c.get('query_style',c.get('query_kind','unspecified'))}
    for f in (root/'capture').glob('*/answers.jsonl'):
        for o in rows(f):baseline[o['id']]=o
exact={o['id']:o for o in rows(w/'output/development/qualified-exact-diagnostic-v172/observations.jsonl')}
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
    for path,d in c['exposed_gold_pins'].items():
        assert sha(path)==d
        for g in rows(path):gold[g['id']]=g
assert set(cases)==set(baseline)==set(gold)==set(exact) and len(cases)==400
y=np.array([int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for q,o in obs.items() for u in o['units']]);scores=np.empty(len(x))
for held in sorted(set(repos)):
    train=repos!=held;test=~train;mean=x[train].mean(axis=0);scale=x[train].std(axis=0);scale=np.where(scale>1e-9,scale,1.);z=(x-mean)/scale;batch=pairwise_examples(z,y,qids,repos,logits,held_out=held);theta,receipt=fit_head(batch,residual=True,regularization=1./len(batch['queries']));assert not set(batch['queries'])&set(qids[test]);scores[test]=z[test]@theta+logits[test];receipt.update(held_out=held,training_repos=sorted(set(repos[train])));registration['folds'].append(receipt);(out/(held+'.json')).write_text(json.dumps({'features':FEATURES,'mean':mean.tolist(),'scale':scale.tolist(),'weights':theta.tolist()},separators=(',',':')))
results={}
for name,values in [('T0_public_v172',None),('T1_minimum_implementation',x[:,10]),('T2_residual',scores)]:
    outcomes=[];orders=[]
    for q,c in cases.items():
        units=baseline[q]['units']
        if values is not None and q in obs and exact[q]['units'] is None:
            assert obs[q]['units']==units;ix=groups[q];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(units)),key=lambda i:(-int(named is not None and units[i]['path']==named),-values[ix[i]],i));units=[units[i] for i in order]
        hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
    result=summarize(outcomes);results[name]=result;(out/(name+'-outcomes.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(out/(name+'-orders.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'variant':name,'total':result['total'],'cohort':result['cohort']}),flush=True)
registration['status']='ALL400clause coverage controls closed; no reserve';(out/'registration.json').write_text(json.dumps(registration,indent=2));(out/'summary.json').write_text(json.dumps(results,indent=2))
