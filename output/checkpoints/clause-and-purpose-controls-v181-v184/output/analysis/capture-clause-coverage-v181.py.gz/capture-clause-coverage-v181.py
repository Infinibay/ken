"""T181: source vectors already prepared, query-only extra encodes, no labels."""
import sys,json,hashlib,os,subprocess,time,resource
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from query_clause_coverage import FEATURES,query_clauses,coverage_features
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.context_preparation import prepare_context
from ken.retrieval.storage import generation
from ken.retrieval.model import EntityKey
from ken.embedder.contextual_onnx import ContextEncoder


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def origins():
    source=Path(os.environ['PYTHONPATH']).resolve()
    result={}
    for name,m in tuple(sys.modules.items()):
        if (name=='ken' or name.startswith('ken.')) and getattr(m,'__file__',None):
            p=Path(m.__file__).resolve();assert p.is_relative_to(source),(name,p,source)
            result[name]={'path':str(p),'sha256':sha(p)}
    return result

w=Path.cwd();previous=w/'output/development/source-syntax-evidence-v162b';p=previous/'registration.json';reg=json.loads(p.read_text());assert reg['status']=='ALL250source syntax public observations closed without Gold'
out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
    rec={'scope':'T181 EXPOSED250symbol current10pool observer only, no labels/private inputs','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/query_clause_coverage.py'),'protocol_sha256':sha('output/analysis/clause-coverage-v181-protocol.md'),'source_registration_sha256':sha(p),'features':FEATURES,'origins_at_registration':origins(),'closed':{}}
    (out/'registration.json').write_text(json.dumps(rec,indent=2))
    for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
        with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
        rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']}
        (out/'registration.json').write_text(json.dumps(rec,indent=2));print(json.dumps({'closed':repo}),flush=True)
    rec['status']='ALL250clause coverage observations closed without labels';rec['origins_at_close']=origins();(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
assert sha(previous/repo/'observations.jsonl')==reg['closed'][repo]['observations.jsonl']
registered_origins=origins();r=default_resources();encoder=r.context
# No new source projection or source inference is permitted in this experiment.
def forbidden(*args,**kwargs):raise RuntimeError('T181 may not encode source passages')
ContextEncoder.embed_passages=forbidden
root=Path('/private/tmp/ken-public-default-v143/repos')/repo;observations=[];matrix=[];qids=[];prep=time.perf_counter()
with project_connection(root) as conn:
    catalog=SourceCatalog(root,owner_passages(conn));context=prepare_context(catalog,generation(conn),encoder,root/'.ken/search-context');prep=(time.perf_counter()-prep)*1000
    lookup={key:i for i,key in enumerate(context.vectors.owners)};views=context.source_views;assert views is not None
    for old in rows(previous/repo/'observations.jsonl'):
        query=old['expanded_query'];clauses=query_clauses(query);start=time.perf_counter();encoded=[];memo={}
        for text in (query,*clauses):
            if text not in memo:
                v=np.asarray(encoder.embed_query(text),dtype=np.float32);memo[text]=v/np.linalg.norm(v)
            encoded.append(memo[text])
        indexes=np.array([lookup[EntityKey(path=u['path'],**u['entity'])] for u in old['units']],dtype=np.int64)
        docs=[context.vectors.matrix[indexes]]+[views.matrix[views.rows[name][indexes]] for name in ['contract','implementation']]
        x=coverage_features(np.array(encoded),docs);assert np.isfinite(x).all();elapsed=(time.perf_counter()-start)*1000
        source_hashes=[]
        for i,u in zip(indexes,old['units']):
            digest=sha(root/u['path']);assert digest==context.vectors.source_hashes[i];source_hashes.append(digest)
        matrix.append(x);qids.extend([old['id']]*len(x));observations.append({'id':old['id'],'repo_id':repo,'query':old['query'],'expanded_query':query,'clauses':clauses,'units':old['units'],'raw_scores':old['raw_scores'],'source_hashes':source_hashes,'observer_ms':elapsed});print(json.dumps({'id':old['id'],'ms':elapsed}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(matrix),qid=np.array(qids),features=np.array(FEATURES));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'queries':len(observations),'source_prepare_ms':prep,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'observer_p50_ms':float(np.median([o['observer_ms'] for o in observations])),'observer_p95_ms':float(np.percentile([o['observer_ms'] for o in observations],95)),'scope':'query encode and 10source dot products, not full search','source_encodes':0,'origins_at_registration':registered_origins,'origins_at_close':origins()},indent=2))
