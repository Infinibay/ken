"""Later controlled regrading/pool verification; not original import attestation."""
from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
w=Path.cwd();rows=lambda p:list(map(json.loads,Path(p).read_text().splitlines()));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();cases={};baseline={}
for name in ['original','symbols']:
 root=w/'output/development'/('public-qualified-locator-v172-'+name);lock=json.loads((root/'lock.json').read_text())
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':name}
 for p in (root/'capture').glob('*/answers.jsonl'):
  for o in rows(p):baseline[o['id']]=o['units']
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
 for p,d in c['exposed_gold_pins'].items():assert sha(p)==d;gold.update({o['id']:o for o in rows(p)})
assert set(cases)==set(baseline)==set(gold) and len(cases)==400
variants={'T0':('clause-coverage-fit-v181/T0_public_v172',191,159),'T1':('clause-coverage-fit-v181/T1_minimum_implementation',165,90),'T2':('clause-coverage-fit-v181/T2_residual',189,161),'U1':('clause-crossencoder-fit-v182/U1_mean_clause',186,156),'U2':('clause-crossencoder-fit-v182/U2_residual',190,166),'V1':('source-purpose-v183/',190,164),'W1':('executable-view-fit-v184/W1_executable',188,164),'W2':('executable-view-fit-v184/W2_equalmean',190,170)};report={'scope':'Later controlled verification of EXPOSED400orders, strict identities, cohort sums and invariant pools; not independent acceptance or original runtime import receipt','producer_sha256':sha(__file__),'scorer_sha256':sha('experiments/search-engine/verifiable_grading.py'),'variants':{}}
canon=lambda units:sorted(json.dumps(u,sort_keys=True) for u in units)
for name,(prefix,old,new) in variants.items():
 root=w/'output/development'/prefix;orderfile=Path(str(root)+'-orders.jsonl') if name!='V1' else root/'orders.jsonl';outcomefile=Path(str(root)+'-outcomes.jsonl') if name!='V1' else root/'outcomes.jsonl';orders=rows(orderfile);outcomes={o['id']:o for o in rows(outcomefile)};assert len(orders)==len(outcomes)==400 and set(outcomes)==set(cases);totals={'original':[0,0],'symbols':[0,0]}
 for o in orders:
  q=o['id'];units=o['units'];assert canon(units)==canon(baseline[q]);hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));top1=bool(units and hit(units[0]));recall=any(map(hit,units));assert outcomes[q]['top1']==top1 and outcomes[q]['recall10']==recall;cohort=cases[q]['cohort'];totals[cohort][0]+=top1;totals[cohort][1]+=recall
 assert totals=={'original':[old,197],'symbols':[new,195]},totals;report['variants'][name]={'counts':totals,'orders_sha256':sha(orderfile),'outcomes_sha256':sha(outcomefile)}
for name in ['clause-coverage-fit-v181','clause-crossencoder-fit-v182']:
 reg=json.loads((w/'output/development'/name/'registration.json').read_text());assert len(reg['folds'])==8
 for f in reg['folds']:assert f['held_out'] not in f['training_repos']
source=Path('output/frozen/public-qualified-locator-v172/src').resolve();report['late_verification_origins']={}
for n,mod in tuple(sys.modules.items()):
 if (n=='ken' or n.startswith('ken.')) and getattr(mod,'__file__',None):
  p=Path(mod.__file__).resolve();assert p.is_relative_to(source);report['late_verification_origins'][n]={'path':str(p),'sha256':sha(p)}
report['status']='ALL3200outcomes and3200candidate sets verified;16fold exclusions checked';(w/'output/analysis/controls-verification-v181-v184.json').write_text(json.dumps(report,indent=2));print(report['status'])
