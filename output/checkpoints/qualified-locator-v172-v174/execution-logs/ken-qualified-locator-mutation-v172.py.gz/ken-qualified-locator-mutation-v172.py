from pathlib import Path
import hashlib
import os
import subprocess

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
p = c / 'src/ken/retrieval/source_locator.py'
original = p.read_bytes()
needle = 'if key.path == self.namespace or module_name(key.path) == self.namespace:'
assert original.decode().count(needle) == 1
try:
    p.write_text(original.decode().replace(needle, 'if True:'))
    with Path('/private/tmp/ken-qualified-locator-v172-mutation.log').open('w') as log:
        r = subprocess.run(['/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace/.venv/bin/python',
            '-m', 'pytest', '-o', 'addopts=', '-q', '-p', 'no:cacheprovider', 'tests/retrieval/test_qualified_locator.py'],
            cwd=c, env=os.environ | {'PYTHONPATH': str(c / 'src'), 'PYTHONDONTWRITEBYTECODE': '1'},
            stdout=log, stderr=subprocess.STDOUT)
    assert r.returncode == 1
finally:
    p.write_bytes(original)
assert p.read_bytes() == original
print('Namespace-bypass mutation rejected; source restored SHA256=' + hashlib.sha256(original).hexdigest())
