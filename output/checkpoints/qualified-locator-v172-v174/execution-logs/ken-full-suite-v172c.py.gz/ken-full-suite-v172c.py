from pathlib import Path
import os
import subprocess

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
w = Path('/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace')
log_path = Path('/private/tmp/ken-qualified-locator-v172c-full-suite.log')
with log_path.open('w') as log:
    result = subprocess.run([str(w / '.venv/bin/python'), '-m', 'pytest', '-p', 'no:cacheprovider'],
        cwd=c, env=os.environ | {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(c / 'src') + ':' + str(w / '.venv-model-runtime/lib/python3.12/site-packages')},
        stdout=log, stderr=subprocess.STDOUT)
Path('/private/tmp/ken-qualified-locator-v172c-suite-exit').write_text(str(result.returncode) + '\n')
print('Complete suite exit:', result.returncode)
raise SystemExit(result.returncode)
