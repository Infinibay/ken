"""Preserve closed development measurements; never collect reference payloads."""
from pathlib import Path
import gzip
import hashlib
import json

w = Path('/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace')
out = w / 'output/checkpoints/qualified-locator-v172-v174'
assert not out.exists()
roots = [w / ('output/development/' + name) for name in [
    'public-qualified-locator-v172-original', 'public-qualified-locator-v172-symbols',
    'qualified-exact-diagnostic-v172', 'qualified-exact-diagnostic-v172b',
    'locator-composition-v173']]
for root in roots[:2]:
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    assert reg['lock_sha256'] == hashlib.sha256((root / 'lock.json').read_bytes()).hexdigest()
summary = json.loads((w / 'output/analysis/public-qualified-locator-v172-summary.json').read_text())
assert [(summary[k]['quality']['top1']['count'], summary[k]['quality']['recall10']['count'])
        for k in ['original200', 'new_symbol200']] == [(191, 197), (159, 195)]
assert summary['original200']['orders_identical_to_public145'] == 200
assert roots[2].joinpath('observations.jsonl').read_bytes() == roots[3].joinpath('observations.jsonl').read_bytes()
assert Path('/private/tmp/ken-qualified-locator-v172c-suite-exit').read_text().strip() == '0'
files = [p for root in roots for p in root.rglob('*') if p.is_file()
         and p.suffix in {'.json', '.jsonl', '.txt', '.log', '.patch', '.py'}]
files.append(w / 'output/frozen/public-qualified-locator-v172/SOURCE-MANIFEST.json')
for name in [
    'public-qualified-locator-v172-summary.json', 'queue-qualified-locator-v172.py',
    'freeze-qualified-locator-v172.py', 'prepare-qualified-public-grader-v172.py',
    'grade-qualified-public-v172.py', 'capture-qualified-exact-v172.py',
    'grade-qualified-exact-v172.py', 'prepare-exact-import-replay-v172b.py',
    'replay-qualified-exact-v172b.py', 'locator-composition-v173-protocol.md',
    'evaluate-locator-composition-v173.py', 'inspect-semantic-misses-v174.py',
    'semantic-misses-v174.json', 'public-measurement-review-v172-v173.json',
    'public-measurement-review-v172-v173.md',
    'public-measurement-review-v172-supplement.json',
    'public-measurement-review-v172-supplement.md']:
    files.append(w / 'output/analysis' / name)
for name in [
    'ken-qualified-locator-v170-red.log', 'ken-qualified-locator-v172-mutation.log',
    'ken-qualified-locator-v172-restored-green.log', 'ken-qualified-locator-v172-targeted.log',
    'ken-qualified-locator-v172-full-suite.log', 'ken-qualified-locator-v172b-full-suite.log',
    'ken-qualified-locator-v172b-suite-exit', 'ken-qualified-locator-v172b-mypy.log',
    'ken-qualified-locator-v172c-full-suite.log', 'ken-qualified-locator-v172c-suite-exit',
    'ken-qualified-locator-v172c-mypy.log', 'ken-qualified-locator-v172c-targeted.log',
    'ken-qualified-locator-mutation-v172.py', 'ken-full-suite-v172b.py',
    'ken-full-suite-v172c.py', 'ken-public-qualified-locator-v172-queue.log',
    'ken-grade-qualified-public-v172.log', 'ken-qualified-exact-v172b.log',
    'ken-semantic-misses-v174.log', 'ken-close-locator-v172.py']:
    files.append(Path('/private/tmp') / name)
assert all(p.is_file() for p in files), [str(p) for p in files if not p.is_file()]
assert len(files) == len(set(files))
out.mkdir()
manifest = {'scope': 'Closed actual public MCP400 and qualified identity correction; exposed development only. No private reference payloads.',
    'limits': ['Original exact-only172diagnostic lacked contemporaneous imported module origin observations. Controlled later172b replay verifies73ken modules and byte-identical400observations; it does not retroactively repair original provenance.',
        'S173 compositions are readouts of existing measurements, not API captures or independent acceptance.',
        'S2 uses legacy193Recall10 pool,32query pools differ from current195; no isolated role effect.',
        'Historical API timing comparisons are not randomized paired causal resource measurements.',
        'Java locator matches physical package directory, not indexed source package declaration.',
        'New stress200is symbol-only development; independent balanced177/198stillfails90; fresh reserve untouched.',
        'First full-suite invocation was interrupted after detecting zsh readonly status variable; second interrupted before source freeze to add empty-match fast path. Only finalc completed current source14944passed10xfail.'],
    'files': {}}
for p in sorted(files):
    key = p.relative_to(w).as_posix() if p.is_relative_to(w) else 'execution-logs/' + p.name
    data = p.read_bytes()
    target = out / (key + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    manifest['files'][key] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'gzip_bytes': target.stat().st_size}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(files), 'gzip_bytes': sum(f['gzip_bytes'] for f in manifest['files'].values()),
    'manifest_sha256': hashlib.sha256((out / 'manifest.json').read_bytes()).hexdigest()}))
