Revisión independiente: medición conforme; sin errores que expliquen los resultados negativos. Se reconstruyeron los 1.200 resultados por consulta y las 800 órdenes de composición exactamente, con 400 IDs únicos, sin exclusiones ni faltantes. Sólo se abrieron las referencias EXPOSED fijadas por fit-manifest 147; las reservas permanecieron cerradas.

| Control cerrado | Original: top1 / Recall10 (n=200) | Símbolos nuevos: top1 / Recall10 (n=200) |
|---|---:|---:|
| v172, proyección exact-only |191 /197 |159 /195 |
| v173, S1 raw actual |189 /197 |169 /195 |
| v173, S2 K LEGACY193 |190 /197 |172 /193 |

Las 40 consultas con locator dan40 identidades exactas canónicas. Antes de reemplazar respuestas, el raw actual ya acertaba 40/40, el K legado 39/40 y el baseline 31/40. Por tanto, S1 no gana consultas y S2 gana una. Los tres conteos nuevos permanecen por debajo del gate 180/200.

Se verificaron los 422 archivos del freeze 3f56b584…; los 4.755 archivos físicos indexados mediante SHA256 y el BLAKE2b32 de ci_files; las ocho generaciones; las 404 unidades aceptables y sus 196 archivos de referencia. Las identidades de resultados corresponden al catálogo canónico source-only de 39.810 owners. Estos controles no modifican referencias ni requieren todas las anclas o suficiencia como gate.

Los alcances se deben conservar: 172 es una proyección sobre 155/157, no una medición ALL400 de la API actual. Cada composición copia 360 órdenes y reemplaza 40 respuestas por singleton; las 40 unidades ya estaban dentro de ambos pools. S1 conserva cobertura 195 y S2 cobertura 193;32 consultas tienen pools diferentes. No se puede atribuir su contraste únicamente al router K. Son composiciones post-hoc de desarrollo expuesto, sin validación independiente, presupuestos de evidencia ni certificación de latencia/RAM. Las respuestas MCP 172 no fueron abiertas ni puntuadas.

Hay un límite de procedencia de ejecución: el controlador 172 verifica los bytes congelados, pero no guarda __file__/SHA de los módulos ken realmente importados. Parent informó posteriormente la invocación registrada con PYTHONPATH explícito al freeze172; esa atestación se conserva como posterior, no como recibo contemporáneo. Esto no altera la reconstrucción de resultados guardados; limita certificar el origen de imports de la ejecución original y se hereda en 173. Un replay posterior debe quedar separado.

Recibo detallado: [public-measurement-review-v172-v173.json](/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace/output/analysis/public-measurement-review-v172-v173.json). Auditoría aritmética independiente sin motor, encoder, fitting, controlador ni cambios a artefactos existentes.
