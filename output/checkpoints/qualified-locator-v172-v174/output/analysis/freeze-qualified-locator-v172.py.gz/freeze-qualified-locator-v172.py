from pathlib import Path
import hashlib
import json
import shutil
import subprocess

w = Path.cwd()
c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
frozen = w / 'output/frozen/public-qualified-locator-v172'
frozen.mkdir(exist_ok=False)
assert hashlib.sha256((c / 'src/ken/embedder/model2vec_backend.py').read_bytes()).hexdigest() == 'df930906f6d381dd634b57c99c1a3c8043d7a687d686b6d4252abab981284b79'
assert hashlib.sha256((c / 'src/ken/retrieval/source_locator.py').read_bytes()).hexdigest() == '9f8d19888af89eb9d58cd619bff426893796b53dfdd69d691f62c4d4b7478ba4'
shutil.copytree(c / 'src', frozen / 'src', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
shutil.copyfile(c / 'pyproject.toml', frozen / 'pyproject.toml')
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=c, text=True).strip()
assert base == 'ef211af5874f9056dec7afc575de9faebb47f93e'
patch = subprocess.check_output(['git', 'diff', '--', 'src/ken/retrieval/candidates.py'], cwd=c)
new_name = 'src/ken/retrieval/source_locator.py'
new = (c / new_name).read_text().splitlines()
patch += ('diff --git a/' + new_name + ' b/' + new_name + '\nnew file mode 100644\n--- /dev/null\n+++ b/' + new_name + '\n@@ -0,0 +1,' + str(len(new)) + ' @@\n' + ''.join('+' + line + '\n' for line in new)).encode()
files = {p.relative_to(frozen).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(frozen.rglob('*')) if p.is_file()}
receipt = {'origin_commit': base, 'source_state': 'uncommitted isolated source-locator correction on cache commit, frozen before public capture',
    'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'files': files,
    'tree_sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()}
(frozen / 'SOURCE-MANIFEST.json').write_text(json.dumps(receipt, indent=2) + '\n')
digest = hashlib.sha256((frozen / 'SOURCE-MANIFEST.json').read_bytes()).hexdigest()
for cohort, previous in [('original', 'public-static-cache-v169-original'), ('symbols', 'public-default-v157-symbols')]:
    lock = json.loads((w / 'output/development' / previous / 'lock.json').read_text())
    lock.update(scope='Complete actual public MCP200 with isolated namespace::qualified-symbol correction; no learned-score changes/private inputs', engine_root=str(frozen), source_receipt=digest)
    lock['variant_policy'].update(engine_root=str(frozen), source_receipt=digest, source_commit=base,
        source_state=receipt['source_state'], static_cache='bounded lossless8MiB cache fromef211af',
        qualified_locator='explicit complete module/path::qualname matched before ordinary named lookup; no prose-reference authority')
    out = w / ('output/development/public-qualified-locator-v172-' + cohort)
    out.mkdir(exist_ok=False)
    (out / 'lock.json').write_text(json.dumps(lock, indent=2) + '\n')
    (out / 'SOURCE-WORKTREE.patch').write_bytes(patch)
    print(json.dumps({'cohort': cohort, 'lock_sha256': hashlib.sha256((out / 'lock.json').read_bytes()).hexdigest()}))
print(json.dumps({'source_receipt': digest, 'source_files': len(files), 'source_base': base}))
