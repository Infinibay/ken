"""Grade closed exact-only observations using pinned EXPOSED references only."""
from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0, 'experiments/search-engine')
from verifiable_grading import identity_hit

w = Path.cwd()
root = w / 'output/development/qualified-exact-diagnostic-v172'
reg = json.loads((root / 'registration.json').read_text())
assert reg['status'] == 'ALL400exact-only diagnostics closed without labels'
assert hashlib.sha256((root / 'observations.jsonl').read_bytes()).hexdigest() == reg['observations_sha256']
rows = lambda p: [json.loads(l) for l in Path(p).read_text().splitlines()]
observations = rows(root / 'observations.jsonl')
assert len(observations) == 400
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        path = Path(name)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        for g in rows(path):
            gold[g['id']] = g
assert len(gold) == 400
baseline = {a['id']: a for cohort in ['public-default-v155-original', 'public-default-v157-symbols'] for f in (w / 'output/development' / cohort / 'capture').glob('*/answers.jsonl') for a in rows(f)}
summary = {}
for cohort in ['original', 'symbols']:
    current = [r for r in observations if r['cohort'] == cohort]
    outcomes = []
    for r in current:
        hit = lambda u: bool(identity_hit({'unit': u}, gold[r['id']]['acceptable_units']))
        original = baseline[r['id']]['units']
        projected = r['units'] if r['units'] is not None else original
        outcomes.append({'id': r['id'], 'projected_top1': bool(projected and hit(projected[0])), 'projected_recall10': any(map(hit, projected)),
            'baseline_top1': bool(original and hit(original[0])), 'locator': r['locator'] is not None, 'exact_count': r['exact_count']})
    summary[cohort] = {'queries': len(current), 'locators': sum(o['locator'] for o in outcomes),
        'locator_hits': sum(o['locator'] and o['projected_top1'] for o in outcomes),
        'projected_top1': sum(o['projected_top1'] for o in outcomes), 'projected_recall10': sum(o['projected_recall10'] for o in outcomes),
        'gains': [o['id'] for o in outcomes if o['projected_top1'] and not o['baseline_top1']],
        'losses': [o['id'] for o in outcomes if not o['projected_top1'] and o['baseline_top1']]}
    (root / (cohort + '-outcomes.jsonl')).write_text(''.join(json.dumps(o) + '\n' for o in outcomes))
result = {'scope': 'Exact-only public source results for40locators; other360orders copied from frozen baselines. PROJECTION, not complete current API validation or latency benchmark.',
    'grader_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'registration_sha256': hashlib.sha256((root / 'registration.json').read_bytes()).hexdigest(), 'summary': summary,
    'private_acceptance': 'Fresh independent reserve unopened; previous independent177/198 unchanged.'}
(root / 'projection-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
