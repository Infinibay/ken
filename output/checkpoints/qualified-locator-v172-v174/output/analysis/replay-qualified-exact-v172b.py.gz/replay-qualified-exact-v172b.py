"""All400 public queries, exact-only model-free diagnostic; not full API benchmark."""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import sqlite3
import sys

from ken.bench.source_receipts import verify_frozen_source
import ken.retrieval.best_search as best
from ken.retrieval.candidates import exact_candidates
from ken.retrieval.model import SearchRequest
from ken.retrieval.source_locator import symbol_locator

w = Path.cwd()
frozen_root = w / 'output/frozen/public-qualified-locator-v172'
manifest = json.loads((frozen_root / 'SOURCE-MANIFEST.json').read_text())
assert verify_frozen_source(frozen_root) == '3f56b5848be8fcb44ce6006b754a6cbfb6d609c872521437be5ceeefd6b36197'
def module_origins():
    result = {}
    for name, module in list(sys.modules.items()):
        if name != 'ken' and not name.startswith('ken.'):
            continue
        path = getattr(module, '__file__', None)
        assert path is not None, name
        path = Path(path).resolve()
        assert path.is_relative_to(frozen_root / 'src'), (name, str(path))
        relative = path.relative_to(frozen_root).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert manifest['files'][relative] == digest
        result[name] = {'path': relative, 'sha256': digest}
    return result
initial_imports = module_origins()
out = w / 'output/development/qualified-exact-diagnostic-v172b'
out.mkdir(exist_ok=False)
registration = {'scope': 'Exact-only400 public-query diagnostic; other queries NOT searched, no API latency/RAM claim, no labels/private inputs.',
    'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'locks': {}, 'status': 'registered before diagnostic'}
registration['module_origins'] = {'at_registration': initial_imports, 'current': module_origins()}
registration['provenance'] = 'NEW controlled later replay, not retroactive proof of original172import paths'
(out / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
def no_models():
    raise AssertionError('Unique qualified lookup unexpectedly tried to load models')
best.default_resources = no_models
records = []
for cohort in ['original', 'symbols']:
    lock_path = w / ('output/development/public-qualified-locator-v172-' + cohort + '/lock.json')
    registration['locks'][cohort] = hashlib.sha256(lock_path.read_bytes()).hexdigest()
    lock = json.loads(lock_path.read_text())
    assert verify_frozen_source(Path(lock['engine_root'])) == lock['source_receipt']
    assert hashlib.sha256(Path(lock['public_cases']).read_bytes()).hexdigest() == lock['input_pins'][lock['public_cases']]
    cases = [json.loads(line) for line in Path(lock['public_cases']).read_text().splitlines()]
    assert len(cases) == 200 and not any('acceptable_units' in c for c in cases)
    for repo in sorted(lock['roots']):
        root = Path(lock['roots'][repo])
        db = root / '.ken/ken.db'
        assert db.is_file()
        with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as conn:
            conn.row_factory = sqlite3.Row
            for case in [c for c in cases if c['repo_id'] == repo]:
                locator = symbol_locator(case['query'])
                request = SearchRequest(case['query'], target='file' if case['target_kind'] in {'file', 'module'} else 'symbol', piece_kind=case['target_kind'])
                exact = exact_candidates(conn, request)
                record = {'id': case['id'], 'cohort': cohort, 'locator': asdict(locator) if locator else None, 'exact_count': len(exact), 'units': None}
                if len(exact) == 1:
                    response = best.search_best(conn, root, request)
                    assert response.profile_version == 'best-exact-source-v1'
                    record['units'] = [{'target_kind': r['piece_kind'], 'path': r['path'], 'entity': r['entity'] if r['piece_kind'] in {'symbol', 'class'} else None,
                        'module_name': r.get('module_name') if r['piece_kind'] == 'module' else None} for r in response.results]
                    assert record['units']
                records.append(record)
    assert verify_frozen_source(Path(lock['engine_root'])) == lock['source_receipt']
assert len(records) == 400 and len({r['id'] for r in records}) == 400
assert not set(sys.modules).intersection({'torch', 'transformers', 'onnxruntime', 'sentence_transformers'})
(out / 'observations.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))
registration.update(status='ALL400exact-only diagnostics closed without labels', observations_sha256=hashlib.sha256((out / 'observations.jsonl').read_bytes()).hexdigest())
registration['module_origins'] = {'at_registration': initial_imports, 'current': module_origins()}
registration['provenance'] = 'NEW controlled later replay, not retroactive proof of original172import paths'
(out / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
print(json.dumps({c: {'queries': sum(r['cohort']==c for r in records), 'locators': sum(r['cohort']==c and r['locator'] is not None for r in records), 'unique_exact': sum(r['cohort']==c and r['exact_count']==1 for r in records)} for c in ['original', 'symbols']}))

original = w / 'output/development/qualified-exact-diagnostic-v172/observations.jsonl'
assert original.read_bytes() == (out / 'observations.jsonl').read_bytes()
print(json.dumps({'original400observations_byte_exact': True, 'verified_ken_modules': len(module_origins())}))
