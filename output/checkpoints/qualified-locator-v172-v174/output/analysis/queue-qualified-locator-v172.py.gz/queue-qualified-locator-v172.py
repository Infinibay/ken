from pathlib import Path
import json
import os
import subprocess
import time

w = Path.cwd()
status = Path('/private/tmp/ken-qualified-locator-v172c-suite-exit')
while not status.exists():
    time.sleep(15)
if status.read_text().strip() != '0':
    raise ValueError('final-byte full suite failed; public capture not started')
for cohort in ['original', 'symbols']:
    out = w / ('output/development/public-qualified-locator-v172-' + cohort)
    lock = json.loads((out / 'lock.json').read_text())
    env = os.environ | {'PYTHONPATH': str(Path(lock['engine_root']) / 'src'), 'PYTHONDONTWRITEBYTECODE': '1'}
    with (out / 'capture.log').open('w') as log:
        subprocess.run([str(w / '.venv-model-runtime/bin/python'),
            'experiments/search-engine/public_default_mcp_run.py', '--lock', str(out / 'lock.json'),
            '--output', str(out / 'capture')], cwd=w, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('Complete ' + cohort + ' public200 capture closed; no grading', flush=True)
