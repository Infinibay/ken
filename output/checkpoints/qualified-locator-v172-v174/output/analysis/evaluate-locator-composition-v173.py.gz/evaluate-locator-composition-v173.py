"""Two preregistered development compositions, no fitting/private references."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, 'experiments/search-engine')
from verifiable_grading import identity_hit

w = Path.cwd()
rows = lambda p: [json.loads(l) for l in Path(p).read_text().splitlines()]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
out = w / 'output/development/locator-composition-v173'
out.mkdir(exist_ok=False)
protocol = w / 'output/analysis/locator-composition-v173-protocol.md'
diagnostic = w / 'output/development/qualified-exact-diagnostic-v172'
reg = json.loads((diagnostic / 'registration.json').read_text())
assert reg['status'] == 'ALL400exact-only diagnostics closed without labels'
assert sha(diagnostic / 'observations.jsonl') == reg['observations_sha256']
exact = {o['id']: o for o in rows(diagnostic / 'observations.jsonl')}
paths = {'S1_raw_current': w / 'output/development/source-syntax-evidence-v162b/raw_current_nn-orders.jsonl',
    'S2_role_LEGACY193': w / 'output/development/source-role-posterior-v156b/orders.jsonl'}
registration = {'scope': 'Post-hoc EXPOSED400 development compositions, never independent validation. No fitting. S2legacy193pool differs from S1current195pool.',
    'producer_sha256': sha(__file__), 'protocol_sha256': sha(protocol),
    'exact_registration_sha256': sha(diagnostic / 'registration.json'),
    'source_order_pins': {name: sha(p) for name,p in paths.items()}, 'status': 'registered before exposed references'}
(out / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        assert sha(name) == digest
        gold.update({g['id']: g for g in rows(name)})
assert len(gold) == len(exact) == 400
results = {}
expected = {'S1_raw_current': {'original': (189,197), 'symbols': (169,195)},
    'S2_role_LEGACY193': {'original': (190,197), 'symbols': (171,193)}}
for name, path in paths.items():
    original = {o['id']: o['units'] for o in rows(path)}
    assert original.keys() == exact.keys()
    outcomes, orders = [], []
    for q, prior in original.items():
        hit = lambda u: bool(identity_hit({'unit': u}, gold[q]['acceptable_units']))
        replacement = exact[q]['units']
        current = replacement if replacement is not None else prior
        outcomes.append({'id': q, 'cohort': exact[q]['cohort'],
            'baseline_top1': bool(prior and hit(prior[0])), 'baseline_recall10': any(map(hit, prior)),
            'top1': bool(current and hit(current[0])), 'recall10': any(map(hit, current)), 'replaced': replacement is not None})
        orders.append({'id': q, 'units': current})
    result = {}
    for cohort in ['original', 'symbols']:
        selected = [o for o in outcomes if o['cohort'] == cohort]
        assert len(selected) == 200
        assert (sum(o['baseline_top1'] for o in selected), sum(o['baseline_recall10'] for o in selected)) == expected[name][cohort]
        result[cohort] = {'queries': 200, 'top1': sum(o['top1'] for o in selected), 'recall10': sum(o['recall10'] for o in selected),
            'gains': [o['id'] for o in selected if o['top1'] and not o['baseline_top1']],
            'losses': [o['id'] for o in selected if not o['top1'] and o['baseline_top1']]}
    results[name] = result
    (out / (name + '-orders.jsonl')).write_text(''.join(json.dumps(o) + '\n' for o in orders))
    (out / (name + '-outcomes.jsonl')).write_text(''.join(json.dumps(o) + '\n' for o in outcomes))
    print(json.dumps({name: result}))
registration['status'] = 'ALLtwo400compositions closed; no fitting/promotion/private inputs'
(out / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
(out / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
