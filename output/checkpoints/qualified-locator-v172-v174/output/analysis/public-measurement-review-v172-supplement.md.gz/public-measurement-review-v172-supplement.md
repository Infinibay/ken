Suplemento independiente conforme: no se detectaron errores de medición en las dos capturas MCP172 cerradas ni en el replay172b. El informe v172-v173 original permanece intacto.

| Captura MCP real | Consultas | Top1 | Recall@10 |
|---|---:|---:|---:|
| Originales |200 |191 |197 |
| Símbolos nuevos |200 |159 |195 |

Se reconstruyeron los 400 outcomes, todos los estratos, intervalos Wilson y agregados de recursos exactamente. Las 400 órdenes reales coinciden por ID con la proyección anterior; las 200 originales también coinciden con 145. No hay IDs duplicados, omisiones ni exclusiones. Las 3.628 unidades devueltas corresponden a la identidad canónica y sus 5.686 citas son literales contra 742 archivos públicos con SHA válido; ninguna está marcada stale. El máximo observado es 4 extractos y 16 líneas por resultado. La representación JSON compacta alcanza 11.998 caracteres, con cero respuestas por encima de 12.000; una serialización que añade espacios alcanza 12.399 y no representa el texto original del transporte.

El scorer espera el cierre de AMBAS capturas y verifica los hashes de sus locks antes de leer el manifiesto o las referencias expuestas; después valida cada cierre por cohorte. La auditoría independiente comprobó ambos cierres y sus 16 conjuntos de answers/performance antes de abrir únicamente los tres Gold expuestos fijados en fit-manifest 147. Los outcomes tienen mtimes posteriores a ambos registros cerrados. Son evidencia de orden compatible con el código; no constituyen un log contemporáneo de cada lectura del sistema operativo.

El replay172b registra 73 módulos ken al inicio y al final, con los mismos paths/SHA y todos bajo src del freeze172. Sus 400 observaciones son byte-idénticas al diagnóstico original, SHA f32b8ecbede033a6ae75965f69573e8fcabef1c92b6dc0d43cfc570df9d78d48. Registro del replay: ba366fb5800d2392a80fc63a26d2974e186160328d156fbfba50bb255288856b. Esta prueba es posterior y separada: no reemplaza el recibo172 ni elimina la ausencia histórica de __file__/SHA contemporáneos en aquella ejecución.

Los recursos agregados coinciden: originales p50=2.340,08ms, p95=3.646,43ms y pico RSS=2.102.460.416B; nuevos p50=1.658,37ms, p95=2.876,60ms y pico RSS=1.928.626.176B. Son observaciones del run, sin certificado causal de aceleración. El CPU total del servidor incluye setup/warmup y comprobaciones compactas; no hay CPU hijo por consulta. El nuevo top1 de 159/200 continúa debajo del gate 180/200. No se modificó criterio, motor, referencia ni resultado; no se abrió reserva ni se ejecutó modelo, controlador o fitting.

[Recibo detallado](/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace/output/analysis/public-measurement-review-v172-supplement.json) conserva bindings y límites, junto con el [informe original](/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace/output/analysis/public-measurement-review-v172-v173.json).
