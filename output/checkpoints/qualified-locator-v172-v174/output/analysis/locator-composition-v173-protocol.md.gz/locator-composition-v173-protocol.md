# S173: compose identity correction with two already closed symbol policies

Before reading new composition metrics, declare exactly two controls. No new
fitting, weights, thresholds, role features or source evidence. Keep all400
exposed-development queries. Existing native top10 remains except complete unique
explicit locators, which use their authenticated exact-only source response.

S1: raw_current_nn-orders from closedP162b (raw neural symbol ranking only;
other150 original kinds keep actual default). S2: source-role-posterior-v156b
orders, using the recorded unchanged repository-held-out K recipe. First confirm
those recorded source orders and query sets have400 cases and reproduce their
published totals before replacing any units. Do not refit or select source rows.
For each, replace a response only when closed exact-diagnostic172 has one exact
source identity; otherwise keep the recorded order. Grade all400 with pinned
exposed references; zero private reserve access. Report counts/gains/losses and
pool changes explicitly. Both controls are post-hoc development compositions,
not independent evidence that the best metric generalizes.

Rationale: the qualified-name defect occurs before scoring. A fixed exact-source
identity should precede both score policies, so evaluate whether it complements
the semantic ordering without adding expensive inference. Never tune on lookup
or failure IDs. Require original>=180/197 and new-symbol>=180 before considering
packaging any relevance policy for fresh balanced private acceptance. If both
fail, stop these compositions without more arithmetic weight sweeps or reopening
private data. Full actual public MCP cost/accuracy and independent>=180/197 are
still mandatory after any prospective promotion.

Pre-composition provenance correction: inspection of K's existing summary shows
new Recall10=193, not195. S2 is therefore a LEGACY-pool control, unlike S1's
current195pool. Preserve this distinction in every output; do not call their
difference an isolated role effect. If promising, same fixed recipe must be
recaptured on current195pool before packaging. The original recorded K counts
are190/197original and171/193new. This correction is recorded before generating
the new composition outcomes.
