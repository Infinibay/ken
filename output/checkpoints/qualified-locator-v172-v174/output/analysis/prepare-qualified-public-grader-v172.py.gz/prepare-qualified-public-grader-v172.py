from pathlib import Path

w = Path.cwd()
source = (w / 'output/analysis/grade-current-public-development-v155-v157.py').read_text()
source = source.replace("('original200','public-default-v155-original'),('new_symbol200','public-default-v157-symbols')",
    "('original200','public-qualified-locator-v172-original'),('new_symbol200','public-qualified-locator-v172-symbols')")
source = source.replace("current-public-development-v155-v157-summary.json", "public-qualified-locator-v172-summary.json")
needle = "w=Path.cwd();manifest="
preflight = '''w=Path.cwd()
# Close BOTH complete200captures before opening any exposed reference files.
for cohort in ['original', 'symbols']:
 root=w/('output/development/public-qualified-locator-v172-'+cohort)
 lock=json.loads((root/'lock.json').read_text());regpath=root/'capture/registration.json'
 while not regpath.exists() or json.loads(regpath.read_text()).get('status')!=lock['closed_status']:time.sleep(15)
 assert json.loads(regpath.read_text())['lock_sha256']==grading.sha(root/'lock.json')
manifest='''
assert source.count(needle) == 1
source = source.replace(needle, preflight)
(w / 'output/analysis/grade-qualified-public-v172.py').write_text(source)
print('Created grader retaining same immutable identity evaluator; whole400closure required before references')
