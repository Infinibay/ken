from pathlib import Path

w = Path.cwd()
source = (w / 'output/analysis/capture-qualified-exact-v172.py').read_text()
source = source.replace("out = w / 'output/development/qualified-exact-diagnostic-v172'", "out = w / 'output/development/qualified-exact-diagnostic-v172b'")
needle = 'w = Path.cwd()\n'
proof = '''w = Path.cwd()
frozen_root = w / 'output/frozen/public-qualified-locator-v172'
manifest = json.loads((frozen_root / 'SOURCE-MANIFEST.json').read_text())
assert verify_frozen_source(frozen_root) == '3f56b5848be8fcb44ce6006b754a6cbfb6d609c872521437be5ceeefd6b36197'
def module_origins():
    result = {}
    for name, module in list(sys.modules.items()):
        if name != 'ken' and not name.startswith('ken.'):
            continue
        path = getattr(module, '__file__', None)
        assert path is not None, name
        path = Path(path).resolve()
        assert path.is_relative_to(frozen_root / 'src'), (name, str(path))
        relative = path.relative_to(frozen_root).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert manifest['files'][relative] == digest
        result[name] = {'path': relative, 'sha256': digest}
    return result
initial_imports = module_origins()
'''
assert source.count(needle) == 1
source = source.replace(needle, proof)
needle = "(out / 'registration.json').write_text(json.dumps(registration, indent=2) + '\\n')"
assert source.count(needle) == 2
source = source.replace(needle, '''registration['module_origins'] = {'at_registration': initial_imports, 'current': module_origins()}
registration['provenance'] = 'NEW controlled later replay, not retroactive proof of original172import paths'
''' + needle)
source += '''
original = w / 'output/development/qualified-exact-diagnostic-v172/observations.jsonl'
assert original.read_bytes() == (out / 'observations.jsonl').read_bytes()
print(json.dumps({'original400observations_byte_exact': True, 'verified_ken_modules': len(module_origins())}))
'''
(w / 'output/analysis/replay-qualified-exact-v172b.py').write_text(source)
print('Created NEW import-pinned replay; original observations untouched')
