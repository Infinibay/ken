"""Pairs from already exposed frozen scores and authenticated public source cards."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, 'experiments/search-engine')
from verifiable_grading import identity_hit

w = Path.cwd()
rows = lambda p: [json.loads(l) for l in Path(p).read_text().splitlines()]
root = w / 'output/development/public-default-v157-symbols'
lock = json.loads((root / 'lock.json').read_text())
cases = {c['id']: c for c in rows(lock['public_cases'])}
answers = {a['id']: a for p in (root / 'capture').glob('*/answers.jsonl') for a in rows(p)}
raw = {a['id']: a for a in rows(w / 'output/development/source-syntax-evidence-v162b/raw_current_nn-orders.jsonl')}
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
        gold.update({g['id']: g for g in rows(name)})
records = []
for q, case in cases.items():
    units = raw[q]['units']
    hit = lambda u: bool(identity_hit({'unit': u}, gold[q]['acceptable_units']))
    if hit(units[0]):
        continue
    acceptable = [u for u in units if hit(u)]
    selected = [units[0]] + acceptable[:1]
    source = []
    for u in selected:
        i = answers[q]['units'].index(u)
        r = answers[q]['public_response']['results'][i]
        path = Path(lock['roots'][case['repo_id']]) / r['path']
        data = path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == r['source_hash']
        lines = data.decode().splitlines()
        span = r['entity_span']
        start, end = span['start_line'], span['end_line']
        source.append({'unit': u, 'full_extent': [start,end], 'source_lines': '\n'.join(f'{n} | {lines[n-1]}' for n in range(start,min(end,start+79)+1)), 'partial': end-start+1>80})
    records.append({'id': q, 'repo_id': case['repo_id'], 'query': case['query'],
        'query_style': case['query_style'], 'correct_raw_rank': next((i+1 for i,u in enumerate(units) if hit(u)), None),
        'expected': gold[q]['acceptable_units'], 'source': source})
out = w / 'output/analysis/semantic-misses-v174.json'
out.write_text(json.dumps(records, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'queries': len(cases), 'raw_misses': len(records), 'present': sum(r['correct_raw_rank'] is not None for r in records), 'output': str(out)}))
for r in records[:8]:
    print(json.dumps({k:v for k,v in r.items() if k!='source'}, ensure_ascii=False))
