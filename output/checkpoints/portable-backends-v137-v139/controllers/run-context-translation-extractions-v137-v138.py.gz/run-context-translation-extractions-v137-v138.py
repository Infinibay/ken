"""After frozen new200 controls, validate each portable backend separately on old200."""
from pathlib import Path
import hashlib,json,os,subprocess,time
w=Path(__file__).resolve().parents[2]
output=w/'output/development/backend-extractions-v137-v138';output.mkdir(parents=True,exist_ok=False)
state={'scope':'Source-free backend parity then original200-only extraction replays. No new quality grading or Gold.',
       'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'closed':[]}
def save(): (output/'registration.json').write_text(json.dumps(state,indent=2)+'\n')
save();deadline=time.monotonic()+7200
while True:
    try:q=json.loads((w/'output/development/unseen-cpu-validation-v135/queue-v136.json').read_text())
    except json.JSONDecodeError:q={}
    if q.get('status','').startswith('Original200 extraction and both new200 controls closed'):break
    if 'Traceback (most recent call last)' in Path('/private/tmp/ken-static-unseen-control-queue-v136.log').read_text():raise RuntimeError('prior control queue failed')
    if time.monotonic()>deadline:raise TimeoutError('control queue closure timeout')
    time.sleep(2)

context_probe=r'''
import importlib.util,json,hashlib,sys
from pathlib import Path
import numpy as np
from ken.embedder.contextual_onnx import ContextEncoder,code_context_model
w=Path.cwd();path=w/'output/frozen/piece-threads4-cpu-v134/experiments/search-engine/contextual_run.py'
s=importlib.util.spec_from_file_location('legacy_context_probe',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=json.loads((w/'output/models/cpu-context-registration-v42.json').read_text())
a=m.CPUContextEncoder(r);b=ContextEncoder(code_context_model(),snapshot=Path(r['root']));assert a.spec==b.spec
texts=['find a stored value','parse an input value','¿Dónde convierte un valor?','def read(value):\n    return value\n'*200]
x=np.stack(a.embed_passages(texts)+[a.embed_query(q) for q in texts]);y=np.stack(b.embed_passages(texts)+[b.embed_query(q) for q in texts]);np.testing.assert_array_equal(x,y)
heavy=sorted(set(sys.modules)&{'torch','transformers','sentence_transformers'});assert not heavy
p=w/'output/development/backend-extractions-v137-v138/context-parity.json';p.write_text(json.dumps({'source_free_vectors':len(x),'bit_equal':True,'max_abs_delta':float(np.max(np.abs(x-y))),'spec':a.spec.revision,'providers':b.providers,'heavy_imports':heavy,'new_gold_opened':False},indent=2))
'''
translation_probe=r'''
import json,hashlib,sys
from pathlib import Path
from ken.retrieval.translation_preparation import default_query_expansion
from ken.retrieval.query_expansion import LocalQueryExpansion
w=Path.cwd();r=json.loads((w/'output/models/es-en-cpu-registration-v21.json').read_text())
a=LocalQueryExpansion(Path(r['root']),r);b=default_query_expansion(cache_root=w/'output/models/portable-prepared-v138',cache_dir=w/'output/models/portable-hub-v138',local_files_only=True)
assert a.identity==b.identity and a.revision==b.revision
queries=['¿Dónde convierte un valor de entrada?','¿Qué clase almacena valores?','Which class stores values?','¿Dónde implementa `Cache.read_value` el acceso?']
left=[a(q) for q in queries];right=[b(q) for q in queries];assert left==right
for name,expected in r['artifacts'].items():
    with (b.root/name).open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    assert digest==expected['sha256']
heavy=sorted(set(sys.modules)&{'torch','transformers','sentence_transformers'});assert not heavy
p=w/'output/development/backend-extractions-v137-v138/translation-parity.json';p.write_text(json.dumps({'source_free_queries':len(queries),'outputs_equal':True,'revision':a.revision,'all_prepared_files_equal':True,'heavy_imports':heavy,'new_gold_opened':False},indent=2))
'''

def environment(engine):
    return os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(engine/'src')+':'+str(engine/'experiments/search-engine')}

def rows(root,name):
    result={}
    for p in root.glob('*/'+name):
        for line in p.read_text().splitlines():
            row=json.loads(line)
            if row['id'] in result:raise ValueError('duplicate old query ID')
            result[row['id']]=row
    return result

old=w/'output/development/piece-production-static-v136';reference=rows(old,'answers.jsonl');reference_orders=rows(old,'orders.jsonl')
for version,name,probe in ((137,'piece-production-context-v137',context_probe),(138,'piece-production-translation-v138',translation_probe)):
    engine=w/'output/frozen'/name;env=environment(engine)
    with (output/(str(version)+'-probe.log')).open('w') as log:
        subprocess.run([str(w/'.venv-model-runtime/bin/python'),'-c',probe],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    dest=w/'output/development'/name
    command=[str(w/'.venv-model-runtime/bin/python'),str(engine/'experiments/search-engine/piece_complete_run.py'),
        '--workspace',str(w),'--public-cases',str(w/'output/development/verifiable-pieces-v98-public/cases.jsonl'),
        '--source-metadata','/private/tmp/ken-verifiable-pieces-benchmark-20261015/source-metadata','--output',str(dest)]
    with (output/(str(version)+'-replay.log')).open('w') as log:subprocess.run(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    reg=json.loads((dest/'registration.json').read_text())
    if reg['status']!='ALL200 complete CPU outputs closed without Gold':raise ValueError('unclosed original200 replay')
    actual=rows(dest,'answers.jsonl');orders=rows(dest,'orders.jsonl')
    if len(actual)!=200 or actual!=reference or set(orders)!=set(reference_orders):raise ValueError('backend extraction changed original200 answers')
    if any(any(orders[q][k]!=reference_orders[q][k] for k in ('native_units','piece_order','fusion_order_in_piece_order','final_order')) for q in orders):raise ValueError('backend extraction changed original200 orders')
    audit={'queries':200,'cards_units_pool_hashes_and_orders_equal136':True,'scope':'Original200 only; identical observable answers preserve180top1/197top10','new_gold_opened':False}
    (dest/'parity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');state['closed'].append({'version':version,'path':str(dest),'audit':audit});save();print(str(version)+' backend parity + original200 replay closed',flush=True)
state['status']='Both separate original200 backend extractions closed; independent new200 Gold still unopened; complete public production arm pending';save()
