"""Archive closed public/old-development evidence; never references or Gold."""
from pathlib import Path
import gzip,hashlib,json
w=Path(__file__).resolve().parents[2];target=w/'output/checkpoints/portable-backends-v137-v139';target.mkdir(parents=True,exist_ok=False);entries=[]
def add(path,label):
    data=path.read_bytes();archive=target/(label+'.gz');archive.parent.mkdir(parents=True,exist_ok=True);archive.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(archive.read_bytes())==data
    entries.append({'source':str(path),'archive':archive.relative_to(target).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for version,name in ((137,'piece-production-context-v137'),(138,'piece-production-translation-v138'),(139,'piece-production-neural-v139')):
    root=w/'output/development'/name;r=json.loads((root/'registration.json').read_text());audit=json.loads((root/'parity-audit.json').read_text())
    if r['status']!='ALL200 complete CPU outputs closed without Gold' or audit['queries']!=200 or not audit['cards_units_pool_hashes_and_orders_equal136']:raise ValueError('unclosed original200 parity')
    for p in sorted(root.glob('*/*.jsonl'))+sorted(root.glob('*/performance.json'))+[root/'registration.json',root/'parity-audit.json']:add(p,str(version)+'/'+p.relative_to(root).as_posix())
    add(w/'output/frozen'/name/'SOURCE-MANIFEST.json','frozen/'+str(version)+'/SOURCE-MANIFEST.json')
for folder in ('backend-extractions-v137-v138','neural-extraction-v139-protocol'):
    for p in sorted((w/'output/development'/folder).glob('*.json')):add(p,'protocol/'+folder+'/'+p.name)
for name in ('run-context-translation-extractions-v137-v138.py','run-neural-extraction-v139.py','freeze-context-backend-v137.py','freeze-translation-backend-v138.py','freeze-neural-backend-v139.py'):
    add(w/'output/analysis'/name,'controllers/'+name)
for name in ('src/ken/embedder/contextual_onnx.py','src/ken/embedder/data/code-context-int8.json','src/ken/retrieval/query_expansion.py','src/ken/retrieval/translation_preparation.py','src/ken/embedder/data/es-en-ct2-int8.json','src/ken/retrieval/neural_reranker.py','src/ken/retrieval/neural_assets.py','src/ken/embedder/data/ettin-68m-fp32.json','experiments/search-engine/contextual_run.py','experiments/search-engine/verifiable_cpu_run.py','experiments/search-engine/ettin_cpu.py','experiments/search-engine/piece_complete_run.py'):
    add(w/'output/frozen/piece-production-neural-v139'/name,'frozen/139/'+name)
queue=w/'output/development/unseen-cpu-validation-v135/queue-v136.json';add(queue,'ungraded-new200/queue-v136.json')
for name in ('closed-baseline-v136','closed-optimized-v136'):
    root=queue.parent/name;r=json.loads((root/'registration.json').read_text())
    if r['status']!='ALL additional public outputs closed without Gold':raise ValueError('unclosed new200 producer')
    for p in sorted(root.glob('*/answers.jsonl'))+sorted(root.glob('*/performance.json'))+[root/'registration.json']:
        add(p,'ungraded-new200/'+name+'/'+p.relative_to(root).as_posix())
add(Path(__file__),'controllers/'+Path(__file__).name)
(target/'MANIFEST.json').write_text(json.dumps({'scope':'Three separate original200 backend parity replays, portable model probes, and CLOSED UNGRADED new200 frozen controls. No Gold/reference payloads. Complete public production arm is still pending.','files':entries},indent=2)+'\n')
print({'files':len(entries),'bytes':sum(p.stat().st_size for p in target.rglob('*') if p.is_file()),'manifest_sha256':hashlib.sha256((target/'MANIFEST.json').read_bytes()).hexdigest()})
