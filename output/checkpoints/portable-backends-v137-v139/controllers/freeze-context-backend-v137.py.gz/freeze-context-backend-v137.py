"""Freeze one contextual-loader extraction over the closed static136 control."""
from pathlib import Path
import hashlib,json,shutil
w=Path(__file__).resolve().parents[2];clean=Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
base=w/'output/frozen/piece-production-static-v136';dest=w/'output/frozen/piece-production-context-v137'
shutil.copytree(base,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ('src/ken/embedder/contextual_onnx.py','src/ken/embedder/data/code-context-int8.json'):
    shutil.copyfile(clean/name,dest/name)
p=dest/'experiments/search-engine/contextual_run.py';s=p.read_text();start=s.index('class CPUContextEncoder:');end=s.index('\ndef main(',start)
s=s[:start]+'''from ken.embedder.contextual_onnx import ContextEncoder, ContextModel
from ken.model_assets import ModelAssets


class CPUContextEncoder(ContextEncoder):
    """Historical control interface over the production encoder; diagnostics only."""
    def __init__(self, registration: dict):
        root = Path(registration['root'])
        assets = ModelAssets.from_dict({'model_id': registration['model_id'],
            'revision': registration['upstream_revision'], 'artifacts': {
                name: {'sha256': digest, 'bytes': (root/name).stat().st_size}
                for name, digest in registration['artifacts'].items()}})
        model = ContextModel(assets, registration['query_prefix'], registration['document_projection'])
        if model.spec != EncoderSpec(**registration['spec']):
            raise ValueError('production contextual identity differs from registered control')
        super().__init__(model, snapshot=root)
        self.calls = []

    def _encode(self, text: str) -> np.ndarray:
        started = time.perf_counter()
        result = super()._encode(text)
        # Only the experimental diagnostics interface keeps call history.
        self.calls.append({'tokens': len(self._tokenizer.encode(text).ids),
                           'ms': (time.perf_counter()-started)*1000})
        return result

''' + s[end:];p.write_text(s)
p=dest/'experiments/search-engine/piece_complete_run.py';s=p.read_text().replace('Single change from v134: shared production RegisteredStaticEncoder replaces benchmark-owned StaticEmbeddingControl. Native Model2Vec math/tokenizer/weights/profile identity remain fixed; batch1/threads4/neural512/FP32/forests/RRF unchanged. No Gold or score reuse.', 'Single change from v136: production lazy ContextEncoder replaces experimental contextual adapter, preserving exact model/tokenizer/spec/raw output and CPU2/batch1/512 policy. All static/piece/neural/fusion controls unchanged.');p.write_text(s)
files={}
for name in ('src','experiments/search-engine','pyproject.toml'):
    path=dest/name
    for f in path.rglob('*') if path.is_dir() else (path,):
        if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':files[f.relative_to(dest).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
files=dict(sorted(files.items()));record={'scope':'Single contextual backend extraction from136; no new Gold; full public production arm still pending','base_receipt':'93c08ae1ffa5f312b44f57b5f89a98714fabd88fc7f04bb9c8de740dd88f90ee','files':files,'tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
p=dest/'SOURCE-MANIFEST.json';p.write_text(json.dumps(record,indent=2)+'\n');print({'source_receipt':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(files)})
