"""Freeze only portable translation preparation over contextual137."""
from pathlib import Path
import hashlib,json,shutil,os
w=Path(__file__).resolve().parents[2];clean=Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
base=w/'output/frozen/piece-production-context-v137';dest=w/'output/frozen/piece-production-translation-v138'
shutil.copytree(base,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ('src/ken/retrieval/query_expansion.py','src/ken/retrieval/translation_preparation.py','src/ken/embedder/data/es-en-ct2-int8.json'):
    shutil.copyfile(clean/name,dest/name)
definition=json.loads((clean/'src/ken/embedder/data/es-en-ct2-int8.json').read_text());source=definition['source']
hub=w/'output/models/portable-hub-v138';snapshot=hub/('models--'+source['model_id'].replace('/','--'))/'snapshots'/source['revision'];snapshot.mkdir(parents=True,exist_ok=False)
reg=json.loads((w/'output/models/es-en-cpu-registration-v21.json').read_text());old=Path(reg['root'])
metadata=Path('/private/tmp/ken-portable-translation')/source['revision']
for name in source['artifacts']:
    origin=(metadata if name in ('config.json','shared_vocabulary.json') else old)/name
    os.link(origin,snapshot/name)
p=dest/'experiments/search-engine/verifiable_cpu_run.py';s=p.read_text();oldblock='''        from ken.retrieval.query_expansion import LocalQueryExpansion
        tr=json.loads((workspace/'output/models/es-en-cpu-registration-v21.json').read_text())
        self.expansion=LocalQueryExpansion(Path(tr['root']),tr)'''
assert oldblock in s
s=s.replace(oldblock,'''        from ken.retrieval.translation_preparation import default_query_expansion
        self.expansion=default_query_expansion(
            cache_root=workspace/'output/models/portable-prepared-v138',
            cache_dir=workspace/'output/models/portable-hub-v138', local_files_only=True)''');p.write_text(s)
p=dest/'experiments/search-engine/piece_complete_run.py';s=p.read_text().replace('Single change from v136: production lazy ContextEncoder replaces experimental contextual adapter, preserving exact model/tokenizer/spec/raw output and CPU2/batch1/512 policy. All static/piece/neural/fusion controls unchanged.', 'Single change from v137: portable pinned public CT2 preparation/factory replaces benchmark-local translation root, preserving exact converted files, expansion identity, CPU2/INT8/beam1 and all ranking/fusion controls.');p.write_text(s)
files={}
for name in ('src','experiments/search-engine','pyproject.toml'):
    path=dest/name
    for f in path.rglob('*') if path.is_dir() else (path,):
        if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':files[f.relative_to(dest).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
files=dict(sorted(files.items()));record={'scope':'Single translation-preparation extraction from137; no new Gold; not complete public default','base_receipt':'100bbfcca104c3ddb9578de0db3d81db7bc1cae515a2382047694c49b4ec3cf4','files':files,'tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
p=dest/'SOURCE-MANIFEST.json';p.write_text(json.dumps(record,indent=2)+'\n');print({'source_receipt':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(files),'public_cache_seeded_from_identical_registered_bytes':True})
