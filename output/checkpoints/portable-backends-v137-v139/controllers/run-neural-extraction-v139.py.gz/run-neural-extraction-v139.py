"""Wait for separate backend replays, then verify portable neural assets + old200."""
from pathlib import Path
import hashlib,json,os,subprocess,time
w=Path(__file__).resolve().parents[2];dest=w/'output/development/piece-production-neural-v139';meta=w/'output/development/neural-extraction-v139-protocol';meta.mkdir(parents=True,exist_ok=False)
record={'scope':'Original200 only; portable neural asset byte/probe parity and scoring extraction; no new Gold', 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(meta/'registration.json').write_text(json.dumps(record,indent=2)+'\n');deadline=time.monotonic()+7200
while True:
    p=w/'output/development/backend-extractions-v137-v138/registration.json'
    try:r=json.loads(p.read_text())
    except json.JSONDecodeError:r={}
    if r.get('status','').startswith('Both separate original200 backend extractions closed'):break
    if 'Traceback (most recent call last)' in Path('/private/tmp/ken-context-translation-extractions-v137-v138.log').read_text():raise RuntimeError('prior backend extraction failed')
    if time.monotonic()>deadline:raise TimeoutError('backend extraction timeout')
    time.sleep(2)
engine=w/'output/frozen/piece-production-neural-v139';env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(engine/'src')+':'+str(engine/'experiments/search-engine')}
probe=r'''
import importlib.util,json,hashlib,sys
from pathlib import Path
import numpy as np
from ken.retrieval.neural_assets import default_reranker
w=Path.cwd();path=w/'output/frozen/piece-threads4-cpu-v134/experiments/search-engine/ettin_cpu.py'
s=importlib.util.spec_from_file_location('legacy_neural_probe',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=json.loads((w/'output/models/ettin-68m-fp32-complete-v110/assembly.json').read_text());a=m.CPUReranker(r,batch_size=1,intra_op_threads=4)
b=default_reranker(cache_root=w/'output/models/portable-prepared-v139',cache_dir=w/'output/models/portable-hub-v139',local_files_only=True)
queries=['find a stored value','parse input'];texts=['class Cache: store values by key','def read(x): return parse(x)','Checks attributes. '+'if value is None: return False\n'*80]
left=[];right=[]
for query in queries:
    x,_=a.score(query,texts);y,_=b.score(query,texts);np.testing.assert_array_equal(x,y);left.extend(x);right.extend(y)
heavy=sorted(set(sys.modules)&{'torch','transformers','sentence_transformers'});assert not heavy
p=w/'output/development/neural-extraction-v139-protocol/portable-parity.json';p.write_text(json.dumps({'source_free_pairs':len(left),'raw_scores_bit_equal':True,'max_abs_delta':float(np.max(np.abs(np.array(left)-right))),'graph_sha256':'8e22c1a014dbb6bf803824b531943ee067de4e9c6dea72f8c178348732db38bf','providers':b.providers,'heavy_imports':heavy,'new_gold_opened':False},indent=2))
'''
with (meta/'portable-probe.log').open('w') as log:subprocess.run([str(w/'.venv-model-runtime/bin/python'),'-c',probe],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
command=[str(w/'.venv-model-runtime/bin/python'),str(engine/'experiments/search-engine/piece_complete_run.py'),'--workspace',str(w),'--public-cases',str(w/'output/development/verifiable-pieces-v98-public/cases.jsonl'),'--source-metadata','/private/tmp/ken-verifiable-pieces-benchmark-20261015/source-metadata','--output',str(dest)]
with (meta/'complete-replay.log').open('w') as log:subprocess.run(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
def rows(root,name):
    out={}
    for p in root.glob('*/'+name):
        for line in p.read_text().splitlines():
            item=json.loads(line)
            if item['id'] in out:raise ValueError('duplicate query')
            out[item['id']]=item
    return out
old=w/'output/development/piece-production-static-v136';actual=rows(dest,'answers.jsonl');reference=rows(old,'answers.jsonl');orders=rows(dest,'orders.jsonl');before=rows(old,'orders.jsonl')
if len(actual)!=200 or actual!=reference or set(orders)!=set(before):raise ValueError('neural extraction changed old200 answers')
if any(any(orders[q][k]!=before[q][k] for k in ('native_units','piece_order','fusion_order_in_piece_order','final_order')) for q in orders):raise ValueError('neural extraction changed old200 orders')
audit={'queries':200,'cards_units_pool_hashes_and_orders_equal136':True,'scope':'Original200; identical returned answers preserve180top1/197top10','new_gold_opened':False}
(dest/'parity-audit.json').write_text(json.dumps(audit,indent=2)+'\n');record['status']='Portable neural byte/score parity and separate original200 replay closed; public production arm still pending';record['audit']=audit;(meta/'registration.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'],flush=True)
