"""Freeze production neural scoring over138; model preparation is probed separately."""
from pathlib import Path
import hashlib,json,shutil,os
w=Path(__file__).resolve().parents[2];clean=Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
base=w/'output/frozen/piece-production-translation-v138';dest=w/'output/frozen/piece-production-neural-v139'
shutil.copytree(base,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ('src/ken/retrieval/neural_reranker.py','src/ken/retrieval/neural_assets.py','src/ken/embedder/data/ettin-68m-fp32.json'):
    shutil.copyfile(clean/name,dest/name)
definition=json.loads((clean/'src/ken/embedder/data/ettin-68m-fp32.json').read_text());source=definition['source']
hub=w/'output/models/portable-hub-v139';snapshot=hub/('models--'+source['model_id'].replace('/','--'))/'snapshots'/source['revision'];snapshot.mkdir(parents=True,exist_ok=False)
a=json.loads((w/'output/models/ettin-68m-fp32-complete-v110/assembly.json').read_text());up=Path(a['upstream']['root'])
for name in source['artifacts']:
    origin=Path(a['upstream']['encoder']['path']) if name=='onnx/model.onnx' else up/name
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);os.link(origin,target)
p=dest/'experiments/search-engine/ettin_cpu.py';s=p.read_text();start=s.index('class CPUReranker:');end=s.index("\n\nif __name__",start)
s=s[:start]+'''from ken.retrieval.neural_reranker import ONNXReranker, RerankerAssets


class CPUReranker(ONNXReranker):
    """Historical registered/eager interface over the production scoring kernel."""
    def __init__(self, registration, *, batch_size=4, intra_op_threads=2):
        super().__init__(lambda: RerankerAssets.from_registration(registration),
                         batch_size=batch_size, intra_op_threads=intra_op_threads)
        self.registration = registration
        self._load()
        self.session, self.tokenizer, self.output = self._session, self._tokenizer, self._output
''' + s[end:];p.write_text(s)
p=dest/'experiments/search-engine/piece_complete_run.py';s=p.read_text().replace('Single change from v137: portable pinned public CT2 preparation/factory replaces benchmark-local translation root, preserving exact converted files, expansion identity, CPU2/INT8/beam1 and all ranking/fusion controls.', 'Single change from v138: production bounded ONNXReranker scoring replaces experimental scorer, preserving full FP32 graph, published padding, batch1/threads4/512 and all candidate/forest/fusion controls. Portable assembly is independently byte/probe verified.');p.write_text(s)
files={}
for name in ('src','experiments/search-engine','pyproject.toml'):
    path=dest/name
    for f in path.rglob('*') if path.is_dir() else (path,):
        if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':files[f.relative_to(dest).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
files=dict(sorted(files.items()));record={'scope':'Single neural-scoring extraction from138; no new Gold; public default still pending','base_receipt':'37075978f3419c3eb4a2d95c69e7a2374bb5a6892d1b56f9680a268dfa7aa0be','files':files,'tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
p=dest/'SOURCE-MANIFEST.json';p.write_text(json.dumps(record,indent=2)+'\n');print({'source_receipt':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(files)})
