from pathlib import Path

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
p = c / 'src/ken/presentation.py'
s = p.read_text()
old = '"sha256", "content_hash", "fingerprint", "model_fingerprint"}'
assert old in s
s = s.replace(old, '"sha256", "content_hash", "fingerprint", "model_fingerprint",\n                "timing", "elapsed_ms"}', 1)
p.write_text(s)
p = c / 'src/ken/presentation_views.py'
s = p.read_text()
a = s.index('    if name == "ken_who":')
b = s.index('    if name == "ken_reason":', a)
s = s[:a] + '''    if name == "ken_who":
        return responsibility_text(value)
    if name == "ken_check":
        return {k: v for k, v in value.items() if k not in {"created_at", "claim", "scope", "selection"}}
    if name == "ken_calculate" and value.get("status") == "calculated" and isinstance(value.get("exact"), (str, int, float)):
        return f"{value['expression']} = {value['exact']}"
    if name == "ken_recall" and "memories" in value:
        result = {k: v for k, v in value.items() if k not in {"detail", "validity_scope"} and not (k == "omitted" and v == 0)}
        result["memories"] = [{k: v for k, v in m.items()
            if k not in {"expand", "reuse"} and not (k == "conclusion_complete" and v is True)
            and not (k == "kind" and v == "note")} for m in value["memories"]]
        return result
    if name == "ken_related" and "imports" in value and "neighbors" in value:
        result = {k: v for k, v in value.items() if k not in {"imports", "imported_by", "tests", "neighbors"}}
        seen = set()
        for group in ("imports", "imported_by", "tests", "neighbors"):
            rows = []
            for item in value.get(group, []):
                path = item if isinstance(item, str) else item.get("path") or item.get("file") or item.get("module")
                if not path or group == "neighbors" and path in seen:
                    continue
                rows.append(path)
                seen.add(path)
            if rows:
                result[group] = rows
        return result
''' + s[b:]
s = s.replace('if k not in {"metrics", "reuse", "proof_note"}',
              'if k not in {"metrics", "reuse", "proof_note", "question", "query", "context", "revision", "world"}\n+                  and not (k == "answers_truncated" and v is False)', 1)
s = s.replace('if k in {"complete", "resumable", "pending"}',
              'if k == "complete" or k in {"resumable", "pending"} and v', 1)
s += '''

def responsibility_text(value: dict[str, Any]) -> str:
    """A location and real code per hypothesis; detailed machinery stays opt-in."""
    from ken.retrieval.public import render
    status = value.get("status", "unknown")
    blocks = ["Ambiguous candidates:" if status == "ambiguous" else
              "Candidates:" if status == "candidates" else "No responsible owner established."]
    if value.get("reason"):
        blocks.append(value["reason"])
    verification = []
    for group in ("candidates", "counterevidence"):
        if group == "counterevidence" and value.get(group):
            blocks.append("Counterevidence:")
        for candidate in value.get(group, []):
            evidence = candidate.get("snippets", [])
            symbol = candidate.get("symbol") or candidate.get("qualname")
            if evidence:
                row = {"path": candidate["path"], "entity": {"qualname": symbol},
                       "evidence": evidence, "truncated": candidate.get("truncated", False),
                       "piece_kind": candidate.get("kind")}
                block = render({"results": [row]})
            else:
                block = candidate["path"] + (f":{candidate['line']}" if candidate.get("line") else "")
                if symbol:
                    block += " :: " + symbol
                if candidate.get("preview_unavailable"):
                    block += "\\nCode unavailable: " + candidate["preview_unavailable"]
            quote = candidate.get("evidence")
            if isinstance(quote, str) and not any(quote in e["content"] for e in evidence):
                block += "\\nDocumentation: " + quote
            if candidate.get("assumed_formulation"):
                block += "\\nAssumed wording: " + candidate["assumed_formulation"]
            for field in ("caveats", "counterevidence", "assumptions"):
                for note in candidate.get(field, []):
                    block += "\\n" + note
            verification.extend(verification_caveats(candidate.get("structure", {})))
            blocks.append(block)
    verification.extend(verification_caveats(value.get("responsibility_map", {})))
    notes = []
    for note in verification:
        # Repeated internal scopes do not change the useful coverage statement.
        note = note.split(": ", 1)[-1]
        if "usage_inventory_open" in note:
            note = "Call verification incomplete."
        if note not in notes:
            notes.append(note)
    if notes:
        blocks.append("Verification: " + " ".join(notes))
    if value.get("uninspected_candidates"):
        blocks.append(f"{value['uninspected_candidates']} candidates could not be read.")
    return "\\n\\n".join(blocks)
'''
p.write_text(s)
print('Implemented decision-focused views; JSON and full/explain bypass these projections.')
