"""Preserve presentation evidence after final test/type commands close."""
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
w = Path('/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace')
tmp = Path('/private/tmp')
assert (tmp / 'ken-useful-output-full-suite-exit-v178b').read_text().strip() == '0'
suite = (tmp / 'ken-useful-output-full-suite-v178b.log').read_text()
counts = re.search(r'(\d+) passed, (\d+) xfailed in ([\d.]+)s', suite)
assert counts, suite[-2000:]
mypy = (tmp / 'ken-useful-output-mypy-v178d.log').read_text()
assert 'Success: no issues found in 357 source files' in mypy
captures = tmp / 'ken-useful-output-v178b-captures'
receipt = json.loads((captures / 'receipt.json').read_text())
assert receipt['capture_count'] == 21
for name, digest in receipt['source_files'].items():
    assert hashlib.sha256((c / name).read_bytes()).hexdigest() == digest, name
changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'src/ken/retrieval', 'src/ken/embedder', 'src/ken/assets'], cwd=c)
assert not changed, changed
out = w / 'output/checkpoints/useful-default-output-v178'
out.mkdir(exist_ok=False)
files = []
for folder in ['ken-useful-output-v178-captures', 'ken-useful-output-v178b-captures']:
    files.extend(p for p in (tmp / folder).rglob('*') if p.is_file())
for name in [
    'ken-useful-output-red-v178.log', 'ken-useful-output-green-v178.log',
    'ken-useful-output-green-v178b.log', 'ken-useful-output-green-v178c.log',
    'ken-useful-output-green-v178d.log', 'ken-useful-output-green-v178e.log',
    'ken-useful-status-red-v178.log', 'ken-useful-context-red-v178.log',
    'ken-useful-dedup-red-v178.log', 'ken-useful-output-full-suite-v178.log',
    'ken-useful-output-full-suite-exit-v178', 'ken-useful-output-full-suite-v178b.log',
    'ken-useful-output-full-suite-exit-v178b', 'ken-useful-output-mypy-v178.log',
    'ken-useful-output-mypy-v178b.log', 'ken-useful-output-mypy-v178c.log',
    'ken-useful-output-mypy-v178d.log', 'ken-useful-mypy-v178c-interruption.json',
    'ken-useful-pytest-sample-v178.txt', 'ken-useful-pytest-policy-v178.json',
    'ken-useful-output-captures-v178.log', 'ken-useful-output-captures-v178b.log',
    'ken-implement-who-code-v178.py', 'ken-implement-useful-views-v178.py',
    'ken-fullsuite-v178.py', 'ken-fullsuite-v178b.py',
    'ken-capture-useful-output-v178.py', 'ken-capture-useful-output-v178b.py',
    'ken-who-code-tests.py.txt', 'ken-useful-compact-tests.py.txt',
    'ken-status-compact-test-v178.txt', 'ken-context-preservation-test-v178.txt',
    'ken-repeat-code-test-v178.txt', 'ken-archive-useful-output-v178.py']:
    files.append(tmp / name)
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'src', 'tests'], cwd=c)
(tmp / 'ken-useful-output-source-v178.patch').write_bytes(patch)
files.append(tmp / 'ken-useful-output-source-v178.patch')
manifest = {'scope': 'Source snapshot excerpts and useful default output; actual21CLI/MCP captures; no private benchmark payloads.',
    'limits': ['Not a retrieval-quality/latency benchmark; no new top1 claim.',
        'Python leading docstrings skipped for implementation selection; other languages use registered parser ranges.',
        'Source excerpt is bounded16lines/4000characters per candidate and can omit needed dependencies.',
        'Original partial full suite intentionally interrupted for scope/dedup fixes; completed final run is separate.',
        'Initial edit-script syntax error and missing type annotations retained in logs; corrected before final capture.'],
    'files': {}}
for p in sorted(files):
    key = p.relative_to(tmp).as_posix()
    data = p.read_bytes()
    target = out / (key + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    manifest['files'][key] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'gzip_bytes': target.stat().st_size}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
validation = {'tests_passed': int(counts[1]), 'preexisting_xfailed': int(counts[2]),
    'suite_seconds': float(counts[3]), 'suite_exit': 0, 'mypy_source_files': 357,
    'actual_captures': 21, 'ranking_models_and_inputs_unchanged': True,
    'archive': 'output/checkpoints/useful-default-output-v178',
    'manifest_sha256': hashlib.sha256((out / 'manifest.json').read_bytes()).hexdigest(),
    'gzip_files': len(manifest['files']), 'gzip_bytes': sum(v['gzip_bytes'] for v in manifest['files'].values()),
    'source_receipt_sha256': hashlib.sha256((captures / 'receipt.json').read_bytes()).hexdigest(),
    'scope': 'Presentation validation only, no new accuracy or performance claim', 'no_release': True}
(tmp / 'ken-useful-output-validation-v178.json').write_text(json.dumps(validation, indent=2) + '\n')
print(json.dumps(validation))
