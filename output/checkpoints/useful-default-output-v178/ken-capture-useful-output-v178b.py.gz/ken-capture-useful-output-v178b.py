"""Actual CLI and MCP examples on disposable sources, no answer-quality claim."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

from ken.db import connect, init_schema
from ken.indexer import index_files
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
out = Path('/private/tmp/ken-useful-output-v178b-captures')
out.mkdir(exist_ok=False)
root = Path(tempfile.mkdtemp(prefix='ken-useful-output-demo-v178-', dir='/private/tmp'))
(root / '.ken').mkdir()
(root / '.ken/meta.json').write_text(json.dumps({'project_id': 'useful-output-demo-v178'}))
previous = Path('/private/tmp/ken-output-demo-_2xptiit')
for name in ['reader.py', 'settings.py', 'tests/test_reader.py', 'readers.kql']:
    target = root / name
    target.parent.mkdir(exist_ok=True, parents=True)
    target.write_bytes((previous / name).read_bytes())
with connect(root / '.ken/ken.db') as conn:
    init_schema(conn)
    index_files(conn, root, [Path('reader.py'), Path('settings.py'), Path('tests/test_reader.py')])
env = dict(os.environ)
env['PYTHONPATH'] = str(c / 'src')
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['HF_HUB_OFFLINE'] = '1'
old = json.loads((c / 'docs/validation/compact-output-2026-10-16-best-default/captures.json').read_text())
captures = []

async def main():
    params = StdioServerParameters(command=sys.executable, args=['-m', 'ken', 'mcp', str(root)], env=env)
    with (out / 'mcp.log').open('w') as log:
        async with stdio_client(params, errlog=log) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                for row in [r for r in old if r['transport'] == 'MCP']:
                    reply = await session.call_tool(row['tool'], row['arguments'])
                    assert not reply.is_error, reply
                    text = '\n'.join(part.text for part in reply.content)
                    captures.append({k: row[k] for k in ['transport', 'tool', 'arguments']} | {'output': text})
                    if row['tool'] == 'ken_who':
                        assert 'return get_value(key)' in text and 'return VALUES[key]' in text
                        assert 'score_kind' not in text and 'usage_inventory_open' not in text
                    print(row['tool'], flush=True)
                for row in [r for r in old if r['transport'] == 'CLI']:
                    argv = [a.replace(str(previous), str(root)) for a in row['argv']]
                    reply = subprocess.run([sys.executable, '-m', 'ken', *argv], env=env, cwd='/private/tmp', text=True, capture_output=True)
                    assert reply.returncode == 0, reply.stderr
                    captures.append({'transport': 'CLI', 'argv': argv, 'output': reply.stdout.rstrip('\n'),
                                     'exit_code': reply.returncode, 'stderr': reply.stderr})
                args = {'query': 'Locate the definition of reader::Reader.read_value.', 'scope': 'symbols'}
                reply = await session.call_tool('ken_find', args)
                assert not reply.is_error
                captures.append({'transport': 'MCP', 'tool': 'ken_find', 'arguments': args,
                                 'output': '\n'.join(part.text for part in reply.content)})
                # A long class whose useful member is far past its documentation.
                source = ('class SettingReader:\n    """Read stored application settings.\n' +
                          '    General API reference material.\n' * 25 + '    """\n' +
                          ''.join(f'    def unrelated_{i}(self):\n        return {i}\n' for i in range(20)) +
                          '    def read_setting(self, key):\n        return settings.get_value(key)\n')
                (root / 'large_reader.py').write_text(source)
                with connect(root / '.ken/ken.db') as conn:
                    index_files(conn, root, [Path('large_reader.py')])
                args = {'question': 'Who reads stored application settings?', 'path': 'large_reader.py'}
                reply = await session.call_tool('ken_who', args)
                assert not reply.is_error
                text = '\n'.join(part.text for part in reply.content)
                assert 'return settings.get_value(key)' in text and '[partial]' in text
                captures.append({'transport': 'MCP', 'tool': 'ken_who', 'arguments': args, 'output': text})
                raw = await session.call_tool('ken_who', args | {'output_format': 'json', 'full': True})
                assert not raw.is_error
                (out / 'who-large-full.json').write_text(raw.content[0].text)
                data = json.loads(raw.content[0].text)
                first = data['candidates'][0]
                assert first['source']['sha256'] == hashlib.sha256((root / 'large_reader.py').read_bytes()).hexdigest()
                for fragment in first['snippets']:
                    assert fragment['content'] == '\n'.join(source.splitlines()[fragment['start_line']-1:fragment['end_line']])
                assert sum(f['end_line']-f['start_line']+1 for f in first['snippets']) <= 16
    (out / 'captures.json').write_text(json.dumps(captures, indent=2, ensure_ascii=False) + '\n')
    blocks = ['# Actual compact output examples',
              'Real CLI and MCP captures from disposable Python sources. Code is quoted with its physical line numbers; `[partial]` means only selected source is shown. JSON and full diagnostics remain explicit options. These examples measure presentation, not retrieval accuracy or latency.']
    for row in captures:
        if row['transport'] == 'MCP':
            heading = row['tool']
            arguments = 'Arguments: `' + json.dumps(row['arguments'], ensure_ascii=False) + '`'
        else:
            heading = 'ken ' + shlex.join(row['argv'])
            arguments = ''
        blocks.extend(['## ' + heading, arguments, '```text\n' + row['output'] + '\n```'])
    (out / 'EXAMPLES.md').write_text('\n\n'.join(b for b in blocks if b) + '\n')
    record = {'fixture': str(root), 'capture_count': len(captures), 'source_commit_before_change': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=c).decode().strip(),
              'source_files': {p.relative_to(c).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in (c / 'src/ken').rglob('*') if p.is_file() and p.suffix != '.pyc'},
              'fixture_files': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['reader.py', 'settings.py', 'tests/test_reader.py', 'large_reader.py']},
              'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Actual presentation examples only; no source engine/ranking/model change or private benchmark access.'}
    (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'captures': len(captures), 'root': str(root), 'out': str(out)}), flush=True)

asyncio.run(main())
