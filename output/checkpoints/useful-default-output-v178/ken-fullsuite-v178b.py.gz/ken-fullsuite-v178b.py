from pathlib import Path
import os
import subprocess

c = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
w = Path('/Users/andres/Projects/ken/output/search-engine-2026-10-14/workspace')
env = dict(os.environ)
env['PYTHONPATH'] = str(c / 'src') + ':' + str(w / '.venv-model-runtime/lib/python3.12/site-packages')
env['PYTHONDONTWRITEBYTECODE'] = '1'
with Path('/private/tmp/ken-useful-output-full-suite-v178b.log').open('w') as log:
    result = subprocess.run([str(w / '.venv/bin/python'), '-m', 'pytest', '-p', 'no:cacheprovider'], cwd=c, env=env, stdout=log, stderr=subprocess.STDOUT)
Path('/private/tmp/ken-useful-output-full-suite-exit-v178b').write_text(str(result.returncode) + '\n')
raise SystemExit(result.returncode)
