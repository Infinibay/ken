"""Two prospectively fixed small heads, source-repo excluded; EXPOSED labels only."""
import json,sys,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from linear_decision_training import pairwise_examples,fit_head
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
base=Path('output/development/score-calibration-v147');capture=Path('output/development/joint-head-evidence-v153');dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False);reg=json.loads((capture/'registration.json').read_text());assert reg['status']=='ALL250joint public observations closed without Gold' and reg['source_free_parity']=='EXACT';lock=json.loads((base/'fit-manifest.json').read_text());registration={'scope':'EXPOSED250symbols,512existing jointvalues, J3direct/J4residual. Sum-of-query-loss C1 equivalent l2=1/effective_train_queries; one regularisation-unit correction, no HPO. Original J1/J2trained only87percent andCVsimilar: underfit diagnosis. All400reported; no private data.','capture_registration_sha256':sha(capture/'registration.json'),'script_sha256':sha(__file__),'training_sha256':sha('experiments/search-engine/linear_decision_training.py'),'recipe':{'loss':'query-balanced pairwise logistic','l2':'1/effective_training_queries','maxiter':1000,'ftol':1e-12,'gtol':1e-8},'status':'registered before any labels for these controls','folds':{}};(dest/'registration.json').write_text(json.dumps(registration,indent=2));cases={};gold={};oldobs={}
for c in lock['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 for r in rows(c['public_cases']):cases[r['id']]={**r,'cohort':c['name'],'query_kind':r['query_style']}
 for p,digest in c['exposed_gold_pins'].items():
  assert sha(p)==digest
  for g in rows(p):gold[g['id']]=g
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  for o in rows(p):oldobs[o['id']]=o
assert set(cases)==set(gold)==set(oldobs) and len(cases)==400
obs={};x=[];y=[];qids=[];repos=[];logits=[];groups={};start=0
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(capture/repo/f)==d
 data=np.load(capture/repo/'features.npz',allow_pickle=False)
 for o in rows(capture/repo/'observations.jsonl'):
  q=o['id'];assert q not in obs and o['units']==oldobs[q]['units'];obs[q]=o;n=len(o['units']);h=data['x'][data['qid']==q];assert h.shape==(n,512);x.append(h);y.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);qids.extend([q]*n);repos.extend([repo]*n);logits.extend(o['logits']);groups[q]=np.arange(start,start+n);start+=n
assert len(obs)==250
x=np.concatenate(x).astype(np.float64);qids,repos,y,logits=map(np.asarray,(qids,repos,y,logits));results={}
for variant,residual in [('J3_direct512_queryscaled',False),('J4_residual512_queryscaled',True)]:
 predictions=np.empty(len(x));folds=[]
 for held in sorted(set(repos)):
  batch=pairwise_examples(x,y,qids,repos,logits,held_out=held);theta,receipt=fit_head(batch,residual=residual,regularization=1./len(batch["queries"]));assert not set(batch['queries'])&set(qids[repos==held]);sel=repos==held;predictions[sel]=x[sel]@theta+(logits[sel] if residual else 0.);receipt.update(held_out=held,training_repositories=sorted(set(repos[repos!=held])));folds.append(receipt);(dest/(variant+'-'+held+'.json')).write_text(json.dumps({'schema':1,'residual':residual,'weights':theta.tolist()},separators=(',',':')))
 outcomes=[];orders=[]
 for q,c in cases.items():
  if q in obs:
   o=obs[q];ix=groups[q];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(ix)),key=lambda i:(-int(named is not None and o['units'][i]['path']==named),-oldobs[q]['exact'][i],-predictions[ix[i]],i));units=[o['units'][i] for i in order]
  else:units=oldobs[q]['baseline_units']
  hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[variant]=result;registration['folds'][variant]=folds;(dest/(variant+'-outcomes.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in outcomes));(dest/(variant+'-orders.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in orders));print(json.dumps({'variant':variant,'total':result['total'],'cohort':result['cohort']}),flush=True)
registration['status']='ALL J3/J4query-scaled small head development controls closed; private reserve not opened';(dest/'registration.json').write_text(json.dumps(registration,indent=2));(dest/'summary.json').write_text(json.dumps(results,indent=2))
