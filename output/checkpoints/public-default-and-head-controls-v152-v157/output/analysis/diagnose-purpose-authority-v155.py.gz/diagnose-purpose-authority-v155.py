import json,sys,collections
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
from ken.retrieval.intent import interpret
from ken.retrieval.model import SearchRequest
base=Path('output/development/score-calibration-v147');c=json.loads((base/'fit-manifest.json').read_text())['cohorts'][1];gold={g['id']:g for p in c['exposed_gold_pins'] for g in map(json.loads,Path(p).read_text().splitlines())};native={r['id']:r for p in Path('output/development/native-symbol-evidence-v152').glob('*/observations.jsonl') for r in map(json.loads,p.read_text().splitlines())};summary=collections.Counter();unknown=[]
for p in Path(c['capture']).glob('*/observations.jsonl'):
 for o in map(json.loads,p.read_text().splitlines()):
  n=native[o['id']];i=next(i for i,u in enumerate(n['units']) if identity_hit({'unit':u},gold[o['id']]['acceptable_units']));role=n['roles'][i];intent=interpret(SearchRequest(o['query']));summary[(role,intent.purpose)]+=1
  if role=='test' and intent.purpose!='tests':unknown.append({'id':o['id'],'query':o['query'],'identity':intent.identity,'identifiers':intent.identifiers})
print([(list(k),v) for k,v in summary.items()]);print(json.dumps(unknown,indent=2,ensure_ascii=False))
