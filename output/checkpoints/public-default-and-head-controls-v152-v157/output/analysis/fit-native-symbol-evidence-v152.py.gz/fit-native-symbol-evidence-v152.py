"""Two fixed source-evidence rankers, repo-excluded exposed development only."""
import json,sys,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from fit_score_calibration import fitted,summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import interpret
from ken.retrieval.model import SearchRequest

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def stats(v):
 v=np.array(v,dtype=float);n=len(v);best=v[0];second=v[1] if n>1 else best;m=v.mean();std=max(1e-9,float(v.std()))
 return np.column_stack((v,v-best,v-m,(v-m)/std,1/np.arange(1,n+1),np.full(n,best-second),v-np.where(v==best,second,best)))
base=Path('output/development/score-calibration-v147');capture=Path('output/development/native-symbol-evidence-v152');dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False);reg=json.loads((capture/'registration.json').read_text());assert reg['status']=='ALL250native source observations closed without Gold';lock=json.loads((base/'fit-manifest.json').read_text());registration={'scope':'H1source251+native7;H2plusrequest/source-test2. Symbols only;fixed recipe;LORO; EXPOSED development','capture_registration_sha256':sha(capture/'registration.json'),'manifest_sha256':sha(base/'fit-manifest.json'),'script_sha256':sha(__file__),'parameters':lock['parameters'],'pool_policies':['same_native10','expand_native100'],'status':'registered before exposed Gold reads','folds':{}};(dest/'registration.json').write_text(json.dumps(registration,indent=2));cases={};gold={};oldobs={}
for c in lock['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 for r in rows(c['public_cases']):cases[r['id']]={**r,'cohort':c['name'],'query_kind':r['query_style']}
 for p,digest in c['exposed_gold_pins'].items():
  assert sha(p)==digest
  for g in rows(p):gold[g['id']]=g
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  for o in rows(p):oldobs[o['id']]=o
assert set(cases)==set(gold)==set(oldobs) and len(cases)==400
obs={};x=[];xroles=[];y=[];qids=[];repos=[];kinds=[];groups={};start=0;names=None
for repo,pins in reg['closed'].items():
 for filename,digest in pins.items():assert sha(capture/repo/filename)==digest
 data=np.load(capture/repo/'features.npz',allow_pickle=False);current=tuple(data['features']);assert names is None or current==names;names=current
 for o in rows(capture/repo/'observations.jsonl'):
  q=o['id'];assert q not in obs and q in cases and o['query']==cases[q]['query'];obs[q]=o;n=len(o['units']);mat=data['x'][data['qid']==q];assert mat.shape==(n,251);assert o['units'][:min(10,n)]==oldobs[q]['units'][:min(10,n)],q
  x.append(np.column_stack((mat,stats(o['native_scores']))));asked=interpret(SearchRequest(o['query'])).purpose=='tests';xroles.append(np.column_stack((np.full(n,float(asked)),np.array(o['roles'])=='test')));y.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);qids.extend([q]*n);repos.extend([repo]*n);kinds.extend(['symbol']*n);groups[q]=np.arange(start,start+n);start+=n
assert len(obs)==250
x=np.concatenate(x);roles=np.concatenate(xroles);qids,repos,kinds,y=map(np.asarray,(qids,repos,kinds,y));statnames=('raw','to_max','mean_delta','z','reciprocal_rank','gap_top2','winning_margin');h1names=(*names,*(f'native_{s}' for s in statnames));matrices={'H1_source258':x,'H2_source260':np.column_stack((x,roles))};schemas={'H1_source258':h1names,'H2_source260':(*h1names,'request_tests','candidate_test')};results={}
for variant,matrix in matrices.items():
 scores=np.empty(len(matrix));folds=[]
 for held in sorted(set(repos)):
  model,receipt=fitted(matrix,y,qids,repos,kinds,schemas[variant],held);folds.append(receipt);mask=repos==held;scores[mask]=model.predict(matrix[mask]);(dest/(variant+'-'+held+'.json')).write_text(json.dumps(model.to_dict(),separators=(',',':')))
 registration['folds'][variant]=folds
 for policy in ['same_native10','expand_native100']:
  outcomes=[];orders=[]
  for q,c in cases.items():
   if q in obs:
    o=obs[q];ix=groups[q];n=min(10,len(ix)) if policy=='same_native10' else len(ix);order=sorted(range(n),key=lambda i:(-o['exact'][i],-scores[ix[i]],i));units=[o['units'][i] for i in order[:10]];pool=o['units']
   else:units=oldobs[q]['baseline_units'];pool=units
   hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units)),'recall100':any(map(hit,pool))});orders.append({'id':q,'units':units})
  key=variant+'_'+policy;result=summarize(outcomes);result['recall100']=sum(r['recall100'] for r in outcomes);results[key]=result;(dest/(key+'-outcomes.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in outcomes));(dest/(key+'-orders.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in orders));print(json.dumps({'variant':key,'total':result['total'],'cohort':result['cohort'],'recall100':result['recall100']}),flush=True)
registration['status']='ALL H1/H2 xsame10/expand100development controls closed; no reserve';(dest/'registration.json').write_text(json.dumps(registration,indent=2));(dest/'summary.json').write_text(json.dumps(results,indent=2))
