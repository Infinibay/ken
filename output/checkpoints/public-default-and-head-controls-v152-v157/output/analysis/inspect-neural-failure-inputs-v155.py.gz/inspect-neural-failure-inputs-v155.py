import json,sys
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
base=Path('output/development/score-calibration-v147');m=json.loads((base/'fit-manifest.json').read_text());c=m['cohorts'][1];gold={g['id']:g for p in c['exposed_gold_pins'] for g in map(json.loads,Path(p).read_text().splitlines())};record={r['id']:r for p in Path('output/development/joint-head-evidence-v153').glob('*/observations.jsonl') for r in map(json.loads,p.read_text().splitlines())};rows=[]
for p in Path(c['capture']).glob('*/observations.jsonl'):
 for o in map(json.loads,p.read_text().splitlines()):
  n=record[o['id']];correct=next((i for i,u in enumerate(o['units']) if identity_hit({'unit':u},gold[o['id']]['acceptable_units'])),None);winner=max(range(len(n['logits'])),key=lambda i:n['logits'][i]);
  if correct is not None and correct!=winner:rows.append({'id':o['id'],'repo':o['repo_id'],'tokens_correct':n['pair_tokens'][correct],'tokens_winner':n['pair_tokens'][winner],'query':o['query'],'gold':o['units'][correct],'winner':o['units'][winner]})
print('misses_present',len(rows),'correct_hits_cap',sum(r['tokens_correct']==512 for r in rows),'winner_hits_cap',sum(r['tokens_winner']==512 for r in rows));print(json.dumps(rows,indent=2,ensure_ascii=False))
