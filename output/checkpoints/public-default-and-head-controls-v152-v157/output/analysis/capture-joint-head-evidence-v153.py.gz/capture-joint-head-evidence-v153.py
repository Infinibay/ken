"""Observe existing joint hidden values on public exposed symbols; no reference IO."""
import json,sys,hashlib,subprocess,os,time,resource
from pathlib import Path
import numpy as np
import onnx
from ken.retrieval.best_resources import default_resources
from ken.retrieval.neural_assets import default_reranker
from ken.retrieval.neural_reranker import ONNXReranker,RerankerAssets
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.piece_cards import build_card,card_text
from ken.retrieval.model import EntityKey
from dataclasses import replace

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();base=w/'output/development/score-calibration-v147';m=json.loads((base/'fit-manifest.json').read_text());out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
 original=default_reranker()._prepare();original.verify();g=onnx.load(original.graph);name='ken_published_head/norm';assert any(n.op_type=='LayerNormalization' and list(n.output)==[name] for n in g.graph.node);g.graph.output.append(onnx.helper.make_tensor_value_info(name,onnx.TensorProto.FLOAT,['batch_size',512]));onnx.checker.check_model(g);onnx.save(g,out/'observed.onnx')
 rec={'scope':'ALL250EXPOSED public symbol queries; no labels; original v102joint inputs andCPU4/1batch1max512','original_graph':str(original.graph),'original_graph_sha256':sha(original.graph),'observed_graph_sha256':sha(out/'observed.onnx'),'hidden_name':name,'producer_sha256':sha(__file__),'fit_manifest_sha256':sha(base/'fit-manifest.json'),'closed':{}}
 # Confirm the added output does not alter synthetic first-output logits.
 test=ONNXReranker(lambda:replace(original,graph=out/'observed.onnx',graph_sha256=rec['observed_graph_sha256']));q='find stored value';docs=['def get(key): return values[key]','def put(key,value): values[key]=value'];a,_=default_reranker().score(q,docs);b,_=test.score(q,docs);assert np.array_equal(a,b);test._load();encoded=test._tokenizer.encode_batch([(q,d) for d in docs]);feeds={'input_ids':np.array([e.ids for e in encoded],np.int64),'attention_mask':np.array([e.attention_mask for e in encoded],np.int64)};_,hidden=test._session.run([test._output,name],feeds);assert hidden.shape==(2,512) and np.isfinite(hidden).all();rec['source_free_parity']='EXACT';(out/'registration.json').write_text(json.dumps(rec,indent=2));del test
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],check=True,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250joint public observations closed without Gold';(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
reg=json.loads((out.parent/'registration.json').read_text());original=default_reranker()._prepare();resources=default_resources();neural=ONNXReranker(lambda:replace(original,graph=out.parent/'observed.onnx',graph_sha256=reg['observed_graph_sha256']));neural._load();hidden_name=reg['hidden_name'];observations=[];mat=[];qids=[];maxdiff=0.
with project_connection(Path('/private/tmp/ken-public-default-v143/repos')/repo) as conn:
 catalog=SourceCatalog(Path('/private/tmp/ken-public-default-v143/repos')/repo,owner_passages(conn))
 for c in m['cohorts']:
  for o in rows(Path(c['capture'])/repo/'observations.jsonl'):
   if o['target_kind']!='symbol':continue
   q=o['id'];expanded=resources.owner_ranker.prepare_query(o['query']);texts=[card_text(build_card(EntityKey(path=u['path'],**u['entity']),'symbol',[EntityKey(path=u['path'],**u['entity'])],expanded,catalog)) for u in o['units']];values=[];logits=[];tokens=[];start=time.perf_counter()
   for text in texts:
    e=neural._tokenizer.encode(expanded,text);feeds={'input_ids':np.array([e.ids],np.int64),'attention_mask':np.array([e.attention_mask],np.int64)};logit,h=neural._session.run([neural._output,hidden_name],feeds);assert h.shape==(1,512) and np.isfinite(h).all();values.append(h[0]);logits.append(float(logit.reshape(-1)[0]));tokens.append(sum(e.attention_mask))
   expected=np.empty(len(logits));expected[o['piece_order']]=o['neural_scores'];diff=float(np.max(np.abs(np.array(logits)-expected)));maxdiff=max(maxdiff,diff)
   # Record any optimizer rounding; semantic input reconstruction is separately pinned.
   assert diff<1e-5,(q,diff)
   mat.append(np.array(values,dtype=np.float32));qids.extend([q]*len(values));observations.append({'id':q,'repo_id':repo,'units':o['units'],'expanded_query':expanded,'logits':logits,'max_abs_score_difference':diff,'input_hashes':[hashlib.sha256(t.encode()).hexdigest() for t in texts],'pair_tokens':tokens,'observer_ms':(time.perf_counter()-start)*1000});print(json.dumps({'id':q,'max_abs_difference':diff}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(mat),qid=np.array(qids));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'repo':repo,'queries':len(observations),'max_abs_score_difference':maxdiff,'peak_rss_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'note':'joint-output observer, not full-search latency'},indent=2))
