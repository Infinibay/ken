"""Current real MCP default, exposed development only; immutable unit evaluator."""
import json,sys,hashlib,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'experiments/search-engine')
import unseen_piece_score as grading
from public_default_three_arm_score import validate_public_closure
from ken.bench.source_receipts import verify_frozen_source
w=Path.cwd();manifest=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());result={}
for name,subdir in [('original200','public-default-v155-original'),('new_symbol200','public-default-v157-symbols')]:
 root=w/'output/development'/subdir;lock=json.loads((root/'lock.json').read_text());capture=root/'capture';regpath=capture/'registration.json'
 while not regpath.exists() or json.loads(regpath.read_text()).get('status')!=lock['closed_status']:time.sleep(15)
 reg=json.loads(regpath.read_text());assert reg['lock_sha256']==grading.sha(root/'lock.json') and reg['variant_policy']==lock['variant_policy'];assert verify_frozen_source(Path(lock['engine_root']))==lock['source_receipt']
 for path,digest in lock['input_pins'].items():assert grading.sha(path)==digest
 cases=grading.rows(lock['public_cases']);assert len(cases)==200;validate_public_closure(capture,cases,production=True);answers=[];times=[];rss=[];perrepo={};cpu=[]
 for repo,pins in reg['closed'].items():
  assert set(pins)=={'answers.jsonl','performance.json'}
  for f,d in pins.items():assert grading.sha(capture/repo/f)==d
  ans=grading.rows(capture/repo/'answers.jsonl');perf=json.loads((capture/repo/'performance.json').read_text());assert perf['providers']==['CPUExecutionProvider'] and not perf['heavy_imports'] and perf['source_receipt']==lock['source_receipt'];answers.extend(ans);t=[r['ms'] for r in perf['timings']];times.extend(t);mem=perf['peak_rss_native']*(1 if perf['rss_unit']=='bytes' else 1024);rss.append(mem);cpu.append(perf['server_cpu_total_ms']);perrepo[repo]={'p50_ms':float(np.median(t)),'p95_ms':float(np.quantile(t,.95)),'peak_rss_bytes':mem,'files':perf['indexed_files']}
  for a in ans:
   grading.validate_returned_units(a);assert len(a['units'])==len(a['public_response']['results'])
   for u,r in zip(a['units'],a['public_response']['results']):assert u=={'target_kind':r['piece_kind'],'path':r['path'],'entity':r['entity'] if r['piece_kind'] in {'class','symbol'} else None,'module_name':r.get('module_name') if r['piece_kind']=='module' else None} and not r['stale']
 assert set(grading.unique(answers))==set(grading.unique(cases))
 # Only named exposed development references admitted; never private reserves.
 cohort=next(c for c in manifest['cohorts'] if c['name']==name);assert cohort['public_cases']==lock['public_cases'];references=[]
 for p,d in cohort['exposed_gold_pins'].items():assert grading.sha(p)==d;references.extend(grading.rows(p))
 quality,outcomes=grading.evaluate_identity(cases,answers,references);runtime={'p50_ms':float(np.median(times)),'p95_ms':float(np.quantile(times,.95)),'max_ms':max(times),'peak_rss_bytes':max(rss),'server_cpu_total_ms':sum(cpu),'per_query_cpu_ms':None,'per_repo':perrepo};report={'scope':'EXPOSED development only, all200actual MCP public default; no independent validation','quality':quality,'cpu':runtime,'capture_registration_sha256':grading.sha(regpath),'source_receipt':lock['source_receipt'],'scorer_sha256':grading.sha(__file__),'identity_evaluator_sha256':grading.sha('experiments/search-engine/verifiable_grading.py')}
 if name=='original200':
  old={a['id']:a for p in (w/'output/development/public-default-v145-original/capture').glob('*/answers.jsonl') for a in grading.rows(p)};report['orders_identical_to_public145']=sum(a['units']==old[a['id']]['units'] for a in answers);assert report['orders_identical_to_public145']==200
 (root/'summary.json').write_text(json.dumps(report,indent=2));(root/'outcomes.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in outcomes));result[name]=report;print(json.dumps({'cohort':name,'top1':quality['top1'],'recall10':quality['recall10'],'cpu':{k:runtime[k] for k in ['p50_ms','p95_ms','max_ms','peak_rss_bytes']}}),flush=True)
(w/'output/analysis/current-public-development-v155-v157-summary.json').write_text(json.dumps(result,indent=2))
