"""Prospective K: query-only source-role preference, same frozen native10/NN logits."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from sklearn.linear_model import LogisticRegression
from verifiable_grading import identity_hit
from fit_score_calibration import summarize
from ken.retrieval.intent import interpret
from ken.retrieval.model import SearchRequest
from ken.embedder.model2vec_backend import Model2VecEmbedder,potion_assets

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
base=Path('output/development/score-calibration-v147');manifest=json.loads((base/'fit-manifest.json').read_text());dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False)
registration={'scope':'K EXPOSED250symbols query-only role LogisticRegression C1/class_weight balanced/lbfgs; LORO; final score fixed rawNN+log estimated source-role preference; no newNN calls or changed pool','policy':'Features256Potion(query expanded) + explicit interpreted tests + identity + identifier test-convention. Other150oldqueries unchanged. Clip p1e-6. No HPO, no private data. All400report. Require old180/197,new180beforefreshreserve.','producer_sha256':sha(__file__),'status':'registered before labels','folds':[]};(dest/'registration.json').write_text(json.dumps(registration,indent=2))
cases={};gold={};oldobs={};extra={o['id']:o for p in Path('output/development/ranking-evidence-v149').glob('*/observations.jsonl') for o in rows(p)};native={o['id']:o for p in Path('output/development/native-symbol-evidence-v152').glob('*/observations.jsonl') for o in rows(p)}
for c in manifest['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 for q in rows(c['public_cases']):cases[q['id']]={**q,'cohort':c['name'],'query_kind':q['query_style']}
 for p,d in c['exposed_gold_pins'].items():
  assert sha(p)==d
  for g in rows(p):gold[g['id']]=g
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  for o in rows(p):oldobs[o['id']]=o
qids=[q for q,c in cases.items() if c['target_kind']=='symbol'];vectors=Model2VecEmbedder(potion_assets()).registered.embed_passages([extra[q]['expanded_query'] for q in qids]);x=[];y=[];repos=[];roles={}
for i,q in enumerate(qids):
 o=native[q];lookup={json.dumps(u,sort_keys=True):r for u,r in zip(o['units'],o['roles'])};roles[q]=[lookup[json.dumps(u,sort_keys=True)] for u in oldobs[q]['units']];correct=next(j for j,u in enumerate(o['units']) if identity_hit({'unit':u},gold[q]['acceptable_units']));y.append(int(o['roles'][correct]=='test'));repos.append(cases[q]['repo_id']);intent=interpret(SearchRequest(cases[q]['query']));identifier_test=any('test' in name.casefold() for name in intent.identifiers);x.append(np.r_[vectors[i],[float(intent.purpose=='tests'),float(intent.identity),float(identifier_test)]])
x=np.asarray(x);y=np.asarray(y);repos=np.asarray(repos);prob=np.empty(len(x));folds=[]
for held in sorted(set(repos)):
 train=repos!=held;test=~train;model=LogisticRegression(C=1,class_weight='balanced',solver='lbfgs',max_iter=1000,random_state=42);model.fit(x[train],y[train]);prob[test]=model.predict_proba(x[test])[:,1];folds.append({'held_out':held,'training_repos':sorted(set(repos[train])),'role_correct':int(((prob[test]>=.5)==y[test]).sum()),'queries':int(test.sum())});(dest/(held+'.json')).write_text(json.dumps({'weights':model.coef_[0].tolist(),'bias':float(model.intercept_[0])},separators=(',',':')))
byq=dict(zip(qids,prob));outcomes=[];orders=[]
for q,c in cases.items():
 o=oldobs[q]
 if q in byq:
  p=float(np.clip(byq[q],1e-6,1-1e-6));nn=np.empty(len(o['units']));nn[o['piece_order']]=o['neural_scores'];score=nn+np.array([np.log(p if r=='test' else 1-p) for r in roles[q]]);order=sorted(range(len(nn)),key=lambda i:(-o['exact'][i],-score[i],i));units=[o['units'][i] for i in order]
 else:units=o['baseline_units']
 hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
summary=summarize(outcomes);summary['source_role_classifier']={'correct':int(((prob>=.5)==y).sum()),'queries':len(y),'folds':folds};registration['folds']=folds;registration['status']='K all400development evaluation closed; no reserve';(dest/'registration.json').write_text(json.dumps(registration,indent=2));(dest/'summary.json').write_text(json.dumps(summary,indent=2));(dest/'outcomes.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(dest/'orders.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'total':summary['total'],'cohort':summary['cohort'],'role_classifier':summary['source_role_classifier']},indent=2))
