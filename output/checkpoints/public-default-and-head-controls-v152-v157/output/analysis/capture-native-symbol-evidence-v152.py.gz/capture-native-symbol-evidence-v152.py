"""Observe the actual frozen owner frontier through public find_best; no labels."""
import json,sys,hashlib,subprocess,os,time,resource
from pathlib import Path
import numpy as np
from ken.retrieval.public import find_best
from ken.retrieval.connections import project_connection
from ken.retrieval.owner_ranking import EvidenceReranker
from ken.retrieval.piece_catalog import SYMBOL_KINDS
from ken.retrieval.model import SearchResponse

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();base=w/'output/development/score-calibration-v147';m=json.loads((base/'fit-manifest.json').read_text());cases=[]
for c in m['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 cases.extend({**r,'cohort':c['name']} for r in rows(c['public_cases']) if r['target_kind']=='symbol')
assert len(cases)==250 and all('acceptable_units' not in c for c in cases)
out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
 rec={'scope':'PUBLIC EXPOSED250symbol observations only, frontier100beforelabels; no final-response or production quality claim','cases':len(cases),'public_case_pins':{c['public_cases']:c['public_sha256'] for c in m['cohorts']},'producer_sha256':sha(__file__),'source':'frozen public145 owner ranker and all251features, first100eligible symbols by native score; query/candidate purpose roles recorded','closed':{}}
 (out/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in sorted({r['repo_id'] for r in cases}):
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],check=True,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250native source observations closed without Gold';(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
class Closed(Exception):pass
record={};orig=EvidenceReranker.rank
class Observer:
 def record(self,**kw):
  assert kw['values'] is not None
  candidates=kw['candidates'];idx={c.entity:i for i,c in enumerate(candidates)};matches=[m for m in kw['matches'] if m.entity.kind in SYMBOL_KINDS][:100];indices=[idx[m.entity] for m in matches]
  record.update(x=kw['values'][indices].copy(),features=kw['model'].features,units=[{'target_kind':'symbol','path':m.entity.path,'entity':m.entity.to_dict(),'module_name':None} for m in matches],native_scores=[m.score for m in matches],exact=[m.signals.get('exact',0.) for m in matches],roles=[candidates[i].passages[0].role for i in indices],expanded_query=kw['expanded'],candidate_count=len(candidates),source_hashes=[m.source_hash for m in matches]);raise Closed
observer=Observer()
def ranked(self,request,candidates,descriptions,**kwargs):kwargs['trace']=observer;return orig(self,request,candidates,descriptions,**kwargs)
EvidenceReranker.rank=ranked
cases=[c for c in cases if c['repo_id']==repo];obs=[];mat=[];qids=[];names=None
with project_connection(Path('/private/tmp/ken-public-default-v143/repos')/repo) as conn:
 for c in cases:
  record.clear();before=time.perf_counter()
  try:find_best(conn,Path('/private/tmp/ken-public-default-v143/repos')/repo,c['query'],scope='symbols',piece_kind='symbol')
  except Closed:pass
  assert 'x' in record,c['id'];x=record.pop('x');current=record.pop('features');assert names is None or names==current;names=current;assert x.shape==(len(record['units']),len(names)) and np.isfinite(x).all();mat.append(x);qids.extend([c['id']]*len(x));obs.append({**{k:c[k] for k in ['id','repo_id','target_kind','query','language','query_style','cohort']},'observer_ms':(time.perf_counter()-before)*1000,**record});print(json.dumps({'id':c['id'],'rows':len(x)}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(mat),qid=np.array(qids),features=np.array(names));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in obs));(out/'summary.json').write_text(json.dumps({'repo':repo,'queries':len(obs),'rows':len(qids),'features':len(names),'peak_rss_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'note':'Frontier observer raises after rank; no final answers/NN executed; not end-to-end latency'},indent=2))
