import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
base=Path('output/development/score-calibration-v147');lock=json.loads((base/'fit-manifest.json').read_text());capture=Path('output/development/joint-head-evidence-v153');fit=Path('output/development/joint-head-fit-v153');gold={g['id']:g for c in lock['cohorts'] for p in c['exposed_gold_pins'] for g in map(json.loads,Path(p).read_text().splitlines())};data=[]
for p in capture.glob('*/observations.jsonl'):
 d=np.load(p.with_name('features.npz'))
 for o in map(json.loads,p.read_text().splitlines()):data.append((o,d['x'][d['qid']==o['id']]))
results={}
for variant,residual in [('J1_direct512',False),('J2_residual512',True)]:
 folds=[]
 for p in fit.glob(variant+'-*.json'):
  model=json.loads(p.read_text());held=p.stem[len(variant)+1:];count=0;hit=0;available=0
  for o,x in data:
   if o['repo_id']==held:continue
   y=[bool(identity_hit({'unit':u},gold[o['id']]['acceptable_units'])) for u in o['units']]
   if not any(y):continue
   score=x@np.array(model['weights'])+(np.array(o['logits']) if residual else 0.);count+=1;hit+=bool(y[int(np.argmax(score))]);available+=sum(y)
  folds.append({'held_out':held,'train_positive_queries':count,'train_top1':hit,'rate':hit/count})
 results[variant]=folds
Path('output/analysis/joint-head-training-diagnostics-v153.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
