import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
from ken.retrieval.intent import interpret
from ken.retrieval.model import SearchRequest
r=Path('output/development/score-calibration-v147');m=json.loads((r/'fit-manifest.json').read_text());ao={o['id']:o['units'] for o in map(json.loads,(r/'fit/A_compact34-cv-orders.jsonl').read_text().splitlines())};summary={};rows=[]
for c in m['cohorts']:
 gold={g['id']:g for p in c['exposed_gold_pins'] for g in map(json.loads,Path(p).read_text().splitlines())};cases={g['id']:g for g in map(json.loads,Path(c['public_cases']).read_text().splitlines())}
 totals={k:0 for k in ['base','neural','A','base_role','neural_role','A_role']};byrole={}
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  data=np.load(p.with_name('features.npz'));names=data['features'].tolist()
  for o in map(json.loads,p.read_text().splitlines()):
   q=o['id'];hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));mat=data['x'][data['qid']==q];units=o['units'];test={json.dumps(u,sort_keys=True):bool(mat[i,names.index('test_path')]) for i,u in enumerate(units)};asked=interpret(SearchRequest(o['query'])).purpose=='tests';nn=o['neural_scores'];order=o['piece_order'];neural=[units[order[i]] for i in sorted(range(len(nn)),key=lambda i:(-nn[i],i))]
   orders={'base':o['baseline_units'],'neural':neural,'A':ao[q]}
   for key,us in list(orders.items()):orders[key+'_role']=sorted(us,key=lambda u:asked and not test[json.dumps(u,sort_keys=True)])
   b='explicit_tests' if asked else 'other';byrole.setdefault(b,{k:0 for k in totals}|{'queries':0});byrole[b]['queries']+=1
   for key,us in orders.items():totals[key]+=int(hit(us[0]));byrole[b][key]+=int(hit(us[0]))
 print(c['name'],totals,byrole)
