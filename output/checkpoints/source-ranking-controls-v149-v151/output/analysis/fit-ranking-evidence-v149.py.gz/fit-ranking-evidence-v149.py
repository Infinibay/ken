"""Predeclared independent development ablations; same numeric recipe and pool."""
import json,sys,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from fit_score_calibration import fitted,summarize
from score_calibration import calibration_features,CALIBRATION_FEATURES
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest
from ken.retrieval.piece_ranking import PIECE_FEATURES

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def stats(values,order):
 values=np.asarray(values,dtype=np.float64);n=len(values);rank=np.empty(n);rank[np.asarray(order)[np.argsort(-values[order],kind='stable')]]=np.arange(1,n+1)
 top=np.sort(values)[::-1];best=top[0];second=top[1] if n>1 else best;mean=values.mean();std=max(1e-9,float(values.std()))
 return np.column_stack((values,values-best,values-mean,(values-mean)/std,1/rank,np.full(n,best-second),values-np.where(values==best,second,best)))
base=Path('output/development/score-calibration-v147');capture=Path('output/development/ranking-evidence-v149');dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False);lock=json.loads((base/'fit-manifest.json').read_text());reg=json.loads((capture/'registration.json').read_text());assert reg['status']=='ALL400public evidence observations closed without Gold';assert reg['fit_manifest_sha256']==sha(base/'fit-manifest.json');extra={}
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(capture/repo/f)==d
 for o in rows(capture/repo/'observations.jsonl'):assert o['id'] not in extra;extra[o['id']]=o
registration={'scope':'EXPOSED development only; Dcontext42, E1owned7, E2scope7 each plus original A34; unchanged actual unit pools; same fixed recipe','input_manifest_sha256':sha(base/'fit-manifest.json'),'capture_registration_sha256':sha(capture/'registration.json'),'producer_sha256':sha(__file__),'parameters':lock['parameters'],'status':'registered before opening exposed labels','folds':{}};(dest/'registration.json').write_text(json.dumps(registration,indent=2))
obs={};cases={};gold={};source={}
for c in lock['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 for x in rows(c['public_cases']):cases[x['id']]={**x,'cohort':c['name'],'query_kind':x['query_style']}
 assert sha(Path(c['capture'])/'registration.json')==c['capture_registration_sha256'];cr=json.loads((Path(c['capture'])/'registration.json').read_text())
 for repo,pins in cr['closed'].items():
  for f,d in pins.items():assert sha(Path(c['capture'])/repo/f)==d
  data=np.load(Path(c['capture'])/repo/'features.npz',allow_pickle=False)
  for o in rows(Path(c['capture'])/repo/'observations.jsonl'):q=o['id'];obs[q]=o;source[q]=data['x'][data['qid']==q]
 for path,d in c['exposed_gold_pins'].items():
  assert sha(path)==d
  for g in rows(path):gold[g['id']]=g
assert set(cases)==set(obs)==set(gold)==set(extra) and len(cases)==400
qids=[];repos=[];kinds=[];labels=[];mat={v:[] for v in ['D_context42','E1_owned7','E2_scope7']};groups={};start=0
statnames=('raw','to_max','mean_delta','z','reciprocal_rank','gap_top2','winning_margin');ctxnames=tuple(f'context_{view}_{query}_{stat}' for view in ['full','contract','implementation'] for query in ['original','expanded'] for stat in statnames);schemas={'D_context42':(*CALIBRATION_FEATURES,*ctxnames),'E1_owned7':(*CALIBRATION_FEATURES,*(f'owned_{s}' for s in statnames)),'E2_scope7':(*CALIBRATION_FEATURES,*(f'scope_{s}' for s in statnames))}
for q,o in obs.items():
 assert not o.get('exact_bypass');e=extra[q];assert o['units']==e['units'];n=len(o['units']);order=o['piece_order'];basefeatures=calibration_features(source[q],**{k:o[k] for k in ['piece_order','piece_scores','neural_scores','exact']})
 cs=np.asarray(e['context_scores']);assert cs.shape==(n,6);ctx=np.column_stack([stats(cs[:,j],order) for j in range(6)])
 native_nn=np.empty(n);native_nn[order]=o['neural_scores'];owned=e.get('neural_owned',native_nn);scope=e.get('neural_scope',native_nn)
 mat['D_context42'].append(np.column_stack((basefeatures,ctx)));mat['E1_owned7'].append(np.column_stack((basefeatures,stats(owned,order))));mat['E2_scope7'].append(np.column_stack((basefeatures,stats(scope,order))))
 labels.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);qids.extend([q]*n);repos.extend([o['repo_id']]*n);kinds.extend([o['target_kind']]*n);groups[q]=np.arange(start,start+n);start+=n
qids,repos,kinds,y=map(np.asarray,(qids,repos,kinds,labels));results={}
for variant,blocks in mat.items():
 x=np.concatenate(blocks);assert np.isfinite(x).all() and x.shape[1]==len(schemas[variant]);scores=np.empty(len(x));folds=[]
 for held in sorted(set(repos)):
  model,receipt=fitted(x,y,qids,repos,kinds,schemas[variant],held);folds.append(receipt);sel=repos==held;scores[sel]=model.predict(x[sel]);(dest/(variant+'-'+held+'.json')).write_text(json.dumps(model.to_dict(),separators=(',',':')))
 outcomes=[];orders=[]
 for q,o in obs.items():
  c=cases[q];ix=groups[q];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(ix)),key=lambda i:(-int(named is not None and o['units'][i]['path']==named),-o['exact'][i],-scores[ix[i]],i));units=[o['units'][i] for i in order];hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']))
  outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':hit(units[0]),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[variant]=result;registration['folds'][variant]=folds;(dest/(variant+'-outcomes.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(dest/(variant+'-orders.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'variant':variant,'total':result['total'],'cohort':result['cohort']}),flush=True)
registration['status']='ALL predeclared development CV controls closed, no reserve Gold';(dest/'registration.json').write_text(json.dumps(registration,indent=2));(dest/'summary.json').write_text(json.dumps(results,indent=2))
