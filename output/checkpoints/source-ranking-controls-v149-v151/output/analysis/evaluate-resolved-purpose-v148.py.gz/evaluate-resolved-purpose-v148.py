"""One development-only feature correction, fixed recipe, unchanged candidate pool."""
import json,sys,hashlib,time,itertools
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from fit_score_calibration import fitted,summarize
from score_calibration import calibration_features,CALIBRATION_FEATURES
from verifiable_grading import identity_hit
from ken.retrieval.intent import interpret,requested_piece_path
from ken.retrieval.model import SearchRequest
from ken.retrieval.piece_ranking import PIECE_FEATURES
r=Path('output/development/score-calibration-v147');m=json.loads((r/'fit-manifest.json').read_text());out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
(out/'registration.json').write_text(json.dumps({'scope':'EXPOSED development only; C34correct resolved original public purpose, no new model calls or pool changes','recipe':m['parameters'],'input_manifest_sha256':sha(r/'fit-manifest.json'),'intent_source':sha(Path(sys.modules['ken.retrieval.intent'].__file__)),'feature_source':sha(Path(sys.modules['ken.retrieval.piece_ranking'].__file__)),'status':'registered before fitting'},indent=2))
x=[];y=[];qids=[];repos=[];kinds=[];cases={};obs={};gold={};groups={};changed=[];start=0
for cohort in m['cohorts']:
 for p,digest in cohort['exposed_gold_pins'].items():
  assert sha(p)==digest
  for g in map(json.loads,Path(p).read_text().splitlines()):gold[g['id']]=g
 for c in map(json.loads,Path(cohort['public_cases']).read_text().splitlines()):cases[c['id']]={**c,'cohort':cohort['name'],'query_kind':c['query_style']}
 regpath=Path(cohort['capture'])/'registration.json';assert sha(regpath)==cohort['capture_registration_sha256'];reg=json.loads(regpath.read_text())
 for repo,pins in reg['closed'].items():
  for name,digest in pins.items():assert sha(Path(cohort['capture'])/repo/name)==digest
  d=np.load(Path(cohort['capture'])/repo/'features.npz',allow_pickle=False)
  for o in map(json.loads,(Path(cohort['capture'])/repo/'observations.jsonl').read_text().splitlines()):
   q=o['id'];obs[q]=o;assert not o.get('exact_bypass');n=len(o['units']);mat=d['x'][d['qid']==q].copy();c=cases[q];intent=interpret(SearchRequest(c['query'],piece_kind=c['target_kind']))
   before=mat[:,PIECE_FEATURES.index('request_tests')].copy();mat[:,PIECE_FEATURES.index('request_tests')]=float(intent.purpose=='tests')
   if not np.array_equal(before,mat[:,PIECE_FEATURES.index('request_tests')]):changed.append(q)
   x.append(calibration_features(mat,**{k:o[k] for k in ['piece_order','piece_scores','neural_scores','exact']}));y.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);qids.extend([q]*n);repos.extend([repo]*n);kinds.extend([c['target_kind']]*n);groups[q]=np.arange(start,start+n);start+=n
x=np.concatenate(x);y,qids,repos,kinds=map(np.asarray,(y,qids,repos,kinds));pred=np.empty(len(x));folds=[]
for held in sorted(set(repos)):
 model,receipt=fitted(x,y,qids,repos,kinds,CALIBRATION_FEATURES,held);folds.append(receipt);sel=repos==held;pred[sel]=model.predict(x[sel]);(out/(held+'.json')).write_text(json.dumps(model.to_dict(),separators=(',',':')))
rows=[];orders=[]
for q,o in obs.items():
 c=cases[q];ix=groups[q];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(ix)),key=lambda i:(-int(named is not None and o['units'][i]['path']==named),-o['exact'][i],-pred[ix[i]],i));units=[o['units'][i] for i in order];hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']))
 rows.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':hit(units[0]),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
summary=summarize(rows);summary['changed_queries']=len(changed);(out/'summary.json').write_text(json.dumps(summary,indent=2));(out/'outcomes.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows));(out/'orders.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in orders));(out/'folds.json').write_text(json.dumps(folds,indent=2));print(json.dumps(summary,indent=2))
