import json,sys,collections
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
base=Path('output/development/score-calibration-v147');lock=json.loads((base/'fit-manifest.json').read_text());capture=Path('output/development/ranking-evidence-v149');reg=json.loads((capture/'registration.json').read_text());assert reg['status']=='ALL400public evidence observations closed without Gold';extra={r['id']:r for p in capture.glob('*/observations.jsonl') for r in map(json.loads,p.read_text().splitlines())};results={};outcomes=[]
for c in lock['cohorts']:
 gold={r['id']:r for p in c['exposed_gold_pins'] for r in map(json.loads,Path(p).read_text().splitlines())};summary=collections.Counter()
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  for o in map(json.loads,p.read_text().splitlines()):
   q=o['id'];e=extra[q];hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));units=o['units'];base=[0]*len(units)
   for i,j in enumerate(o['piece_order']):base[j]=o['neural_scores'][i]
   vs={'old':base,'owned':e.get('neural_owned',base),'scope':e.get('neural_scope',base)}; row={'id':q,'cohort':c['name']};summary['queries']+=1
   for key,values in vs.items():
    order=sorted(range(len(units)),key=lambda i:(-values[i],i));rank=next((j+1 for j,i in enumerate(order) if hit(units[i])),None);row[key]=rank;summary[key]+=rank==1
   row['oracle_neural_top1']=any(row[k]==1 for k in vs);summary['oracle_neural_top1']+=row['oracle_neural_top1'];outcomes.append(row)
 results[c['name']]=dict(summary)
print(json.dumps(results,indent=2));(capture/'neural-stage-diagnostics.json').write_text(json.dumps(results,indent=2));(capture/'neural-stage-diagnostics.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in outcomes))
