"""Public exposed queries only: existing raw context signals and two bounded source projections."""
import json,sys,time,hashlib,os,subprocess,resource
from pathlib import Path
import numpy as np
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.context_preparation import prepare_context
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.model import EntityKey
from ken.retrieval.storage import generation as source_generation
from ken.bench.source_receipts import verify_frozen_source

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
root=Path.cwd();base=root/'output/development/score-calibration-v147';lock=json.loads((base/'fit-manifest.json').read_text());dest=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None
dest.mkdir(exist_ok=False)
if not repo:
 rec={'scope':'EXPOSED public queries only; no reference inputs or ranks changed','fit_manifest_sha256':sha(base/'fit-manifest.json'),'producer_sha256':sha(__file__),'policy':'Context original+expanded full/contract/implementation raw scores; NN compact raw owned prefix and authenticated lexical container prefix with same 68M/max512/CPU. Non-symbol unchanged.','closed':{}}
 (dest/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (dest/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(dest/repo),repo],check=True,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
  rec['closed'][repo]={n:sha(dest/repo/n) for n in ['observations.jsonl','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL400public evidence observations closed without Gold';(dest/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
project=Path('/private/tmp/ken-public-default-v143/repos')/repo
resources=default_resources();observations=[]
with project_connection(project) as conn:
 owners=owner_passages(conn);catalog=SourceCatalog(project,owners);generation=source_generation(conn)
 context=prepare_context(catalog,generation,resources.context,project/'.ken/search-context');assert context.source_views
 snapshot=context.vectors;lookup={k:i for i,k in enumerate(snapshot.owners)}
 for cohort in lock['cohorts']:
  p=Path(cohort['capture'])/repo/'observations.jsonl'
  for o in rows(p):
   query=o['query'];expanded=resources.owner_ranker.prepare_query(query)
   def vector(s):
    v=np.array(resources.context.embed_query(s),dtype=np.float32);v/=np.linalg.norm(v);return v
   a=vector(query);b=a if expanded==query else vector(expanded)
   scores=[];owned_texts=[];scope_texts=[];units=o['units'];n=len(units)
   for unit in units:
    # Context is member max for larger requested pieces, direct owner for symbols.
    if unit['entity']:key=EntityKey(path=unit['path'],**unit['entity']);members=[key] if unit['target_kind']=='symbol' else [key]+[k for k,c in catalog.classes.items() if c==key]
    else:members=catalog.by_path[unit['path']]
    indices=np.array([lookup[k] for k in members],dtype=np.int64)
    values=[]
    matrices=[snapshot.matrix[indices],*(context.source_views.matrix[context.source_views.rows[v][indices]] for v in ['contract','implementation'])]
    for vectors in matrices:
     values.extend([float(np.max(vectors@a)),float(np.max(vectors@b))])
    scores.append(values)
    if unit['target_kind']=='symbol':
     header=unit['path']+' '+(key.qualname or '')+'\n'
     text='\n'.join('\n'.join(catalog.lines[key.path][s-1:e]) for s,e in catalog.owned_ranges(key))
     start,end=catalog.extent(key);members=catalog.scope_members(key)
     whole='\n'.join(catalog.lines[key.path][start-1:end]) if members is not None else text
     owned_texts.append(header+text);scope_texts.append(header+whole)
   record={'id':o['id'],'repo_id':repo,'target_kind':o['target_kind'],'expanded_query':expanded,'units':units,'context_scores':scores}
   if owned_texts:
    before=time.perf_counter();owned,od=resources.neural.score(expanded,owned_texts);scope,sd=resources.neural.score(expanded,scope_texts);elapsed=(time.perf_counter()-before)*1000
    record.update(neural_owned=owned,neural_scope=scope,owned_sha256=[hashlib.sha256(s.encode()).hexdigest() for s in owned_texts],scope_sha256=[hashlib.sha256(s.encode()).hexdigest() for s in scope_texts],projection_ms=elapsed,owned_details=od,scope_details=sd)
   observations.append(record);print(json.dumps({'id':o['id'],'captured':True}),flush=True)
(dest/'observations.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in observations));(dest/'summary.json').write_text(json.dumps({'queries':len(observations),'repo':repo,'peak_rss_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'providers':resources.neural.providers,'note':'two additional experimental neural views plus existing context replay, NOT production latency'},indent=2))
