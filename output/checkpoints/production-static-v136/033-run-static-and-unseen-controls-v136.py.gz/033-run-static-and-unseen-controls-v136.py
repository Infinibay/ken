"""Close old200 extraction replay, then public-only frozen new200 controls."""
import hashlib,json,os,subprocess,time
from pathlib import Path

w=Path(__file__).resolve().parents[2]
run=w/'output/development/piece-production-static-v136'
queue=w/'output/development/unseen-cpu-validation-v135/queue-v136.json'
def save(data):queue.write_text(json.dumps(data,indent=2)+'\n')
state={'scope':'Public producers only; no references or quality grading of new200',
       'policy':'132/134 were selected before new public corpus merge. Production arm must still be registered and closed before any new Gold grading.',
       'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'closed':[]}
save(state)
deadline=time.monotonic()+3600
while True:
    try:reg=json.loads((run/'registration.json').read_text())
    except json.JSONDecodeError:reg={}
    if reg.get('status')=='ALL200 complete CPU outputs closed without Gold':break
    if 'Traceback (most recent call last)' in Path('/private/tmp/ken-piece-production-static-v136.log').read_text():
        raise RuntimeError('static replay failed; do not continue the queue')
    if time.monotonic()>deadline:raise TimeoutError('static replay closure timeout')
    time.sleep(2)

def read_rows(root,name):
    result={}
    for p in root.glob('*/'+name):
        for line in p.read_text().splitlines():
            row=json.loads(line)
            if row['id'] in result:raise ValueError('duplicate query ID')
            result[row['id']]=row
    return result
old=w/'output/development/piece-threads4-cpu-v134'
a=read_rows(run,'answers.jsonl');b=read_rows(old,'answers.jsonl')
c=read_rows(run,'orders.jsonl');d=read_rows(old,'orders.jsonl')
if len(a)!=200 or a!=b or set(c)!=set(d):raise ValueError('static extraction changed complete outputs')
order_keys=('native_units','piece_order','fusion_order_in_piece_order','final_order')
if any(any(c[q][k]!=d[q][k] for k in order_keys) for q in c):raise ValueError('static extraction changed orders')
audit={'scope':'Original200 only; exact returned cards/units/pool hashes and all native/piece/final orders equal134',
       'queries':200,'answers_equal':True,'orders_equal':True,'new_gold_accessed':False,
       'reference_registration_sha256':hashlib.sha256((old/'registration.json').read_bytes()).hexdigest(),
       'actual_registration_sha256':hashlib.sha256((run/'registration.json').read_bytes()).hexdigest()}
(run/'parity-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
state['static_original200_parity']=audit;save(state);print('Original200 production-static parity closed',flush=True)
lock=w/'output/development/unseen-cpu-validation-v135/lock-v135c.json'
settings=json.loads(lock.read_text())
caller=w/'output/frozen/unseen-cpu-caller-v135/unseen_piece_cpu_run.py'
for variant in ('baseline','optimized'):
    engine=Path(settings['variants'][variant]['engine_root'])
    output=w/'output/development/unseen-cpu-validation-v135'/('closed-'+variant+'-v136')
    env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(engine/'src')+':'+str(engine/'experiments/search-engine')}
    command=[str(w/'.venv-model-runtime/bin/python'),str(caller),'--workspace',str(w),'--lock',str(lock),'--output',str(output),'--variant',variant]
    with (output.parent/(variant+'-v136.log')).open('w') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    registration=json.loads((output/'registration.json').read_text())
    if registration['status']!='ALL additional public outputs closed without Gold':raise ValueError('unclosed public control')
    state['closed'].append({'variant':variant,'path':str(output),'registration_sha256':hashlib.sha256((output/'registration.json').read_bytes()).hexdigest()})
    save(state);print(variant+' new200 outputs closed; Gold unopened',flush=True)
state['status']='Original200 extraction and both new200 controls closed; no new scoring; production arm pending';save(state)
