"""Fixed raw versus document-control scores; complete EXPOSED400, no private data."""
import json,sys,time,hashlib
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
w=Path.cwd();capture=w/'output/development/current-document-prior-v158';p=capture/'registration.json'
while not p.exists() or json.loads(p.read_text()).get('status')!='ALL250current public document controls closed without Gold':time.sleep(15)
reg=json.loads(p.read_text());extra={}
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(capture/repo/f)==d
 for o in rows(capture/repo/'observations.jsonl'):assert o['id'] not in extra;extra[o['id']]=o
assert len(extra)==250
cases={};baseline={}
for rootname in ['public-default-v155-original','public-default-v157-symbols']:
 root=w/'output/development'/rootname;lock=json.loads((root/'lock.json').read_text());assert sha(root/'capture/registration.json')==reg['source_captures'][str(root/'capture/registration.json')]
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if rootname.endswith('original') else 'new_symbol200','query_kind':c['query_style']}
 for f in (root/'capture').glob('*/answers.jsonl'):
  for a in rows(f):baseline[a['id']]=a
assert set(cases)==set(baseline) and len(cases)==400
manifest=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in manifest['cohorts']:
 for path,d in c['exposed_gold_pins'].items():
  assert sha(path)==d
  for g in rows(path):gold[g['id']]=g
assert set(gold)==set(cases)
results={}
for name,key in [('raw_current_nn','raw_scores'),('L1_query_free_difference','conditional_scores')]:
 outcomes=[];orders=[]
 for q,c in cases.items():
  units=baseline[q]['units']
  if q in extra:
   o=extra[q];assert o['units']==units;named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(units)),key=lambda i:(-int(named is not None and units[i]['path']==named),-o[key][i],i));units=[units[i] for i in order]
  hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[name]=result;(capture/(name+'-outcomes.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in outcomes));(capture/(name+'-orders.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in orders));print(json.dumps({'variant':name,'total':result['total'],'cohort':result['cohort']}),flush=True)
(capture/'development-summary.json').write_text(json.dumps(results,indent=2));(capture/'grading-registration.json').write_text(json.dumps({'scope':'EXPOSED400only','capture_registration_sha256':sha(p),'script_sha256':sha(__file__),'L2_allowed':results['L1_query_free_difference']['cohort']['new_symbol200']['top1']>=results['raw_current_nn']['cohort']['new_symbol200']['top1']+2},indent=2))
