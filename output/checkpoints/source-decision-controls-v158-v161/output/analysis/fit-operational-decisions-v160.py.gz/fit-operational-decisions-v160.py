"""Fixed residual source-evidence heads; EXPOSED development, full-group LORO."""
import json,sys,time,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from linear_decision_training import pairwise_examples,fit_head
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
w=Path.cwd();capture=w/'output/development/operational-evidence-v160';p=capture/'registration.json'
while not p.exists() or json.loads(p.read_text()).get('status')!='ALL250operational public source observations closed without Gold':time.sleep(15)
reg=json.loads(p.read_text());dest=w/'output/development/operational-decision-fit-v160';dest.mkdir(exist_ok=False);registration={'scope':'N1role/reference vsN2adds operational cues, residual rawNN, fixed C1query-balanced pairwiseL2=1/effective_queries; LORO; no private inputs','capture_registration_sha256':sha(p),'producer_sha256':sha(__file__),'training_sha256':sha('experiments/search-engine/linear_decision_training.py'),'status':'registered before exposed labels','folds':{}};(dest/'registration.json').write_text(json.dumps(registration,indent=2));cases={};baseline={};gold={}
for rootname in ['public-default-v155-original','public-default-v157-symbols']:
 root=w/'output/development'/rootname;lock=json.loads((root/'lock.json').read_text())
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if rootname.endswith('original') else 'new_symbol200','query_kind':c['query_style']}
 for p in (root/'capture').glob('*/answers.jsonl'):
  for o in rows(p):baseline[o['id']]=o
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text())
for c in m['cohorts']:
 for path,d in c['exposed_gold_pins'].items():
  assert sha(path)==d
  for g in rows(path):gold[g['id']]=g
assert set(cases)==set(gold)==set(baseline) and len(cases)==400
obs={};x=[];y=[];qids=[];repos=[];logits=[];groups={};start=0;n1=None
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(capture/repo/f)==d
 data=np.load(capture/repo/'features.npz',allow_pickle=False);assert data['features'].tolist()==reg['n2_features'];this=int(data['n1_count']);assert n1 is None or n1==this;n1=this
 for o in rows(capture/repo/'observations.jsonl'):
  q=o['id'];assert q not in obs and o['units']==baseline[q]['units'];obs[q]=o;n=len(o['units']);mat=data['x'][data['qid']==q];assert mat.shape==(n,len(reg['n2_features']));x.append(mat);y.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);qids.extend([q]*n);repos.extend([repo]*n);logits.extend(o['raw_scores']);groups[q]=np.arange(start,start+n);start+=n
assert len(obs)==250
x=np.concatenate(x);qids,repos,y,logits=map(np.asarray,(qids,repos,y,logits));results={}
for variant,matrix in [('N1_role_reference',x[:,:n1]),('N2_operational',x)]:
 scores=np.empty(len(x));folds=[]
 for held in sorted(set(repos)):
  batch=pairwise_examples(matrix,y,qids,repos,logits,held_out=held);theta,receipt=fit_head(batch,residual=True,regularization=1./len(batch['queries']));test=repos==held;assert not set(batch['queries'])&set(qids[test]);scores[test]=matrix[test]@theta+logits[test];receipt.update(held_out=held,regularization=1./len(batch['queries']),training_repositories=sorted(set(repos[~test])));folds.append(receipt);(dest/(variant+'-'+held+'.json')).write_text(json.dumps({'schema':1,'residual':True,'features':reg['n1_features'] if variant.startswith('N1') else reg['n2_features'],'weights':theta.tolist()},separators=(',',':')))
 outcomes=[];orders=[]
 for q,c in cases.items():
  units=baseline[q]['units']
  if q in obs:
   ix=groups[q];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(ix)),key=lambda i:(-int(named is not None and units[i]['path']==named),-scores[ix[i]],i));units=[units[i] for i in order]
  hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[variant]=result;registration['folds'][variant]=folds;(dest/(variant+'-outcomes.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(dest/(variant+'-orders.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'variant':variant,'total':result['total'],'cohort':result['cohort']}),flush=True)
registration['status']='ALL N1/N2development controls closed; no reserve';(dest/'registration.json').write_text(json.dumps(registration,indent=2));(dest/'summary.json').write_text(json.dumps(results,indent=2))
