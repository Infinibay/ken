"""Query-free controls on the exact current public symbol pool, no labels."""
import json,sys,hashlib,os,subprocess,time,resource
from pathlib import Path
from dataclasses import replace
import numpy as np
from ken.retrieval.best_resources import default_resources
from ken.retrieval.neural_reranker import ONNXReranker
from ken.retrieval.neural_assets import default_reranker
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.piece_cards import build_card,card_text
from ken.retrieval.model import EntityKey
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from document_prior import control_tokens,conditional_scores

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();roots=[w/'output/development/public-default-v155-original',w/'output/development/public-default-v157-symbols'];out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None
if not repo:
 for root in roots:
  lock=json.loads((root/'lock.json').read_text());p=root/'capture/registration.json'
  while not p.exists() or json.loads(p.read_text()).get('status')!=lock['closed_status']:time.sleep(15)
 out.mkdir(exist_ok=False)
 rec={'scope':'L actual current dce44 public400pool, symbols250only. Fixed raw-minus-query-free score, all document tokens identical. No labels, no model/weight/tokenbudget change. Observe jointdelta for optional followup only if fixed difference improves.','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/document_prior.py'),'source_captures':{str(r/'capture/registration.json'):sha(r/'capture/registration.json') for r in roots},'parameters':{'prior_weight':1.,'max_pair_tokens':512,'batch':1,'threads':4,'optional_head':'only if fixed difference improves >=2newhits: J2queryscaled pairwise residual on512jointdelta, no HPO, same LORO gates180/200'},'closed':{}}
 (out/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],check=True,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250current public document controls closed without Gold';(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
out.mkdir(exist_ok=False);oldreg=json.loads((w/'output/development/joint-head-evidence-v153/registration.json').read_text());assets=default_reranker()._prepare();graph=w/'output/development/joint-head-evidence-v153/observed.onnx';assert sha(graph)==oldreg['observed_graph_sha256'];neural=ONNXReranker(lambda:replace(assets,graph=graph,graph_sha256=oldreg['observed_graph_sha256']));neural._load();resources=default_resources();hidden_name=oldreg['hidden_name'];observations=[];matrix=[];qids=[];cache={};hits=0
project=Path('/private/tmp/ken-public-default-v143/repos')/repo
with project_connection(project) as conn:
 catalog=SourceCatalog(project,owner_passages(conn))
 for root in roots:
  lock=json.loads((root/'lock.json').read_text());cases={c['id']:c for c in rows(lock['public_cases'])};reg=json.loads((root/'capture/registration.json').read_text());assert reg['closed'][repo]['answers.jsonl']==sha(root/'capture'/repo/'answers.jsonl')
  for answer in rows(root/'capture'/repo/'answers.jsonl'):
   c=cases[answer['id']]
   if c['target_kind']!='symbol':continue
   expanded=resources.owner_ranker.prepare_query(c['query']);texts=[card_text(build_card(EntityKey(path=u['path'],**u['entity']),'symbol',[EntityKey(path=u['path'],**u['entity'])],expanded,catalog)) for u in answer['units']];actual=[];prior=[];deltas=[];keys=[];before=time.perf_counter()
   for text in texts:
    e=neural._tokenizer.encode(expanded,text);ids=control_tokens(e);key=hashlib.sha256(np.asarray(ids,np.int64).tobytes()).hexdigest();keys.append(key)
    feeds={'input_ids':np.array([e.ids],np.int64),'attention_mask':np.array([e.attention_mask],np.int64)};score,h=neural._session.run([neural._output,hidden_name],feeds);actual.append(float(score.reshape(-1)[0]))
    if key not in cache:
     feeds={'input_ids':np.array([ids],np.int64),'attention_mask':np.ones((1,len(ids)),np.int64)};score,h0=neural._session.run([neural._output,hidden_name],feeds);cache[key]=(float(score.reshape(-1)[0]),h0[0])
    else:hits+=1
    scalar,h0=cache[key];prior.append(scalar);deltas.append(h[0]-h0)
   adjusted=conditional_scores(actual,prior);d=np.asarray(deltas,dtype=np.float32);assert d.shape==(len(texts),512) and np.isfinite(d).all();matrix.append(d);qids.extend([c['id']]*len(d));observations.append({'id':c['id'],'repo_id':repo,'query':c['query'],'target_kind':'symbol','units':answer['units'],'raw_scores':actual,'control_scores':prior,'conditional_scores':adjusted.tolist(),'control_token_hashes':keys,'input_hashes':[hashlib.sha256(t.encode()).hexdigest() for t in texts],'observer_ms':(time.perf_counter()-before)*1000});print(json.dumps({'id':c['id'],'observed':True}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(matrix),qid=np.array(qids));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'repo':repo,'queries':len(observations),'unique_controls':len(cache),'cache_hits':hits,'peak_rss_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'note':'Two forward observer with existing joint output; not final production latency'},indent=2))
