import json,sys,collections
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from verifiable_grading import identity_hit
from ken.retrieval.roles import classify_role
w=Path.cwd();cap=w/'output/development/operational-evidence-v160';m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={g['id']:g for c in m['cohorts'] for p in c['exposed_gold_pins'] for g in map(json.loads,Path(p).read_text().splitlines())};t=collections.Counter();fail=[]
for p in cap.glob('*/observations.jsonl'):
 for o in map(json.loads,p.read_text().splitlines()):
  q=o['id'];cohort='new' if q.startswith('symdev') else 'old';units=o['units'];hit=lambda i:identity_hit({'unit':units[i]},gold[q]['acceptable_units']);positives=[i for i in range(len(units)) if hit(i)]
  raw=sorted(range(len(units)),key=lambda i:(-o['raw_scores'][i],i));t[cohort+'-queries']+=1;t[cohort+'-raw']+=bool(raw and hit(raw[0]));t[cohort+'-recall']+=bool(positives)
  for feature in ['file_role','source_entry_role']:
   role=lambda i: classify_role(units[i]['path']) if feature=='file_role' else ('entry' if o['source_cues'][i]['test_entry'] else 'helper' if o['source_cues'][i]['test_helper'] else 'runtime')
   accepted={role(i) for i in positives};order=[i for i in raw if role(i) in accepted];t[cohort+'-'+feature]+=bool(order and hit(order[0]))
  if positives and not hit(raw[0]):fail.append({'id':q,'roles_raw_gold':[(classify_role(units[i]['path']),o['source_cues'][i]['test_entry'],o['source_cues'][i]['test_helper']) for i in [raw[0],positives[0]]]})
print(json.dumps(dict(t),indent=2));print(json.dumps(fail,indent=2))
