"""Source/query cues on current public pools, no reference reads or new NN calls."""
import sys,json,hashlib,subprocess,os,resource,re
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from operational_evidence import critical_references,reference_coverage,test_entrypoint,operation_alignment
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.description import describe_owner
from ken.retrieval.model import SearchRequest,EntityKey
from ken.retrieval.intent import interpret
from ken.retrieval.roles import classify_role

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();prior=w/'output/development/current-document-prior-v158';preg=json.loads((prior/'registration.json').read_text());assert preg['status']=='ALL250current public document controls closed without Gold';out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
qnames=(*(f'qembed_{i}' for i in range(256)),'explicit_tests','test_word','helper_word','identity_reference','negative_words','bias');base_names=('initial_reciprocal_rank','reference_identity','reference_owned','reference_scope','reference_docs','reference_owned_count','negative_reference_owned','negative_reference_scope');n1=tuple(f'{role}_{f}' for role in ['test_entry','test_helper'] for f in qnames)+base_names;ops=tuple(f'{scope}_{f}' for scope in ['owned','scope'] for f in [*(f'query_{op}_match' for op in ['branch','mutation','exception','loop','call','return']),*(f'test_query_{op}_match' for op in ['branch','mutation','exception','loop','call','return']),'call_action_overlap']);n2=(*n1,*ops)
if not repo:
 reg={'scope':'EXPOSED current250symbol public pools; N1role+reference, N2adds operational cues; no labels or new NN calls','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/operational_evidence.py'),'public_pool_registration_sha256':sha(prior/'registration.json'),'n1_features':n1,'n2_features':n2,'closed':{}};(out/'registration.json').write_text(json.dumps(reg,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
  reg['closed'][repo]={n:sha(out/repo/n) for n in ['features.npz','observations.jsonl','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 reg['status']='ALL250operational public source observations closed without Gold';(out/'registration.json').write_text(json.dumps(reg,indent=2));sys.exit(0)
assert sha(prior/repo/'observations.jsonl')==preg['closed'][repo]['observations.jsonl'];examples=rows(prior/repo/'observations.jsonl');resources=default_resources();root=Path('/private/tmp/ken-public-default-v143/repos')/repo;mat=[];qids=[];observations=[];cache={}
with project_connection(root) as conn:
 catalog=SourceCatalog(root,owner_passages(conn));descriptions={}
 def describe(key):
  if key not in descriptions:descriptions[key]=describe_owner(catalog.owners[key])
  return descriptions[key]
 def info(key):
  if key in cache:return cache[key]
  desc=describe(key);members=catalog.scope_members(key);ds=[desc,*[describe(k) for k in members]] if members else [desc];scope='\n'.join(d.fields['executable'] for d in ds);scope_calls='\n'.join(d.fields['calls'] for d in ds);start,end=catalog.extent(key);imp=min((p.implementation_start_line for p in catalog.owners[key] if p.implementation_start_line),default=start);prelude='\n'.join(catalog.lines[key.path][start-1:max(start,imp)-1]);file_test=classify_role(key.path)=='test';entry=test_entrypoint(key.qualname or '',prelude,file_test=file_test,nested_callable=catalog.enclosing_callable(key) is not None);helper=file_test and not entry;value=(desc,scope,scope_calls,entry,helper);cache[key]=value;return value
 for example in examples:
  q=example['id'];query=example['query'];expanded=resources.owner_ranker.prepare_query(query);vec=np.array(resources.words.embed_query(expanded),dtype=np.float64);assert vec.shape==(256,);intent=interpret(SearchRequest(query));testword=bool(re.search(r'\b(?:test\w*|regression\w*|prueb\w*|regresi\w*)\b',expanded,re.I));helperword=bool(re.search(r'\b(?:helper|fixture|mock|stub|double|factory|utility|support)\b',expanded,re.I));identity=bool(re.search(r'`[^`]+`',query));negative=bool(re.search(r'\b(?:not|no|never|without|except|sin)\b',expanded,re.I));qvec=np.r_[vec,[float(intent.purpose=='tests'),float(testword),float(helperword),float(identity),float(negative),1.]];refs=critical_references(query);notes=[]
  for rank,unit in enumerate(example['units'],1):
   key=EntityKey(path=unit['path'],**unit['entity']);desc,scope,scalls,entry,helper=info(key);direct,name=reference_coverage(refs,desc.fields['executable'],desc.fields['signature'],qualname=key.qualname or '');whole,_=reference_coverage(refs,scope,desc.fields['signature'],qualname=key.qualname or '');docs,_=reference_coverage(refs,desc.fields['documentation'],'',qualname=key.qualname or '');base=np.r_[qvec*float(entry),qvec*float(helper),[1/rank,name,direct,whole,docs,direct*len(refs),direct*negative,whole*negative]];full=np.r_[base,operation_alignment(expanded,desc.fields['executable'],desc.fields['calls'],test_query=testword),operation_alignment(expanded,scope,scalls,test_query=testword)];assert full.shape==(len(n2),) and np.isfinite(full).all();mat.append(full);qids.append(q);notes.append({'source_hash':desc.source_hash,'test_entry':bool(entry),'test_helper':bool(helper),'refs':refs,'coverage':{'owned':direct,'scope':whole,'identity':name}})
  observations.append({'id':q,'repo_id':repo,'units':example['units'],'raw_scores':example['raw_scores'],'source_cues':notes})
np.savez_compressed(out/'features.npz',x=np.asarray(mat),qid=np.array(qids),features=np.array(n2),n1_count=len(n1));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'repo':repo,'queries':len(observations),'rows':len(qids),'n1_features':len(n1),'n2_features':len(n2),'peak_rss_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'neural_calls':0},indent=2))
