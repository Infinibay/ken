"""Research portable512->24ReLU->1decision head, no sklearn at inference."""
import numpy as np

def head_logits(model,x):
    x=np.asarray(x,dtype=np.float64);mean=np.asarray(model['mean']);scale=np.asarray(model['scale']);weights=[np.asarray(w) for w in model['weights']];biases=[np.asarray(b) for b in model['biases']]
    if x.ndim!=2 or len(weights)!=2 or len(biases)!=2 or mean.shape!=scale.shape or mean.shape!=(x.shape[1],) or not all(np.isfinite(a).all() for a in [x,mean,scale,*weights,*biases]) or np.any(scale<=0):raise ValueError('finite aligned model and candidate features required')
    h=np.maximum((x-mean)/scale@weights[0]+biases[0],0.)
    logits=h@weights[1]+biases[1]
    if logits.shape!=(len(x),1):raise ValueError('one raw affine logit per candidate required')
    return logits[:,0]
