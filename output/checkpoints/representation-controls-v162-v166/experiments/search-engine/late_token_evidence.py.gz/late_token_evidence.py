"""Research contextual word coverage; no probabilities or behavior proofs."""
import re
import numpy as np

_STOP=set('a an the of to is are was were be being been for in on at by as with from and or that this those these it its which what where who how when find locate identify function method symbol class module file code implementation does do did can could would should whose'.split())

def normalized_tokens(x):
    x=np.asarray(x,dtype=np.float32)
    if x.ndim!=2 or not np.isfinite(x).all():raise ValueError('finite token matrix required')
    norms=np.linalg.norm(x,axis=1,keepdims=True)
    return np.divide(x,norms,out=np.zeros_like(x),where=norms>1e-9)

def late_features(q,d,block_size=64):
    q,d=np.asarray(q,dtype=np.float32),np.asarray(d,dtype=np.float32)
    if q.ndim!=2 or d.ndim!=2 or q.shape[1]!=d.shape[1] or not np.isfinite(q).all() or not np.isfinite(d).all() or type(block_size)is not int or block_size<1:raise ValueError('compatible finite token matrices and positive block required')
    if not len(q) or not len(d):return np.zeros(5)
    peaks=np.full(len(q),-np.inf,dtype=np.float32)
    for a in range(0,len(d),block_size):peaks=np.maximum(peaks,(q@d[a:a+block_size].T).max(axis=1))
    return np.array([peaks.mean(),peaks.min(),np.quantile(peaks,.25),np.quantile(peaks,.75),np.mean(np.sort(peaks)[:max(1,(len(peaks)+1)//2)])],dtype=np.float64)

def word_vectors(text,offsets,values,question_start=None):
    values=np.asarray(values,dtype=np.float32)
    if values.ndim!=2 or len(offsets)!=len(values) or not np.isfinite(values).all():raise ValueError('one finite vector per token required')
    names=[];vectors=[]
    for m in re.finditer(r'[\w$]+',text):
        name=m.group()
        if question_start is not None and (m.start()<question_start or name.casefold() in _STOP and not(name.isupper() and len(name)>1)):continue
        indexes=[i for i,(a,b) in enumerate(offsets) if a<b and a<m.end() and b>m.start()]
        if indexes:names.append(name);vectors.append(values[indexes].mean(axis=0))
    return names,normalized_tokens(np.array(vectors,dtype=np.float32).reshape(-1,values.shape[1]))
