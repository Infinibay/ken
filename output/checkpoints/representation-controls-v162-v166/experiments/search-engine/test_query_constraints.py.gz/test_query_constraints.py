from query_constraints import query_constraint_priorities

def cue(identity=0.,owned=0.,docs=0.,entry=False,helper=False):return {'test_entry':entry,'test_helper':helper,'coverage':{'identity':identity,'owned':owned,'docs':docs}}
def test_explicit_test_request_prioritizes_test_entry_then_neural_can_order():
    p=query_constraint_priorities([cue(),cue(entry=True),cue(helper=True)],tests_requested=True,positive_references=False)
    assert p[1]>p[0] and p[1]>p[2]
def test_exact_declared_reference_wins_over_a_body_mention():
    p=query_constraint_priorities([cue(owned=1.),cue(identity=1.)],tests_requested=False,positive_references=True)
    assert p[1]>p[0]
def test_full_reference_match_is_required_and_negated_queries_do_not_get_priority():
    p=query_constraint_priorities([cue(owned=.5),cue(owned=1.)],tests_requested=False,positive_references=True)
    assert p[1]>p[0]
    assert query_constraint_priorities([cue(owned=.5),cue(owned=1.)],tests_requested=False,positive_references=False)==[(0,0,0),(0,0,0)]
def test_test_helpers_are_eligible_when_no_entry_is_in_pool():
    p=query_constraint_priorities([cue(),cue(helper=True)],tests_requested=True,positive_references=False)
    assert p[1]>p[0]
