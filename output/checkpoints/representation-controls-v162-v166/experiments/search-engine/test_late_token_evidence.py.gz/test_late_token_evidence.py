import numpy as np
import pytest
from late_token_evidence import normalized_tokens, late_features, word_vectors

def test_per_token_normalization_retains_direction():
    assert np.allclose(normalized_tokens(np.array([[3.,4.],[1.,0.]])),[[.6,.8],[1.,0.]])
    with pytest.raises(ValueError):normalized_tokens(np.array([[float('nan'),1.]]))

def test_coverage_requires_every_query_direction_and_duplicate_docs_add_no_votes():
    q=np.eye(2);a=late_features(q,np.eye(2));b=late_features(q,np.array([[1.,0.]]));dup=late_features(q,np.array([[1.,0.],[0.,1.],[1.,0.]]))
    assert a[1]>b[1] and np.array_equal(a,dup)
    assert a[0]==1. and b[0]==.5

def test_short_scoring_blocks_do_not_change_result():
    rng=np.random.default_rng(0);q=normalized_tokens(rng.normal(size=(3,4)));d=normalized_tokens(rng.normal(size=(10,4)))
    a=late_features(q,d,block_size=2)
    assert a[0]==pytest.approx((q@d.T).max(axis=1).mean())
    assert np.allclose(a,late_features(q,d,block_size=100),atol=1e-7)

def test_query_instruction_is_encoded_but_not_counted_as_question_evidence():
    text='Represent code: find boolean AND nodes';offsets=[(0,9),(10,14),(14,15),(16,20),(21,28),(29,32),(33,38)]
    values=np.eye(len(offsets));names,v=word_vectors(text,offsets,values,question_start=16)
    assert names==['boolean','AND','nodes'] and v.shape==(3,len(offsets))

def test_empty_document_has_zero_coverage_and_malformed_shapes_fail():
    assert np.array_equal(late_features(np.eye(2),np.empty((0,2))),np.zeros(5))
    with pytest.raises(ValueError):late_features(np.eye(2),np.ones((3,4)))
