import numpy as np
import pytest
from small_nonlinear_head import head_logits

def test_hidden_relu_then_affine_retains_raw_logit_differences():
    x=np.array([[-2.,0.],[1.,3.]]);model={'mean':[0.,0.],'scale':[1.,1.],'weights':[[[1.,-1.],[0.,1.]],[[2.],[-1.]]],'biases':[[0.,0.],[.5]]}
    assert np.array_equal(head_logits(model,x),[-1.5,.5])

def test_training_scaler_is_applied_and_malformed_inputs_are_rejected():
    model={'mean':[1.,1.],'scale':[2.,2.],'weights':[[[1.],[1.]],[[2.]]],'biases':[[0.],[0.]]}
    assert np.array_equal(head_logits(model,np.array([[3.,3.]])),[4.])
    with pytest.raises(ValueError):head_logits(model,np.array([[1.,float('nan')]]))
