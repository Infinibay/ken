"""Research explicit request priorities, keeping every candidate identity."""
def query_constraint_priorities(cues,*,tests_requested,positive_references):
    entry_present=any(c['test_entry'] for c in cues)
    return [(int(positive_references and c['coverage']['identity']==1.),
             int(tests_requested and (c['test_entry'] if entry_present else c['test_helper'])),
             int(positive_references and max(c['coverage']['owned'],c['coverage']['docs'])==1.)) for c in cues]
