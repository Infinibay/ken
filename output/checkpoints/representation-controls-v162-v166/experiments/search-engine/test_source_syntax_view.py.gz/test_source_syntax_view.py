from source_syntax_view import SourceSyntax

def test_guarded_return_preserves_condition():
    source=b'def choose(x):\n    if x is None:\n        return fallback(x)\n    return x\n'
    facts=SourceSyntax(source,'x.py').facts(1,5)
    returns=[f for f in facts if f.operation=='return']
    assert len(returns)==2
    assert returns[0].guards==('x is None',) and 'fallback' in returns[0].text
    assert returns[1].guards==()
    assert returns[0].start_line==3 and returns[0].end_line==3

def test_nested_helper_does_not_become_direct_parent_operation():
    source=b'def outer():\n    def helper():\n        raise ValueError("nested")\n    assert helper is not None\n'
    facts=SourceSyntax(source,'x.py').facts(1,4)
    assert any(f.operation=='define' and 'helper' in f.text for f in facts)
    assert not any(f.operation=='raise' for f in facts)
    nested=SourceSyntax(source,'x.py').facts(2,3)
    assert any(f.operation=='raise' and 'ValueError' in f.text for f in nested)

def test_java_nonblocking_return_has_source_call_and_operator():
    source=b'class L { boolean ready() { return acquired || (acquired = lock.tryLock()); } }'
    facts=SourceSyntax(source,'x.java').facts(1,1)
    assert any(f.operation=='return' and 'or' in f.text and 'tryLock' in f.text for f in facts)

def test_typescript_branch_facts_keep_comparison_and_scope():
    source=b'function choose(value) { if (value !== null) { return equal(value, expected); } return value === expected; }'
    facts=SourceSyntax(source,'x.ts').facts(1,1)
    returns=[f for f in facts if f.operation=='return']
    assert len(returns)==2 and 'not equal' in returns[0].guards[0]
    assert 'equal' in returns[1].text

def test_source_comments_are_not_executable_facts():
    facts=SourceSyntax(b'def f():\n    # raise GhostError()\n    return 1\n','x.py').facts(1,3)
    assert facts and not any('GhostError' in f.text for f in facts)

def test_unsupported_language_is_explicit_before_parsing():
    assert not SourceSyntax.supported('build.gradle.kts')
    assert SourceSyntax.supported('module.ts')
