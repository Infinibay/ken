"""Source syntax reranker view; capture all current250symbols before labels."""
import sys,json,hashlib,os,subprocess,time,resource
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path.cwd()/'experiments/search-engine'))
from source_syntax_view import SourceSyntax
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.description import describe_owner
from ken.retrieval.model import EntityKey
from ken.retrieval.piece_cards import build_card,card_text,terms
from ken.retrieval.tokenization import code_tokens
from ken.retrieval.owner_ranking import EvidenceReranker

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();cap=w/'output/development/operational-evidence-v160';reg=json.loads((cap/'registration.json').read_text());assert reg['status']=='ALL250operational public source observations closed without Gold';out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
 rec={'scope':'P1source syntax view current250symbol public10pools, no labels. P2equalmean P1/originalraw. All400evaluation. No fitting.','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/source_syntax_view.py'),'previous_registration_sha256':sha(cap/'registration.json'),'fallback':'Unsupported language uses identical original card, no syntax assertions','closed':{}}
 (out/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','summary.json']};print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250source syntax public observations closed without Gold';(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
assert sha(cap/repo/'observations.jsonl')==reg['closed'][repo]['observations.jsonl'];r=default_resources();root=Path('/private/tmp/ken-public-default-v143/repos')/repo;observations=[];parsed={};desc_cache={}
with project_connection(root) as conn:
 catalog=SourceCatalog(root,owner_passages(conn))
 for o in rows(cap/repo/'observations.jsonl'):
  q=o['id'];texts=[];n_facts=[];sourcehashes=[];expanded=None
  # Previous capture does not store raw query; registered public observation does.
  source=next(x for x in rows(w/'output/development/current-document-prior-v158'/repo/'observations.jsonl') if x['id']==q);query=source['query'];expanded=r.owner_ranker.prepare_query(query);qt=set(EvidenceReranker.stem_words(code_tokens(expanded)))
  start=time.perf_counter()
  for i,u in enumerate(o['units']):
   key=EntityKey(path=u['path'],**u['entity']);a,b=catalog.extent(key)
   if not SourceSyntax.supported(key.path):
    card=build_card(key,'symbol',[key],expanded,catalog);texts.append(card_text(card));n_facts.append(0);sourcehashes.append(catalog.hashes[key.path]);continue
   if key.path not in parsed:
    data=(root/key.path).read_bytes();assert hashlib.sha256(data).hexdigest()==catalog.hashes[key.path];parsed[key.path]=SourceSyntax(data,key.path)
   facts=parsed[key.path].facts(a,b)
   if key not in desc_cache:desc_cache[key]=describe_owner(catalog.owners[key])
   desc=desc_cache[key];fit=lambda f:len(qt&set(EvidenceReranker.stem_words(code_tokens(f.sentence))))
   chosen=sorted(sorted(enumerate(facts),key=lambda pair:(-fit(pair[1]),pair[0]))[:16]);sentences='\n'.join(f'{f.start_line}: {f.sentence}' for _,f in chosen)
   cue=o['source_cues'][i];role='test case or regression test' if cue['test_entry'] else 'test support helper' if cue['test_helper'] else 'runtime implementation'
   card=build_card(key,'symbol',[key],expanded,catalog);raw=card_text(card)
   text=f"{role}: {key.qualname}\nFile: {key.path}\nDocumentation: {desc.fields['documentation'][:600]}\nSource syntax operations (nested callables keep their own scope):\n{sentences}\nOriginal code:\n{raw[:3000]}"
   texts.append(text);n_facts.append(len(facts));sourcehashes.append(desc.source_hash)
  scores,details=r.neural.score(expanded,texts);observations.append({'id':q,'repo_id':repo,'query':query,'expanded_query':expanded,'units':o['units'],'raw_scores':o['raw_scores'],'syntax_scores':scores,'input_hashes':[hashlib.sha256(t.encode()).hexdigest() for t in texts],'texts':texts,'source_hashes':sourcehashes,'source_fact_counts':n_facts,'details':details,'observer_ms':(time.perf_counter()-start)*1000});print(json.dumps({'id':q}),flush=True)
(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'queries':len(observations),'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'observer only, not full-search latency'},indent=2))
