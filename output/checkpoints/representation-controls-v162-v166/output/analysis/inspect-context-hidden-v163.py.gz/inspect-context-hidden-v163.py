from pathlib import Path
import onnx,json
from ken.embedder.contextual_onnx import code_context_model
p=code_context_model().assets.resolve(local_files_only=True)/'onnx/model.onnx';m=onnx.load(p);print(json.dumps({'outputs':[o.name for o in m.graph.output],'tail':[{'op':n.op_type,'name':n.name,'input':list(n.input),'output':list(n.output)} for n in m.graph.node[-12:]]},indent=2))
