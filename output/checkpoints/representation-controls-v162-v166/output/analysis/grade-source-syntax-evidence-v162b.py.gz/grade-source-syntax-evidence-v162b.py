import sys,json,hashlib,time
from pathlib import Path
sys.path.insert(0,'experiments/search-engine')
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
w=Path.cwd();cap=w/'output/development/source-syntax-evidence-v162b';p=cap/'registration.json'
while not p.exists() or json.loads(p.read_text()).get('status')!='ALL250source syntax public observations closed without Gold':time.sleep(15)
reg=json.loads(p.read_text());obs={}
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(cap/repo/f)==d
 for o in rows(cap/repo/'observations.jsonl'):assert o['id'] not in obs;obs[o['id']]=o
assert len(obs)==250
cases={};baseline={}
for rootname in ['public-default-v155-original','public-default-v157-symbols']:
 root=w/'output/development'/rootname;lock=json.loads((root/'lock.json').read_text())
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if rootname.endswith('original') else 'new_symbol200','query_kind':c['query_style']}
 for f in (root/'capture').glob('*/answers.jsonl'):
  for o in rows(f):baseline[o['id']]=o
assert set(cases)==set(baseline) and len(cases)==400
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
 for path,d in c['exposed_gold_pins'].items():
  assert sha(path)==d
  for g in rows(path):gold[g['id']]=g
assert set(cases)==set(gold);results={}
for name in ['raw_current_nn','P1_syntax','P2_equal_raw_mean']:
 outcomes=[];orders=[]
 for q,c in cases.items():
  units=baseline[q]['units']
  if q in obs:
   o=obs[q];assert o['units']==units
   scores=o['raw_scores'] if name=='raw_current_nn' else o['syntax_scores'] if name=='P1_syntax' else [(a+b)/2 for a,b in zip(o['raw_scores'],o['syntax_scores'])]
   named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(units)),key=lambda i:(-int(named is not None and units[i]['path']==named),-scores[i],i));units=[units[i] for i in order]
  hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[name]=result;(cap/(name+'-outcomes.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(cap/(name+'-orders.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'variant':name,'total':result['total'],'cohort':result['cohort']}),flush=True)
(cap/'development-summary.json').write_text(json.dumps(results,indent=2));(cap/'grading-registration.json').write_text(json.dumps({'scope':'EXPOSED400ONLY','capture_registration_sha256':sha(p),'producer_sha256':sha(__file__)},indent=2))
