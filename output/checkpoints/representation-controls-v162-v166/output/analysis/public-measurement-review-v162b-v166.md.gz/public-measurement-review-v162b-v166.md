# Independent measurement review: public controls162b–166

Conforming for the recorded readouts, with the comparison limits below. No blocking ID, denominator, unit/matrix alignment or scoring defect was found.

I independently reconstructed all3,200 saved orders and outcomes (eight readouts ×400), including every reported stratum, using only the exposed references pinned in fit-manifest147. The250 current symbol pools and2,500 matrix rows align exactly; all150 other queries remain in the denominator. Saved orders preserve their declared pools. All24 learned heads exclude the complete held repository. Linear normalizers/losses, lexical vocabularies and train-only IDFs, and nonlinear normalizers/exported arithmetic/losses reproduce the stored results. The documentation adapter uses the actual reference_docs column correctly.425 candidate source files match physical hashes. No fit, encoder, producer, API or private acceptance payload was used.

| Readout | Original top1/200 | New symbol top1/200 | New Recall10/200 |
|---|---:|---:|---:|
| raw_current_nn |189|169|195|
| P1 syntax |188|155|195|
| P2 equal raw mean |190|166|195|
| Q1 mean MaxSim |190|154|195|
| Q2 residual |192|162|195|
| R1 lexical role |189|168|195|
| R2 explicit constraints |189|165|195|
| v166 nonlinear, LEGACY |184|137|193|

The raw_current_nn readout is not the complete public API baseline: the cited public captures themselves give191/200 original and150/200 new top1. These differences are real ranking-policy differences; the audit does not conflate their baselines. Every new-cohort readout remains below180.

R165c omits the three explicit flags used by the prior K router, so its result does not isolate TFIDF against Potion. V166 uses the declared LEGACY pool:32 symbol-query pools differ from the current pool, and new Recall10 is193 instead of195. Its in-sample1700/1701 occurrences are correlated; all eight fits stopped at iteration300 with convergence warnings. The held result is valid for this recipe, without proving a converged optimum or a universal failure of nonlinear models.

P/Q/R replay uses the matching intent/roles in frozen public-default-cpu-v155 (source receipt28a2aa518fa300f99885d6c6fcd27e41b090fba3370e91228fb590ca10bde1ce). The parent supplied that launch attestation after execution; the controllers did not originally pin the transitive imports. R/src is an older foreign copy. The report preserves this provenance limit instead of presenting a late check as a startup receipt.

Q164 explicitly tests native query parity on a synthetic input; its per-encode assertion is token0 versus sentence_embedding. Its summary label should distinguish those checks. Observer timings and RSS cover partial offline stages; Q164 query encoding precedes its observer timer. No API resource certificate or causal speedup follows. No result or source was changed.
