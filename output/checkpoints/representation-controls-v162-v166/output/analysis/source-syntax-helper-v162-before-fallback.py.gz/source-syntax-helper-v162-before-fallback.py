"""Research source syntax facts. Describes syntax, not resolved execution effects."""
from dataclasses import dataclass
from pathlib import Path
from importlib import import_module
import re

_CALLABLE={'function_definition','function_declaration','generator_function_declaration','method_declaration','constructor_declaration','method_definition','arrow_function','function_expression','generator_function'}
_ATOMIC={'string','string_literal','template_string','character_literal','integer','integer_literal','float','true','false','none','null_literal','identifier','property_identifier','type_identifier','comment','line_comment','block_comment'}
_OPERATORS={'==':'equal','===':'strictly equal','!=':'not equal','!==':'strictly not equal','&&':'and','||':'or','!':'not','>=':'at least','<=':'at most','>':'greater than','<':'less than','=':'assign','+=':'add and assign','-=':'subtract and assign','*':'multiply','/':'divide','%':'modulo'}
_KINDS={'return_statement':'return','raise_statement':'raise','throw_statement':'raise','yield':'yield','assert_statement':'assert','assignment':'assign','augmented_assignment':'assign','assignment_expression':'assign','variable_declarator':'assign','call':'call','call_expression':'call','method_invocation':'call','object_creation_expression':'construct','update_expression':'assign','break_statement':'break','continue_statement':'continue'}
@dataclass(frozen=True)
class SyntaxFact:
    operation:str
    text:str
    guards:tuple[str,...]
    start_line:int
    end_line:int
    @property
    def sentence(self):
        return ('When '+' and '.join(self.guards)+': ' if self.guards else '')+self.text

class SourceSyntax:
    def __init__(self,source,path):
        self.source=source
        ext=Path(path).suffix
        module,parser={'.py':('python','_PARSER'),'.pyi':('python','_PARSER'),'.java':('java','_PARSER'),'.ts':('typescript','_PARSER_TS'),'.tsx':('typescript','_PARSER_TSX'),'.js':('javascript','_PARSER'),'.mjs':('javascript','_PARSER'),'.cjs':('javascript','_PARSER')}[ext]
        self.tree=getattr(import_module('ken.parsers.'+module),parser).parse(source)
    def _raw(self,node):return self.source[node.start_byte:node.end_byte].decode('utf8',errors='replace')
    def _expr(self,node):
        if node is None:return ''
        if node.type in _ATOMIC:return self._raw(node)
        if node.type in _CALLABLE:return 'nested callable'
        if not node.children:return _OPERATORS.get(self._raw(node),self._raw(node))
        return re.sub(r'\s+',' ',' '.join(self._expr(c) for c in node.children)).strip()
    def facts(self,start,end):
        candidates=[]
        def locate(node):
            a,b=node.start_point[0]+1,node.end_point[0]+1
            if b<start or a>end:return
            if node.type in _CALLABLE and start<=a<=b<=end:candidates.append(node)
            for child in node.named_children:locate(child)
        locate(self.tree.root_node)
        root=min(candidates,key=lambda n:(n.start_byte,-n.end_byte)) if candidates else self.tree.root_node
        facts=[]
        def emit(node,op,text,guards):
            text=re.sub(r'\s+',' ',text).strip()
            if text:facts.append(SyntaxFact(op,text[:320],guards,node.start_point[0]+1,node.end_point[0]+1))
        def visit(node,guards=()):
            a,b=node.start_point[0]+1,node.end_point[0]+1
            if b<start or a>end:return
            if node.type in {'comment','line_comment','block_comment'}:return
            if node!=root and node.type in _CALLABLE:
                name=node.child_by_field_name('name');emit(node,'define','Defines nested callable '+(self._raw(name) if name else 'anonymous'),guards);return
            if node.type in {'if_statement','elif_clause','while_statement','for_statement','for_in_statement','enhanced_for_statement','catch_clause','except_clause','with_statement','switch_case'}:
                condition=node.child_by_field_name('condition') or node.child_by_field_name('value') or node.child_by_field_name('subject')
                text=self._expr(condition)
                body=node.child_by_field_name('consequence') or node.child_by_field_name('body')
                if text:emit(node,'condition','Checks '+text,guards)
                for c in node.named_children:
                    if c==condition:continue
                    if c.type in {'else_clause','else','else_if_clause'}:
                        visit(c,guards+(('not ('+text+')') if text else 'alternative branch',))
                    else:visit(c,guards+((text,) if text and (c==body or body is None) else ()))
                return
            op=_KINDS.get(node.type)
            if op and start<=a<=b<=end:
                if op in {'return','raise','assert'}:text=op.title()+' '+' '.join(self._expr(c) for c in node.named_children)
                elif op=='call':text='Calls '+self._expr(node)
                else:text=op.title()+' '+self._expr(node)
                emit(node,op,text,guards)
            for child in node.named_children:visit(child,guards)
        visit(root)
        return list(dict.fromkeys(facts))
