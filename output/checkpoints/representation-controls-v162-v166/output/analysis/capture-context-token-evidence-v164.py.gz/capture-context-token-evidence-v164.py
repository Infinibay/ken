"""Existing code contextual graph token output, current250public pools, no labels."""
import sys,json,hashlib,os,subprocess,resource,time
from pathlib import Path
from collections import OrderedDict
import numpy as np
sys.path.insert(0,'experiments/search-engine')
from late_token_evidence import word_vectors,late_features
from ken.retrieval.best_resources import default_resources
from ken.retrieval.connections import project_connection
from ken.retrieval.candidates import owner_passages
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.description import describe_owner
from ken.retrieval.context_preparation import full_owner_text
from ken.retrieval.model import EntityKey

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();previous=w/'output/development/source-syntax-evidence-v162b';p=previous/'registration.json'
while not p.exists() or json.loads(p.read_text()).get('status')!='ALL250source syntax public observations closed without Gold':time.sleep(15)
reg=json.loads(p.read_text());out=Path(sys.argv[1]);repo=sys.argv[2] if len(sys.argv)>2 else None;out.mkdir(exist_ok=False)
if not repo:
 rec={'scope':'Q1raw meanMaxSim, Q2residual six contextual token/CLS features; all current250symbol public pools; no labels or new weights; observation only','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/late_token_evidence.py'),'source_registration_sha256':sha(p),'features':['mean','min','p25','p75','lowerhalf','fullCLS_cosine'],'closed':{}}
 (out/'registration.json').write_text(json.dumps(rec,indent=2))
 for repo in ['ajv','attrs','boltons','commons-csv','junit5','marked','packaging','pytest']:
  with (out/(repo+'.log')).open('w') as log:subprocess.run([sys.executable,__file__,str(out/repo),repo],env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
  rec['closed'][repo]={n:sha(out/repo/n) for n in ['observations.jsonl','features.npz','summary.json']};(out/'registration.json').write_text(json.dumps(rec,indent=2));print(json.dumps({'closed':repo}),flush=True)
 rec['status']='ALL250contextual token public observations closed without Gold';(out/'registration.json').write_text(json.dumps(rec,indent=2));sys.exit(0)
assert sha(previous/repo/'observations.jsonl')==reg['closed'][repo]['observations.jsonl'];r=default_resources();encoder=r.context;encoder._load();root=Path('/private/tmp/ken-public-default-v143/repos')/repo;cache=OrderedDict();observations=[];matrix=[];qids=[];hits=0

def encode(text,question_start=None):
 e=encoder._tokenizer.encode(text);feeds={'input_ids':np.array([e.ids],np.int64),'attention_mask':np.array([e.attention_mask],np.int64)};tokens,cls=encoder._session.run(['token_embeddings','sentence_embedding'],feeds);assert tokens.shape==(1,len(e.ids),768) and cls.shape==(1,768) and np.array_equal(tokens[0,0],cls[0]);names,values=word_vectors(text,e.offsets,tokens[0],question_start=question_start);return names,values,cls[0]
# Independent public API parity on a synthetic input with the exact same prefix.
sample='find a stored setting';_,_,raw=encode(encoder.model.query_prefix+sample,question_start=len(encoder.model.query_prefix));assert np.array_equal(raw,encoder.embed_query(sample))
with project_connection(root) as conn:
 catalog=SourceCatalog(root,owner_passages(conn))
 for old in rows(previous/repo/'observations.jsonl'):
  query=old['expanded_query'];prefix=encoder.model.query_prefix;qnames,qvec,qcls=encode(prefix+query,question_start=len(prefix));qcls=qcls/np.linalg.norm(qcls);this=[];hashes=[];wordcounts=[];start=time.perf_counter()
  for unit in old['units']:
   key=EntityKey(path=unit['path'],**unit['entity']);text=full_owner_text(describe_owner(catalog.owners[key]));digest=hashlib.sha256(text.encode()).hexdigest();hashes.append(digest)
   if digest not in cache:
    if hashlib.sha256((root/key.path).read_bytes()).hexdigest()!=catalog.hashes[key.path]:raise ValueError('stale source')
    _,dvec,dcls=encode(text);cache[digest]=(dvec,dcls/np.linalg.norm(dcls))
    while len(cache)>32:cache.popitem(last=False)
   else:hits+=1;cache.move_to_end(digest)
   dvec,dcls=cache[digest];value=np.r_[late_features(qvec,dvec),float(qcls@dcls)];this.append(value);wordcounts.append(len(dvec))
  matrix.append(np.asarray(this));qids.extend([old['id']]*len(this));observations.append({'id':old['id'],'repo_id':repo,'units':old['units'],'raw_scores':old['raw_scores'],'expanded_query':query,'query_words':qnames,'source_input_hashes':hashes,'document_words':wordcounts,'observer_ms':(time.perf_counter()-start)*1000});print(json.dumps({'id':old['id']}),flush=True)
np.savez_compressed(out/'features.npz',x=np.concatenate(matrix),qid=np.array(qids));(out/'observations.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in observations));(out/'summary.json').write_text(json.dumps({'queries':len(observations),'cache_hits':hits,'cache_max_entries':32,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'synthetic_and_each_query_CLS_parity':'EXACT','scope':'observer only, no complete-query latency claim'},indent=2))
