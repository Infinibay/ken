"""Single fixed small nonlinear decision head, LEGACY public pools, strict LORO."""
import sys,json,hashlib,warnings,time
from pathlib import Path
import numpy as np
from sklearn.neural_network import MLPClassifier
from scipy.special import expit
sys.path.insert(0,'experiments/search-engine')
from small_nonlinear_head import head_logits
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
w=Path.cwd();cap=w/'output/development/joint-head-evidence-v153';reg=json.loads((cap/'registration.json').read_text());assert reg['status']=='ALL250joint public observations closed without Gold';out=w/'output/development/small-nonlinear-head-v166';out.mkdir(exist_ok=False);registration={'scope':'EXPOSED400LEGACY pools only, original197new193Recall; no private data. Fixed24ReLUMLP, balanced perquerypositive/negative mass, LORO. Current195newpool NOT validated by this control.','capture_registration_sha256':sha(cap/'registration.json'),'producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/small_nonlinear_head.py'),'recipe':{'hidden':24,'activation':'relu','solver':'lbfgs','alpha':1,'max_iter':300,'max_fun':15000,'random_state':42,'tol':1e-8},'status':'registered before exposed labels','folds':[]};(out/'registration.json').write_text(json.dumps(registration,indent=2));lock=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());cases={};baseline={};gold={}
for c in lock['cohorts']:
 assert sha(c['public_cases'])==c['public_sha256']
 for q in rows(c['public_cases']):cases[q['id']]={**q,'cohort':c['name'],'query_kind':q['query_style']}
 for p,d in c['exposed_gold_pins'].items():
  assert sha(p)==d
  for g in rows(p):gold[g['id']]=g
 for p in Path(c['capture']).glob('*/observations.jsonl'):
  for o in rows(p):baseline[o['id']]=o
assert set(cases)==set(gold)==set(baseline) and len(cases)==400;obs={};matrix=[];y=[];qids=[];repos=[];groups={};start=0
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(cap/repo/f)==d
 data=np.load(cap/repo/'features.npz',allow_pickle=False)
 for o in rows(cap/repo/'observations.jsonl'):
  q=o['id'];assert q not in obs and o['units']==baseline[q]['units'];obs[q]=o;mat=data['x'][data['qid']==q];assert mat.shape==(len(o['units']),512);matrix.append(mat);n=len(mat);qids.extend([q]*n);repos.extend([repo]*n);y.extend(int(identity_hit({'unit':u},gold[q]['acceptable_units'])) for u in o['units']);groups[q]=np.arange(start,start+n);start+=n
assert len(obs)==250;x=np.concatenate(matrix).astype(np.float64);qids,repos,y=map(np.asarray,(qids,repos,y));scores=np.empty(len(x))
for held in sorted(set(repos)):
 train=np.zeros(len(x),bool);weights=np.zeros(len(x));trainq=[]
 for q,ix in groups.items():
  if repos[ix[0]]==held or not y[ix].any() or y[ix].all():continue
  train[ix]=True;trainq.append(q);pos=ix[y[ix]==1];neg=ix[y[ix]==0];weights[pos]=1./len(pos);weights[neg]=1./len(neg)
 assert not set(trainq)&set(qids[repos==held]);weights[train]/=weights[train].mean();mean=x[train].mean(axis=0);scale=x[train].std(axis=0);scale=np.where(scale>1e-9,scale,1.);z=(x-mean)/scale;model=MLPClassifier(hidden_layer_sizes=(24,),activation='relu',solver='lbfgs',alpha=1,max_iter=300,max_fun=15000,random_state=42,tol=1e-8);before=time.perf_counter()
 with warnings.catch_warnings(record=True) as warning_list:
  warnings.simplefilter('always');model.fit(z[train],y[train],sample_weight=weights[train])
 record={'mean':mean.tolist(),'scale':scale.tolist(),'weights':[a.tolist() for a in model.coefs_],'biases':[a.tolist() for a in model.intercepts_]};raw=head_logits(record,x);assert np.allclose(expit(raw),model.predict_proba(z)[:,1],atol=1e-12,rtol=1e-12);scores[repos==held]=raw[repos==held];train_correct=sum(bool(y[ix[np.argmax(raw[ix])]]) for q,ix in groups.items() if q in set(trainq));receipt={'held_out':held,'training_repositories':sorted(set(repos[train])),'training_queries':len(trainq),'train_top1':int(train_correct),'iterations':int(model.n_iter_),'loss':float(model.loss_),'warnings':[str(e.message) for e in warning_list],'fit_ms':(time.perf_counter()-before)*1000};registration['folds'].append(receipt);(out/(held+'.json')).write_text(json.dumps(record,separators=(',',':')));print(json.dumps(receipt),flush=True)
outcomes=[];orders=[]
for q,c in cases.items():
 units=baseline[q]['baseline_units']
 if q in obs:
  ix=groups[q];units=obs[q]['units'];named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(ix)),key=lambda i:(-int(named is not None and units[i]['path']==named),-baseline[q]['exact'][i],-scores[ix[i]],i));units=[units[i] for i in order]
 hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
summary=summarize(outcomes);(out/'outcomes.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(out/'orders.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in orders));(out/'summary.json').write_text(json.dumps(summary,indent=2));registration['status']='ALL400small nonlinear head development closed; no reserve';(out/'registration.json').write_text(json.dumps(registration,indent=2));print(json.dumps({'total':summary['total'],'cohort':summary['cohort']}),flush=True)
