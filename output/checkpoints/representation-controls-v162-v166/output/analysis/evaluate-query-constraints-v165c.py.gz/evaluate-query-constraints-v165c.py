"""Fixed lexical query-role model and separately added explicit priorities."""
import json,sys,re,hashlib
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
sys.path.insert(0,'experiments/search-engine')
from query_constraints import query_constraint_priorities
from fit_score_calibration import summarize
from verifiable_grading import identity_hit
from ken.retrieval.intent import interpret,requested_piece_path
from ken.retrieval.model import SearchRequest
from ken.retrieval.roles import classify_role

def rows(p):return list(map(json.loads,Path(p).read_text().splitlines()))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
w=Path.cwd();cap=w/'output/development/operational-evidence-v160';syntax=w/'output/development/source-syntax-evidence-v162b';native=w/'output/development/native-symbol-evidence-v152';out=w/'output/development/query-constraints-v165c';out.mkdir(exist_ok=False);reg=json.loads((cap/'registration.json').read_text());sreg=json.loads((syntax/'registration.json').read_text());nreg=json.loads((native/'registration.json').read_text());assert reg['status']=='ALL250operational public source observations closed without Gold' and sreg['status']=='ALL250source syntax public observations closed without Gold';obs={};expanded={};nativeobs={}
registration={'scope':'R1char_wbTFIDF3-5sublinearTF,max20000,trainfoldonly,LogRegC1balanced,rawNN+logRoleProb; R2adds explicitquery priorities. EXPOSED400only, no HPO or private data','producer_sha256':sha(__file__),'helper_sha256':sha('experiments/search-engine/query_constraints.py'),'captures':{str(p):sha(p) for p in [cap/'registration.json',syntax/'registration.json',native/'registration.json']},'status':'registered before exposed labels','folds':[]};(out/'registration.json').write_text(json.dumps(registration,indent=2))
for repo,pins in reg['closed'].items():
 for f,d in pins.items():assert sha(cap/repo/f)==d
 assert sha(syntax/repo/'observations.jsonl')==sreg['closed'][repo]['observations.jsonl']
 assert sha(native/repo/'observations.jsonl')==nreg['closed'][repo]['observations.jsonl']
 feature_data=np.load(cap/repo/'features.npz',allow_pickle=False);doc_column=reg['n1_features'].index('reference_docs')
 for o in rows(cap/repo/'observations.jsonl'):
  local=feature_data['x'][feature_data['qid']==o['id']];assert len(local)==len(o['source_cues'])
  for cue,value in zip(o['source_cues'],local[:,doc_column]):cue['coverage']['docs']=float(value)
  obs[o['id']]=o
 for o in rows(syntax/repo/'observations.jsonl'):expanded[o['id']]=o['expanded_query']
 for o in rows(native/repo/'observations.jsonl'):nativeobs[o['id']]=o
assert len(obs)==len(expanded)==len(nativeobs)==250
cases={};baseline={}
for rootname in ['public-default-v155-original','public-default-v157-symbols']:
 root=w/'output/development'/rootname;lock=json.loads((root/'lock.json').read_text())
 for c in rows(lock['public_cases']):cases[c['id']]={**c,'cohort':'original200' if rootname.endswith('original') else 'new_symbol200','query_kind':c['query_style']}
 for f in (root/'capture').glob('*/answers.jsonl'):
  for o in rows(f):baseline[o['id']]=o
m=json.loads((w/'output/development/score-calibration-v147/fit-manifest.json').read_text());gold={}
for c in m['cohorts']:
 for path,d in c['exposed_gold_pins'].items():
  assert sha(path)==d
  for g in rows(path):gold[g['id']]=g
assert set(cases)==set(gold)==set(baseline) and len(cases)==400;qids=list(obs);queries=[expanded[q] for q in qids];repos=np.array([cases[q]['repo_id'] for q in qids]);labels=[]
for q in qids:
 n=nativeobs[q];positive=[i for i,u in enumerate(n['units']) if identity_hit({'unit':u},gold[q]['acceptable_units'])];assert positive;roles={classify_role(n['units'][i]['path'])=='test' for i in positive};assert len(roles)==1;labels.append(int(roles.pop()))
y=np.array(labels);prob=np.empty(len(y))
for held in sorted(set(repos)):
 train=np.flatnonzero(repos!=held);test=np.flatnonzero(repos==held);vectorizer=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,max_features=20000,lowercase=True);a=vectorizer.fit_transform([queries[i] for i in train]);b=vectorizer.transform([queries[i] for i in test]);model=LogisticRegression(C=1,class_weight='balanced',max_iter=1000,random_state=42);model.fit(a,y[train]);prob[test]=model.predict_proba(b)[:,1];registration['folds'].append({'held_out':held,'training_repositories':sorted(set(repos[train])),'training_queries':[qids[i] for i in train],'role_correct':int(((prob[test]>=.5)==y[test]).sum()),'queries':len(test)});(out/(held+'.json')).write_text(json.dumps({'vocabulary':{k:int(v) for k,v in vectorizer.vocabulary_.items()},'idf':vectorizer.idf_.tolist(),'weights':model.coef_[0].tolist(),'bias':float(model.intercept_[0])},separators=(',',':')))
byq=dict(zip(qids,prob));results={}
for name in ['R1_lexical_role','R2_explicit_constraints']:
 outcomes=[];orders=[]
 for q,c in cases.items():
  units=baseline[q]['units']
  if q in obs:
   o=obs[q];assert o['units']==units;p=float(np.clip(byq[q],1e-6,1-1e-6));scores=np.array(o['raw_scores'])+np.array([np.log(p if classify_role(u['path'])=='test' else 1-p) for u in units]);priorities=[(0,0,0)]*len(units)
   if name.startswith('R2'):
    positive=not bool(re.search(r'\b(?:not|no|never|without|except)\b',expanded[q],re.I));priorities=query_constraint_priorities(o['source_cues'],tests_requested=interpret(SearchRequest(c['query'])).purpose=='tests',positive_references=positive)
   named=requested_piece_path(SearchRequest(c['query']));order=sorted(range(len(units)),key=lambda i:(-int(named is not None and units[i]['path']==named),*[-v for v in priorities[i]],-scores[i],i));units=[units[i] for i in order]
  hit=lambda u:bool(identity_hit({'unit':u},gold[q]['acceptable_units']));outcomes.append({k:c[k] for k in ['cohort','target_kind','repo_id','language','query_kind']}|{'id':q,'top1':bool(units and hit(units[0])),'recall10':any(map(hit,units))});orders.append({'id':q,'units':units})
 result=summarize(outcomes);results[name]=result;(out/(name+'-outcomes.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in outcomes));(out/(name+'-orders.jsonl')).write_text(''.join(json.dumps(o)+'\n' for o in orders));print(json.dumps({'variant':name,'total':result['total'],'cohort':result['cohort']}),flush=True)
results['role_classification']={'correct':int(((prob>=.5)==y).sum()),'queries':len(y)};registration['status']='ALL R1/R2development closed; no reserve';(out/'registration.json').write_text(json.dumps(registration,indent=2));(out/'summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results['role_classification']))
