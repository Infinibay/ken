from pathlib import Path
import json,tempfile,sys,hashlib
from unittest.mock import patch
import unseen_piece_score as score
class StopBeforeScoring(Exception):pass

def dump(p,x,jsonl=False):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(r)+'\n' for r in x) if jsonl else json.dumps(x))
def probe(defect):
 with tempfile.TemporaryDirectory(prefix='v135b-scorer-synthetic-') as td:
  d=Path(td).resolve();cases=[{'id':i,'repo_id':'r','target_kind':'file'} for i in ['synthetic-a','synthetic-b']];pc=d/'public.jsonl';dump(pc,cases,True)
  refs=[]
  for c in cases:
   p=d/(c['id']+'-refs.jsonl');dump(p,[{'id':c['id'],'acceptable_units':[{'target_kind':'file','path':'expected.txt','entity':None}]}],True);refs.append(p)
  variants={'baseline':{'source_receipt':'old'},'optimized':{'source_receipt':'new'}}
  lk={'queries':2,'public_cases':str(pc),'input_pins':{str(pc):score.sha(pc)},'reference_pins':{str(p):score.sha(p) for p in refs},'variants':variants,'scorer_sha256':'0'*64 if defect=='scorer_pin' else score.sha(score.__file__),'grading_sha256':'0'*64 if defect=='grading_pin' else score.sha(score.verifiable_grading.__file__)}
  lock=d/'lock.json';dump(lock,lk);roots=[]
  for role in variants:
   root=d/role;repo=root/'r';chosen=cases[:1] if defect=='incomplete' else cases
   answers=[dict(c,card=None,units=[],native_units=[],pool_sha256='synthetic-unchanged-pool') for c in chosen]
   if role=='optimized' and defect=='top1_order':answers[0].update(card={'unit':{'target_kind':'file','path':'wrong.txt','entity':None}},units=[{'target_kind':'file','path':'expected.txt','entity':None}])
   if role=='optimized' and defect=='too_many_units':answers[0]['units']=[{'target_kind':'file','path':str(i)+'.txt','entity':None} for i in range(11)]
   if role=='optimized' and defect=='duplicate_units':answers[0]['units']=[{'target_kind':'file','path':'expected.txt','entity':None}]*2
   dump(repo/'answers.jsonl',answers,True)
   dump(repo/'performance.json',{'providers':['CPUExecutionProvider'],'heavy_imports':[],'timings':[{'id':c['id'],'ms':1,'cpu_ms':1} for c in chosen],'peak_rss_native':1,'rss_unit':'bytes'})
   reg={'status':'ALL additional public outputs closed without Gold','lock_sha256':score.sha(lock),'variant':role,'variant_policy':variants[role],'closed':{'r':{f:score.sha(repo/f) for f in ['answers.jsonl','performance.json']}}}
   if defect=='wrong_policy' and role=='optimized':reg['variant_policy']={'source_receipt':'old'}
   dump(root/'registration.json',reg);roots.append(root)
  args=['score','--baseline',str(roots[0]),'--candidate',str(roots[0] if defect=='same_capture' else roots[1]),'--lock',str(lock),'--output',str(d/'out'),'--private-output',str(d/'private'),'--gold',*[str(p) for p in refs]]
  opened=[];old_rows=score.rows
  def trace(p):
   if Path(p) in refs:opened.append(Path(p).name)
   return old_rows(p)
  caught=None
  try:
   with patch.object(sys,'argv',args),patch.object(score,'rows',trace):score.main()
  except Exception as e:caught=type(e).__name__+': '+str(e)
  return {'reference_files_opened':len(opened),'exception':caught,'summary_created':(d/'out/summary.json').exists(),'all_data_synthetic':True}
x={'scorer_sha256':score.sha(score.__file__),'probes':{d:probe(d) for d in ['incomplete','scorer_pin','grading_pin','same_capture','wrong_policy','top1_order','too_many_units','duplicate_units']},'real_outputs_or_references_opened_or_scored':False}
p=Path('/private/tmp/ken-unseen-cpu-validation-20261015-cs/review/scorer-v135b-synthetic-results.json');p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n');print(json.dumps(x,indent=2))
