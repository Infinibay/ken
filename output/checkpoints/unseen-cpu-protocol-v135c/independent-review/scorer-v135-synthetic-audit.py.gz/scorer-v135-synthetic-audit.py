from pathlib import Path
import hashlib,json,tempfile,sys
from unittest.mock import patch
import unseen_piece_score as score

class StopBeforeScoring(Exception):pass

def dump(p,x,jsonl=False):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(''.join(json.dumps(r)+'\n' for r in x) if jsonl else json.dumps(x))

def probe(missing=False,bad_scorer=False,same_run=False):
 with tempfile.TemporaryDirectory(prefix='unseen-scorer-synthetic-') as d:
  d=Path(d).resolve();cases=[{'id':'synthetic-a','repo_id':'synthetic-r','target_kind':'file'},{'id':'synthetic-b','repo_id':'synthetic-r','target_kind':'file'}]
  pc=d/'public.jsonl';dump(pc,cases,True)
  refs=[]
  for c in cases:
   p=d/(c['id']+'-refs.jsonl');dump(p,[{'id':c['id'],'acceptable_units':[{'target_kind':'file','path':'synthetic.txt','entity':None}]}],True);refs.append(p)
  lock=d/'lock.json';dump(lock,{'queries':2,'public_cases':str(pc),'input_pins':{str(pc):score.sha(pc)},'reference_pins':{str(p):score.sha(p) for p in refs},'scorer_sha256':'0'*64 if bad_scorer else score.sha(score.__file__),'variants':{'baseline':{'source_receipt':'baseline-synthetic'},'optimized':{'source_receipt':'candidate-synthetic'}}})
  roots=[]
  for role in ['baseline','candidate']:
   r=d/role;repo=r/'synthetic-r';chosen=cases[:1] if missing else cases
   answers=[{'id':c['id'],'card':None,'units':[],'native_units':[],'pool_sha256':'synthetic-fixed-pool'} for c in chosen]
   dump(repo/'answers.jsonl',answers,True)
   dump(repo/'performance.json',{'providers':['CPUExecutionProvider'],'heavy_imports':[],'timings':[{'ms':1,'cpu_ms':1} for _ in answers],'peak_rss_native':1,'rss_unit':'bytes'})
   dump(r/'registration.json',{'status':'ALL additional public outputs closed without Gold','lock_sha256':score.sha(lock),'variant':'baseline' if same_run else role,'closed':{'synthetic-r':{f:score.sha(repo/f) for f in ['answers.jsonl','performance.json']}}})
   roots.append(r)
  opened=[];old_rows=score.rows
  def trace_rows(p):
   if Path(p) in refs:opened.append(str(Path(p).name))
   return old_rows(p)
  args=['unseen_piece_score.py','--baseline',str(roots[0]),'--candidate',str(roots[0] if same_run else roots[1]),'--lock',str(lock),'--output',str(d/'out'),'--private-output',str(d/'private'),'--gold',*[str(p) for p in refs]]
  def stop(*a):raise StopBeforeScoring()
  caught=None
  try:
   with patch.object(sys,'argv',args),patch.object(score,'rows',trace_rows):
    if missing:score.main()
    else:
     with patch.object(score,'evaluate_identity',stop):score.main()
  except Exception as e:caught=type(e).__name__+': '+str(e)
  return {'reference_files_opened_before_rejection_or_score_boundary':len(opened),'exception':caught,'no_engine_model_or_real_reference_opened':True}

results={'identical_partial_closed_runs':probe(missing=True),'mismatched_scorer_pin':probe(bad_scorer=True),'same_baseline_directory_as_both_roles':probe(same_run=True)}
# Fixed-identity synthetic semantics, not real outputs or benchmark scoring.
ent={'kind':'method','qualname':'C.run','owner':'C','definition_ordinal':0}
u={'target_kind':'symbol','path':'s.py','entity':ent};g=[u,{'target_kind':'symbol','path':'alt.py','entity':ent}]
assert score.identity_hit({'unit':g[1]},g)
assert not score.identity_hit({'unit':{**u,'entity':{**ent,'definition_ordinal':1}}},g)
assert not score.identity_hit({'unit':{**u,'entity':{**ent,'owner':'D'}}},g)
assert score.identity_hit({'unit':{'target_kind':'module','path':'m.py','entity':None}},[{'target_kind':'module','path':'m.py','entity':{'kind':'module'}}])
assert not score.identity_hit(None,g)
results['canonical_identity_synthetic_assertions']=5
print(json.dumps(results,indent=2))
