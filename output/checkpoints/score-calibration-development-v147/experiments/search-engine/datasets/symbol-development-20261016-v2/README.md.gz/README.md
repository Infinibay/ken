# Exposed symbol development, source wording revision 2

This is EXPOSED-DEVELOPMENT, available for training. It preserves the 200 canonical symbol identities and all source hashes, witness ranges, alternative lists, order, languages, styles and denominator from revision 1. Two English behavior queries, their public facets, request projections and source rationales were made precise after independent source review. No motor, candidate, ranking, score or fit informed this revision.

See CHANGELOG.json for the exact two changes and the binding to the immutable original. All 200 requests must be recaptured after this public-text revision; do not reuse previous query results. Source metadata, exclusion union and prospective selection protocol were copied byte for byte. Acceptance labels remain private and untouched.
