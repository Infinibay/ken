from collections import defaultdict
from pathlib import Path
import pytest
from ken.parsers import detect_language
from ken.retrieval.model import SearchRequest
from ken.retrieval.passages import extract_passages
from ken.retrieval.piece_catalog import SourceCatalog
from source_role_preference import prefer_source_role


@pytest.fixture
def catalog(tmp_path):
    owners = defaultdict(list)
    for path, source in [('src/worker.py', b'def build_value():\n    return 1\n'),
                         ('tests/test_worker.py', b'def build_expected():\n    return 1\n\ndef test_value():\n    assert build_expected() == 1\n')]:
        target = tmp_path / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source)
        language, parse = detect_language(Path(path))
        for passage in extract_passages(source, parse(source, path), path=path, language=language):
            owners[passage.entity].append(passage)
    return SourceCatalog(tmp_path, owners)


def units(catalog, *names):
    lookup = {key.qualname: key for key in catalog.owners}
    return [{'target_kind': 'symbol', 'path': lookup[name].path, 'entity': lookup[name].to_dict(), 'module_name': None}
            for name in names]


def test_production_request_preference_keeps_all_candidates(catalog):
    choices = units(catalog, 'test_value', 'build_value', 'build_expected')
    assert prefer_source_role(SearchRequest('Find the value factory.'), choices, catalog) == [1, 0, 2]


def test_source_role_does_not_invent_a_test_entry_requirement_for_a_helper(catalog):
    choices = units(catalog, 'build_value', 'build_expected', 'test_value')
    assert prefer_source_role(SearchRequest('Where does a value test helper construct its output?'), choices, catalog) == [1, 2, 0]


def test_explicit_purpose_is_authoritative(catalog):
    choices = units(catalog, 'test_value', 'build_value')
    request = SearchRequest('Which regression checks the value?', purpose='implementation')
    assert prefer_source_role(request, choices, catalog) == [1, 0]


def test_absent_role_and_non_symbol_search_preserve_existing_order(catalog):
    choices = units(catalog, 'test_value', 'build_value')
    assert prefer_source_role(SearchRequest('Find an example of this API.', purpose='usage'), choices, catalog) == [0, 1]
    assert prefer_source_role(SearchRequest('Which file owns the worker?'), [{'target_kind': 'file', 'path': 'src/worker.py', 'entity': None}], catalog) == [0]
