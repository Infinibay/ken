"""Source-level relational witnesses, distinct from word/count features.

These are observed syntax relations, not interprocedural execution proofs.
Unsupported code remains unknown and every candidate remains in the pool.
"""
import ast
import re

from lexical_code_view import LexicalCodeView
from source_syntax_view import SourceSyntax, _CALLABLE


def requested_operations(query):
    lower = query.casefold()
    required = set()
    if (re.search(r'\b(?:retain\w*|preserv\w*|keep\w*)\b', lower)
            and re.search(r'\bexception\b', lower) and re.search(r'\bcause\b', lower)
            and not re.search(r'\b(?:not|without|suppress\w*)\b[^.;]{0,60}\bcause\b', lower)):
        family = 'AttributeError' if re.search(r'\battribute[\s-]+error\b', lower) else '*'
        required.add('cause:' + family)
    if (re.search(r'\b(?:mapping|dictionary)\b', lower) and re.search(r'\bkey\b', lower)
            and re.search(r'\b(?:assign\w*|writ\w*|set\w*)\b', lower)
            and re.search(r'\b(?:remember\w*|previous|old|undo|absent)\b', lower)
            and not re.search(r'\b(?:without|never|not)\s+(?:assign\w*|writ\w*|set\w*)\b', lower)):
        required.add('snapshot_keyed_write')
    if (re.search(r'\breturn\w*\b', lower) and re.search(r'\b(?:flag|boolean|state)\b', lower)
            and re.search(r'\bor\b', lower) and re.search(r'\b(?:updat\w*|refresh\w*|assign\w*)\b', lower)):
        required.add('returned_flag_refresh')
    return required


def prefer_operations(required, witnesses, order):
    def matches(observed):
        return all((any(item.startswith('cause:') for item in observed) if item == 'cause:*'
                    else item in observed) for item in required)
    return sorted(order, key=lambda index: not matches(witnesses[index])) if required else list(order)


def _same(left, right):
    return ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False)


def _direct_nodes(root):
    pending = [root]
    while pending:
        node = pending.pop()
        yield node
        for child in ast.iter_child_nodes(node):
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                pending.append(child)


def _snapshot_write(statements):
    for read, write, record in zip(statements, statements[1:], statements[2:]):
        if not (isinstance(read, ast.Assign) and len(read.targets) == 1 and isinstance(read.targets[0], ast.Name)
                and isinstance(read.value, ast.Call) and isinstance(read.value.func, ast.Attribute)
                and read.value.func.attr == 'get' and read.value.args):
            continue
        if not (isinstance(write, ast.Assign) and len(write.targets) == 1
                and isinstance(write.targets[0], ast.Subscript)):
            continue
        target = write.targets[0]
        if not (_same(target.value, read.value.func.value) and _same(target.slice, read.value.args[0])):
            continue
        if not (isinstance(record, ast.Expr) and isinstance(record.value, ast.Call)
                and isinstance(record.value.func, ast.Attribute) and record.value.func.attr == 'append'
                and len(record.value.args) == 1 and isinstance(record.value.args[0], (ast.Tuple, ast.List))):
            continue
        values = record.value.args[0].elts
        if (len(values) == 3 and _same(values[0], target.value) and _same(values[1], target.slice)
                and isinstance(values[2], ast.Name) and values[2].id == read.targets[0].id):
            return True
    return False


class OperationWitnesses:
    def __init__(self, catalog):
        self.catalog = catalog
        self.python = LexicalCodeView(catalog)
        self._syntax = {}
        self._cache = {}

    def for_owner(self, key):
        if key in self._cache:
            return self._cache[key]
        result = set()
        if key.path.endswith(('.py', '.pyi')):
            root = self.python._node(key)
            if root is not None:
                for node in _direct_nodes(root):
                    if isinstance(node, ast.Raise) and node.cause is not None and not (
                            isinstance(node.cause, ast.Constant) and node.cause.value is None):
                        name = node.exc.func if isinstance(node.exc, ast.Call) else None
                        family = name.id if isinstance(name, ast.Name) else 'unknown'
                        result.add('cause:' + family)
                    for field in ('body', 'orelse', 'finalbody'):
                        block = getattr(node, field, None)
                        if isinstance(block, list) and _snapshot_write(block):
                            result.add('snapshot_keyed_write')
                    if isinstance(node, ast.Return) and isinstance(node.value, ast.BoolOp) and isinstance(node.value.op, ast.Or):
                        values = node.value.values
                        if (len(values) == 2 and isinstance(values[1], ast.NamedExpr)
                                and isinstance(values[0], ast.Name) and isinstance(values[1].target, ast.Name)
                                and values[0].id == values[1].target.id and isinstance(values[1].value, ast.Call)):
                            result.add('returned_flag_refresh')
        elif key.path.endswith(('.java', '.js', '.mjs', '.cjs', '.ts', '.tsx')):
            self._returned_update(key, result)
        self._cache[key] = frozenset(result)
        return self._cache[key]

    def _returned_update(self, key, result):
        if key.path not in self._syntax:
            self._syntax[key.path] = SourceSyntax((self.catalog.root / key.path).read_bytes(), key.path)
        syntax = self._syntax[key.path]
        start, end = self.catalog.extent(key)
        candidates = []
        pending = [syntax.tree.root_node]
        while pending:
            node = pending.pop()
            a, b = node.start_point[0]+1, node.end_point[0]+1
            if b < start or a > end:
                continue
            if node.type in _CALLABLE and start <= a <= b <= end:
                candidates.append(node)
            pending.extend(node.named_children)
        if not candidates:
            return
        root = min(candidates, key=lambda node: (node.start_byte, -node.end_byte))
        if root.end_point[0]+1 != end:
            return

        def unwrap(node):
            while node is not None and node.type == 'parenthesized_expression' and len(node.named_children) == 1:
                node = node.named_children[0]
            return node

        pending = [root]
        while pending:
            node = pending.pop()
            if node != root and node.type in _CALLABLE:
                continue
            if node.type == 'return_statement' and node.named_children:
                value = unwrap(node.named_children[0])
                if value.type == 'binary_expression' and any(c.type == '||' for c in value.children):
                    left = unwrap(value.child_by_field_name('left'))
                    right = unwrap(value.child_by_field_name('right'))
                    if right is not None and right.type == 'assignment_expression':
                        target = unwrap(right.child_by_field_name('left'))
                        assigned = unwrap(right.child_by_field_name('right'))
                        if (left is not None and target is not None and assigned is not None
                                and assigned.type in {'call_expression', 'method_invocation'}
                                and re.sub(r'\s+', '', syntax._raw(left)) == re.sub(r'\s+', '', syntax._raw(target))):
                            result.add('returned_flag_refresh')
            pending.extend(node.named_children)
