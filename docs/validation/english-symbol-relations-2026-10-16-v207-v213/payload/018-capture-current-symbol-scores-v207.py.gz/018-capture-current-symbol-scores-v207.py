"""Authenticate current201symbol scores: reuse identical inputs, debug changed intent only."""
from pathlib import Path
import hashlib
import json
import os
import sys
import numpy as np
from ken.bench.source_receipts import verify_frozen_source
from ken.retrieval.best_resources import default_resources
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.intent import interpret, requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_cards import build_card, card_text
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.public import find_best
from ken.retrieval.reranker_fusion import fused_reranker_order


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def canonical(unit):
    return json.dumps(unit, sort_keys=True)


w = Path.cwd()
frozen = w / 'output/frozen/requested-test-role-v201'
receipt = verify_frozen_source(frozen)
assert receipt == 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5'
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
scope = json.loads(scope_path.read_text())
cases, answers, current_pins = {}, {}, {}
for cohort, selection in scope['cohorts'].items():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row for row in rows(path) if row['target_kind'] == 'symbol'})
    root = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    current_pins[cohort] = sha(root / 'capture/registration.json')
    for repo, files in reg['closed'].items():
        path = root / 'capture' / repo / 'answers.jsonl'
        assert sha(path) == files['answers.jsonl']
        answers.update({row['id']: row for row in rows(path) if row['id'] in cases})
assert set(cases) == set(answers) and len(cases) == 150
native = w / 'output/development/english-native-trace-v196'
native_reg = json.loads((native / 'registration.json').read_text())
assert native_reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
prior = w / 'output/development/token-budget-v193'
prior_reg = json.loads((prior / 'registration.json').read_text())
assert prior_reg['status'] == 'ALL250token-budget observations closed without Gold'
out = w / 'output/development/current-symbol-scores-v207'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English150symbols, current201ACTUALMCP pool/order parity; no Gold, no inference-policy changes, reserve CLOSED',
    'recipe': 'For unchanged normal intent: same original/expandedEnglish query, same query_test feature, same currentMCPorder, same entire neural card bytes/hash => reuse closed publishedD193original1024logit and native196rank. Any changed intent/pool/query => real201find_best explain=True; verify normalMCPunitorder exactly before retaining actual signals. Exact bypass unchanged.',
    'limitation': 'Guarded scalar reconstruction, not fresh251trace or normal MCP latency. Reused scores marked explicitly; debug presentation differs from normal output but ranking source/code is identical.',
    'producer_sha256': sha(Path(__file__)), 'source_receipt': receipt,
    'selection_sha256': sha(scope_path), 'current_mcp_pins': current_pins,
    'native_trace_sha256': sha(native / 'registration.json'), 'nn_capture_sha256': sha(prior / 'registration.json'),
    'status': 'Registered BEFORE score reconstruction and inference',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
records = []
for repo, native_pins in native_reg['closed'].items():
    for name, digest in native_pins.items():
        assert sha(native / repo / name) == digest
    path = prior / repo / 'observations.jsonl'
    assert sha(path) == prior_reg['closed'][repo]['observations.jsonl']
    previous = {row['id']: row for row in rows(path)}
    old_native = {row['id']: row for row in rows(native / repo / 'observations.jsonl')}
    values = np.load(native / repo / 'features.npz', allow_pickle=False)
    feature_index = list(values['features']).index('expanded_query_test')
    selected = [case for case in cases.values() if case['repo_id'] == repo]
    root = Path('/private/tmp/ken-public-default-v143/repos') / repo
    paths = {unit['path'] for case in selected for unit in answers[case['id']]['units']}
    with project_connection(root) as connection:
        catalog = SourceCatalog(root, {key: ps for key, ps in owner_passages(connection).items() if key.path in paths})
        for case in selected:
            query_id = case['id']
            before = old_native[query_id]
            units = answers[query_id]['units']
            if before['exact_bypass']:
                assert answers[query_id]['public_response']['profile_version'] == 'best-exact-source-v1'
                assert units == before['actual_units']
                records.append({'id': query_id, 'exact_bypass': True, 'units': units, 'score_rows': []})
                continue
            old_nn = previous[query_id]
            expanded = old_nn['expanded_query']
            matrix = values['x'][values['qid'] == query_id]
            old_test = matrix[:, feature_index]
            assert len(old_test) > 0 and len(set(old_test)) == 1
            current_test = float(interpret(SearchRequest(case['query'])).purpose == 'tests')
            can_reuse = (expanded == case['query'] and old_test[0] == current_test
                         and units == before['verified_current_mcp_units'])
            scores = []
            if can_reuse:
                old_lookup = {canonical(unit): index for index, unit in enumerate(old_nn['units'])}
                native_lookup = {canonical(unit): index for index, unit in enumerate(before['units'][:10])}
                for unit in units:
                    key = EntityKey(path=unit['path'], **unit['entity'])
                    text = card_text(build_card(key, 'symbol', [key], expanded, catalog))
                    digest = hashlib.sha256(text.encode()).hexdigest()
                    index = old_lookup[canonical(unit)]
                    assert digest == old_nn['modes']['original_1024']['input_hashes'][index]
                    n = native_lookup[canonical(unit)]
                    scores.append({'unit': unit, 'native_rank': n + 1, 'native_score': before['native_scores'][n],
                                   'neural_score': old_nn['modes']['original_1024']['scores'][index], 'input_sha256': digest})
                source = 'Guarded same intent/source/MCPorder/query/card hashes; closed193NN1024 and196native scalars reused'
            else:
                response = find_best(connection, root, case['query'], scope='symbols', piece_kind='symbol',
                                     explain=True, max_chars=1_000_000)
                actual_units = [{'target_kind': result['piece_kind'], 'path': result['path'],
                                 'entity': result['entity'], 'module_name': None} for result in response['results']]
                assert actual_units == units, query_id
                expanded = default_resources().owner_ranker.prepare_query(case['query'])
                for unit, result in zip(units, response['results'], strict=True):
                    signal = result['signals']
                    key = EntityKey(path=unit['path'], **unit['entity'])
                    text = card_text(build_card(key, 'symbol', [key], expanded, catalog))
                    scores.append({'unit': unit, 'native_rank': signal['piece_rank'],
                                   'native_score': signal['piece_score'], 'neural_score': signal['neural_score'],
                                   'input_sha256': hashlib.sha256(text.encode()).hexdigest()})
                (out / (query_id + '-debug.json')).write_text(json.dumps(response, indent=2))
                source = 'Fresh201realAPI explain=True, exact current normalMCPorder verified'
            native_order = sorted(range(len(units)), key=lambda index: scores[index]['native_rank'])
            assert [scores[index]['native_rank'] for index in native_order] == list(range(1, len(units)+1))
            order = [native_order[index] for index in fused_reranker_order([scores[i]['neural_score'] for i in native_order])]
            named = requested_piece_path(SearchRequest(case['query']))
            if named:
                order.sort(key=lambda i: units[i]['path'] != named)
            assert [units[index] for index in order] == units, query_id
            records.append({'id': query_id, 'query': case['query'], 'expanded_query': expanded,
                            'exact_bypass': False, 'units': units, 'score_rows': scores, 'score_origin': source})
            if not can_reuse:
                print(json.dumps({'id': query_id, 'fresh_API': True, 'normalMCPorder_exact': True}), flush=True)
assert len(records) == 150 and {row['id'] for row in records} == set(cases)
assert not any(name in sys.modules for name in ['torch', 'transformers', 'sentence_transformers'])
origins = {}
source_root = (frozen / 'src').resolve()
for name, module in tuple(sys.modules.items()):
    if (name == 'ken' or name.startswith('ken.')) and getattr(module, '__file__', None):
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(source_root), path
        origins[name] = {'path': str(path), 'sha256': sha(path)}
models = default_resources()
assets = models.neural._prepare()
assets.verify()
assert assets.graph_sha256 == '8e22c1a014dbb6bf803824b531943ee067de4e9c6dea72f8c178348732db38bf'
assert models.neural._max_tokens == 1024 and models.neural._session.get_providers() == ['CPUExecutionProvider']
(out / 'scores.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in records))
protocol.update(status='ALL150currentEnglishsymbol scores CLOSED without Gold', scores_sha256=sha(out / 'scores.jsonl'),
                exact=sum(row['exact_bypass'] for row in records),
                fresh_API=sum(not row['exact_bypass'] and row['score_origin'].startswith('Fresh') for row in records),
                origins=origins, graph_sha256=assets.graph_sha256, max_tokens=1024, providers=['CPUExecutionProvider'])
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({key: protocol[key] for key in ['status', 'exact', 'fresh_API', 'scores_sha256']}), flush=True)
