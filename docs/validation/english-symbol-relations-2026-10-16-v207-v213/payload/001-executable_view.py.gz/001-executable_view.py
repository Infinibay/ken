"""Research-only isolated source projection, no query/label inputs."""
def executable_view(description):
    key=description.entity
    lines=[f'symbol {key.path} {key.qualname}',description.fields['signature'],'Implementation:']
    used=sum(map(len,lines))+len(lines)-1
    for line in description.fields['executable'].splitlines()[:64]:
        if used+len(line)+1>12000:
            break
        lines.append(line)
        used+=len(line)+1
    return '\n'.join(lines)
