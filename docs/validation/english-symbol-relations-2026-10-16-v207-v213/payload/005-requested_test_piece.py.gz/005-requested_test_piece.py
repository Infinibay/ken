"""Research distinction between a requested test case and test support code.

This is source evidence of a conventional test entry, not proof that a runner
will collect or execute it. No test-case identity or repository name is encoded.
"""
from collections.abc import Sequence
import re
from ken.retrieval.intent import _TEST_OBJECT, interpret
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog

_SUPPORT = re.compile(r'^\s+(?:helpers?|fixtures?|factor(?:y|ies)|builders?|utilit(?:y|ies))\b')
_JAVA_TEST = re.compile(r'(?m)^\s*@(?:[\w]+\.)*(?:Test|RepeatedTest|ParameterizedTest|TestFactory|TestTemplate)\b')


def requests_test_case(query: str) -> bool:
    if interpret(SearchRequest(query)).purpose != 'tests':
        return False
    lower = query.casefold().strip()
    subject = re.sub(r'^where\s+(?:does|do|is|are)\s+', 'find ', lower)
    if re.search(r'\b[\w]+-double\s+(?:factory|helper|fixture|builder)\b', subject):
        return False
    match = _TEST_OBJECT.match(subject)
    if match:
        return not bool(_SUPPORT.match(subject[match.end():]))
    return bool(re.match(r'^where\s+(?:is|are)\b', lower) and re.search(r'\btested\b', lower))


def is_test_case(key: EntityKey, catalog: SourceCatalog) -> bool:
    if (key.kind not in {'function', 'method'} or key not in catalog.owners
            or catalog.owners[key][0].role != 'test' or catalog.enclosing_callable(key) is not None):
        return False
    name = (key.qualname or '').rsplit('.', 1)[-1]
    if key.path.endswith(('.py', '.pyi')):
        return name.startswith('test')
    if key.path.endswith('.java'):
        start, end = catalog.extent(key)
        declaration = '\n'.join(catalog.lines[key.path][start-1:min(end, start+11)]).split('{', 1)[0]
        return bool(_JAVA_TEST.search(declaration))
    return False


def prefer_requested_test_piece(query: str, units: Sequence[dict], catalog: SourceCatalog) -> list[int]:
    order = list(range(len(units)))
    if not requests_test_case(query) or any(unit['target_kind'] != 'symbol' for unit in units):
        return order
    entries = [is_test_case(EntityKey(path=unit['path'], **unit['entity']), catalog) for unit in units]
    return sorted(order, key=lambda index: not entries[index])
