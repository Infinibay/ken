"""Query-free Python lexical code and explicitly imported type contracts.

Lexical containment is not execution. Imported class documentation is context,
not evidence that its methods execute in the primary candidate. Unknown or
shadowed bindings add no context. Every addition retains source provenance.
"""
import ast
from collections import defaultdict
import io
import tokenize

from ken.retrieval.description import describe_owner
from ken.retrieval.piece_catalog import module_name


class LexicalCodeView:
    def __init__(self, catalog):
        self.catalog = catalog
        self._trees = {}
        self._cleaned = {}
        self._types = defaultdict(list)
        for key in catalog.owners:
            if key.kind == 'class' and key.qualname and '.' not in key.qualname:
                self._types[module_name(key.path), key.qualname].append(key)

    def _tree(self, path):
        if path not in self._trees:
            try:
                self._trees[path] = ast.parse('\n'.join(self.catalog.lines[path]))
            except (SyntaxError, ValueError):
                self._trees[path] = None
        return self._trees[path]

    def _node(self, key):
        if not key.path.endswith(('.py', '.pyi')):
            return None
        tree = self._tree(key.path)
        if tree is None:
            return None
        start, end = self.catalog.extent(key)
        name = (key.qualname or '').rsplit('.', 1)[-1]
        matches = [node for node in ast.walk(tree)
                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                   and node.name == name and node.end_lineno == end and start <= node.lineno <= end]
        return matches[0] if len(matches) == 1 else None

    def _code_lines(self, path):
        if path in self._cleaned:
            return self._cleaned[path]
        source = '\n'.join(self.catalog.lines[path])
        raw = source.splitlines(keepends=True)
        offsets = [0]
        for line in raw:
            offsets.append(offsets[-1] + len(line))
        removed = []
        def ast_offset(line, column):
            # AST columns count UTF-8 bytes; tokenize columns count characters.
            prefix = raw[line-1].encode('utf8')[:column].decode('utf8')
            return offsets[line-1] + len(prefix)
        for inner in ast.walk(self._tree(path)):
            if isinstance(inner, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and inner.body:
                first = inner.body[0]
                if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                    removed.append((ast_offset(first.lineno, first.col_offset),
                                    ast_offset(first.end_lineno, first.end_col_offset)))
        for token in tokenize.generate_tokens(io.StringIO(source).readline):
            if token.type == tokenize.COMMENT:
                removed.append((offsets[token.start[0]-1] + token.start[1], offsets[token.end[0]-1] + token.end[1]))
        chars = list(source)
        for a, b in removed:
            for i in range(a, b):
                if chars[i] != '\n':
                    chars[i] = ' '
        self._cleaned[path] = ''.join(chars).splitlines()
        return self._cleaned[path]

    def scope(self, key):
        node = self._node(key)
        if node is None:
            return None
        start, end = self.catalog.extent(key)
        lines = [line.rstrip() for line in self._code_lines(key.path)[start-1:end]]
        lines = [line for line in lines if line.strip()]
        body = '\n'.join(lines)
        text = f'symbol {key.path} {key.qualname}\nLexically contained executable source:\n{body}'
        return text if len(lines) <= 64 and len(text) <= 12000 else None

    def contracts(self, key):
        node = self._node(key)
        if node is None:
            return []
        tree = self._tree(key.path)
        imports = defaultdict(list)
        rebound = set()
        for statement in tree.body:
            if isinstance(statement, ast.ImportFrom) and statement.level == 0:
                if any(alias.name == '*' for alias in statement.names):
                    return []
                for alias in statement.names:
                    imports[alias.asname or alias.name].append((statement.module, alias.name))
            elif isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                rebound.add(statement.name)
            elif isinstance(statement, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                rebound.update(n.id for n in ast.walk(statement) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store))
            elif isinstance(statement, ast.Import):
                rebound.update(alias.asname or alias.name.split('.')[0] for alias in statement.names)
        loads = {n.id for n in ast.walk(node) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
        # Conservative: even a possible local binding prevents importing context.
        rebound.update(n.id for n in ast.walk(node) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store))
        rebound.update(n.arg for n in ast.walk(node) if isinstance(n, ast.arg))
        rebound.update(n.name for n in ast.walk(node) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)))
        rebound.update(alias.asname or alias.name.split('.')[0]
                       for n in ast.walk(node) if isinstance(n, (ast.Import, ast.ImportFrom)) for alias in n.names)
        result = []
        for name in sorted(loads - rebound):
            bindings = imports.get(name, [])
            if len(bindings) != 1:
                continue
            types = self._types.get(bindings[0], [])
            if len(types) != 1:
                continue
            target = types[0]
            fields = describe_owner(self.catalog.owners[target]).fields
            contract = '\n'.join([fields['signature'], *fields['documentation'].splitlines()[:12]])
            if not fields['documentation'].strip() or len(contract) > 2400:
                continue
            result.append({'path': target.path, 'entity': target.to_dict(), 'bound_name': name,
                           'source_hash': self.catalog.hashes[target.path], 'text': contract})
            if len(result) == 4:
                break
        return result
