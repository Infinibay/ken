"""Archive closed English controls and source review, no sealed benchmark inputs."""
from pathlib import Path
import gzip
import hashlib
import json


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
out = w / 'output/analysis/symbol-relations-export-v207-v213'
out.mkdir(exist_ok=False)
payload = out / 'payload'
payload.mkdir()
inputs = set()
stages = ['combined-symbol-policies-v206-r1', 'combined-symbol-policies-grade-v206-r1',
          'current-symbol-scores-v207', 'source-role-order-v208', 'source-role-order-grade-v208',
          'current-executable-view-v209', 'executable-view-policies-v209', 'executable-view-policies-grade-v209',
          'lexical-code-context-v210', 'lexical-code-policies-v210', 'lexical-code-policies-grade-v210',
          'relational-operation-policies-v211', 'relational-operation-policies-grade-v211',
          'bounded-operation-policies-v213', 'bounded-operation-policies-grade-v213']
for name in stages:
    root = w / 'output/development' / name
    assert (root / 'registration.json').is_file(), name
    inputs.update(path for path in root.rglob('*') if path.is_file())
for name in ['combined-symbol-policies-v206-r1', 'source-role-order-v208', 'executable-view-policies-v209',
             'lexical-code-policies-v210', 'relational-operation-policies-v211', 'bounded-operation-policies-v213']:
    root = w / 'output/development' / name
    registration = json.loads((root / 'registration.json').read_text())
    assert registration['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
    assert sha(root / 'predictions.jsonl') == registration['predictions_sha256']
scripts = ['capture-current-symbol-scores-v207.py', 'capture-executable-view-v209.py',
           'capture-lexical-code-context-v210.py', 'english-reference-source-review-v212.json',
           'english-reference-source-review-v212.md']
scripts += [prefix + name + '.py' for prefix in ['capture-', 'grade-'] for name in [
    'combined-symbol-policies-v206-r1', 'source-role-order-v208', 'executable-view-policies-v209',
    'lexical-code-policies-v210', 'relational-operation-policies-v211', 'bounded-operation-policies-v213']]
inputs.update(w / 'output/analysis' / name for name in scripts)
helpers = ['source_role_preference', 'executable_view', 'lexical_code_view', 'relational_operations',
           'source_syntax_view', 'requested_test_piece', 'explicit_code_terms']
for name in helpers:
    inputs.add(w / 'experiments/search-engine' / (name + '.py'))
    tests = w / 'experiments/search-engine' / ('test_' + name + '.py')
    if tests.is_file():
        inputs.add(tests)
inputs.add(Path(__file__))
manifest147 = w / 'output/development/score-calibration-v147/fit-manifest.json'
inputs.add(manifest147)
public_gold = {}
for i, cohort in enumerate(json.loads(manifest147.read_text())['cohorts']):
    for j, (name, digest) in enumerate(cohort['exposed_gold_pins'].items()):
        path = Path(name)
        assert sha(path) == digest
        inputs.add(path)
        public_gold[path] = f'fixed-exposed-gold/cohort-{i}-{j}.jsonl'
logs = ['ken-current-symbol-scores-v207.log', 'ken-source-role-preference-v208-red.log',
        'ken-current-executable-view-v209.log', 'ken-lexical-code-view-v210-red.log',
        'ken-lexical-code-view-v210-inline-red.log', 'ken-lexical-code-context-v210.log',
        'ken-relational-operations-v211-red.log']
inputs.update(Path('/private/tmp') / name for name in logs)
records = []
for i, path in enumerate(sorted(inputs)):
    assert path.is_file(), path
    label = public_gold.get(path) or (path.relative_to(w).as_posix() if path.is_relative_to(w) else 'verification/' + path.name)
    data = path.read_bytes()
    target = payload / (f'{i:03d}-' + path.name + '.gz')
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    records.append({'source': label, 'source_sha256': sha(path), 'bytes': len(data),
                    'payload': target.name, 'payload_sha256': sha(target)})
manifest = {'scope': 'Closed exposed English development207-213 and source-only curation212. No reserve or fitted model weights. Fixed exposed400Gold copied byte-identically, never edited.',
    'files': records, 'source201_receipt': 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5',
    'final_status': '213bounded replay passes110/108; actual new product214MCP and full-cost confirmation REQUIRED before activation'}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
results = {}
for number, name in [(206, 'combined-symbol-policies-grade-v206-r1'), (208, 'source-role-order-grade-v208'),
                     (209, 'executable-view-policies-grade-v209'), (210, 'lexical-code-policies-grade-v210'),
                     (211, 'relational-operation-policies-grade-v211'), (213, 'bounded-operation-policies-grade-v213')]:
    summary = json.loads((w / 'output/development' / name / 'summary.json').read_text())
    results[str(number)] = {key: {k: value[k] for k in ['cohorts', 'goal_reached']} for key, value in summary.items()}
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
(out / 'reference-review.md').write_bytes((w / 'output/analysis/english-reference-source-review-v212.md').read_bytes())
(out / 'README.md').write_text('''# English symbol evidence207–213

Fixed English development:120original and120new queries,>=108strict piece top1
in EACH,Recall10>=118/119. Queries, language labels and exposed references are
unchanged. The acceptance reserve, including its public queries, remains CLOSED.
These are exposed development experiments, not a blind test or a population
accuracy estimate. Current committed actualMCP201measures113/95English top1.

## Source and mathematical controls

207authenticates all150English symbol score records:22exact bypasses,
122guarded reuses of original published68M1024logits and current native order,
plus six fresh201debugAPI captures for changed intent. Source, expanded query,
native intent feature and entire neural input hashes are checked before reuse.
No raw logits were invented from normal MCP responses.206r1then closes all240
orders before fixed Gold: raw neural symbols110/100, +requested test entry
110/103, +explicit code operator110/104. Aggregate kinds retain existing RRF.

208uses authoritative201query purpose and actual passage source role, avoiding
the duplicated old183grammar. Hard source-role preference still loses valid
test helpers and implicit regression questions: final111/101versus110/104.
It is rejected. Default implementation intent cannot be treated as a source
exclusion rule.

209scores a second query-free view with the SAME published68M1024model:
signature, path and exclusive owned executable source. Original/documentation
and code logits are averaged equally, no fitted weights or thresholds.
Mean111/102, +test entry111/104, +operator111/105. Additional view stage median
839.14ms,p951816.04ms,max2537.03ms,peak observerRSS984301568bytes onCPU.
These are NOT complete API timings or full-server RSS. One209pair truncates.

210isolates Python complete lexical executable source (including nested class
fields but excluding comments/docstrings) and explicit unshadowed imported
class documentation. Source provenance, atomic token sections and unknown
bindings are retained. Both variants reach112/104with test/operator preference,
below209. More context alone is insufficient; neither is activated.

## Relational source evidence

211adds three independent syntax witnesses, with no candidate removal:

- Explicit exception chaining, excluding `from None`, optionally matching the
  requested built-in error family. Nested callable bodies remain separate.
- A keyed update that reads a previous value with `.get`, writes the SAME
  container/key and appends that SAME previous value, in three consecutive
  source statements. A deletion or a different key is not that pattern.
- A returned short-circuit OR whose right operand assigns a call result to
  the SAME flag as its left operand. A bare flag return or a different target
  does not satisfy the complete observed relation.

Each independently recovers one new-English query; raw combined110/107.
Combined with209mean and existing test/operator preferences:111/108.
These are positive local SYNTAX witnesses, not execution or interprocedural
proofs, and absence is unknown.212source-only curator review confirms the
direct matches and records valid delegates: `setenv` also performs the keyed
update through `setitem`. Such delegation is not declared irrelevant by the
witness policy. Fixed Gold is NOT edited to add or remove any identity.

213removes naive prefix cuts from the second view. Use the COMPLETE exclusive
owned executable projection only if<=64nonblank lines,<=12000characters and
the complete query+document pair<=1024tokens. Otherwise reuse the exact
original-card score; do not truncate a longer new view. Bounded combined result:
**110/120original (91.67%),108/120new (90%),118/119Recall10**. All240variant
orders are closed before exposed Gold, including controls that fail the goal.

This qualifies the variant for production integration and actual MCP validation,
not activation by replay alone.214must reproduce source/input/order parity,
pass the complete test/type suite and measure actual400normal tool calls onCPU
with all latency outliers and whole-server memory. No release is authorized.

## Reproducing the record

`manifest.json` records the original logical path, source SHA256, compressed
payload path/SHA256 and byte count for each file. Gzip uses deterministicmtime0.
Restore public corpus snapshots and the pinned201runtime, extract payloads under
their recorded logical paths, then run each capture before its grade. External
absolute paths in old receipts must be mapped to restored exposed inputs;
their content hashes stay fixed. The three copied Gold files are exposed
development references, not any part of the sealed acceptance reserve.
''')
print(json.dumps({'payloads': len(records), 'gzip_bytes': sum(path.stat().st_size for path in payload.iterdir()),
                  'manifest_sha256': sha(out / 'manifest.json')}))
