"""Strict grading of all closed V210 variants; no adaptation or selection loop."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from verifiable_grading import identity_hit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
capture = w / 'output/development/lexical-code-policies-v210'
reg = json.loads((capture / 'registration.json').read_text())
assert reg['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
assert sha(capture / 'predictions.jsonl') == reg['predictions_sha256']
predictions = rows(capture / 'predictions.jsonl')
assert len(predictions) == 240
out = w / 'output/development/lexical-code-policies-grade-v210'
out.mkdir(exist_ok=False)
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        path = Path(name)
        assert sha(path) == digest
        gold.update({row['id']: row for row in rows(path)})
summary, outcomes = {}, []
for variant in reg['variants']:
    counts = defaultdict(lambda: {'n': 0, 'top1': 0, 'recall10': 0})
    changes = []
    for row in predictions:
        units = row['orders'][variant]
        hit = lambda unit: bool(identity_hit({'unit': unit}, gold[row['id']]['acceptable_units']))
        top1 = bool(units and hit(units[0]))
        recall10 = any(map(hit, units))
        baseline_top1 = bool(row['orders']['current_rrf'] and hit(row['orders']['current_rrf'][0]))
        count = counts[row['cohort']]
        count['n'] += 1
        count['top1'] += top1
        count['recall10'] += recall10
        outcome = {name: row[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} | {
            'variant': variant, 'top1': top1, 'recall10': recall10, 'baseline_top1': baseline_top1}
        outcomes.append(outcome)
        if top1 != baseline_top1:
            changes.append(outcome)
    assert counts['original']['n'] == counts['symbols']['n'] == 120
    assert counts['original']['recall10'] == 118 and counts['symbols']['recall10'] == 119
    summary[variant] = {'cohorts': dict(counts), 'goal_reached': all(c['top1'] >= 108 for c in counts.values()), 'changes': changes}
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
(out / 'outcomes.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in outcomes))
(out / 'registration.json').write_text(json.dumps({'status': 'ALL240English fixed variants graded', 'capture_sha256': sha(capture / 'registration.json'), 'producer_sha256': sha(Path(__file__)), 'reserve': 'CLOSED', 'limitation': 'Exposed development replay, not independent acceptance or full MCP cost'}, indent=2))
print(json.dumps({name: {k: value[k] for k in ['cohorts', 'goal_reached']} for name, value in summary.items()}))
