"""Prefer the requested source role without changing candidate membership.

Query intent owns the requested role; the indexed passage owns its source role.
This component neither guesses a second intent nor confuses test support with
a test entry point. The latter is a separate source granularity decision.
"""
from collections.abc import Sequence

from ken.retrieval.intent import interpret
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog


def prefer_source_role(request: SearchRequest, units: Sequence[dict], catalog: SourceCatalog) -> list[int]:
    order = list(range(len(units)))
    if any(unit['target_kind'] != 'symbol' for unit in units):
        return order
    role = {'implementation': 'definition', 'tests': 'test', 'usage': 'example',
            'documentation': 'documentation'}.get(interpret(request).purpose)
    matches = []
    for unit in units:
        passages = catalog.owners.get(EntityKey(path=unit['path'], **unit['entity']), ())
        matches.append(bool(passages and passages[0].role == role))
    return sorted(order, key=lambda index: not matches[index])
