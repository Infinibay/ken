"""Current EN owned executable view: fixed published68M,1024; no Gold."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

import numpy as np

sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from executable_view import executable_view
from ken.bench.source_receipts import verify_frozen_source
from ken.retrieval.best_resources import default_resources
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.model import EntityKey
from ken.retrieval.piece_cards import build_card, card_text
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def origins():
    base = Path(os.environ['PYTHONPATH']).resolve()
    result = {}
    for name, module in tuple(sys.modules.items()):
        if (name == 'ken' or name.startswith('ken.')) and getattr(module, '__file__', None):
            path = Path(module.__file__).resolve()
            assert path.is_relative_to(base), (name, path)
            result[name] = {'path': str(path), 'sha256': sha(path)}
    return result


w = Path.cwd()
frozen = w / 'output/frozen/requested-test-role-v201'
receipt = verify_frozen_source(frozen)
assert receipt == 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5'
prior = w / 'output/development/current-symbol-scores-v207'
previous = json.loads((prior / 'registration.json').read_text())
assert previous['status'] == 'ALL150currentEnglishsymbol scores CLOSED without Gold'
assert sha(prior / 'scores.jsonl') == previous['scores_sha256']
scope = json.loads((w / 'output/analysis/english-ranking-v196/registration.json').read_text())
cases = {}
for selection in scope['cohorts'].values():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row for row in rows(path)})
observed = [row for row in rows(prior / 'scores.jsonl') if not row['exact_bypass']]
assert len(observed) == 128
out = Path(sys.argv[1])
repo = sys.argv[2] if len(sys.argv) > 2 else None
out.mkdir(exist_ok=False)
if repo is None:
    registration = {
        'scope': 'Current201EN128nonexact symbol10pools, no Gold; reserve CLOSED',
        'hypothesis': 'Docstring-free owned executable projection may add complementary behavior evidence. Old W184 used512+old pools; capture current1024 independently, preserving current source/input parity.',
        'policy': 'Same executable_view W184: query-free signature+path+64whole executable lines,12000chars, no new language rewrite. Fixed controls W1code-only and W2equalmean original207logits+code-only, native tie break. No training, weights or threshold fitting. Exact and non-symbol cases stay current201. Separately test requested test-case and explicit operator policies; source-role hard policy208 already rejected.',
        'acceptance': 'Fixed240English development:>=108EACH;Recall10>=118/119. Full MCP CPU/RAM must be measured before activation. Additional view observer time is not end-to-end.',
        'producer_sha256': sha(Path(__file__)), 'helper_sha256': sha(w / 'experiments/search-engine/executable_view.py'),
        'source_receipt': receipt, 'scores_registration_sha256': sha(prior / 'registration.json'),
        'status': 'Registered BEFORE capture and Gold', 'closed': {},
    }
    (out / 'registration.json').write_text(json.dumps(registration, indent=2))
    for repo in sorted({case['repo_id'] for case in cases.values()}):
        with (out / (repo + '.log')).open('w') as log:
            subprocess.run([sys.executable, __file__, str(out / repo), repo], env=os.environ,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        registration['closed'][repo] = {name: sha(out / repo / name) for name in ['observations.jsonl', 'summary.json']}
        (out / 'registration.json').write_text(json.dumps(registration, indent=2))
        print(json.dumps({'closed': repo}), flush=True)
    registration['status'] = 'ALL128currentEnglish executable view scores CLOSED before Gold'
    (out / 'registration.json').write_text(json.dumps(registration, indent=2))
    sys.exit(0)

root = Path('/private/tmp/ken-public-default-v143/repos') / repo
selected = [row for row in observed if cases[row['id']]['repo_id'] == repo]
paths = {unit['path'] for row in selected for unit in row['units']}
observations, cache = [], {}
resources = default_resources()
with project_connection(root) as connection:
    catalog = SourceCatalog(root, {key: ps for key, ps in owner_passages(connection).items() if key.path in paths})
    # Explicit warmup is excluded from observer timings, never from end-to-end claims.
    resources.neural.score('Find the implementation.', ['def example():\n    return 1'])
    assert resources.neural._max_tokens == 1024
    assert resources.neural.providers == ('CPUExecutionProvider',)
    for row in selected:
        query = row['expanded_query']
        texts, source_hashes, original_hashes = [], [], []
        for unit, scores in zip(row['units'], row['score_rows'], strict=True):
            key = EntityKey(path=unit['path'], **unit['entity'])
            assert sha(root / key.path) == catalog.hashes[key.path]
            source_hashes.append(catalog.hashes[key.path])
            card = card_text(build_card(key, 'symbol', [key], query, catalog))
            original_hashes.append(hashlib.sha256(card.encode()).hexdigest())
            assert original_hashes[-1] == scores['input_sha256']
            if key not in cache:
                cache[key] = executable_view(describe_owner(catalog.owners[key]))
            texts.append(cache[key])
        start = time.perf_counter()
        scores, details = resources.neural.score(query, texts)
        observations.append({'id': row['id'], 'query': row['query'], 'expanded_query': query,
            'units': row['units'], 'executable_scores': scores, 'texts': texts,
            'original_input_hashes': original_hashes, 'source_hashes': source_hashes,
            'input_hashes': [hashlib.sha256(text.encode()).hexdigest() for text in texts],
            'observer_ms': (time.perf_counter() - start) * 1000, 'details': details})
        print(json.dumps({'id': row['id']}), flush=True)
(out / 'observations.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in observations))
(out / 'summary.json').write_text(json.dumps({'queries': len(observations), 'origins': origins(),
    'providers': resources.neural.providers, 'max_tokens': resources.neural._max_tokens,
    'peak_observer_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'observer_p50_ms': float(np.median([row['observer_ms'] for row in observations])),
    'observer_p95_ms': float(np.percentile([row['observer_ms'] for row in observations], 95)),
    'not_end_to_end_latency': True}, indent=2))
