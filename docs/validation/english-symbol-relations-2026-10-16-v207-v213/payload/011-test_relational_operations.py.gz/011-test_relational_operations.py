from test_lexical_code_view import make_catalog
from relational_operations import OperationWitnesses, requested_operations, prefer_operations


def test_cause_requires_direct_non_null_chaining_and_keeps_error_family(tmp_path):
    catalog = make_catalog(tmp_path, {'sample.py': '''def chained(error):
    raise AttributeError("location") from error
def suppressed():
    raise AttributeError("location") from None
def wrapper(error):
    def nested():
        raise AttributeError("location") from error
    return nested
'''})
    witnesses = OperationWitnesses(catalog)
    keys = {k.qualname: k for k in catalog.owners}
    assert 'cause:AttributeError' in witnesses.for_owner(keys['chained'])
    assert 'cause:AttributeError' not in witnesses.for_owner(keys['suppressed'])
    assert 'cause:AttributeError' not in witnesses.for_owner(keys['wrapper'])


def test_snapshot_write_binds_the_same_mapping_key_and_previous_value(tmp_path):
    template = '''def update(mapping, key, value, undo):
    old = mapping.get(key, None)
    mapping[key] = value
    undo.append((mapping, key, old))
'''
    catalog = make_catalog(tmp_path, {'sample.py': template + template.replace('update(', 'delete(').replace('mapping[key] = value', 'del mapping[key]') + template.replace('update(', 'other_key(').replace('undo.append((mapping, key, old))', 'undo.append((mapping, "different", old))')})
    witnesses = OperationWitnesses(catalog)
    keys = {k.qualname: k for k in catalog.owners}
    assert 'snapshot_keyed_write' in witnesses.for_owner(keys['update'])
    assert 'snapshot_keyed_write' not in witnesses.for_owner(keys['delete'])
    assert 'snapshot_keyed_write' not in witnesses.for_owner(keys['other_key'])


def test_returned_flag_update_is_same_value_not_just_an_or_token(tmp_path):
    catalog = make_catalog(tmp_path, {'Sample.java': '''class Sample {
    boolean flag, other;
    boolean refresh() {
        return flag || (flag = attempt());
    }
    boolean wrongTarget() {
        return flag || (other = attempt());
    }
    boolean blocking() {
        flag = attempt();
        return true;
    }
}
'''})
    keys = {k.qualname: k for k in catalog.owners}
    witnesses = OperationWitnesses(catalog)
    assert 'returned_flag_refresh' in witnesses.for_owner(keys['Sample.refresh'])
    assert 'returned_flag_refresh' not in witnesses.for_owner(keys['Sample.wrongTarget'])
    assert 'returned_flag_refresh' not in witnesses.for_owner(keys['Sample.blocking'])


def test_query_requirements_are_explicit_and_skip_negated_prose():
    assert requested_operations('Which lookup retains the original exception as its cause after an attribute error?') == {'cause:AttributeError'}
    assert requested_operations('Where is an existing flag returned or updated from an attempt?') == {'returned_flag_refresh'}
    assert requested_operations('Which update remembers an absent mapping key before assigning a temporary value and adding the old state to an undo log?') == {'snapshot_keyed_write'}
    assert requested_operations('Which helper suppresses the exception cause?') == set()
    assert requested_operations('Which mapping helper deletes a key without assigning a replacement?') == set()


def test_preference_is_stable_and_never_drops_unknown_candidates():
    required = {'cause:AttributeError'}
    assert prefer_operations(required, [set(), required, set()], [0, 1, 2]) == [1, 0, 2]
    assert prefer_operations(required, [set(), set()], [1, 0]) == [1, 0]
    assert prefer_operations(set(), [required, set()], [1, 0]) == [1, 0]
