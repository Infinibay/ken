import pytest
from explicit_code_terms import explicit_code_terms, prefer_explicit_code_terms


def test_ordinary_conjunctions_remain_stopwords_but_explicit_operators_survive():
    assert explicit_code_terms('Find a parser and a scanner or a lexer') == frozenset()
    assert explicit_code_terms('Build AND nodes or accept `not`') == frozenset({'and', 'not'})


def test_qualified_code_members_have_exact_leaf_words_but_longer_identifiers_do_not():
    documents = ['return ast.Or(values)', 'return ast.And(values)', 'return and_expression(values)']
    assert prefer_explicit_code_terms('Build AND nodes', documents, [0, 1, 2]) == [1, 0, 2]


def test_all_explicit_terms_are_required_and_original_order_is_stable():
    documents = ['ast.Or()', 'ast.And(); ast.Not()', 'ast.And()', 'ast.And(); ast.Not()']
    assert prefer_explicit_code_terms('AND with NOT', documents, [3, 0, 2, 1]) == [3, 1, 0, 2]


def test_missing_or_non_discriminating_literals_cannot_invent_a_preference():
    documents = ['return a', 'return b']
    assert prefer_explicit_code_terms('Use OR', documents, [1, 0]) == [1, 0]
    assert prefer_explicit_code_terms('Find the result', documents, [1, 0]) == [1, 0]
    assert prefer_explicit_code_terms('Use IN', ['for x in y:', 'if x in z:'], [1, 0]) == [1, 0]


def test_non_stopword_identifiers_keep_the_existing_ranking_contract():
    assert explicit_code_terms('Find the HTTP AST or CLI implementation') == frozenset()


@pytest.mark.parametrize('order', [[1], [0, 0], [-1, 0], [0, 2]])
def test_candidate_membership_cannot_be_dropped_or_duplicated(order):
    with pytest.raises(ValueError, match='permutation'):
        prefer_explicit_code_terms('Use AND', ['a', 'b'], order)
