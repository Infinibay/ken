"""Combine separately tested pure symbol-order policies on actual201MCP pools."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from relational_operations import OperationWitnesses, requested_operations, prefer_operations
from explicit_code_terms import explicit_code_terms, prefer_explicit_code_terms
from requested_test_piece import prefer_requested_test_piece
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.best_resources import default_resources
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
scope = json.loads(scope_path.read_text())
cases, answers = {}, {}
pins = {}
for cohort, selection in scope['cohorts'].items():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row | {'cohort': cohort} for row in rows(path)})
    root = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    pins[cohort] = sha(root / 'capture/registration.json')
    for repo, files in reg['closed'].items():
        path = root / 'capture' / repo / 'answers.jsonl'
        assert sha(path) == files['answers.jsonl']
        answers.update({row['id']: row for row in rows(path) if row['id'] in cases})
assert len(cases) == len(answers) == 240 and set(cases) == set(answers)
score_root = w / 'output/development/current-symbol-scores-v207'
score_reg = json.loads((score_root / 'registration.json').read_text())
assert score_reg['status'] == 'ALL150currentEnglishsymbol scores CLOSED without Gold'
assert sha(score_root / 'scores.jsonl') == score_reg['scores_sha256']
score_records = {row['id']: row for row in rows(score_root / 'scores.jsonl')}
assert len(score_records) == 150
views_root = w / 'output/development/current-executable-view-v209'
views_reg = json.loads((views_root / 'registration.json').read_text())
assert views_reg['status'] == 'ALL128currentEnglish executable view scores CLOSED before Gold'
view_records = {}
for repo, digests in views_reg['closed'].items():
    path = views_root / repo / 'observations.jsonl'
    assert sha(path) == digests['observations.jsonl']
    view_records.update({row['id']: row for row in rows(path)})
assert len(view_records) == 128
out = w / 'output/development/bounded-operation-policies-v213'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 EXPOSED development on ACTUAL201pools, authenticated207NN1024scalars:122guarded source/query/card identical reuses plus6freshAPI and22exact. No inference or model changes. Reserve CLOSED.',
    'hypothesis': 'V213same211semantic policies, source projection budget guard: atomic fallback to original current card if >64owned executable lines, full projection>12000chars or complete query+code pair>1024tokens. No prefix cuts in second view. V211 relational syntax rather than pooled operation counts. Query explicitly requests exception chaining, snapshot keyed update, or returned flag short-circuit refresh. Stable preference for direct source witnesses; preserve unknown candidates and all identities. Test each signal separately then combined on rawNN and fixed209equalmean. No learned scores/weights, source names, query IDs or repository names in policy.',
    'variants': ['current_rrf', 'neural_test_piece_operator', 'two_views_test_piece_operator', 'neural_cause', 'neural_snapshot_write', 'neural_flag_refresh', 'neural_all_relations', 'two_views_all_relations'],
    'policy': 'Actual201 answers stay fixed for non-symbols and unique exact bypass. Raw neural order preserves native ties; requested test-case preference then literal-operator preference. Always retain namedpath priority and all candidate identities. No fitted weights/IDs/names of repositories.',
    'acceptance': '>=108/120EACH;118/119Recall10; all refs unchanged. Results are pure policy replay, not full combined MCP latency/acceptance.',
    'producer_sha256': sha(Path(__file__)), 'selection_sha256': sha(scope_path), 'capture_pins': pins,
    'score_receipt_sha256': sha(score_root / 'registration.json'),
    'view_receipt_sha256': sha(views_root / 'registration.json'),
    'policy_sources': {name: sha(w / 'experiments/search-engine' / name) for name in ['requested_test_piece.py', 'explicit_code_terms.py', 'relational_operations.py', 'lexical_code_view.py', 'source_syntax_view.py']},
    'status': 'Registered BEFORE orders and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
predictions = []
witness_records = []
budget_records = []
checker = default_resources().neural
checker._load()
assert checker._max_tokens == 1024
for repo in sorted({row['repo_id'] for row in cases.values()}):
    selected = [case for case in cases.values() if case['repo_id'] == repo]
    symbol_cases = [case for case in selected if case['target_kind'] == 'symbol' and
                    answers[case['id']]['public_response']['profile_version'] != 'best-exact-source-v1']
    paths = {unit['path'] for case in symbol_cases for unit in answers[case['id']]['units']}
    catalog = None
    relations = None
    if paths:
        root = Path('/private/tmp/ken-public-default-v143/repos') / repo
        with project_connection(root) as connection:
            catalog = SourceCatalog(root, {key: ps for key, ps in owner_passages(connection).items() if key.path in paths})
            relations = OperationWitnesses(catalog)
    for case in selected:
        query_id = case['id']
        answer = answers[query_id]
        units = answer['units']
        orders = {name: units for name in protocol['variants']}
        if case in symbol_cases:
            assert catalog is not None
            results = answer['public_response']['results']
            assert len(results) == len(units)
            scored = score_records[query_id]
            assert not scored['exact_bypass'] and scored['units'] == units
            signals = scored['score_rows']
            assert [row['unit'] for row in signals] == units
            assert sorted(signal['native_rank'] for signal in signals) == list(range(1, len(units)+1))
            raw = sorted(range(len(units)), key=lambda i: (-signals[i]['neural_score'], signals[i]['native_rank']))
            neural_units = [units[i] for i in raw]
            view = view_records[query_id]
            assert view['units'] == units
            assert view['original_input_hashes'] == [row['input_sha256'] for row in signals]
            code_scores = list(view['executable_scores'])
            for index, unit in enumerate(units):
                key = EntityKey(path=unit['path'], **unit['entity'])
                description = describe_owner(catalog.owners[key])
                full = '\n'.join([f'symbol {key.path} {key.qualname}', description.fields['signature'], 'Implementation:', description.fields['executable']])
                length = len(checker._query_tokenizer.encode(case['query'], full).ids)
                accepted = (len(description.fields['executable'].splitlines()) <= 64 and len(full) <= 12000 and length <= 1024)
                if accepted:
                    assert full == view['texts'][index]
                else:
                    code_scores[index] = signals[index]['neural_score']
                budget_records.append({'id': query_id, 'unit': unit, 'full_pair_tokens': length,
                    'complete_owned_lines': len(description.fields['executable'].splitlines()), 'full_chars': len(full),
                    'accepted_complete_code_view': accepted})
            means = [(s['neural_score'] + score) / 2 for s, score in zip(signals, code_scores, strict=True)]
            mean_order = sorted(range(len(units)), key=lambda i: (-means[i], signals[i]['native_rank']))
            mean_units = [units[i] for i in mean_order]
            requested = requested_operations(case['query'])
            observed = [relations.for_owner(EntityKey(path=unit['path'], **unit['entity'])) for unit in units]
            lookup = {json.dumps(unit, sort_keys=True): value for unit, value in zip(units, observed, strict=True)}
            witness_records.append({'id': query_id, 'query': case['query'], 'requested': sorted(requested),
                'units': units, 'observed': [sorted(value) for value in observed],
                'source_hashes': [catalog.hashes[unit['path']] for unit in units]})
            for name, base, allowed in [
                ('neural_test_piece_operator', neural_units, set()),
                ('two_views_test_piece_operator', mean_units, set()),
                ('neural_cause', neural_units, {item for item in requested if item.startswith('cause:')}),
                ('neural_snapshot_write', neural_units, requested & {'snapshot_keyed_write'}),
                ('neural_flag_refresh', neural_units, requested & {'returned_flag_refresh'}),
                ('neural_all_relations', neural_units, requested),
                ('two_views_all_relations', mean_units, requested)]:
                facts = [lookup[json.dumps(unit, sort_keys=True)] for unit in base]
                base = [base[i] for i in prefer_operations(allowed, facts, list(range(len(base))))]
                orders[name] = [base[i] for i in prefer_requested_test_piece(case['query'], base, catalog)]
            for name in protocol['variants'][1:]:
                base = orders[name]
                implementations = []
                if explicit_code_terms(case['query']):
                    for unit in base:
                        key = EntityKey(path=unit['path'], **unit['entity'])
                        implementations.append(describe_owner(catalog.owners[key]).fields['executable'])
                else:
                    implementations = [''] * len(base)
                order = prefer_explicit_code_terms(case['query'], implementations, list(range(len(base))))
                orders[name] = [base[i] for i in order]
            named = requested_piece_path(SearchRequest(case['query']))
            if named:
                for result in orders.values():
                    result.sort(key=lambda unit: unit['path'] != named)
        canonical = lambda unit: json.dumps(unit, sort_keys=True)
        assert all(sorted(map(canonical, result)) == sorted(map(canonical, units)) for result in orders.values())
        predictions.append({name: case[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} | {'orders': orders})
(out / 'budgets.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in budget_records))
(out / 'witnesses.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in witness_records))
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold', predictions_sha256=sha(out / 'predictions.jsonl'), witnesses_sha256=sha(out / 'witnesses.jsonl'), budgets_sha256=sha(out / 'budgets.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants']}))
