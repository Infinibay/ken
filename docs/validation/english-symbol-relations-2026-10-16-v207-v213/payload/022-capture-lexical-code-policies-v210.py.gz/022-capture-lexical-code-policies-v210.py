"""Combine separately tested pure symbol-order policies on actual201MCP pools."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from explicit_code_terms import explicit_code_terms, prefer_explicit_code_terms
from requested_test_piece import prefer_requested_test_piece
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
scope = json.loads(scope_path.read_text())
cases, answers = {}, {}
pins = {}
for cohort, selection in scope['cohorts'].items():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row | {'cohort': cohort} for row in rows(path)})
    root = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    pins[cohort] = sha(root / 'capture/registration.json')
    for repo, files in reg['closed'].items():
        path = root / 'capture' / repo / 'answers.jsonl'
        assert sha(path) == files['answers.jsonl']
        answers.update({row['id']: row for row in rows(path) if row['id'] in cases})
assert len(cases) == len(answers) == 240 and set(cases) == set(answers)
score_root = w / 'output/development/current-symbol-scores-v207'
score_reg = json.loads((score_root / 'registration.json').read_text())
assert score_reg['status'] == 'ALL150currentEnglishsymbol scores CLOSED without Gold'
assert sha(score_root / 'scores.jsonl') == score_reg['scores_sha256']
score_records = {row['id']: row for row in rows(score_root / 'scores.jsonl')}
assert len(score_records) == 150
views_root = w / 'output/development/current-executable-view-v209'
views_reg = json.loads((views_root / 'registration.json').read_text())
assert views_reg['status'] == 'ALL128currentEnglish executable view scores CLOSED before Gold'
view_records = {}
for repo, digests in views_reg['closed'].items():
    path = views_root / repo / 'observations.jsonl'
    assert sha(path) == digests['observations.jsonl']
    view_records.update({row['id']: row for row in rows(path)})
assert len(view_records) == 128
context_root = w / 'output/development/lexical-code-context-v210'
context_reg = json.loads((context_root / 'registration.json').read_text())
assert context_reg['status'] == 'ALL128currentEnglish lexical code context scores CLOSED before Gold'
context_records = {}
for repo, digests in context_reg['closed'].items():
    path = context_root / repo / 'observations.jsonl'
    assert sha(path) == digests['observations.jsonl']
    context_records.update({row['id']: row for row in rows(path)})
assert len(context_records) == 128
out = w / 'output/development/lexical-code-policies-v210'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 EXPOSED development on ACTUAL201pools, authenticated207NN1024scalars:122guarded source/query/card identical reuses plus6freshAPI and22exact. No inference or model changes. Reserve CLOSED.',
    'hypothesis': 'V210fixed equalmean original207+lexical code / imported type contract context. Separate source additions and semantic test/operator preference. Compare209typedmean105new without adding isolated gains. No fitted weights or threshold search.',
    'variants': ['current_rrf', 'neural_symbols_only', 'neural_test_piece_operator', 'two_views_test_piece_operator', 'lexical_code_mean', 'lexical_code_mean_test_operator', 'lexical_type_mean', 'lexical_type_mean_test_operator'],
    'policy': 'Actual201 answers stay fixed for non-symbols and unique exact bypass. Raw neural order preserves native ties; requested test-case preference then literal-operator preference. Always retain namedpath priority and all candidate identities. No fitted weights/IDs/names of repositories.',
    'acceptance': '>=108/120EACH;118/119Recall10; all refs unchanged. Results are pure policy replay, not full combined MCP latency/acceptance.',
    'producer_sha256': sha(Path(__file__)), 'selection_sha256': sha(scope_path), 'capture_pins': pins,
    'score_receipt_sha256': sha(score_root / 'registration.json'),
    'view_receipt_sha256': sha(views_root / 'registration.json'),
    'context_receipt_sha256': sha(context_root / 'registration.json'),
    'policy_sources': {name: sha(w / 'experiments/search-engine' / name) for name in ['requested_test_piece.py', 'explicit_code_terms.py', 'executable_view.py', 'lexical_code_view.py']},
    'status': 'Registered BEFORE orders and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
predictions = []
for repo in sorted({row['repo_id'] for row in cases.values()}):
    selected = [case for case in cases.values() if case['repo_id'] == repo]
    symbol_cases = [case for case in selected if case['target_kind'] == 'symbol' and
                    answers[case['id']]['public_response']['profile_version'] != 'best-exact-source-v1']
    paths = {unit['path'] for case in symbol_cases for unit in answers[case['id']]['units']}
    catalog = None
    if paths:
        root = Path('/private/tmp/ken-public-default-v143/repos') / repo
        with project_connection(root) as connection:
            catalog = SourceCatalog(root, {key: ps for key, ps in owner_passages(connection).items() if key.path in paths})
    for case in selected:
        query_id = case['id']
        answer = answers[query_id]
        units = answer['units']
        orders = {name: units for name in protocol['variants']}
        if case in symbol_cases:
            assert catalog is not None
            results = answer['public_response']['results']
            assert len(results) == len(units)
            scored = score_records[query_id]
            assert not scored['exact_bypass'] and scored['units'] == units
            signals = scored['score_rows']
            assert [row['unit'] for row in signals] == units
            assert sorted(signal['native_rank'] for signal in signals) == list(range(1, len(units)+1))
            raw = sorted(range(len(units)), key=lambda i: (-signals[i]['neural_score'], signals[i]['native_rank']))
            orders['neural_symbols_only'] = [units[i] for i in raw]
            view = view_records[query_id]
            assert view['units'] == units
            assert view['original_input_hashes'] == [row['input_sha256'] for row in signals]
            code_scores = view['executable_scores']
            means = [(s['neural_score'] + score) / 2 for s, score in zip(signals, code_scores, strict=True)]
            context = context_records[query_id]
            assert context['units'] == units and context['original_input_hashes'] == view['original_input_hashes']
            lexical = [(s['neural_score'] + score) / 2 for s, score in zip(signals, context['modes']['lexical_code']['scores'], strict=True)]
            types = [(s['neural_score'] + score) / 2 for s, score in zip(signals, context['modes']['lexical_type_context']['scores'], strict=True)]
            for name, values in [('two_views_test_piece_operator', means), ('lexical_code_mean', lexical), ('lexical_type_mean', types)]:
                order = sorted(range(len(units)), key=lambda i: (-values[i], signals[i]['native_rank']))
                orders[name] = [units[i] for i in order]
            for name, base in [('two_views_test_piece_operator', orders['two_views_test_piece_operator']),
                               ('lexical_code_mean_test_operator', orders['lexical_code_mean']),
                               ('lexical_type_mean_test_operator', orders['lexical_type_mean']),
                               ('neural_test_piece_operator', orders['neural_symbols_only'])]:
                orders[name] = [base[i] for i in prefer_requested_test_piece(case['query'], base, catalog)]
            for name in ['neural_test_piece_operator', 'two_views_test_piece_operator', 'lexical_code_mean_test_operator', 'lexical_type_mean_test_operator']:
                base = orders[name]
                implementations = []
                if explicit_code_terms(case['query']):
                    for unit in base:
                        key = EntityKey(path=unit['path'], **unit['entity'])
                        implementations.append(describe_owner(catalog.owners[key]).fields['executable'])
                else:
                    implementations = [''] * len(base)
                order = prefer_explicit_code_terms(case['query'], implementations, list(range(len(base))))
                orders[name] = [base[i] for i in order]
            named = requested_piece_path(SearchRequest(case['query']))
            if named:
                for result in orders.values():
                    result.sort(key=lambda unit: unit['path'] != named)
        canonical = lambda unit: json.dumps(unit, sort_keys=True)
        assert all(sorted(map(canonical, result)) == sorted(map(canonical, units)) for result in orders.values())
        predictions.append({name: case[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold', predictions_sha256=sha(out / 'predictions.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants']}))
