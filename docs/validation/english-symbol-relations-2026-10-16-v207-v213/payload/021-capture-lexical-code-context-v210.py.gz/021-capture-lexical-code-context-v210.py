"""Current EN owned executable view: fixed published68M,1024; no Gold."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

import numpy as np

sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from executable_view import executable_view
from lexical_code_view import LexicalCodeView
from ken.bench.source_receipts import verify_frozen_source
from ken.retrieval.best_resources import default_resources
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.model import EntityKey
from ken.retrieval.piece_cards import build_card, card_text
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def origins():
    base = Path(os.environ['PYTHONPATH']).resolve()
    result = {}
    for name, module in tuple(sys.modules.items()):
        if (name == 'ken' or name.startswith('ken.')) and getattr(module, '__file__', None):
            path = Path(module.__file__).resolve()
            assert path.is_relative_to(base), (name, path)
            result[name] = {'path': str(path), 'sha256': sha(path)}
    return result


w = Path.cwd()
frozen = w / 'output/frozen/requested-test-role-v201'
receipt = verify_frozen_source(frozen)
assert receipt == 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5'
prior = w / 'output/development/current-symbol-scores-v207'
previous = json.loads((prior / 'registration.json').read_text())
assert previous['status'] == 'ALL150currentEnglishsymbol scores CLOSED without Gold'
assert sha(prior / 'scores.jsonl') == previous['scores_sha256']
scope = json.loads((w / 'output/analysis/english-ranking-v196/registration.json').read_text())
cases = {}
for selection in scope['cohorts'].values():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row for row in rows(path)})
observed = [row for row in rows(prior / 'scores.jsonl') if not row['exact_bypass']]
assert len(observed) == 128
base_root = w / 'output/development/current-executable-view-v209'
base_reg = json.loads((base_root / 'registration.json').read_text())
assert base_reg['status'] == 'ALL128currentEnglish executable view scores CLOSED before Gold'
out = Path(sys.argv[1])
repo = sys.argv[2] if len(sys.argv) > 2 else None
out.mkdir(exist_ok=False)
if repo is None:
    registration = {
        'scope': 'V210Current201EN128nonexact symbol10pools, same207original+209code base; no Gold; reserve CLOSED',
        'hypothesis': 'W209ownedcode omits nested class fields. Separately test Python lexical executable closure (no docs/comments) and explicitly imported unshadowed class contracts. B192complete scope included docs; W209code omitted nested bodies. New factorial combination retains argument coupling and imported type meaning.',
        'policy': 'S: complete lexical executable scope only for Python,<=64nonblank lines/12000chars and fullpair<=1024; fallback exact W209owned view otherwise. C: append at most4explicitly imported class signature/first12documentationlines, source-resolved unique binding, no shadowing, each section atomic within fullpair1024. No guessed imports/callee execution. Existing published68M1024, fixed equalmean original207+S/C, plus isolated testpiece/operator. NonPython keep209unchanged. No fitted thresholds/weights; reserveCLOSED.',
        'acceptance': 'Fixed240English development:>=108EACH;Recall10>=118/119. Full MCP CPU/RAM must be measured before activation. Additional view observer time is not end-to-end.',
        'producer_sha256': sha(Path(__file__)), 'helper_sha256': sha(w / 'experiments/search-engine/lexical_code_view.py'),
        'base_registration_sha256': sha(base_root / 'registration.json'),
        'source_receipt': receipt, 'scores_registration_sha256': sha(prior / 'registration.json'),
        'status': 'Registered BEFORE capture and Gold', 'closed': {},
    }
    (out / 'registration.json').write_text(json.dumps(registration, indent=2))
    for repo in sorted({case['repo_id'] for case in cases.values()}):
        with (out / (repo + '.log')).open('w') as log:
            subprocess.run([sys.executable, __file__, str(out / repo), repo], env=os.environ,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        registration['closed'][repo] = {name: sha(out / repo / name) for name in ['observations.jsonl', 'summary.json']}
        (out / 'registration.json').write_text(json.dumps(registration, indent=2))
        print(json.dumps({'closed': repo}), flush=True)
    registration['status'] = 'ALL128currentEnglish lexical code context scores CLOSED before Gold'
    (out / 'registration.json').write_text(json.dumps(registration, indent=2))
    sys.exit(0)

root = Path('/private/tmp/ken-public-default-v143/repos') / repo
selected = [row for row in observed if cases[row['id']]['repo_id'] == repo]
paths = {unit['path'] for row in selected for unit in row['units']}
observations, cache = [], {}
resources = default_resources()
with project_connection(root) as connection:
    catalog = SourceCatalog(root, owner_passages(connection))
    context = LexicalCodeView(catalog)
    base_path = base_root / repo / 'observations.jsonl'
    assert sha(base_path) == base_reg['closed'][repo]['observations.jsonl']
    base_records = {row['id']: row for row in rows(base_path)}
    # Explicit warmup is excluded from observer timings, never from end-to-end claims.
    resources.neural.score('Find the implementation.', ['def example():\n    return 1'])
    assert resources.neural._max_tokens == 1024
    assert resources.neural.providers == ('CPUExecutionProvider',)
    for row in selected:
        query = row['expanded_query']
        texts, source_hashes, original_hashes = [], [], []
        for unit, scores in zip(row['units'], row['score_rows'], strict=True):
            key = EntityKey(path=unit['path'], **unit['entity'])
            assert sha(root / key.path) == catalog.hashes[key.path]
            source_hashes.append(catalog.hashes[key.path])
            card = card_text(build_card(key, 'symbol', [key], query, catalog))
            original_hashes.append(hashlib.sha256(card.encode()).hexdigest())
            assert original_hashes[-1] == scores['input_sha256']
            if key not in cache:
                cache[key] = executable_view(describe_owner(catalog.owners[key]))
            texts.append(cache[key])
        base = base_records[row['id']]
        assert base['units'] == row['units'] and base['texts'] == texts
        start = time.perf_counter()
        variants = {'lexical_code': [], 'lexical_type_context': []}
        provenance = []
        for unit, original in zip(row['units'], texts, strict=True):
            key = EntityKey(path=unit['path'], **unit['entity'])
            proposal = context.scope(key)
            accepted = bool(proposal is not None and len(resources.neural._query_tokenizer.encode(query, proposal).ids) <= 1024)
            lexical = proposal if accepted else original
            variants['lexical_code'].append(lexical)
            extended = lexical
            contracts = []
            for contract in context.contracts(key):
                assert sha(root / contract['path']) == contract['source_hash']
                addition = f"\nReferenced imported type {contract['bound_name']} from {contract['path']} (context, not primary implementation):\n{contract['text']}"
                if len(resources.neural._query_tokenizer.encode(query, extended + addition).ids) <= 1024:
                    extended += addition
                    contracts.append(contract)
            variants['lexical_type_context'].append(extended)
            provenance.append({'unit': unit, 'complete_scope_accepted': accepted,
                               'source_hash': catalog.hashes[key.path], 'type_contracts': contracts})
        construction_ms = (time.perf_counter() - start) * 1000
        score_cache = dict(zip(texts, base['executable_scores'], strict=True))
        modes = {}
        for name, documents in variants.items():
            fresh = list(dict.fromkeys(text for text in documents if text not in score_cache))
            scores, details = resources.neural.score(query, fresh)
            score_cache.update(zip(fresh, scores, strict=True))
            modes[name] = {'texts': documents, 'scores': [score_cache[text] for text in documents],
                           'input_hashes': [hashlib.sha256(text.encode()).hexdigest() for text in documents],
                           'fresh_documents': len(fresh), 'details': details}
        observations.append({'id': row['id'], 'query': row['query'], 'expanded_query': query,
            'units': row['units'], 'modes': modes, 'construction_ms': construction_ms, 'provenance': provenance,
            'original_input_hashes': original_hashes, 'source_hashes': source_hashes,
            'observer_ms': (time.perf_counter() - start) * 1000})
        print(json.dumps({'id': row['id']}), flush=True)
(out / 'observations.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in observations))
(out / 'summary.json').write_text(json.dumps({'queries': len(observations), 'origins': origins(),
    'providers': resources.neural.providers, 'max_tokens': resources.neural._max_tokens,
    'peak_observer_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'observer_p50_ms': float(np.median([row['observer_ms'] for row in observations])),
    'observer_p95_ms': float(np.percentile([row['observer_ms'] for row in observations], 95)),
    'not_end_to_end_latency': True}, indent=2))
