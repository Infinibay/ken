from collections import defaultdict
from pathlib import Path

from ken.parsers import detect_language
from ken.retrieval.passages import extract_passages
from ken.retrieval.piece_catalog import SourceCatalog
from lexical_code_view import LexicalCodeView


def make_catalog(tmp_path, files):
    owners = defaultdict(list)
    for name, source in files.items():
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source)
        language, parse = detect_language(Path(name))
        data = source.encode()
        for passage in extract_passages(data, parse(data, name), path=name, language=language):
            owners[passage.entity].append(passage)
    return SourceCatalog(tmp_path, owners)


def test_nested_code_keeps_argument_coupling_but_excludes_docs_comments_and_sibling(tmp_path):
    catalog = make_catalog(tmp_path, {'sample.py': '''def sample():
    """Misleading words in documentation."""
    class Local:
        """Nested documentation."""
        flag = field(init=False, default=0, kw_only=True)
    # prose outside a string
    assert Local().flag == "# literal stays"

def sibling():
    return "unrelated"
'''})
    key = next(key for key in catalog.owners if key.qualname == 'sample')
    view = LexicalCodeView(catalog).scope(key)
    assert view is not None
    assert 'field(init=False, default=0, kw_only=True)' in view
    assert 'class Local:' in view and '"# literal stays"' in view
    assert all(text not in view for text in ['Misleading', 'Nested documentation', 'prose outside', 'unrelated'])


def test_imported_type_contract_uses_exact_import_binding_and_source_only(tmp_path):
    catalog = make_catalog(tmp_path, {'pkg/types.py': 'class Container:\n    """A container backed by many blocks."""\n    pass\n',
        'test_use.py': 'from pkg.types import Container as Box\n\ndef test_use():\n    assert len(Box()) == 0\n'})
    key = next(key for key in catalog.owners if key.qualname == 'test_use')
    contracts = LexicalCodeView(catalog).contracts(key)
    assert len(contracts) == 1
    assert contracts[0]['path'] == 'pkg/types.py'
    assert contracts[0]['bound_name'] == 'Box'
    assert 'backed by many blocks' in contracts[0]['text']
    assert contracts[0]['source_hash'] == catalog.hashes['pkg/types.py']


def test_shadowed_type_is_not_resolved_from_import(tmp_path):
    catalog = make_catalog(tmp_path, {'pkg/types.py': 'class Container:\n    """External contract."""\n    pass\n',
        'test_use.py': 'from pkg.types import Container as Box\n\ndef use(Box):\n    return Box()\n'})
    key = next(key for key in catalog.owners if key.qualname == 'use')
    assert LexicalCodeView(catalog).contracts(key) == []


def test_large_scope_is_rejected_atomically_instead_of_cutting_a_definition(tmp_path):
    source = 'def sample():\n' + ''.join(f'    value_{i} = {i}\n' for i in range(70))
    catalog = make_catalog(tmp_path, {'sample.py': source})
    key = next(key for key in catalog.owners if key.qualname == 'sample')
    assert LexicalCodeView(catalog).scope(key) is None


def test_unsupported_language_has_no_invented_contract_or_projection(tmp_path):
    catalog = make_catalog(tmp_path, {'sample.java': 'class Sample {\n    int value() {\n        return 1;\n    }\n}\n'})
    key = next(key for key in catalog.owners if key.qualname == 'Sample.value')
    assert LexicalCodeView(catalog).scope(key) is None
    assert LexicalCodeView(catalog).contracts(key) == []


def test_inline_docstring_does_not_remove_adjacent_return(tmp_path):
    catalog = make_catalog(tmp_path, {'sample.py': 'def sample(): """docs"""; return "café"\n'})
    key = next(key for key in catalog.owners if key.qualname == 'sample')
    view = LexicalCodeView(catalog).scope(key)
    assert 'docs' not in view and 'return "café"' in view
