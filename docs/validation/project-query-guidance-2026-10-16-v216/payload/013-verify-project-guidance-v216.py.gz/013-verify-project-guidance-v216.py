"""Exercise real installer and fresh MCP tools/list without any neural model."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

worktree = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
out = Path.cwd() / 'output/analysis/project-guidance-v216-r1'
out.mkdir(exist_ok=False)
root = Path('/private/tmp/ken-project-instructions-v216-example-r1')
root.mkdir(exist_ok=False)
(root / 'example.py').write_text('def greet(name):\n    return f"Hello {name}"\n')
env = os.environ | {'PYTHONPATH': str(worktree / 'src'), 'PYTHONDONTWRITEBYTECODE':'1'}
result = subprocess.run([sys.executable,'-m','ken','install',str(root),'--codex','--agents-md','--quiet'],
                        cwd=worktree,env=env,text=True,capture_output=True)
assert result.returncode == 0, result.stderr
(out / 'install.txt').write_text(result.stdout + result.stderr)
agents = (root / 'AGENTS.md').read_bytes()
assert b'English' in agents and agents.count(b'<!-- ken:instructions:start -->') == 1
(out / 'AGENTS.md').write_bytes(agents)
again = subprocess.run([sys.executable,'-m','ken','install',str(root),'--codex','--agents-md','--quiet'],
                       cwd=worktree,env=env,text=True,capture_output=True)
assert again.returncode == 0 and (root / 'AGENTS.md').read_bytes() == agents
help_result = subprocess.run([sys.executable,'-m','ken','install','--help'],cwd=worktree,
                             env=env,text=True,capture_output=True,check=True)
assert '--agents-md' in help_result.stdout and '--no-agents-md' in help_result.stdout
(out / 'install-help.txt').write_text(help_result.stdout)

async def check():
    params = StdioServerParameters(command=sys.executable,args=['-m','ken','mcp',str(root)],env=env)
    with (out / 'mcp.log').open('w') as log:
        async with stdio_client(params,errlog=log) as (read,write):
            async with ClientSession(read,write) as session:
                await session.initialize()
                response = await session.list_tools()
                tools = {tool.name:tool.model_dump(mode='json',by_alias=True) for tool in response.tools}
                for name in ['ken_find','ken_who','ken_rank']:
                    assert 'English' in tools[name]['description'],name
                assert tools['ken_find']['inputSchema']['properties']['piece_kind']['default'] == 'auto'
                assert tools['ken_find']['inputSchema']['properties']['output_format']['default'] == 'compact'
                (out / 'semantic-tool-descriptions.json').write_text(json.dumps({k:tools[k] for k in
                    ['ken_find','ken_who','ken_rank']},indent=2)+'\n')
                (out / 'tools-list.json').write_text(response.model_dump_json(indent=2)+'\n')
asyncio.run(check())
pins = {p.relative_to(worktree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [worktree/'src/ken/project_instructions.py',worktree/'src/ken/cli.py',
                  worktree/'src/ken/install.py',worktree/'src/ken/install_uninstall.py',
                  worktree/'src/ken/mcp/server.py']}
(out / 'summary.json').write_text(json.dumps({'status':'Real explicit install twice, guidance idempotence, CLI help and fresh MCP tools/list passed',
    'source_files':pins,'connected_old_server_restarted':False,'neural_models_used':False},indent=2)+'\n')
print(json.dumps({'status':'PASS','fresh_mcp_english_descriptions':3,'install_idempotent':True}))
