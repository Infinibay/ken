"""Save completed optional-instruction and fresh MCP interface verification."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess

w=Path.cwd();clean=Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
out=w/'output/analysis/project-guidance-export-v216'
out.mkdir(exist_ok=False);(out/'payload').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
verification=json.loads((w/'output/analysis/project-instructions-v216-full-verification.json').read_text())
assert verification['passed']==15011 and verification['xfail_existing']==10
probe=json.loads((w/'output/analysis/project-guidance-v216-r1/summary.json').read_text())
for name,digest in probe['source_files'].items():assert sha(clean/name)==digest
def code_without_docstrings(data):
    tree=ast.parse(data)
    for node in ast.walk(tree):
        if isinstance(node,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            if node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
                node.body.pop(0)
    return ast.dump(tree,include_attributes=False)
old=subprocess.check_output(['git','show','HEAD:src/ken/mcp/server.py'],cwd=clean)
assert code_without_docstrings(old)==code_without_docstrings((clean/'src/ken/mcp/server.py').read_bytes())
for name in ['neural_reranker','piece_search','source_operations','symbol_ranking','symbol_requirements']:
    path='src/ken/retrieval/'+name+'.py'
    assert (clean/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=clean)
inputs={Path(__file__),w/'output/analysis/verify-project-guidance-v216.py',
    w/'output/analysis/project-instructions-v216-full-verification.json'}
for folder in ['project-guidance-v216','project-guidance-v216-r1']:
    inputs.update(p for p in (w/'output/analysis'/folder).iterdir() if p.is_file())
for name in ['red','green','full-tests','full-tests-r1','mypy','focused-r1','focused-r2']:
    inputs.add(Path('/private/tmp/ken-project-instructions-v216-'+name+'.log'))
inputs.add(Path('/private/tmp/ken-project-guidance-v216-r1.log'))
records=[]
for i,p in enumerate(sorted(inputs)):
    data=p.read_bytes();target=out/'payload'/(f'{i:03d}-'+p.name+'.gz')
    target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data
    records.append({'source':p.relative_to(w).as_posix() if p.is_relative_to(w) else 'verification/'+p.name,
        'source_sha256':sha(p),'bytes':len(data),'payload':target.name,'payload_sha256':sha(target)})
write=lambda name,value:(out/name).write_text(json.dumps(value,indent=2)+'\n')
write('manifest.json',{'scope':'Completed V216 tests and real installer/fresh MCP tools-list; no model or ranking changes, no release',
    'files':records,'mcp_code_AST_unchanged_ignoring_docstrings':True,'engine_five_files_unchanged':True})
write('verification.json',verification)
write('public-interface.json',probe)
(out/'README.md').write_text('''# Optional project guidance and English code queries

Interactive `ken install` offers to append a compact managed section to
AGENTS.md, default yes. --agents-md/--no-agents-md are explicit script choices.
Noninteractive and quiet defaults do not prompt or write instructions; an
explicit yes works without stdin. --no-wire skips instructions. Existing user
content, CRLF prefixes, unowned blocks, symlinks and local edits are preserved.
Ownership hashes live separately in .ken/instructions.json; uninstall removes
only unchanged owned sections. Claude integration adds a managed @AGENTS.md
import without replacing CLAUDE.md. The canonical recommended text also appears
in README. No existing project instructions were automatically replaced.

English natural-language code-search guidance is exposed in ken_find,ken_who
and ken_rank descriptions, plus all eight bundled skills. Paths, identifiers,
quoted source, literal search, regex and KQL stay unchanged; the assistant
responds in the user's language. Exact memory keys are preserved and memory
queries may use the saved finding's language. This guides callers; the engine
does not silently translate literal input or change stored session context.

Validation:15011tests passed,10existing xfails; mypy361sourcefiles clean.
23focused installer tests pass. New file-system tests use real temporary files,
terminal input boundaries and public CLI installation/uninstallation. A real
explicit install twice preserves identical AGENTS.md bytes; CLI help shows both
flags. A fresh MCP stdio tools/list exposes the English descriptions and compact
default schema. This does not restart the already connected older MCP process.
These checks establish interface/content delivery, not measured agent adherence.

The first full suite failed because the existing fake_install test double did
not accept the approved new optional argument. Its original flag assertions
are retained and expanded to all three instruction choices; the complete final
suite was then rerun successfully. Both logs remain. The initial tools-list
probe used the SDK's unaliased dictionary keys and stopped during a schema
assertion; the final probe uses public JSON field aliases. Product behavior
was unchanged by that probe repair. No failed run is counted as a pass.

The five V214engine files are byte-identical to8ce6b00c. MCP server ASTs are
identical after stripping docstrings, so tool description changes do not alter
ranking, schemas or response logic. V214quality remains its separate, closed
actual MCP evidence. No new400accuracy or latency claim is made from prose edits.
English development goal is110/120 and108/120top1,118/119Recall10, reserveCLOSED.

manifest.json authenticates compressed payloads and their original logical
paths with SHA256 and byte counts. Full logs, failed probes, final tools-list,
real installed instructions and test/type receipts are retained. No release.
''')
print(json.dumps({'payloads':len(records),'manifest_sha256':sha(out/'manifest.json')}))
