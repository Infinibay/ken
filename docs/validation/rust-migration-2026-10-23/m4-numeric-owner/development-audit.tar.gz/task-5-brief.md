### Task 5: Owner reranking and immutable diagnostic traces

**Files:** Create src/owner_ranking.rs,ranking_trace.rs; tests/owner_ranking.rs,ranking_trace.rs.

**Interfaces:** EvidenceReranker::new(model,word_encoder,stemmer,optional_expansion)->Result<Self>, validate(&EvidenceRanking), prepare_query(&PythonText), rank(request,candidates,descriptions,optional_expanded,evidence_version,optional_trace)->Result<Vec<CodeMatch>>; RankingTrace::new(optional_request_id), record(...), from_json(...,&NumericRanker), to_json(include_query), compare(left,right). Expansion identity is explicit and pinned.

- [ ] Capture original owner ranking and trace behavior/suites once: feature/profile/expansion validation, unique exact no calls, versions1–3, complete evidence, stable proposal ties, repeated attempts, deep-copy exports, query hashes, replayed scores/rank permutations and actual divergent paths. Add tests; Expected absent APIs RED.
- [ ] Coordinate accepted components without duplicating projection/model rules; preserve exact priority, original evidence-version rules and immutable request-local traces. Invalid source/profile data must not reach encoding.
- [ ] Run owner/trace plus directly affected complete suites and fmt/clippy; Expected PASS. Commit/push `feat(retrieval): rerank source owners with reproducible request-local traces`.

