from pathlib import Path
import tarfile
from tools.rust_migration.selection_evidence import verify_original
from tools.rust_migration.selection_validate import run_capture
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';old=w/'accepted-selection-linux';old.mkdir(exist_ok=True)
with tarfile.open('/tmp/accepted-selection-linux.tar.gz')as t:t.extractall(old,filter='data')
reference=verify_original(old/'original',root,'linux')
actual=run_capture(root,root/'target/debug/examples/search_selection_probe',reference,w/'selection-linux-current')
print('unchanged old original cases',len(actual['cases']),actual['metrics'])
