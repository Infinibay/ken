### Task 6: Registered production forests and native model composition

**Files:** Create src/rank_models.rs; preserve exact copies of the two original gzip artifacts under resources/ranking with manifest/licenses; tests/rank_models.rs; associate already-locked flate2=1.1.10.

**Interfaces:** ProductionRankModels::open(resources)->Result<Self>, native()/piece()->Result<Arc<NumericRanker>>; compressed bytes and canonical fingerprint verified, lazy owned model lifetime.

- [ ] Capture actual original registered artifact fingerprints/predictions and scoped tests once. Add byte corruption, truncation, wrong decoded schema/fingerprint, lazy missing-resource and both2560/1280tree tests; Expected missing loader RED.
- [ ] Verify/preserve original artifacts and native lazy loading. Add new owner-feature/rank composition with the accepted static encoder on a small fixed source corpus, complete model/encoder/source provenance and call traces. Reuse M2 catalogs; do not refit models or reopen private search reserves.
- [ ] Run artifact/integration and directly affected suites/fmt/clippy; Expected PASS. Commit/push `feat(retrieval): load verified production ranking forests natively`.

