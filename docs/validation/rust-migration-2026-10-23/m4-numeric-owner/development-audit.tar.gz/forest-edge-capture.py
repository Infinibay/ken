import json,pathlib,subprocess,os
from tools.rust_migration.numeric_reference import SCRIPT,SUITES,owners
from tools.rust_migration.reference import Reference,reference_env
from tools.rust_migration.native_json import identity
from tools.rust_migration.retrieval_reference import digest
root=pathlib.Path.cwd();ws=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';out=ws/'original-macos-forest-edges';out.mkdir()
ref=Reference.load(pathlib.Path(os.environ['KEN_RUST_REFERENCE']));cases=[]
def add(name,m,kind='model',**kw):cases.append(dict(id=name,kind=kind,input=dict(model=m,**kw)))
def model(features=['a'],trees=[{'value':0.}]):return dict(schema=1,features=features,trees=trees)
add('dict-order',model({'z':1,'a':2}))
for key in ['features','trees']:
 for value in [None,1,True,1.,{},'ab']:
  m=model();m[key]=value;add(key+'-'+repr(value),m)
for n in [0,1,128,129]:
 for index in [False,True]:
  m=model(['a','b'],[dict(feature=index,threshold=.5,left={'value':-1.},right={'value':1.})])
  add('bool-'+str(index)+'-'+str(n),m,'predict',rows=n,columns=2,values=[0.,1.]*n)
for name in ['a\n\ud800','é😀\"\udfff','\ud800\ud800','\udfff\ud800']:
 add('surrogate-'+ascii(name),model([name]))
for name,values in [('fsum-overflow',[1e308,1e308,-1e308]),('fsum-infinity',[1e308,-1e308]),('rounding-tie',[1e16,1.,1e-16])]:
 m=model(trees=[dict(feature=0,threshold=0.,left={'value':v},right={'value':-v})for v in values]);add(name,m,'explain',left=[-1.],right=[1.])
p=root/'crates/ken-retrieval/tests/fixtures/numeric-inputs-forest-edges.json';p.write_text(json.dumps(dict(cases=cases),ensure_ascii=True,separators=(',',':'))+'\n')
# New disjoint edge cases reuse the already captured four original test roots.
script=SCRIPT.replace("exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q',*request['suite'],'--junitxml='+request['junit']],plugins=[Plugin()])","cached=json.loads(pathlib.Path(request['cached_suite']).read_bytes());discovered=cached['discovered'];states=cached['test_states'];exit_code=cached['original_test_exit']")
(out/'capture.py').write_text(script)
request=dict(root=str(ref.root),family='forest-edges',cases=cases,cached_suite=str(ws/'original-macos-forest/reference.json'),result=str(out/'observations.json'))
(out/'request.json').write_text(json.dumps(request,ensure_ascii=True))
proc=subprocess.run([str(ref.python),str(out/'capture.py'),str(out/'request.json')],cwd=ref.root,env=reference_env(ref,out/'environment'),capture_output=True)
(out/'stdout.log').write_bytes(proc.stdout);(out/'stderr.log').write_bytes(proc.stderr);(out/'process-exit.json').write_text(json.dumps(dict(exit=proc.returncode)));assert proc.returncode==0,proc.stderr
v=json.loads((out/'observations.json').read_bytes());v.update(script_sha256=__import__('hashlib').sha256(script.encode()).hexdigest(),owners=owners(root),execution=dict(exit=0,files={n:identity(out/n)for n in ['capture.py','request.json','observations.json','stdout.log','stderr.log','process-exit.json']}),reused_suite=dict(path='original-macos-forest/reference.json',sha256=identity(ws/'original-macos-forest/reference.json')['sha256']))
v['corpus_sha256']=digest(v['cases']);(out/'reference.json').write_text(json.dumps(v,ensure_ascii=True)+'\n')
(root/'crates/ken-retrieval/tests/fixtures/numeric-reference-forest-edges.json').write_bytes((json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode(errors='backslashreplace'))
print(len(cases));print([(c['id'],c.get('error',c.get('result')))for c in v['cases']if'error'in c])
