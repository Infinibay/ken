from pathlib import Path
import subprocess,tempfile,tarfile,json
root=Path.cwd();out=root/'docs/validation/rust-migration-2026-10-23/m4-numeric-owner';python=root/'.venv/bin/python'
with tempfile.TemporaryDirectory(prefix='ken-numeric-independent-')as tmp:
 snap=Path(tmp)
 for name in ['native-sources','validation-sources']:
  with tarfile.open(out/(name+'.tar.gz'))as t:t.extractall(snap,filter='data')
 code="import sys,json;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from tools.rust_migration.numeric_evidence import aggregate_matrix;v=aggregate_matrix(Path(sys.argv[2]),Path(sys.argv[3]),snapshot=Path(sys.argv[4]),current=True);print(json.dumps(v,indent=2));assert v['passed']and v['M4c1_accepted']and not v['M4_accepted']and not v['migration_complete']"
 subprocess.run([str(python),'-I','-B','-c',code,str(snap/'validation-sources'),str(out),str(root),str(snap)],cwd=snap,check=True)
