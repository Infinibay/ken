### Task 3: Dtype-aware term alignment and original numerical dispatch

**Files:** Create src/alignment.rs; extend private dense_math.rs only for required F64 dot/norm and F32/F64 matrix products/reductions; tests/alignment.rs.

**Interfaces:** FloatMatrix{F32(Matrix<f32>),F64(Matrix<f64>)}, FloatVector{F32(Vec<f32>),F64(Vec<f64>)}; TermAlignment::new(FloatMatrix,FloatVector)->Result<Self>, similarities(&FloatMatrix)->Result<FloatMatrix>, coverage(&FloatMatrix)->Result<TermCoverage>, summarize(&FloatMatrix)->Result<TermCoverage>, summarize_maxima(&FloatMatrix,present:&[bool])->Result<Vec<TermCoverage>>; TermCoverage{mean,minimum,quartile,above50,above70,weighted}:f64.

- [ ] Capture original alignment/maximum-summary observations and scoped tests once, including empty rows/columns, mixed dtypes, invalid dimensions/weights/presence, inactive nonfinite maxima, scalar/GEMV/GEMM shapes, threshold/quartile/weighted cancellation and block-shaped products. Add numerical and ordered cutoff regressions before changing shared math; run alignment tests, Expected missing API RED.
- [ ] Implement original dtype promotion, finite checks, row-wise reductions and one-row weighted dot. Extend the already pinned platform BLAS with exact original dispatch; retain all accepted F32 storage/dense paths unchanged. Check dimensions/lengths before every FFI call; reuse existing pairwise reduction where appropriate.
- [ ] Run alignment plus all affected M4b storage/dense/context/index regressions on both platforms after a shared arithmetic change; Expected PASS, original fixed bounds/order, fmt/clippy. Commit/push `feat(retrieval): align query terms with dtype-correct bounded arithmetic`.

