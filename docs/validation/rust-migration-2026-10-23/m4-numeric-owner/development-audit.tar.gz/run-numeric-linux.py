from pathlib import Path
import json,shutil
from tools.rust_migration.numeric_reference import SCRIPTS
from tools.rust_migration.numeric_validate import run_capture
from tools.rust_migration.numeric_evidence import verify_original,verify_capture
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';e=w/'evidence-linux';(e/'original').mkdir(parents=True,exist_ok=True)
for family in SCRIPTS:shutil.copytree(w/f'original-linux-{family}',e/'original'/family,dirs_exist_ok=True)
reference=verify_original(e/'original',root,'linux');print('originals',len(reference['cases']),flush=True)
actual=run_capture(root,root/'target/debug/examples/numeric_owner_probe',reference,e/'native')
errors=verify_capture(e/'native',reference);print('native',len(actual['cases']),'metrics',actual['metrics'],'verification',errors,flush=True);assert not errors
