from pathlib import Path
import tarfile
from tools.rust_migration.native_json import load
from tools.rust_migration.selection_evidence import verify_original
from tools.rust_migration.selection_validate import run_capture
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';old=w/'accepted-selection-macos';old.mkdir(exist_ok=True)
with tarfile.open(root/'docs/validation/rust-migration-2026-10-23/m4-selection-review/macos-capture.tar.gz')as t:t.extractall(old,filter='data')
reference=verify_original(old/'original',root,'macos')
actual=run_capture(root,root/'.ken/rust-migration/m2-fastembed/target-final-ci/debug/examples/search_selection_probe',reference,w/'selection-macos-current')
print('unchanged old original cases',len(actual['cases']),actual['metrics'])
