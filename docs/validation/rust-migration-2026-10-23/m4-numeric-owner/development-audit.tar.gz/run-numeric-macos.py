from pathlib import Path
import json
from tools.rust_migration.numeric_reference import SCRIPTS
from tools.rust_migration.numeric_validate import run_capture
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';cases=[]
for family in SCRIPTS:
 value=json.loads((w/f'original-macos-{family}/reference.json').read_bytes())
 cases.extend(dict(c,id=f'{family}/{i}/{c["id"]}',family=family)for i,c in enumerate(value['cases']))
reference=dict(cases=cases);(w/'combined-reference-macos.json').write_text(json.dumps(reference,ensure_ascii=True,allow_nan=False)+'\n')
print('new original cases',len(cases))
actual=run_capture(root,root/'.ken/rust-migration/m2-fastembed/target-final-ci/debug/examples/numeric_owner_probe',reference,w/'native-macos-attempt3')
print('native cases',len(actual['cases']),'metrics',actual['metrics'])
