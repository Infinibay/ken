### Task 2: Exact English stemming and provider-owned reuse

**Files:** Create src/stemming.rs, private snowball/{mod.rs,english.rs,runtime.rs}; license/provenance manifest; tests/stemming.rs; extend original-reference families.

**Interfaces:** WordStemmer:Send+Sync::stem(&PythonText)->Result<PythonText>; EnglishStems::shared()->Arc<Self>, stem_words(&[PythonText])->Result<Vec<PythonText>>. A supplied provider owns its cache; default English shares one bounded provider cache.

- [ ] Capture original stem output and scoped test_stem_reuse once, including long/Unicode/lone-marker words, order, duplicate/mutated outputs,32768bound,128/129codepoints, concurrent independent state and factory replacement. Write public native tests; run `cargo test --locked --offline -p ken-retrieval --test stemming`; Expected absent API RED.
- [ ] Acquire only official commit e4b3efb449ccb994d39230eb6e8440d267471f4a into owned scratch, record source/license hashes and native compiler/generator command, generate English Rust and vendor only required runtime/algorithm. No runtime compiler or Python; preserve algorithm/source provenance. Integrate without new lint suppressions. Implement bounded provider-owned reuse and proven lossless text handling.
- [ ] Run stem differentials, concurrent/cache boundary roots and affected complete native/tooling/fmt/clippy checks; Expected PASS. Commit/push `feat(retrieval): preserve Snowball English stemming with bounded native reuse`.

