use ken_retrieval::{numeric_ranker::NumericRanker, ranking_trace::RankingTrace};
fn main() {
 let model=NumericRanker::from_json(r#"{"schema":1,"features":["x","y"],"trees":[{"feature":1,"threshold":2.5,"left":{"value":1},"right":{"value":0}}]}"#).unwrap();
 let raw=std::fs::read_to_string("/private/tmp/ken-m4c1-final-review/trace.json").unwrap().replace("FINGERPRINT", &model.fingerprint().unwrap());
 match RankingTrace::from_json(&raw, &model) { Ok(trace)=>println!("ACCEPTED {}", trace.to_json(false).unwrap()),Err(e)=>println!("REJECTED {e}") }
}
