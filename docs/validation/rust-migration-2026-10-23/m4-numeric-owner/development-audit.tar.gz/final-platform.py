from pathlib import Path
import json,sys,shutil,subprocess
from tools.rust_migration.numeric_evidence import verify_original,verify_capture
from tools.rust_migration.numeric_validate import run_capture
from tools.rust_migration.selection_evidence import verify_original as old_original
from tools.rust_migration.selection_validate import run_capture as old_capture
from tools.rust_migration.reference import Reference,reference_env
from tools.rust_migration.native_json import load
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';system='macos'if sys.platform=='darwin'else'linux';e=w/f'evidence-{system}'
if system=='linux':
 r=Reference.load(Path('/app/.ken/rust-migration/m2-optional/reference-final-t9'))
 p=subprocess.run([str(r.python),str(w/'review-original.py'),str(w/'review-original-linux'),str(w/'review-trace-input.json')],cwd=r.root,env=reference_env(r,w/'review-original-environment'),capture_output=True)
 (w/'review-original-linux.stdout.log').write_bytes(p.stdout);(w/'review-original-linux.stderr.log').write_bytes(p.stderr)
 print('original review',p.returncode,p.stdout.decode(),p.stderr.decode(),flush=True);assert p.returncode==0
 a=load(w/'review-original-linux/observations.json');b=load(root/'crates/ken-retrieval/tests/fixtures/numeric-review-regressions.json')
 assert {k:v for k,v in a.items()if k!='runtime'}=={k:v for k,v in b.items()if k!='runtime'}
binary=root/('.ken/rust-migration/m2-fastembed/target-final-ci'if system=='macos'else'target')/'debug/examples'
reference=verify_original(e/'original',root,system)
actual=run_capture(root,binary/'numeric_owner_probe',reference,e/'native-final')
assert not verify_capture(e/'native-final',reference)
(e/'native').rename(e/'native-pre-review');(e/'native-final').rename(e/'native')
print('numeric final',len(actual['cases']),actual['metrics'],flush=True)
reference=old_original(w/f'accepted-selection-{system}/original',root,system)
actual=old_capture(root,binary/'search_selection_probe',reference,w/f'selection-{system}-final')
(w/f'selection-{system}-current').rename(w/f'selection-{system}-pre-review');(w/f'selection-{system}-final').rename(w/f'selection-{system}-current')
print('selection final',len(actual['cases']),actual['metrics'],flush=True)
(e/'gates').rename(e/'gates-pre-review')
subprocess.run([sys.executable,str(w/'run-gates.py')],check=True)
