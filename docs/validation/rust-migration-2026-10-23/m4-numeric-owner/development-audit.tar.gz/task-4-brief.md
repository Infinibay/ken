### Task 4: Full owner feature projection and bounded vocabulary

**Files:** Create src/feature_matrix.rs,word_encoder.rs,coverage.rs,evidence_features.rs,contextual_features.rs; extend vocabulary.rs with lossless code_terms_python; tests/coverage.rs,evidence_features.rs,contextual_features.rs.

**Interfaces:** FeatureMatrix{names:Vec<PythonText>,values:Matrix<f64>}; WordEncoder::{spec()->&EncoderSpec,embed_query(&PythonText)->Result<Vec<f32>>,embed_passages(&[PythonText])->Result<Vec<Vec<f32>>>}; ManagedWordEncoder adapter consumes Arc<ManagedEncoder> plus pinned spec. coverage(query,documents,fields,encoder,optional_stemmer)->Result<Vec<BTreeMap<String,f64>>>; base_features(request,candidate), evidence_features(request,candidates,descriptions,encoder,stemmer,expanded), contextual_features(candidates,source_views)->Result<FeatureMatrix>.

- [ ] Capture actual base/coverage/owner/contextual feature matrices, names and encoder/stemmer call traces with disjoint original suites. Pin all field/schema orders; include stale/foreign/empty evidence, missing signals, original/expanded equal/different queries, Unicode/negation/operations, duplicates and4095/4096/4097vocab/term boundaries. Add tests; Expected missing APIs RED.
- [ ] Implement complete projections and pool-relative ranks with one authoritative schema. Preserve query128/field4096limits, membership order, shared-field reuse, query/source coverage passes and original dtype/mean normalization. Stream vocabulary blocks4096, retaining field sums/maxima rather than full similarity history. Validate source identity before embedding with the accepted evidence guard.
- [ ] Run complete affected feature/alignment/vocabulary/owner-selection suites, deterministic call/memory bounds, fmt/clippy; Expected PASS. Commit/push `feat(retrieval): project complete source evidence into pinned ranking features`.

