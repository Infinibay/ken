### Task 1: Numeric forest, rectangular values and canonical identity

**Files:** Create ken-retrieval/src/matrix.rs,numeric_ranker.rs,rank_json.rs; tests/numeric_ranker.rs; tools/rust_migration/numeric_reference.py and input-only fixtures. Export through lib.rs.

**Interfaces:** Matrix<T>::new(rows,columns,values)->Result<Self>, rows/columns/values immutable access; NumericRanker::from_json(&str)->Result<Self>, features()->&[PythonText], to_json()->Result<String>, fingerprint()->Result<String>, predict(&Matrix<f64>)->Result<Vec<f64>>, explain_pair(left:&[f64],right:&[f64])->Result<PairExplanation>. Named explanation structs serialize original fields.

- [ ] Capture actual original numeric_ranker observations and its complete scoped suite once: schemas/extra keys/coercions, bounds/depth64/65, Unicode names, signed zero/exponent formatting, cancellation, mixed-depth independent paths,0/1/32/128/129rows, nonfinite input/output/explanation errors and margins. Capture nonfinite values explicitly; never turn them into null.
- [ ] Add complete native model/dict/fingerprint/prediction/explanation comparisons. Run `$MAC cargo test --locked --offline -p ken-retrieval --test numeric_ranker`; Expected missing API RED.
- [ ] Implement bounded immutable tree parsing, original canonical compact JSON/float spelling, checked matrix shape, sequential prediction and accurate pair-path/fsum accounting. Avoid modifying the accepted M2 serializer, whose spacing/escaping differs.
- [ ] Run new and directly affected complete suites plus fmt/clippy; Expected PASS. Commit/push `feat(retrieval): execute pinned numeric forests and explain margins`.

