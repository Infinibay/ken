from pathlib import Path
import json,tarfile,shutil
from tools.rust_migration.native_json import identity,tree,load
from tools.rust_migration.index_validate import source_identity
from tools.rust_migration.numeric_evidence import PREDECESSOR,aggregate_matrix
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-numeric-owner-ranking';out=root/'docs/validation/rust-migration-2026-10-23/m4-numeric-owner';out.mkdir(exist_ok=True)
snapshot=w/'matrix-snapshot';native=snapshot/'native-sources';validation=snapshot/'validation-sources';native.mkdir(parents=True,exist_ok=True);validation.mkdir(parents=True,exist_ok=True)
sources=source_identity(root)
extra=['src/ken/embedder/data/ken__static-qwen3-r512-v2.npz','docs/validation/rust-migration-2026-10-18/baseline.json']
for name in [*sources,*extra]:
 p=native/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
for folder in ['tools/rust_migration','tests/rust_migration']:
 for p in sorted((root/folder).rglob('*.py')):
  dest=validation/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for name in ['native-sources','validation-sources']:
 with tarfile.open(out/(name+'.tar.gz'),'w:gz')as t:t.add(snapshot/name,arcname=name)
platforms={}
for system in ['macos','linux']:
 e=w/f'evidence-{system}'
 with tarfile.open(out/(system+'-capture.tar.gz'),'w:gz')as t:
  for name in ['original','native','gates']:t.add(e/name,arcname=name)
  t.add(w/f'accepted-selection-{system}/original',arcname='selection-original');t.add(w/f'selection-{system}-current',arcname='selection-native')
 platforms[system]=dict(native_sha256=load(e/'native/BUILD.json')['native_sha256'],selection_sha256=load(w/f'selection-{system}-current/BUILD.json')['native_sha256'])
index=dict(format='ken-numeric-matrix/1',predecessor=PREDECESSOR,sources=sources,tooling=tree(validation),platforms=platforms,review=dict(status='complete',critical_remaining=0,important_remaining=0,report_sha256=identity(out/'REVIEW.md')['sha256']))
(out/'INDEX.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n');shutil.copy2(w/'progress.md',out/'LEDGER.md')
with tarfile.open(out/'development-audit.tar.gz','w:gz')as t:
 for p in sorted(w.iterdir()):
  if p.is_file()and p.suffix in ['.log','.py','.md']:t.add(p,arcname=p.name)
  elif p.name in ['snowball-source.tar.gz','english-generated.rs','english-python-generated.py','english_stemmer.py','original-macos-production-invalid-observer','original-macos-production-invalid-relative','original-macos-alignment-edges-invalid-family','native-macos','native-macos-attempt2','review-original-macos','review-original-linux','reviewer-repro']:
   t.add(p,arcname=p.name)
 for system in ['macos','linux']:
  for name in ['native-pre-review','gates-pre-review']:t.add(w/f'evidence-{system}'/name,arcname=system+'/'+name)
  t.add(w/f'selection-{system}-pre-review',arcname=system+'/selection-pre-review')
(out/'README.md').write_text('''# Native numeric owner ranking (M4c1)\n\nBoth actual platforms reproduce861new original observations:854differentials and7explicit source-admission guards that reject inherited unsafe inputs.35original scoped test roots/platform were captured once and reused by supplemental observations; no old model catalog or training was rerun. Both hosts pass80affected Rust roots and92validation roots, strict fmt/clippy, and all758previous selection observations reexecuted natively on the new source.1066original files remain unchanged.\n\nThe production forests are the exact original2560/1280-tree artifacts. Real static-table composition retains the fixed upstream F32 bound and additionally matches every chosen leaf bit-pattern/ordered branch path, score, owner/evidence order and model call. Isolated native runs use empty PATH/HOME, pinned owned resources and actual loader/exec/connect auditing. Numeric process scope includes input parsing and complete bounded numerical/feature/ranking operations/resource loading before serialization; it is not a public CLI/service latency claim. macOS9.124606959s/461209600peakRSS bytes; Linux14.309425215s/343425024bytes.\n\nThe original Python captures are preserved verbatim. Invalid development attempts are retained only in development-audit and excluded from accepted counts. Source/tooling snapshots support independent receipt replay. The single final review and its three Important fixes are complete; see REVIEW.md, FIXES.md, RULINGS.md and MINORS.md. Actual original review regressions cover257models/32805finite values and ragged trace rejection on both platforms, without rerunning any scoped suite. M4c1 is accepted; full M4 and global migration remain false. M4c2/piece catalogs and ranking, M4d/public runtime composition, and M5–M8 are still required.\n''')
manifest=dict(files=[dict(path=str(p.relative_to(out)),**identity(p))for p in sorted(out.rglob('*'))if p.is_file()and p.name!='FILES.json']);(out/'FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
result=aggregate_matrix(out,root,snapshot=snapshot,current=True);(w/'matrix-final-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert result['passed']and result['M4c1_accepted']
