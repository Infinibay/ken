"""Disjoint review regressions; no original test suite or model catalog rerun."""
import hashlib,json,math,pathlib,platform,random,struct,sys
import numpy as np
from ken.retrieval.numeric_ranker import NumericRanker
from ken.retrieval.ranking_trace import RankingTrace
out=pathlib.Path(sys.argv[1]);out.mkdir()
rng=random.Random(20261023)
values=[601174747868153.25,-1270080588912175.25,-1952118768138121.25,664194692707708.25,885754054047377.25]
bits=lambda v:struct.unpack('>Q',struct.pack('>d',v))[0]
decode=lambda v:struct.unpack('>d',struct.pack('>Q',v))[0]
seed=list(values)
for v in seed:
 for sign in [1.,-1.]:
  v=abs(v)*sign
  values.extend([math.nextafter(v,-math.inf),v,math.nextafter(v,math.inf)])
values.extend([0.,-0.,decode(1),-decode(1),sys.float_info.max,-sys.float_info.max,sys.float_info.min,-sys.float_info.min])
for _ in range(16384):
 v=decode(rng.getrandbits(64))
 if math.isfinite(v):values.append(v)
for _ in range(16384):values.append(decode((rng.randrange(1070,1077)<<52)|rng.getrandbits(52)))
models=[]
for start in range(0,len(values),128):
 model=NumericRanker.from_dict(dict(schema=1,features=['x'],trees=[dict(value=v)for v in values[start:start+128]]))
 models.append(dict(model=model.to_dict(),canonical=json.dumps(model.to_dict(),sort_keys=True,separators=(',',':'),ensure_ascii=False),fingerprint=model.fingerprint))
model=NumericRanker.from_dict(dict(schema=1,features=['x','y'],trees=[dict(feature=1,threshold=2.5,left=dict(value=1),right=dict(value=0))]))
trace=json.loads(pathlib.Path(sys.argv[2]).read_bytes());trace['model_fingerprint']=model.fingerprint
try:RankingTrace.from_dict(trace,model)
except ValueError as error:failure=dict(type=type(error).__name__,message=str(error))
else:raise AssertionError('original accepted ragged trace')
value=dict(format='ken-numeric-review-regressions/1',runtime=dict(system=platform.system(),python=platform.python_version(),numpy=np.__version__),values=len(values),models=models,trace_model=model.to_dict(),ragged_trace=trace,ragged_error=failure)
(out/'observations.json').write_text(json.dumps(value,ensure_ascii=True,allow_nan=False)+'\n')
owners=['src/ken/retrieval/numeric_ranker.py','src/ken/retrieval/ranking_trace.py']
(out/'OWNERS.json').write_text(json.dumps({p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()for p in owners},indent=2)+'\n')
print(json.dumps(dict(models=len(models),values=len(values),ragged_error=failure,runtime=value['runtime'])))
