from pathlib import Path
import json,copy
p=Path('tools/rust_migration/numeric_reference.py');s=p.read_text().replace('from .numeric_feature_reference import SCRIPT as FEATURE_SCRIPT','from .numeric_feature_reference import SCRIPT as FEATURE_SCRIPT\nfrom .numeric_owner_reference import SCRIPT as OWNER_SCRIPT').replace("'features':['tests/retrieval/test_evidence_features.py','tests/retrieval/test_contextual_features.py','tests/retrieval/test_batched_term_coverage.py']}","'features':['tests/retrieval/test_evidence_features.py','tests/retrieval/test_contextual_features.py','tests/retrieval/test_batched_term_coverage.py'],'owner-ranking':['tests/retrieval/test_owner_ranking.py','tests/retrieval/test_ranking_trace.py']}").replace("'features-math-edges':FEATURE_EDGES_SCRIPT}","'features-math-edges':FEATURE_EDGES_SCRIPT,'owner-ranking':OWNER_SCRIPT}");p.write_text(s)
f=json.loads(Path('crates/ken-retrieval/tests/fixtures/numeric-reference-features.json').read_bytes());base=f['feature_names'];context=next(c['result']['names']for c in f['cases']if c['kind']=='feature_context'and c['input']['source_views'])
source=copy.deepcopy(next(c['input']for c in f['cases']if c['kind']=='evidence'));source['candidates']=source['candidates'][:2];source['owners']=source['owners'][:2];source.pop('expanded',None);source['stemmer']='english'
for i,(c,o)in enumerate(zip(source['candidates'],source['owners'])):
 c['signals'].update(cosine_code_original=[.1,.9][i],cosine_code_expanded=[.2,.8][i],**{'cosine_view_'+v+'_'+q:[.2,.8][i]for v in ['contract','implementation']for q in ['original','expanded']})
 o['passages'][0]['fields']['body']='def operation(cookie):\n    begin_transaction()'
 o['passages'][1]['fields']['body']='    persist(durable, cookie)\n    return cookie' if i else '    unrelated(values)\n    return values'
 c['passages']=[copy.deepcopy(o['passages'][0])];c['signals']['rrf']=[.9,.1][i]
def model(version=1,constant=None):
 names=base+(context[:8] if version==2 else context if version==3 else [])
 tree={'value':constant} if constant is not None else dict(feature=names.index('expanded_implementation_exact' if version==1 else 'code_original_raw' if version==2 else 'view_implementation_expanded_raw'),threshold=.6,left={'value':0.},right={'value':1.})
 return dict(schema=1,features=names,trees=[tree])
cases=[]
def add(name,kind,**data):cases.append(dict(id=name,kind=kind,input=data))
for fv in [1,2,3]:
 for ev in [1,2,3]:
  for expand in [False,True]:
   data=copy.deepcopy(source);data.update(model=model(fv),evidence_version=ev,expand=expand,expansion_revision='d'*64 if expand else None,request_id='rank-'+str(len(cases)));add('rank-'+str(len(cases)),'rank_trace',**data)
for name,change in [('tie',{}),('reverse',{'reverse':True}),('exact',{'exact':True}),('empty',{'empty':True}),('attempts',{'second_query':'find tests for storage'})]:
 data=copy.deepcopy(source);data.update(model=model(constant=1.),request_id=name)
 if change.get('reverse'):data['candidates'].reverse()
 if change.get('exact'):data['candidates'][1]['signals']['exact']=1.
 if change.get('empty'):data['candidates']=[];data['owners']=[]
 if 'second_query' in change:data['second_query']=change['second_query']
 add(name,'rank_trace',**data)
data=copy.deepcopy(source);data['candidates']=data['candidates'][:1];data['candidates'][0]['signals']['exact']=1.;data.update(owners=[],model=model(),expand=True,expansion_revision='d'*64,expansion_result='',request_id='exact-bypass');add('unique-exact','rank_trace',**data)
for ev in [0,4]:
 data=copy.deepcopy(source);data.update(model=model(),evidence_version=ev);add('evidence-version-'+str(ev),'rank',**data)
for name,expand,revision,value in [('none',False,None,None),('expanded',True,'d'*64,'  persist cookie  '),('empty',True,'d'*64,''),('spaces',True,'d'*64,'  '),('nontext',True,'d'*64,42),('missing-revision',True,None,'cookies'),('missing-callback',False,'d'*64,None)]:add('prepare-'+name,'prepare',model=model(),query='browser state',expand=expand,expansion_revision=revision,expansion_result=value)
for fv in [1,2,3]:
 for key,value in [('ok',None),('model_revision','c'*64),('word_model',dict(model_id='wrong-words',revision='b'*64,backend='provided',batch_size=1)),('feature_version',1 if fv!=1 else 2),('expansion_revision','d'*64)]:add('validate-'+str(fv)+'-'+key,'validate',model=model(fv),profile={} if value is None else {key:value})
add('bad-feature-schema','prepare',model=dict(schema=1,features=['wrong'],trees=[{'value':0.}]),query='cookies')
small=dict(schema=1,features=['coverage','path'],trees=[dict(feature=0,threshold=.5,left={'value':-2.},right=dict(feature=1,threshold=.4,left={'value':3.},right={'value':7.})),dict(feature=1,threshold=.4,left={'value':1.},right={'value':-1.}),{'value':.25}])
for tamper in [None,'model','names','proposal','ranks','duplicate','scores','order','policy','exact-policy','query','expanded','drop-query']:add('restore-'+str(tamper),'trace_restore',model=small,query='café 😀 storage',expanded='persist cookie',candidates=source['candidates'],values=[[.7,.8],[.5,.2]],tamper=tamper,request_id='trace-restore')
for reason,exact,values in [('score',False,[[.7,.8],[.5,.2]]),('tie',False,[[.5,.2],[.5,.2]]),('exact',True,[[.7,.8],[.5,.2]])]:
 candidates=copy.deepcopy(source['candidates'])
 if exact:candidates[1]['signals']['exact']=1.
 add('compare-'+reason,'trace_record',model=small,query='stored values',candidates=candidates,values=values,request_id='compare-'+reason)
for compare in [False,True]:add('empty-trace-'+str(compare),'trace_empty',model=small,compare_empty=compare)
for request_id in [None,'']:add('ids-'+str(request_id),'trace_ids',model=small,request_id=request_id)
nonfinite=dict(schema=1,features=['x'],trees=[dict(feature=0,threshold=.5,left={'value':1e308},right={'value':-1e308}),dict(feature=0,threshold=.5,left={'value':-1e308},right={'value':0.})]);add('nonfinite-leaf-deltas','trace_record',model=nonfinite,query='margin',candidates=source['candidates'],values=[[0.],[1.]],request_id='nonfinite-deltas')
Path('crates/ken-retrieval/tests/fixtures/numeric-inputs-owner-ranking.json').write_text(json.dumps(dict(cases=cases),ensure_ascii=True,separators=(',',':'))+'\n');print('owner/trace cases',len(cases))
