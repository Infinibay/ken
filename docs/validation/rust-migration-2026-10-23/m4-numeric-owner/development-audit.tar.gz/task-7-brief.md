### Task 7: Authenticated numeric-owner acceptance and one final review

**Files:** Extend/reuse strict native probe/capture infrastructure with new numeric families, tools/rust_migration/numeric_{validate,evidence}.py and test_selection-compatible tamper gates; docs/validation/rust-migration-2026-10-23/m4-numeric-owner/.

**Interfaces:** Bounded input-only numerical/feature/rank/trace operations plus explicit verified resource inputs; fixed dtype-aware comparisons retain complete names/rows/order/owner/evidence/traces/errors. Reuse generic NativeJsonCapture/receipt/source helpers and M4b predecessor rather than recapture old cases.

- [ ] Add actual-positive/tamper tests for omitted/reordered feature rows/names/calls, resealed results, stale resources/runtime/source/binary, skipped tests and altered raw originals. Run; Expected missing protocol/verifier RED.
- [ ] Execute both actual platforms once for new complete families and affected native/tooling gates, original preservation, isolated runtime, measured resources and independent source/tooling/raw replay. Expected full PASS. Archive before commit/push `test(retrieval): authenticate numeric owner features and ranking`.
- [ ] One fresh whole-plan reviewer with Review Focus verbatim and ledger rulings; regrade all findings/declined behaviors, one Critical/Important RED→GREEN fix pass with affected green suites; preserve exhaustive review/rulings/minors, final replay, clean only owned obsolete scratch and continue M4c2 without confirmation. M4/global stay false.
