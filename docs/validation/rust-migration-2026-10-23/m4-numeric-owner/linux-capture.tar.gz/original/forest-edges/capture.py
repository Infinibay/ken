
import importlib,json,math,pathlib,platform,sys,unicodedata,warnings
import numpy as np,pytest
request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root'])
from ken.retrieval.numeric_ranker import NumericRanker
if not pathlib.Path(importlib.import_module('ken.retrieval.numeric_ranker').__file__).resolve().is_relative_to(root.resolve()):raise ValueError('wrong original numeric module')
def restore(value):
 if isinstance(value,dict):
  if set(value)=={'$float'}:return float(value['$float'])
  return{k:restore(v)for k,v in value.items()}
 if isinstance(value,list):return[restore(v)for v in value]
 return value
def clean(value):
 if isinstance(value,np.ndarray):return clean(value.tolist())
 if isinstance(value,np.generic):return clean(value.item())
 if isinstance(value,float)and not math.isfinite(value):return{'$float':'nan'if math.isnan(value)else'inf'if value>0 else'-inf'}
 if isinstance(value,dict):return{k:clean(v)for k,v in value.items()}
 if isinstance(value,(list,tuple)):return[clean(v)for v in value]
 return value
records=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore',RuntimeWarning)
 for case in request['cases']:
  data=restore(case['input'])
  try:
   model=NumericRanker.from_dict(data['model']);kind=case['kind']
   if kind=='model':result=dict(model=model.to_dict(),canonical=json.dumps(model.to_dict(),sort_keys=True,separators=(',',':'),ensure_ascii=False),fingerprint=model.fingerprint)
   elif kind=='dict':result=model.to_dict()
   elif kind=='predict':
    matrix=np.asarray(data['values'],dtype=np.float64).reshape(data['rows'],data['columns']);before=model.to_dict();scores=model.predict(matrix)
    result=dict(scores=scores,unchanged=before==model.to_dict())
   elif kind=='explain':result=model.explain_pair(data['left'],data['right'])
   else:raise ValueError('unknown numeric operation')
   records.append(dict(**case,result=clean(result)))
  except Exception as error:records.append(dict(**case,error=dict(type=type(error).__name__,message=str(error))))
discovered=[];states=[]
class Plugin:
 def pytest_collection_finish(self,session):discovered.extend(i.nodeid for i in session.items)
 def pytest_runtest_logreport(self,report):
  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
cached=json.loads(pathlib.Path(request['cached_suite']).read_bytes());discovered=cached['discovered'];states=cached['test_states'];exit_code=cached['original_test_exit']
value=dict(format='ken-numeric-reference/1',family=request['family'],cases=records,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version(),unicode=unicodedata.unidata_version,numpy=np.__version__),discovered=discovered,test_states=states,original_test_exit=exit_code)
pathlib.Path(request['result']).write_text(json.dumps(value,ensure_ascii=True,allow_nan=False)+'\n');sys.exit(exit_code)
