
import hashlib,importlib.metadata,json,pathlib,platform,snowballstemmer
root=pathlib.Path(snowballstemmer.__file__).parent
value=dict(format='ken-original-snowball/2',distribution=importlib.metadata.version('snowballstemmer'),python=platform.python_version(),files={name:dict(bytes=(root/name).stat().st_size,sha256=hashlib.sha256((root/name).read_bytes()).hexdigest())for name in ['english_stemmer.py','basestemmer.py','among.py']},factory=dict(path=str(root/'__init__.py'),bytes=(root/'__init__.py').stat().st_size,sha256=hashlib.sha256((root/'__init__.py').read_bytes()).hexdigest()),runtime=dict(system=platform.system(),machine=platform.machine()))
print(json.dumps(value,sort_keys=True))
