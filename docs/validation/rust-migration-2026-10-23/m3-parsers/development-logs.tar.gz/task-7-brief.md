### Task 7: Native differential acceptance and final review

**Files:** Create `crates/ken-syntax/examples/parser_probe.rs`, `tools/rust_migration/{parser_validate.py,parser_evidence.py}`, `tests/rust_migration/{test_parser_validate.py,test_parser_evidence.py}`, `docs/validation/rust-migration-2026-10-23/m3-parsers/`; update `docs/rust-migration.md`.

**Interfaces:** Consumes complete `ParserRegistry` and original capture; produces bounded strict JSON probe with actual language/source bytes/hint only, and authenticated platform acceptance. No expected fields are accepted by native requests. Matrix accepts M3b only; M3 and whole migration remain false.

- [ ] **Step 1:** Write comparator/evidence RED tests rejecting missing/duplicate/reordered cases, changed symbol ranges/kinds, lost docs/scope/annotations, injected expected results, altered grammar/source hashes, false passing summaries and absent language/platform coverage. Real process tests exercise unknown fields, invalid source encoding and resource failures.
- [ ] **Step 2:** Implement strict native batch transport and full ordered semantic comparison. Record actual copied binary, outside-checkout cwd, sentinelPATH, complete input/output and loader/exec/connect audit; grammar preparation occurs before isolated native execution.
- [ ] **Step 3:** Build and run full syntax/tooling gates and one current native differential per platform; compare complete case inventories and grammar shapes. Reuse prior source/model receipts at exact snapshots; verify original1066files unchanged.
- [ ] **Step 4:** Replay authenticated evidence independently; resealed mutations must reject. Record source/bin/resource/test identities and compression of raw artifacts; no hundreds of disposable files left as product sources. Do not promote indexing or installed commands.
- [ ] **Step 5:** Commit scope-specific evidence. Run one fresh whole-plan review, one TDD Important/Critical repair pass and affected gates. Archive complete ledger/rulings/minors/review before deleting own workspace; continue common-model/import-resolution/indexing plan without asking for confirmation.

## Self-review

All spec capabilities map to Tasks1–7; no parser language or ParsedFile field is
omitted. Task1 precedes all grammar consumers; Task2 establishes shared model and
scope interfaces before language groups; detection follows available C++ extraction.
Every review-focus condition has a boundary test. Preparation remains separate
from native consumption and final distribution is reserved for M8. Native inline
execution and no approval pauses are the user's continuing selected method.

Task1 source verification amendment: Python binding0.25.2 vendors C engine0.25.10 at da6fe9be. All42original C/header inputs match Rust0.25.10 exactly; the compiled lock records this evidence. The initial Rust0.25.2 corpus happened to pass all215inputs, but matching the actual engine avoids untested runtime behavior differences. No original capture or model inference was repeated.

Task2 model refinement: PythonStringLiteral owns full docstring decoding; py_literal
alone does not decode the captured triple-quoted docs or raw/Unicode-name forms.
The native adapter normalizes delimiters/line breaks and preserves raw/u/bytes/f
behavior. Pinned unicode_names2=1.2.0 supplies formal names, with a reproducible
original-Unicode15 filter (627new15.1codepoints excluded,473original aliases).
Its derived dataset carries Unicode-DFS-2016 attribution/license. A separate
19case original corpus tests these forms and CRLF comments without rerunning the
124original tests. Shared text splitting treats CRLF as one boundary.
