from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
folder=Path('.ken/rust-migration/m3-parsers/research')
catalog=json.loads((folder/'language_definitions.json').read_bytes());manifest=json.loads((folder/'pack-manifest.json').read_bytes())
licenses=json.loads((folder/'license_cache.json').read_bytes())
names=['bash','c','cpp','csharp','css','dart','graphql','html','kotlin','php','powershell','ruby','sql']
lock=dict(format='ken-grammar-lock/1',pack=dict(version='1.8.1',revision='33602ce7d17edd24cc00a1a9fe7129a61138f8ef',bundles={}),direct=[])
for platform in ['macos-arm64','linux-aarch64']:
 suffix='.dylib'if platform.startswith('macos')else'.so'
 wanted={'libtree_sitter_'+('c_sharp'if name=='csharp'else name)+suffix:name for name in names}
 rows={};source=manifest['platforms'][platform];archive=folder/f'parsers-{platform}.tar.zst'
 assert archive.stat().st_size==source['size']and hashlib.sha256(archive.read_bytes()).hexdigest()==source['sha256']
 with subprocess.Popen(['zstd','-q','-d','-c',str(archive)],stdout=subprocess.PIPE)as process:
  with tarfile.open(fileobj=process.stdout,mode='r|')as tar:
   for member in tar:
    filename=Path(member.name).name
    if filename not in wanted:continue
    name=wanted[filename];assert name not in rows and member.isfile()
    raw=tar.extractfile(member).read();lang=catalog[name];repo=lang['repo'].removeprefix('https://github.com/')
    notice=json.loads((folder/f'license-{name}.json').read_bytes());text=base64.b64decode(notice['content']).decode()
    rows[name]=dict(file=filename,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),revision=lang['rev'],
      repository=lang['repo'],symbol='tree_sitter_'+('c_sharp'if name=='csharp'else name),
      license=dict(id=licenses[repo],text=text,url=notice['download_url'],sha256=hashlib.sha256(text.encode()).hexdigest()))
  while process.stdout.read(65536):pass
  assert process.wait(timeout=20)==0
 assert set(rows)==set(names)
 lock['pack']['bundles'][platform]=dict(url=source['url'],bytes=source['size'],sha256=source['sha256'],libraries=rows)
for record in json.loads((folder/'direct-grammars.json').read_bytes()):
 name,version=record['name'],record['version'];crate=json.loads((folder/f'crate-{name}-{version}.json').read_bytes())['version']
 archive=folder/f'{name}-{version}.crate';assert hashlib.sha256(archive.read_bytes()).hexdigest()==crate['checksum']
 with tarfile.open(archive)as tar:parsers={m.name.split('/',1)[1]:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in tar if m.name.endswith('/parser.c')}
 with tarfile.open(folder/Path(record['source']['url']).name)as tar:originals={m.name.split('/',1)[1]:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in tar if m.name.endswith('/parser.c')}
 assert parsers==originals
 lock['direct'].append(dict(name=name,version=version,crate_sha256=crate['checksum'],sdist=record['source'],parser_sources=parsers))
Path('crates/ken-syntax/grammars.lock.json').write_text(json.dumps(lock,indent=2)+'\n')
print('Pinned13native modules on2platforms and7byte-identical direct C grammars, including source licenses.')
