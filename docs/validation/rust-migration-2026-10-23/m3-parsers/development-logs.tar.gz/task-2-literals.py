from pathlib import Path
import hashlib,json,os,subprocess
from tools.rust_migration.reference import Reference,reference_env
from tools.rust_migration.parser_reference import parser_owner_hashes
r=Path.cwd();w=r/'.superpowers/sdd/2026-10-23-rust-parsers';ref=Reference.load(Path(os.environ.get('KEN_RUST_REFERENCE',r/'.ken/rust-migration/m2-optional/reference-final-t9')))
inputs=[]
literals=[r'r"raw \n value"',r'u"café \u263a"',r'"\N{LATIN CAPITAL LETTER A}"',r'"\N{LF}"',r'"\N{latin capital letter a}"',r'"\N{LATIN_CAPITAL_LETTER_A}"',r'"\N{SNOWMAN}"',r'"\N{CJK UNIFIED IDEOGRAPH-4E00}"',r'"\N{CJK UNIFIED IDEOGRAPH-2EBF0}"',r'b"bytes"',r'f"{missing}"',r'"bad \N{UNKNOWN NAME}"',r'"line\\nnotline"',"'a\"b'",'"""First line.\n\nComplete documentation."""',r'"\d"',r'R"double \" quote"', '"""CRLF\r\nSecond line."""']
for i,literal in enumerate(literals):
 source=('def read_value():\n    '+literal.replace('\n','\n    ')+'\n    return 1\n').encode()
 inputs.append(dict(language='python',hint=f'literal-{i}.py',source_hex=source.hex()))
owners=parser_owner_hashes(r)
assert all(hashlib.sha256((ref.root/p).read_bytes()).hexdigest()==v for p,v in owners.items())
script=r'''import dataclasses,hashlib,json,pathlib,sys
from ken.parsers.python import parse_python_file
import ken.parsers.python
request=json.load(sys.stdin)
assert pathlib.Path(ken.parsers.python.__file__).resolve().is_relative_to(pathlib.Path(request['root']).resolve())
rows=[]
for case in request['inputs']:
 source=bytes.fromhex(case['source_hex']);result=parse_python_file(source,case['hint'])
 identity=hashlib.sha256(case['language'].encode()+b'\0'+case['hint'].encode()+b'\0'+source).hexdigest()
 rows.append(dict(id=identity,input=case,parsed=dataclasses.asdict(result)))
print(json.dumps(dict(cases=rows)))
'''
actual=subprocess.run([str(ref.python),'-c',script],input=json.dumps(dict(root=str(ref.root),inputs=inputs)),text=True,cwd=ref.root,env=reference_env(ref,w/'literal-original-environment'),capture_output=True,timeout=20)
assert actual.returncode==0,actual.stderr
result=json.loads(actual.stdout);result.update(owners=owners,script=script,execution=dict(exit=actual.returncode,stdout=actual.stdout,stderr=actual.stderr))
(r/'crates/ken-syntax/tests/fixtures/python-literals.json').write_text(json.dumps(result,indent=2,ensure_ascii=True)+'\n')
print('Captured',len(result['cases']),'independent original literal ParsedFile values')
