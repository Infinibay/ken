### Task 6: Shell, stylesheet, markup and declarative parsers

**Files:** Create `crates/ken-syntax/src/{bash.rs,powershell.rs,css.rs,html.rs,graphql.rs,sql.rs}`; extend registry/tests.

**Interfaces:** Same Task2 extraction signature/model. Domain-specific symbol kinds remain the original strings; no new cross-language taxonomy changes them.

- [ ] **Step 1:** Write complete captured-result tests for Bash functions/source, PowerShell functions/filter/class/import forms, CSS selectors/custom properties/imports, HTML tags/ids/script sources/templates, GraphQL declarations/fields/imports and SQL definitions. Include comments, nesting, duplicates, Unicode and malformed syntax.
- [ ] **Step 2:** Run six affected filters; expect pending-language RED.
- [ ] **Step 3:** Implement original syntax rules and attach scopes only where original does; remove the last explicit pending extraction branches.
- [ ] **Step 4:** Run full ken-syntax suite, fmt/clippy and complete coverage inventory: exactly19languages/20grammars/44extensions represented in both environments.
- [ ] **Step 5:** Commit as `feat(syntax): complete native parser language coverage`.

