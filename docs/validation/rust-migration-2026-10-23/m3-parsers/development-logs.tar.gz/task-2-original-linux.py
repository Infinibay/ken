from dataclasses import replace
from pathlib import Path
import hashlib,json,os,subprocess,sys
from tools.rust_migration.reference import Reference,reference_env
from tools.rust_migration.parser_reference import parser_owner_hashes
r=Path.cwd();reference=replace(Reference.load(Path(os.environ['KEN_RUST_REFERENCE'])),python=Path(sys.executable).absolute())
cases=json.loads(Path('crates/ken-syntax/tests/fixtures/parser-edges.json').read_bytes())['cases']
owners=parser_owner_hashes(r)
assert all(hashlib.sha256((reference.root/p).read_bytes()).hexdigest()==v for p,v in owners.items())
script=r'''import dataclasses,hashlib,importlib,json,pathlib,platform,sys,unicodedata
import tree_sitter_language_pack as pack
q=json.load(sys.stdin);pack.configure({'cache_dir':q['grammar_cache']})
rows=[]
for case in q['inputs']:
 module=importlib.import_module('ken.parsers.'+case['language'])
 assert pathlib.Path(module.__file__).resolve().is_relative_to(pathlib.Path(q['reference']).resolve())
 source=bytes.fromhex(case['source_hex']);parsed=getattr(module,'parse_'+case['language']+'_file')(source,case['hint'])
 identity=hashlib.sha256(case['language'].encode()+b'\0'+case['hint'].encode()+b'\0'+source).hexdigest()
 rows.append(dict(id=identity,input=case,parsed=dataclasses.asdict(parsed)))
print(json.dumps(dict(cases=rows,runtime=dict(python=platform.python_version(),system=platform.system(),machine=platform.machine(),unicode=unicodedata.unidata_version))))
'''
execution=subprocess.run([str(reference.python),'-c',script],input=json.dumps(dict(reference=str(reference.root),grammar_cache=os.environ['KEN_PARSER_ORIGINAL_GRAMMARS'],inputs=[c['input']for c in cases])),text=True,cwd=reference.root,env=reference_env(reference,r/'.superpowers/sdd/2026-10-23-rust-parsers/task-2-original-linux-env'),capture_output=True,timeout=20)
assert execution.returncode==0,execution.stderr
result=json.loads(execution.stdout);assert result['cases']==cases
result.update(owners=owners,script=script,execution=dict(exit=execution.returncode,stdout=execution.stdout,stderr=execution.stderr))
Path('.superpowers/sdd/2026-10-23-rust-parsers/task-2-original-linux.json').write_text(json.dumps(result,indent=2)+'\n')
print('IndependentLinuxoriginal19edgecases match Mac exactly, including full docstrings andCRLF.')
