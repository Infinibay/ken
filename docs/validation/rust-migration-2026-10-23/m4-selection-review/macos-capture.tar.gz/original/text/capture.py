
import dataclasses,hashlib,importlib,json,pathlib,platform,re,sys,unicodedata
import pytest
request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root'])
from ken.retrieval.model import SearchRequest,EntityKey
from ken.retrieval.intent import interpret,requested_piece_kind,requested_piece_path
from ken.retrieval.source_locator import symbol_locator
from ken.retrieval.piece_catalog import module_name
for name in ['intent','source_locator','piece_catalog']:
 if not pathlib.Path(importlib.import_module('ken.retrieval.'+name).__file__).resolve().is_relative_to(root.resolve()):raise ValueError('wrong original selection module')
records=[]
for case in request['cases']:
 data=case['input'];kind=case['kind']
 try:
  if kind=='intent':
   search=SearchRequest(**data);result=dict(intent=dataclasses.asdict(interpret(search)),piece_kind=requested_piece_kind(search),path=requested_piece_path(search))
  elif kind=='locator':
   locator=symbol_locator(data['query']);result=dict(locator=dataclasses.asdict(locator)if locator else None,matches=[locator.matches(EntityKey(**key))if locator else False for key in data['entities']])
  elif kind=='module':result=module_name(data['path'])
  elif kind=='identifier':result=data['text'].isidentifier()
  else:raise ValueError('unknown text operation')
  records.append(dict(**case,result=result))
 except Exception as error:records.append(dict(**case,error=dict(type=type(error).__name__,message=str(error))))
def ranges(predicate):
 result=[];start=None
 for cp in range(0x110000):
  if predicate(chr(cp)):
   if start is None:start=cp
  elif start is not None:result.append([start,cp-1]);start=None
 if start is not None:result.append([start,0x10ffff])
 return result
alphabet='abcdefghijklmnopqrstuvwxyzáéíóúñü';patterns=[(letter,re.compile(re.escape(letter),re.I))for letter in alphabet];allowed=re.compile('['+alphabet+']',re.I)
fold={}
for cp in range(0x110000):
 c=chr(cp)
 if allowed.fullmatch(c):
  letter=next(letter for letter,pattern in patterns if pattern.fullmatch(c))
  if c!=letter:fold[str(cp)]=letter
text_semantics=dict(unicode=unicodedata.unidata_version,identifier_start=ranges(str.isidentifier),identifier_continue=ranges(lambda c:('A'+c).isidentifier()),query_literal_fold=fold)
discovered=[];states=[]
class Plugin:
 def pytest_collection_finish(self,session):discovered.extend(i.nodeid for i in session.items)
 def pytest_runtest_logreport(self,report):
  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q',*request['suite'],'--junitxml='+request['junit']],plugins=[Plugin()])
value=dict(format='ken-selection-reference/1',family='text',cases=records,text_semantics=text_semantics,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version(),unicode=unicodedata.unidata_version),discovered=discovered,test_states=states,original_test_exit=exit_code)
pathlib.Path(request['result']).write_text(json.dumps(value,ensure_ascii=True,allow_nan=False)+'\n');sys.exit(exit_code)
