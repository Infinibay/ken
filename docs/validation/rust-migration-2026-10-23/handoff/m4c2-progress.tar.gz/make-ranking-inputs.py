from pathlib import Path
from copy import deepcopy
import json,gzip
assembly=json.loads(Path('crates/ken-retrieval/tests/fixtures/piece-reference-assembly.json').read_bytes())['cases']
prototype={k:deepcopy(next(c['result']['pieces']for c in assembly if c['id']==k+'-descending'))for k in ['class','module','symbol','file']}
manifest=json.loads(Path('crates/ken-retrieval/resources/ranking/manifest.json').read_bytes());file=manifest['models']['piece']['file'];names=json.loads(gzip.decompress((Path('crates/ken-retrieval/resources/ranking')/file).read_bytes()))['features']
def forest(feature='native_rank',threshold=.75):return dict(schema=1,features=names,trees=[dict(feature=names.index(feature),threshold=threshold,left=dict(value=1.),right=dict(value=0.))])
base=dict(request=dict(query='Which class reads values?',piece_kind='class'),pieces=prototype['class'],stemmer='english',model=forest())
cases=[]
def add(name,kind='piece_features',data=None):
 d=deepcopy(data or base);cases.append(dict(id=name,kind=kind,input=d));return d
def relocate(p,path):
 p=deepcopy(p);p['path']=path
 if p['entity']:p['entity']['path']=path
 for m in p['members']:
  m['entity']['path']=path;m['fields']['path']=path
  for passage in m['passages']:passage['entity']['path']=path;passage['fields']['path']=path
 for m in p['matches']:
  m['entity']['path']=path
  for passage in m['evidence']:passage['entity']['path']=path;passage['fields']['path']=path
 return p
for kind in prototype:
 pieces=prototype[kind]
 if len(pieces)==1:pieces=[*pieces,relocate(pieces[0],'other/engine.py')]
 for mode in ['features','rank']:
  for purpose in ['auto','implementation','usage','tests','documentation']:
   d=add(kind+'-'+mode+'-'+purpose,'piece_features'if mode=='features'else'piece_rank');d['pieces']=deepcopy(pieces);d['request']=dict(query='Find code that reads values',piece_kind=kind,purpose=purpose)
 d=add(kind+'-empty');d['pieces']=[];d['request']['piece_kind']=kind
for expanded in [None,'','persist durable read values','   ']:
 d=add('expanded-'+str(expanded));d['expanded']=expanded
d=add('identity-stems');d['stemmer']='identity'
d=add('inferred-kind');d['request'].pop('piece_kind')
d=add('wrong-request-kind');d['request']['piece_kind']='module'
d=add('incompatible-model','piece_rank');d['model']=dict(schema=1,features=['wrong'],trees=[dict(value=0.)])
d=add('stable-ties','piece_rank');d['model']=dict(schema=1,features=names,trees=[dict(value=0.)])
d=add('exact-priority','piece_rank');d['pieces'][0]['matches'][0]['signals']['exact']=1.
d=add('named-path-priority','piece_rank');d['pieces']=[deepcopy(prototype['file'][0]),relocate(prototype['file'][0],'other/engine.py')];d['request']=dict(query='Find src/pkg/engine.py and show its declaration.',piece_kind='file')
for label,scores in [('unsorted',[1.,4.,2.]),('negative',[-4.,-2.,-3.]),('cancel',[1e16,1.,-1e16]),('near-cancel',[1e16,1e-20,-1e16]),('overflow',[1.7976931348623157e308,1.7976931348623157e308,-1.7976931348623157e308])]:
 for mode in ['piece_features','piece_rank']:
  d=add('top3-'+label+'-'+mode,mode);d['pieces']=[deepcopy(prototype['file'][0])];d['request']['piece_kind']='file';d['model']=forest('member_score_mean3',.1)
  d['pieces'][0]['matches']=d['pieces'][0]['matches'][:3]
  for m,score in zip(d['pieces'][0]['matches'],scores,strict=True):m['score']=score
d=add('duplicate-piece-proposals','piece_rank');d['pieces']=[d['pieces'][0],deepcopy(d['pieces'][0])]
for path in ['tests/engine.py','typing_tests/a.py','specs/a.py','data/config.json','settings/config.toml','data/config.JSON']:
 d=add('path-'+path.replace('/','-'));d['pieces']=[relocate(prototype['file'][0],path)];d['request']['piece_kind']='file'
for query in ['readValue cliente á 😀','read\ud800value','persist authentication cookies','Which test checks invalid input?']:
 d=add('query-'+str(len(cases)));d['request']['query']=query
for kind in ['class','module','file','symbol']:
 for query in ['read values','persist durable cookie']:
  d=add('production-'+kind+'-'+str(len(cases)),'piece_rank');d['production']=True;d.pop('model');d['pieces']=deepcopy(prototype[kind]);d['request']=dict(query=query,piece_kind=kind)
Path('crates/ken-retrieval/tests/fixtures/piece-inputs-ranking.json').write_text(json.dumps(dict(cases=cases),ensure_ascii=True,allow_nan=False)+'\n')
print(len(cases),'ranking cases')
