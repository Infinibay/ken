from pathlib import Path
from copy import deepcopy
import json
catalog=json.loads(Path('crates/ken-retrieval/tests/fixtures/piece-inputs-catalog.json').read_bytes())['cases'][0]['input']
def matches(order=(2,3,4,0),scores=(4.,3.,2.,1.)):
 return [dict(entity=deepcopy(catalog['owners'][i]['key']),score=score,evidence=deepcopy(catalog['owners'][i]['passages']),source_hash=catalog['owners'][i]['passages'][0]['source_hash'],signals={'rrf':.1},owned_regions=[])for i,score in zip(order,scores,strict=True)]
base=dict(catalog=catalog,matches=matches(),piece_kind='class',limit=10);cases=[]
def add(name,kind='assemble',data=None):
 d=deepcopy(data or base);cases.append(dict(id=name,kind=kind,input=d));return d
for kind in ['class','module','symbol','file']:
 for label,scores in [('descending',(4.,3.,2.,1.)),('ascending',(1.,2.,3.,4.)),('ties',(0.,0.,0.,0.)),('negative',(-1.,-2.,-3.,-4.))]:
  d=add(kind+'-'+label);d['piece_kind']=kind;d['matches']=matches(scores=scores)
 d=add(kind+'-empty');d['piece_kind']=kind;d['matches']=[]
for limit in [0,1,2]:d=add('limit-'+str(limit));d['limit']=limit
d=add('unknown-kind');d['piece_kind']='other'
d=add('duplicate-support');d['matches'].append(deepcopy(d['matches'][0]))
d=add('partial-retrieval');d['matches'][0]['evidence'][0]['span']['end_line']=4;d['matches'][0]['evidence'][0]['fields']['body']='partial'
d=add('exact-signal');d['matches'][0]['signals']['exact']=1.
d=add('mixed-version');d['matches'][0]['source_hash']='0'*64
for mode in ['foreign-evidence','stale-evidence','empty-evidence']:
 d=add(mode,kind='assembly_admission')
 if mode=='foreign-evidence':d['matches'][0]['evidence'][0]['entity']=d['matches'][-1]['entity']
 elif mode=='stale-evidence':d['matches'][0]['evidence'][0]['source_hash']='0'*64
 else:d['matches'][0]['evidence']=[]
for label,kind,member_indices,entity_index in [('class','class',[1,2],1),('symbol','symbol',[4],4),('file','file',[0,1,2,3,4],None),('module','module',[0,1,2,3,4],None)]:
 d=add('constructor-'+label,kind='piece_constructor');d['matches']=matches((2,),(1.,))if label=='class'else matches((4,),(1.,));d['direct']=dict(kind=kind,path=catalog['owners'][0]['key']['path'],entity=deepcopy(catalog['owners'][entity_index]['key'])if entity_index is not None else None,members=member_indices)
direct=deepcopy(next(c['input']for c in cases if c['id']=='constructor-class'))
for mode in ['unknown-kind','empty-members','empty-matches','identity-kind','duplicate-members','wrong-path','mixed-version','missing-declaration','outside-member','outside-match']:
 d=add('constructor-'+mode,kind='piece_constructor',data=direct);p=d['direct']
 if mode=='unknown-kind':p['kind']='other'
 elif mode=='empty-members':p['members']=[]
 elif mode=='empty-matches':d['matches']=[]
 elif mode=='identity-kind':p['entity']=None
 elif mode=='duplicate-members':p['members']=[1,1]
 elif mode=='wrong-path':p['path']='elsewhere.py'
 elif mode=='mixed-version':p['overrides']={'0':{'source_hash':'0'*64}}
 elif mode=='missing-declaration':p['members']=[2]
 elif mode=='outside-member':p['members']=[1,4]
 else:d['matches']=matches((4,),(1.,))
Path('crates/ken-retrieval/tests/fixtures/piece-inputs-assembly.json').write_text(json.dumps(dict(cases=cases),ensure_ascii=True)+'\n')
print(len(cases),'assembly cases')
