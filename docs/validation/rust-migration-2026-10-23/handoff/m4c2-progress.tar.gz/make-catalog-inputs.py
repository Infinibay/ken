from pathlib import Path
from copy import deepcopy
import hashlib,json
path='src/pkg/engine.py'
text='class Outer:\n    value = 1\n    class Inner:\n        def run(self):\n            return 1\n    def read(self):\n        return self.value\ndef helper():\n    return 2\n'
def key(name,kind='function',ordinal=0):return dict(path=path,kind=kind,qualname=name,owner=name.rpartition('.')[0]or None,definition_ordinal=ordinal)
def owner(name,kind,a,b,end=None):
 k=key(name,kind);return dict(key=k,passages=[dict(entity=k,span=dict(start_line=a,end_line=b),entity_span=dict(start_line=a,end_line=end or b),fields=dict(identity=name,signature='',documentation='',body='\n'.join(text.splitlines()[a-1:b]),path=path),source_hash='',language='python',role='definition',split_reason=None,signals={},implementation_start_line=None)])
base=dict(files={path:list(text.encode())},owners=[owner('Outer','class',1,2,7),owner('Outer.Inner','class',3,3,5),owner('Outer.Inner.run','method',4,5),owner('Outer.read','method',6,7),owner('helper','function',8,9)])
cases=[]
def add(name,data=None,kind='catalog'):
 data=deepcopy(data or base)
 for o in data['owners']:
  source=bytes(data['files'][o['key']['path']])
  for p in o['passages']:p['source_hash']=hashlib.sha256(source).hexdigest()
 cases.append(dict(id=name,kind=kind,input=data));return cases[-1]['input']
add('nested')
d=add('reverse-insertion');d['owners'].reverse()
d=add('only-helper');d['owners']=d['owners'][-1:]
d=add('empty-catalog');d['owners']=[]
d=add('uncovered-nonblank');d['owners'][0]['passages'][0]['span']['end_line']=1
d=deepcopy(base);d['files'][path]=list(text.replace('    value = 1','    ').encode());d=add('uncovered-blank',d);d['owners'][0]['passages'][0]['span']['end_line']=1
d=add('adjacent-chunks');p=d['owners'][-1]['passages'][0];p['span']['end_line']=8;q=deepcopy(p);q['span']=dict(start_line=9,end_line=9);d['owners'][-1]['passages'].append(q)
d=add('overlap-duplicate');d['owners'][-1]['passages']*=2
d=add('implementation-trim');d['owners'][-1]['passages'][0]['implementation_start_line']=9
d=add('implementation-empty');d['owners'][-1]['passages'][0]['implementation_start_line']=10
d=add('ambiguous-class');q=deepcopy(d['owners'][0]);q['key']['definition_ordinal']=1;q['passages'][0]['entity']=q['key'];d['owners'].append(q)
d=add('callable-containment');d['owners'][0]['key']['kind']='function';d['owners'][0]['passages'][0]['entity']=d['owners'][0]['key']
d=add('ambiguous-callable');d['owners'][0]['key']['kind']='function';d['owners'][0]['passages'][0]['entity']=d['owners'][0]['key'];q=deepcopy(d['owners'][0]);q['key']['definition_ordinal']=1;q['passages'][0]['entity']=q['key'];d['owners'].append(q)
for name,kind in [('ctor','constructor'),('dtor','destructor'),('constant','constant'),('const','const'),('interface','interface'),('module','module')]:
 d=add(name);d['owners'][-1]['key']['kind']=kind;d['owners'][-1]['passages'][0]['entity']=d['owners'][-1]['key']
for name,separator in [('crlf','\r\n'),('cr','\r'),('unicode-lines','\u2028'),('controls','\x0b'),('paragraphs','\u2029')]:
 d=deepcopy(base);d['files'][path]=list(text.replace('\n',separator).encode());add(name,d)
d=deepcopy(base);d['files'][path]=list((text+'\n\n').encode());add('trailing-blank-lines',d)
d=deepcopy(base);d['files'][path]=list(text.replace('return 2','return "á😀"').encode());add('unicode-source',d)
for newpath in ['src/pkg/__init__.py','src/Settings.java','src/pkg/engine.ts','vendor/pkg/engine.js']:
 d=deepcopy(base);d['files'][newpath]=d['files'].pop(path)
 for o in d['owners']:
  o['key']['path']=newpath
  for p in o['passages']:p['entity']=o['key'];p['fields']['path']=newpath
 add('path-'+newpath.replace('/','-'),d)
d=add('empty-owner');d['owners'][0]['passages']=[]
d=add('stale-version');d['owners'][0]['passages'][0]['source_hash']='0'*64
d=add('foreign-owner',kind='catalog_admission');d['owners'][0]['passages'][0]['entity']=d['owners'][-1]['key']
d=add('extent-outside-source',kind='catalog_admission');d['owners'][0]['passages'][0]['entity_span']['end_line']=100
d=add('range-outside-source',kind='catalog_admission');d['owners'][-1]['passages'][0]['span']['end_line']=100
d=deepcopy(base);d['files'][path]=[255];add('invalid-utf8',d)
d=add('internal-symlink');d['files']['real.py']=d['files'].pop(path);d['symlinks']=[dict(path=path,target='../../real.py')]
d=add('outside-symlink');d['files']['../outside.py']=d['files'].pop(path);d['symlinks']=[dict(path=path,target='../../../outside.py')]
Path('crates/ken-retrieval/tests/fixtures/piece-inputs-catalog.json').write_text(json.dumps(dict(cases=cases),ensure_ascii=True)+'\n')
print(len(cases),'catalog cases')
