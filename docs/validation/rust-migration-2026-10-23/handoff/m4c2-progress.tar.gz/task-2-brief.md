### Task 2: Generation-bound complete piece assembly

**Files:** Create piece_candidates.rs; tests/piece_candidates.rs; extend new reference family.

**Interfaces:** PieceCandidate::new(kind,path,entity,members:Vec<Arc<OwnerDescription>>,matches:Vec<CodeMatch>)->Result<Self>, declaration()->Option<&OwnerDescription>; immutable member/match access. PieceAssembler::new(Arc<SourceCatalog>), assemble(&mut self,matches:&[CodeMatch],kind:&str,limit:usize)->Result<Vec<PieceCandidate>>. Cache is private and tied to this catalog; callers cannot inject another generation.

- [ ] Capture tests/retrieval/test_piece_candidates.py and piece-admission observations once/host, including constructor/destructor source extraction, nested class membership, limits1/10/invalid0, stable unsorted support and malformed source/version/owner/member identities.
- [ ] Write complete_piece_membership_and_generation_cache: assert Inner pieces contain Inner/run, Outer pieces contain Outer/Inner/read, files/modules all owners, symbols one, all canonical support passages, stable score ties and Arc reuse on repeated assembly. New catalog must not reuse old descriptions. Run piece_candidates test; Expected absent API RED.
- [ ] Implement typed immutable membership validation and catalog-owned description reuse using describe_owner. Validate every retrieved match/evidence against catalog identity/version before encoding; no caller-controlled cache. Group in proposal order and sort support stably by score.
- [ ] Run source_catalog/piece_candidates/description and affected selection roots plus tooling/fmt/clippy both hosts; Expected PASS. Commit/push `feat(retrieval): assemble complete requested pieces with catalog-owned reuse`.

