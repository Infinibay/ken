### Task 1: Confined physical source and canonical catalog

**Files:** Create source_snapshot.rs,source_catalog.rs; tests/source_catalog.rs and catalog fixtures; piece_reference.py. Modify Cargo.toml/lock for ken-core and lib.rs exports.

**Interfaces:** SourceAuthority::new(&ProjectPaths)->Result<Self>, read(path:&str)->Result<SourceSnapshot>; SourceSnapshot owns hash/lines and verifies a required hash. SourceCatalog::new(Arc<SourceAuthority>,Vec<(EntityKey,Vec<Passage>)>)->Result<Self>; extent(&EntityKey),encloses(outer,inner),scope_members(key),enclosing_callable(key),owned_ranges(key,implementation),source_inventory(),primary(key,kind). Expose immutable accessors for owners/by_path/snapshots/classes and source authority; preserve input order with Vec plus identity lookup. PieceIdentity is typed Entity(EntityKey) or Path(String).

- [ ] Capture catalog observations and tests/retrieval/test_piece_catalog.py once per host. Add nested/ambiguous extents, uncovered nonblank scope, merged/gapped owned ranges, module-name policy, empty/mixed/foreign/stale owners, invalid ranges, UTF8/CRLF/Unicode splitlines and confined symlink cases. Capture unsafe-original outcomes explicitly.
- [ ] Write public original-corpus test and source_catalog_confines_current_bytes_and_preserves_owner_gaps: assert nearest Inner for Inner.run, Outer for Outer.read, complete descendants, exact source_inventory, stale/outside rejection and no child borrowing. Run `cargo test --locked --offline -p ken-retrieval --test source_catalog`; Expected missing-API RED.
- [ ] Implement SourceAuthority using accepted SourceFileReader, strict UTF8/Python splitlines, and immutable ordered SourceCatalog. Validate owner/hash/range admission before containment; reuse source_locator::module_name and merge_spans. No alternative unsafe reader or copied module policy.
- [ ] Run all catalog tests, original-capture tooling and directly affected core/source/retrieval suites on both hosts; Expected PASS, fmt/clippy. Commit/push `feat(retrieval): authenticate physical sources and canonical piece catalogs`.

