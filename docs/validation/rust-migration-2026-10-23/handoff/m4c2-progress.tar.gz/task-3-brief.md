### Task 3: Requested-piece feature schema and production forest ranking

**Files:** Create piece_features.rs,piece_ranking.rs; tests/piece_ranking.rs; extend original input families.

**Interfaces:** piece_features(request,&[PieceCandidate],&dyn WordEncoder,&dyn WordStemmer,Option<&PythonText>)->Result<FeatureMatrix>; piece_feature_names()->Vec<PythonText>. PieceReranker::new(Arc<NumericRanker>,Rc<dyn WordEncoder>,Arc<dyn WordStemmer>)->Result<Self>; rank(request,pieces,expanded)->Result<Vec<PieceMatch>>; PieceMatch owns piece and score.

- [ ] Capture tests/retrieval/test_piece_ranking.py once/host and full262column/call observations for four kinds, request-purpose overrides, missing declarations, unsorted/equal/negative priors, empty/mismatched kinds, duplicate/shared fields, expansion fallback and actual registered forest composition. Reuse M4c1 resources; capture actual branch/leaf digests for production inputs.
- [ ] Write piece_feature_columns_calls_and_stable_order: full schema/matrix equality at declared bound, first-proposal relative prior, original/expanded/declaration pass calls, finite cutoff examples, path/exact/stable priorities and zero optional calls for symbols. Test real1280tree score/order/path identity. Run piece_ranking test; Expected missing API RED.
- [ ] Implement documents with explicit original field order and accepted code_terms/coverage. Keep projection separate from rank coordination; use authoritative schema, accepted forest loader and stable tie handling. Do not duplicate numeric prediction or stemming.
- [ ] Run pieces/features/coverage/alignment/numeric/rank_models and affected complete suites/tooling/fmt/clippy both hosts; Expected PASS. Commit/push `feat(retrieval): rank complete source pieces with the registered forest`.

