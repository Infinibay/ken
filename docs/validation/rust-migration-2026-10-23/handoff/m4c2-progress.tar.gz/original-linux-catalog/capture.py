
import hashlib,importlib,json,pathlib,platform,sys,tempfile,unicodedata
import pytest
request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root'])
from ken.retrieval.model import EntityKey,Passage,Span
from ken.retrieval.piece_catalog import SourceCatalog,entity_id
if not pathlib.Path(importlib.import_module('ken.retrieval.piece_catalog').__file__).resolve().is_relative_to(root.resolve()):raise ValueError('wrong original piece catalog')
def passage(v):return Passage(**{**v,'entity':EntityKey(**v['entity']),'span':Span(**v['span']),'entity_span':Span(**v['entity_span'])})
records=[]
for case in request['cases']:
 data=case['input']
 with tempfile.TemporaryDirectory(prefix='ken-original-piece-')as temporary:
  base=pathlib.Path(temporary);project=base/'project';project.mkdir()
  for name,content in data['files'].items():
   p=project/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(bytes(content))
  for link in data.get('symlinks',[]):
   p=project/link['path'];p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(link['target'])
  try:
   catalog=SourceCatalog(project,{EntityKey(**o['key']):[passage(p)for p in o['passages']]for o in data['owners']})
   projections=[]
   for key in catalog.owners:
    scopes=catalog.scope_members(key);enclosing=catalog.enclosing_callable(key)
    primaries={}
    for kind in ['class','module','symbol','file']:
     value=catalog.primary(key,kind);primaries[kind]=entity_id(value)if isinstance(value,EntityKey)else value
    projections.append(dict(identity=entity_id(key),extent=catalog.extent(key),owned_ranges=catalog.owned_ranges(key),implementation_ranges=catalog.owned_ranges(key,implementation=True),scope_members=[entity_id(k)for k in scopes]if scopes is not None else None,enclosing_callable=entity_id(enclosing)if enclosing else None,primary=primaries))
   records.append(dict(**case,result=dict(inventory=catalog.source_inventory(),projections=projections,lines=catalog.lines,hashes=catalog.hashes)))
  except Exception as error:records.append(dict(**case,error=dict(type=type(error).__name__,message=str(error).replace(str(project),'{project}').replace(str(base),'{scenario}'))))
discovered=[];states=[]
class Plugin:
 def pytest_collection_finish(self,session):discovered.extend(i.nodeid for i in session.items)
 def pytest_runtest_logreport(self,report):
  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q',*request['suite'],'--junitxml='+request['junit']],plugins=[Plugin()])
value=dict(format='ken-piece-reference/1',family=request['family'],cases=records,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version(),unicode=unicodedata.unidata_version),discovered=discovered,test_states=states,original_test_exit=exit_code)
pathlib.Path(request['result']).write_text(json.dumps(value,ensure_ascii=True,allow_nan=False)+'\n');sys.exit(exit_code)
