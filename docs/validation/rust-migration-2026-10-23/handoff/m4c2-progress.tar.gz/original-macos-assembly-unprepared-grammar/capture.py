
import hashlib,importlib,json,pathlib,platform,sys,tempfile,unicodedata
import pytest
request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root'])
from ken.retrieval.model import EntityKey,Passage,Span
from ken.retrieval.piece_catalog import SourceCatalog,entity_id
if not pathlib.Path(importlib.import_module('ken.retrieval.piece_catalog').__file__).resolve().is_relative_to(root.resolve()):raise ValueError('wrong original piece catalog')
def passage(v):return Passage(**{**v,'entity':EntityKey(**v['entity']),'span':Span(**v['span']),'entity_span':Span(**v['entity_span'])})

import dataclasses
from ken.retrieval.model import CodeMatch
from ken.retrieval.description import describe_owner
from ken.retrieval.piece_candidates import assemble_pieces
from ken.retrieval.piece_ranking import PieceCandidate
def match(v):return CodeMatch(EntityKey(**v['entity']),v['score'],[passage(p)for p in v['evidence']],v['source_hash'],v.get('signals',{}),tuple(Span(**s)for s in v.get('owned_regions',[])))
def clean(v):
 if dataclasses.is_dataclass(v):return clean(dataclasses.asdict(v))
 if isinstance(v,dict):return{k:clean(x)for k,x in v.items()}
 if isinstance(v,(list,tuple)):return[clean(x)for x in v]
 return v
records=[]
for case in request['cases']:
 data=case['input'];physical=data['catalog']
 with tempfile.TemporaryDirectory(prefix='ken-original-piece-')as temporary:
  base=pathlib.Path(temporary);project=base/'project';project.mkdir()
  for name,content in physical['files'].items():
   p=project/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(bytes(content))
  try:
   catalog=SourceCatalog(project,{EntityKey(**o['key']):[passage(p)for p in o['passages']]for o in physical['owners']})
   matches=[match(v)for v in data['matches']]
   if case['kind']=='piece_constructor':
    direct=data['direct'];members=[describe_owner(catalog.owners[list(catalog.owners)[i]])for i in direct['members']]
    for index,updates in direct.get('overrides',{}).items():
     members[int(index)]=dataclasses.replace(members[int(index)],**{k:EntityKey(**v)if k=='entity'else v for k,v in updates.items()})
    p=PieceCandidate(direct['kind'],direct['path'],EntityKey(**direct['entity'])if direct.get('entity')else None,tuple(members),tuple(matches))
    result=dict(piece=p,declaration=p.declaration)
   else:
    descriptions={};pieces=assemble_pieces(matches,data['piece_kind'],catalog,descriptions,limit=data.get('limit',10))
    again=assemble_pieces(matches,data['piece_kind'],catalog,descriptions,limit=data.get('limit',10))
    result=dict(pieces=pieces,declarations=[p.declaration for p in pieces],cache_size=len(descriptions),reused=all(a is b for p,q in zip(pieces,again,strict=True)for a,b in zip(p.members,q.members,strict=True)),unchanged=clean(matches)==data['matches'])
   records.append(dict(**case,result=clean(result)))
  except Exception as error:records.append(dict(**case,error=dict(type=type(error).__name__,message=str(error).replace(str(project),'{project}').replace(str(base),'{scenario}'))))
discovered=[];states=[]
class Plugin:
 def pytest_collection_finish(self,session):discovered.extend(i.nodeid for i in session.items)
 def pytest_runtest_logreport(self,report):
  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q',*request['suite'],'--junitxml='+request['junit']],plugins=[Plugin()])
value=dict(format='ken-piece-reference/1',family=request['family'],cases=records,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version(),unicode=unicodedata.unidata_version),discovered=discovered,test_states=states,original_test_exit=exit_code)
pathlib.Path(request['result']).write_text(json.dumps(value,ensure_ascii=True,allow_nan=False)+'\n');sys.exit(exit_code)
