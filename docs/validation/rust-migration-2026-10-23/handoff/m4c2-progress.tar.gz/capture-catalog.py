from pathlib import Path
import shutil
from tools.rust_migration.reference import Reference
from tools.rust_migration.piece_reference import capture
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-23-rust-source-pieces';r=Reference.load(Path('/app/.ken/rust-migration/m2-optional/reference-final-t9'));v=capture(r,w/'original-linux-catalog');shutil.copy2(w/'original-linux-catalog/reference.json',root/'crates/ken-retrieval/tests/fixtures/piece-reference-catalog-linux.json');print('original cases',len(v['cases']),'roots',len(v['discovered']),flush=True)
