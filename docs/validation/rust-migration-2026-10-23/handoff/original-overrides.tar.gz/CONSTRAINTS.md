# Restricciones de calidad

## Autorización vigente — 16 de octubre

El usuario pide por defecto la mejor configuración completa medida en CLI y MCP,
además de presentación compacta y ejemplos de todos los outputs. Autoriza integrar
el default; se mantienen >=90% top1 de pieza, top10 nativo197/200 y recursos CPU/RAM,
validación del camino público real y compatibilidad de índices. No release ni tags.
La prohibición de promoción de secciones históricas deja de impedir esta integración;
los resultados sellados conservan sus políticas y no certifican automáticamente
el nuevo default. Ver docs/design/best-default-search-2026-10-16.md.

## Aclaración vigente del usuario — 15 de octubre

El usuario retiró el requisito de suficiencia del contexto retornado como condición
del acierto: exige >=90% de **pieza solicitada correcta en top1** (clase, módulo,
símbolo o archivo). La suficiencia se informa por separado. Las definiciones y
resultados históricos de los protocolos sellados no se reescriben. Se mantiene
Recall10>=95%; en las200 consultas actuales se preservará además la pertenencia
del top10 nativo (197/200), con cambios de orden dentro de esa lista. Se medirán
tiempo completo y pico RSS en CPU, sin depender de GPU ni modelos pesados.
Las reservas privadas permanecen cerradas mientras se ajusta en desarrollo.

Las secciones siguientes documentan contratos históricos; esta aclaración prevalece
en la métrica primaria del trabajo actual y no certifica un resultado alcanzado.

2026-10-14. Alcance numérico: mejora del engine de búsqueda descrita en [el diseño](docs/superpowers/specs/2026-10-14-search-engine-top1-design.md). Estado: contrato aprobado por el usuario; verificadores y motor en implementación. Este documento no certifica que Ken alcance actualmente sus objetivos.

## Piso de trabajo

- No añadir supresiones de tipado/lint, stubs sin implementar, secretos, tests omitidos ni aserciones debilitadas para conseguir un resultado verde.
- Una modificación deliberada de contrato requiere explicar y probar el contrato nuevo; no eliminar pruebas de compatibilidad sin revisar sus consumidores.
- Preservar cambios anteriores del usuario. No reset, stash ni commits ajenos al trabajo propio.
- No cambiar referencias, denominadores, exclusiones, presupuesto de salida o umbrales después de inspeccionar aceptación para declarar éxito.
- Mantener procesamiento local de consultas y código. Las descargas de modelos/dependencias no autorizan enviar código a servicios externos.

## Aceptación de búsqueda

El usuario exige **top‑1 mínimo 90% y archivo más función o fragmento correctos**. El diseño aprobado lo concreta con evidencia visible:

| Dimensión | Condición | Verificador previsto | Estado |
|---|---|---|---|
| Calidad primaria | `strict_top1 >= 0.90` global y macro por repositorio | `ken bench --engine retrieval --gate ...` | Verificador implementado; aceptación pendiente |
| Preguntas difíciles y multilingües | `strict_top1 >= 0.90` en comportamiento, EN y ES | Mismo gate con estratos congelados | Verificadores y curación congelados; aceptación pendiente |
| Identidad determinista | 100% de los casos de identificador único calificado | Suite de lookup y regresión | 48/48 en slice anterior; repetir con el perfil final |
| Reserva | 300 positivos en 12 repositorios nuevos; 60 negativos separados | Manifiesto y registro de uso | Curada y congelada independientemente; sin usar |
| Evidencia | Hash y rangos fieles; errores/abstenciones positivas cuentan como fallos | Scorer y pruebas de presentación/frescura | Implementados; validar perfil final |
| Rendimiento aprobado | Referencia aproximada de 1 s por cada 100 archivos indexables del repositorio, para la respuesta completa; CPU y RAM contenida, sin necesitar GPU | Medición reproducible del perfil público final, p50/p95/máximo y pico de RAM en el equipo del usuario | Pendiente |

`candidate_recall@100 >= 0.98` es un checkpoint diagnóstico de desarrollo, no un reemplazo del 90% en primer lugar. El usuario reemplazó los 500 ms iniciales por 3–5 segundos y luego precisó una referencia escalable de aproximadamente 1 segundo por cada 100 archivos del repositorio para obtener la respuesta final. Se informan los archivos indexables reales según la política de exclusiones existente (sin inflar el denominador con archivos ignorados), p50/p95/máximo del tiempo de respuesta completa y pico de RAM. CPU y bajo consumo de RAM son las condiciones esenciales; no hay un límite numérico de RAM pactado. Las pruebas históricas con modelos pesados/GPU no transfieren calidad al perfil de CPU. Se informan también arranque, indexación y memoria; la indexación se mide aparte de la consulta con índice preparado. No se añade cobertura porcentual global ni un linter nuevo para esta tarea.

## Uso de los gates

Las 60 preguntas anteriores sirven para desarrollo/regresión, nunca como única certificación. Cambios del scorer o de etiquetas deben quedar versionados con motivo y comparación histórica; no se reescribe el resultado anterior. La reserva sólo se usa cuando fuente, perfil y modelos están congelados. Tras inspeccionar sus fallos deja de ser reserva.

La promoción predeterminada exige recibo del gate, compatibilidad y revisión. Hasta entonces se informa avance y métricas observadas, sin declarar alcanzado el 90%. Una falla bloquea la promoción; no autoriza a bajar el umbral.

## Criterio vigente de pieza verificable, 15 de octubre

El usuario precisó después que la respuesta debe identificar la pieza solicitada
(clase, módulo, símbolo o archivo) y permitir verificar sus requisitos en el
contexto devuelto. El protocolo `experiments/search-engine/cpu-verifiable-pieces-v98.md`
concreta ese criterio: identidad correcta y juicio ciego de relevancia/suficiencia
completo, con citas literales para todas las facetas. Encontrar la identidad sola
no satisface el 90%. Se mantiene además identidad top‑10 de al menos 95%, sin
excluir errores, faltantes o abstenciones del denominador positivo.

Las 200 consultas descriptivas de desarrollo no sustituyen aceptación privada.
La reserva nueva v104 la curan los dos revisores autorizados, sin exposición al
implementador antes de congelar el motor; no se abre la reserva antigua para
ajustar resultados. Los presupuestos vigentes por tarjeta son 64 líneas físicas,
4 citas y 12000 caracteres canónicos. No se amplían para hacer pasar casos.

CPU es el mínimo obligatorio; una GPU/acelerador puede aprovecharse si está
disponible y es más rápido con salida válida. No se requiere hardware potente.
Se conserva la referencia aproximada de tiempo por cantidad de archivos y se
miden tiempo completo, arranque, indexación y RAM por separado. Una mejora de
ranking sin contexto suficiente o con gasto inaceptable no cumple el objetivo.

## Latencia de consultas KQL2

Contrato inicial confirmado por el usuario el 2026-10-14: una consulta pequeña debía tardar **como máximo 10 ms en total** en un proyecto mediano de **500 archivos de código**, con el índice ya preparado y actualizado. El motivo es la composición de consultas anidadas. La preparación inicial ocurre antes de la medición.

**Ajuste posterior autorizado expresamente por el usuario:** «no importa que sean unos pocos los que quedan fuera del limite si la gran mayoria esta dentro». El objetivo vigente es que la gran mayoría de consultas simples quede dentro de 10 ms, admitiendo unas pocas excedencias. No se acordó un percentil mínimo nuevo; se informan proporción, percentiles, máximos y respuestas incompletas sin eliminar muestras. Los verificadores históricos conservan su criterio estricto y sus resultados originales.

**Aclaración explícita del usuario, 2026-10-14:** «10ms no es para consultas
anidadas, sino para consultas simples. Justamente para que las anidadas esten
por debajo de los 2 segundos».

| Consulta | Objetivo vigente con índice preparado |
| --- | --- |
| Simple | 10 ms para la gran mayoría, con unas pocas excedencias aceptadas |
| Anidada | Menos de 2000 ms para la consulta completa |

El objetivo de las operaciones simples permite componerlas dentro del presupuesto
de la consulta anidada. No se aplica un límite global de 10 ms a toda composición.
Guardar una consulta o invocar un pattern no convierte automáticamente una pregunta
simple en compleja: la clasificación debe corresponder al trabajo que compone.
Las nuevas matrices deben declarar esa clasificación y el presupuesto antes de
medir. Esta aclaración no modifica las muestras ni los criterios de los recibos
históricos; su comparación con 10 ms se conserva como diagnóstico.

**Matiz posterior autorizado por el usuario, 2026-10-14:** si una consulta es muy
compleja o tiene muchas anidaciones, acepta algo más de tiempo, siempre razonable
para esa consulta. No se acordó un techo numérico adicional. Se mantiene `<2000 ms`
como referencia para las anidadas habituales; las muy complejas se identifican
antes de medir y se informa su tiempo, profundidad y trabajo, sin inventar un SLA
ni convertir automáticamente cualquier excedencia en un éxito.

- El cronómetro va desde la entrada de la consulta hasta la respuesta entregada por la API. Medir sólo operadores, omitir preparación que aún se repite dentro de la petición, o medir únicamente respuestas cacheadas no certifica este contrato.
- Se cuenta cada excedencia con el umbral de su clase: `10 ms` para simples y `<2000 ms` para la consulta anidada completa. Las consultas deben conservar resultados, evidencia, incertidumbre y consistencia del snapshot; un timeout explícito se informa como incompleto, nunca como un resultado completo correcto. El presupuesto `timeout_ms` sigue siendo opcional y mantiene el valor pedido por el llamador; estos objetivos no lo cambian automáticamente.
- La matriz debe incluir consultas pequeñas distintas y consultas anidadas, evaluadas por separado con sus presupuestos respectivos. Su conjunto definitivo y la muestra representativa se fijan antes de aceptar una implementación; el corpus diagnóstico de 500 archivos y sus predicados anidados no certifican todas las consultas.
- Un cambio de SQLite es admisible para una parte del motor si la medición lo justifica. No se elige almacenamiento antes de localizar el coste dominante.

Ampliación CLI/MCP confirmada en esta sesión: el reloj incluye transporte local.
El arranque de un proceso Python nuevo se mide aparte. Si el índice está
actualizándose, la consulta espera; los presupuestos aplican con el índice listo. No se
ocultan preparación ni espera: permanecen incluidas en el total y se desglosan.

Estado: requisito vigente. La API pública `QuerySession` está implementada y su matriz congelada de 420 consultas sobre 500 archivos pasó: máximo 5,223 ms hasta entregar JSON, sin caché de respuestas. El recibo y el alcance se registran en `docs/validation/kql2-performance-2026-10-14/IMPLEMENTATION.md` y `public-session.json`. Esta aceptación corresponde a la ruta preparada y al corpus medido; no certifica todas las consultas ni el máximo bajo cualquier carga. Una ejecución simultánea con tests excedió el límite y se conserva como fallo en `public-session-concurrent-tests.json`.

Verificador de la ruta preparada: `.venv/bin/python -m examples.bench.kql2_session /ruta/al/corpus-500 /ruta/al/recibo.json --manifest docs/validation/kql2-performance-2026-10-14/medium500.json`. Exige máximo <=10 ms, respuestas completas y valores esperados, con compilación y JSON incluidos. El corpus exacto y su reproducción están incluidos en el informe. La búsqueda de una llamada sin sesión conserva la captura de fuentes y no adquiere esta certificación.

Verificador diagnóstico disponible: `.venv/bin/python docs/validation/kql2-performance-2026-10-14/medium500.py --gate`. Para comprobar un recibo existente: el mismo script con `--check-report docs/validation/kql2-performance-2026-10-14/medium500.json`; devuelve exit 1 en el estado medido. No sustituye la futura matriz representativa de aceptación.

La integración automática CLI/MCP está implementada, con verificación de revisión
por eventos nativos cuando es posible y fallback íntegro por metadatos. Gate:
`.venv/bin/python -m examples.bench.kql2_frontends /ruta/al/corpus-500 /ruta/al/recibo.json --manifest docs/validation/kql2-performance-2026-10-14/medium500.json`.
Exige las mismas siete consultas, 30 textos/planes por caso, 420 por cada ruta,
sin caché de respuestas ni consultas incompletas; llega hasta stdout real en CLI
y hasta `ClientSession.call_tool` sobre stdio en MCP.

Estado de aceptación de entradas automáticas bajo el ajuste autorizado:
`frontends-final.json` registra **1257 de 1260 consultas dentro de 10 ms
(99,76 %)**. MCP tuvo 420 de 420 (máximo 7,040 ms); CLI KQL2 y tools CLI
tuvieron tres excedencias en conjunto. Sus p99 fueron 6,185 / 6,144 / 4,729 ms,
respectivamente. Dos peticiones terminaron incompletas por el presupuesto
explícito de 10 ms del ensayo; una excedencia entregó la respuesta completa.
Este resultado cumple la preferencia revisada de admitir unas pocas excedencias;
el recibo conserva `passed=false` para el criterio histórico de máximo estricto.
Todas las muestras y los ensayos fallidos se conservan en
`docs/validation/kql2-frontends-2026-10-14/`.

Ampliación del registro persistente KQL2: `named-frontends.json` en
`docs/validation/kql2-registry-2026-10-14/` registra **1440 de 1440 consultas
por nombre dentro de 10 ms**, correctas/completas y sin caché de respuestas,
sobre el mismo corpus congelado de 500 archivos. Incluye ocho casos, entre ellos
predicados anidados e imports transitivos de patterns, con planes nuevos y
reutilizados. Máximos: CLI 5,592 ms; tools CLI 6,998 ms; MCP 5,123 ms.
Se midió con índice y registro preparados y sin carga concurrente. El ensayo
no certifica todos los operadores, plataformas o escrituras concurrentes; no
cambia los umbrales ni sustituye los recibos históricos.
