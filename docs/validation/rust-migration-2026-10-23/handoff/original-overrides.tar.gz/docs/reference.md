# Ken reference

[Quickstart and benchmarks](../README.md) · Advanced configuration, integrations and tools.

## Why it works

ken is not only a code embedding index. It builds several local signals and ranks files by combining them:

- **Structural code index**: each file is hashed and parsed when possible. The AST parser extracts symbols, line ranges, imports, module docstrings, and symbol docstrings. Files that cannot be parsed are still tracked by path, mtime, and lightweight text intent when useful.
- **Semantic index**: ken embeds files, symbols, and explicit purpose text. File embeddings are based on language, filename, and top symbol names. Symbol embeddings include kind, name, and docstring. Docstrings are also stored as separate intent sources, so a prompt can find code by what it is for, not only by what it is named.
- **Live task memory**: hooks record local interactions in the project SQLite DB: prompts, reads, edits, writes, dismissals, and the files touched in each turn. Recent interactions are weighted more heavily, and useful patterns such as read-then-edit score higher than repeated reads with no follow-through.
- **Predictive memory**: at the end of a session, ken snapshots which files were productive for that task. Later, when a new prompt is semantically similar to a previous one, those files get a predictive boost.
- **Relationship boosts**: after the main channels rank candidates, ken applies conservative boosts for things like recently modified files, symbols pointing to their containing file, source/test counterparts, imports, and files that often co-occurred in past similar sessions.

The result is closer to a local project memory than a plain search tool. Raw text search can find exact strings. Embeddings can find semantic neighbors. AST indexing can find named symbols. ken combines all of that with how the assistant actually used the project over time. That is why results are often better after a few real sessions: the database accumulates project-specific evidence about which files matter for which kinds of tasks.

All of these signals stay local in `.ken/ken.db`. They are not sent to a any server.

## Benchmarks

The "why it works" section above is descriptive. This section is what we measured.

### Retrieval: ken vs alternatives on a real project

Same 54 questions, same index, four methods. Questions were hand-written so
the obvious keyword is rarely in the expected file — they look like
"how does the daemon know if another instance is already running" rather
than "find daemon.py". Each method returns its top 10 candidates and we
score whether any of the expected files appears in the top-K.

| | hit@1 | hit@5 | hit@10 | MRR | median latency |
|---|---:|---:|---:|---:|---:|
| **ken (`ken rank --json`)** | **0.241** | 0.389 | 0.389 | **0.295** | 153 ms |
| naive cosine over file embeddings | 0.185 | **0.426** | **0.481** | 0.291 | 291 ms |
| filesystem walk (read first chunk of each .py) | 0.185 | 0.370 | 0.444 | 0.266 | 368 ms |
| ripgrep lexical search, ranked by match count | 0.130 | 0.333 | 0.426 | 0.208 | 146 ms |

Project: this repo (`/Users/andres/Projects/ken`, 2 137 files indexed,
100 % embedding coverage, 362 sessions of recorded interactions).
Hardware: Apple M-series laptop, single-thread. Dataset and harness:
`output/benchmarks-2026-10/`.

**What this says, honestly:**

- **ken wins where it matters most — top-1 ranking.** The first file ken
  suggests is the correct one almost twice as often as `rg` (0.241 vs 0.130)
  and ~30 % more often than naive embeddings or filesystem walk. For an
  agent that opens the first suggestion, this is the only number that counts.
- **ken wins on MRR** (0.295), so when the first suggestion isn't right, the
  correct file is still closer to the top than under the alternatives.
- **Naive embeddings win on hit@10** (0.481 vs ken's 0.389). They surface
  more candidates that match semantically, but with worse ordering and twice
  the latency. The boost channels ken adds on top of embeddings trade some
  recall for precision.
- **Walk has the broadest coverage at top-10** but it is not free: it reads
  the first 8 KB of up to 50 candidate files, which is what an agent does
  by hand and is exactly the cost ken saves.
- **rg is fast and reliably *wrong* on intent queries.** When the file name
  has nothing to do with the question, lexical search returns nothing useful
  in the top.

**Limitations of this benchmark:**

- Single repo, single author. Project-specific signals (session memory,
  recent files, predictive boosts) favour this dataset; on a fresh project
  ken will look more like the naive embedding row.
- One seed; expect ±5 % variance on the small numbers.
- Dataset and harness are in the repo under `output/benchmarks-2026-10/` and
  can be re-run with `.venv/bin/python output/benchmarks-2026-10/run_benchmark.py`.

### Agent: Codex with ken vs without ken

Same ten questions, two conditions per question. In the `codex-ken`
condition the agent has the full ken CLI in PATH (`ken rank`, `ken find`,
`ken read`, …) and a `ken install --codex` hook wiring in its project copy.
In the `codex-no-ken` condition `AGENTS.md` is stripped, no MCP server is
registered, and the agent has only `rg`, `ls`, `cat`, `find`. Same model,
same prompt, same timeout (240 s), one run per cell.

The grading is whether the path the agent names in its final `ANSWER:`
line appears in the question's `expected_files`. The agent receives the
question and the format, never the expected answer.

| condition | n | hit@1 | hit@3 | hit@5 | median elapsed |
|---|---:|---:|---:|---:|---:|
| codex-ken | 10 | **0.10** | **0.10** | **0.10** | 36.5 s |
| codex-no-ken | 10 | 0.00 | 0.00 | 0.00 | 36.5 s |

Model: `gpt-reserve` (the only Codex CLI model that this environment's
ChatGPT authentication accepts; `gpt-5`, `gpt-4o-mini`,
`deepseek-v4.1-flash`, and the older `gpt-6-astra` documented in
[`docs/codex-ken-benchmark-2026-09-07.md`](../docs/codex-ken-benchmark-2026-09-07.md)
all return HTTP 400). Dataset and harness: `output/benchmarks-2026-10/agent-bench/`.

**What this says, honestly:**

- The delta goes in ken's direction (1/10 vs 0/10) but **n=10 with a single
  a-cell hit is not a measurement of effect**. Treat it as "ken did not
  hurt and the one case where ken scored correctly was a non-trivial
  question" — not as proof of a win.
- `codex-no-ken` produced plausible-looking but wrong paths on 8/10
  questions (TypeScript and Rust paths that don't exist in this Python
  repo), suggesting the model often defaults to generic conventions
  without grounding.
- `codex-ken` produced paths that look like real files in the repo on
  most cells — the structure is right, the specific file is not — which
  is what we'd expect from a model that has tools to narrow down but is
  not large enough to follow through precisely.
- Median elapsed is identical (36.5 s), so neither condition added measurable
  wall-clock cost in this run.

Three sample `ANSWER:` lines from the same question with and without ken:

| question | codex-no-ken | codex-ken |
|---|---|---|
| "fix codex hook installation and config wiring" | `src/codex/hooks.ts` | `src/ken/cli.py` |
| "what happens when two saved findings contradict each other" | `src/findings/contradictions.ts` | `src/ken/memory.py` (✓) |
| "how do I make the agent remember a constraint across sessions" | `AGENTS.md` | `docs/design/justified-memory.md` |

The single correct cell is q8 — the agent with ken landed on
`src/ken/memory.py`, which is in the expected set. Without ken, it named
a file that does not exist.

**To make this section defensible we would need:**
- A larger question set (the retrieval benchmark used 54; ten is too few
  for a binary outcome).
- At least three repetitions per cell to estimate variance.
- A larger model (the `gpt-reserve` agent often produced the right
  directory and the wrong file).
- Token and tool-call counts so we can claim "ken reaches the answer with
  fewer reads", not just "ken gets a marginally higher hit rate".

Those are runnable with the same harness (`output/benchmarks-2026-10/agent-bench/run.py`)
once a usable model is configured.

## Install the CLI

ken is published on PyPI as [`ken-rank`](https://pypi.org/project/ken-rank/). The
distribution name is `ken-rank`, but it installs the `ken` command. Install it
with `pipx` (recommended, isolates the tool) or `uv`:

```sh
pipx install ken-rank
# or
uv tool install ken-rank
# or
pip install ken-rank
```

Verify the install:

```sh
ken --version
```

The MCP Python SDK is a required runtime dependency and is installed with
`ken-rank`; there is no separate MCP extra to enable. Current releases require
MCP 2.x (`mcp>=2.0,<3`) because the server uses the 2.x `MCPServer` API.

### From a checkout

To install from a local clone (for development or an unreleased build):

```sh
./install.sh
```

The installer uses `uv` to install the `ken` command into your user-local tool
directory. If `uv` is not present, the script bootstraps it with Astral's
official installer unless you pass `--no-bootstrap-uv`. You can also install the
checkout directly with `uv`:

```sh
uv tool install --editable . --force --reinstall --refresh
```

For development, create or refresh the locked environment and run the same
quality checks as CI:

```sh
uv sync --locked --dev
uv run pytest
uv run mypy
```

The mypy gate is incremental: it checks all of `src/ken`, while modules with
known historical annotation debt are listed explicitly in `pyproject.toml` as
temporary per-module overrides. New modules and modules outside that list must
remain clean.

### Troubleshooting MCP startup

If the host assistant (Claude Code, Codex, OpenCode, …) lists the `ken`
MCP server as `failed` or `disconnected` while the project itself looks
fine, the most common cause is a stale install of ken-rank 0.10.0 from
PyPI — that release shipped with the wrong `mcp>=1.0` pin, and depending
on what `mcp` was already on the system, the SDK version that got
resolved could be incompatible with the MCP server. `ken mcp` exits with
a clear remediation message in that case; if you see one, reinstall:

```sh
uv tool install --reinstall ken-rank
# or
pipx reinstall ken-rank
# or
pip install --upgrade --force-reinstall ken-rank
```

Then restart the assistant so it respawns the `ken mcp` process. 0.11.0
and later pin `mcp>=2.0,<3` and refuse to start against older SDKs.

## Install ken in a project

Run this once from the project you want ken to index:

```sh
ken install .
```

By default, ken detects the assistant setup you use and wires itself into the supported local agent config. The install creates `.ken/`, adds it to `.gitignore`, installs hooks/MCP config and problem-oriented skills where applicable, and performs the initial structural code index.

Embeddings are lazy by default. That means `ken install .` does not eagerly embed the whole repository; the daemon warms embeddings as they are needed. This keeps install fast and avoids doing expensive work before the project needs it.

To keep archived code, generated fixtures, or evaluation copies out of Ken's
source search while retaining them in Git, add patterns to a project-root
`.kenignore`. It uses gitignore syntax and adds exclusions; it cannot override
`.gitignore` or built-in exclusions. For example, `docs/validation/` excludes
that archive from project scans. The watcher reloads this file and requests an
index resync when it changes. Explicitly reading a known file remains possible.

ken also gets better with use. The first run starts from the project index, names, symbols, docstrings, and any available embeddings. As you and the assistant read files, edit code, dismiss weak context, and save findings, ken records those interactions as local ranking signals. Results should improve after real sessions because the system learns which files were useful for similar work in this project.

### Force a target assistant

Use `--claude` when you specifically want Claude Code wiring:

```sh
ken install --claude .
```

Use `--codex` when you specifically want Codex CLI wiring:

```sh
ken install --codex .
```

Use `--opencode` when you specifically want [OpenCode](https://opencode.ai)
wiring — it registers ken as a local MCP server in the project's
`opencode.json` (or `opencode.jsonc`):

```sh
ken install --opencode .
```

For the official [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)
(`dsh`), install its project overlay and launch with that overlay:

```sh
ken install --deepseek .
dsh --profile web --patch .dsh/ken.cordis.json
# Or run a task from the CLI:
dsh --profile headless --patch .dsh/ken.cordis.json "Use Ken to locate the storage implementation"
```

DeepSeek requires the explicit `--patch` argument. Ken prints the launch command,
including in quiet mode, and detects `.dsh/` on subsequent installs. The overlay
pins the MCP process to this project and the Python installation that ran
`ken install`. Reinstall after moving the project or replacing that environment.
It composes with existing profile patches; no global Harness profile is edited.

You can pass several when a project uses several assistants:

```sh
ken install --claude --codex .
ken install --claude --opencode .
ken install --codex --opencode .
ken install --claude --codex --opencode .
```

OpenCode and DeepSeek receive MCP tools and skills. Ken does not currently
install native lifecycle hooks for these two hosts: recall, ranking, and
contract checks are available on demand. Automatic context injection and edit
checks require a host hook integration; merely connecting MCP does not run them.

### Skills organized by problem

All eight bundled skills are in English. Each works through a programming
problem: the question, evidence to collect, how to interpret the result, and
what to do when it is ambiguous or incomplete:

| Skill | When to use it |
| --- | --- |
| `ken-locate-code` | Find who implements a behavior or handles an entry point. |
| `ken-investigate-bug` | Connect a failure to its cause, consumers, and tests. |
| `ken-plan-change` | Scope a refactor or migration and compare existing contracts. |
| `ken-understand-architecture` | Explain responsibilities and observed collaboration. |
| `ken-reuse-code` | Find reusable code and a candidate access expression in Python. |
| `ken-find-code-patterns` | Search structural properties and bug signatures with KQL2. |
| `ken-prevent-regressions` | Author and validate an explicit source contract. |
| `ken-resume-work` | Reuse conclusions with their sources, assumptions, and validity. |

The three query-authoring skills include a self-contained KQL2 guide with
executable examples: captures and ownership, filters, correlated absence,
returned values, target identity, reusable patterns, libraries, and graph
hazards. The contract skill includes both witness (`some_match`) and violation
(`no_matches`) examples with cases that expose misleading success.

`ken install` follows the selected/detected hosts: `.claude/skills` for Claude,
`.agents/skills` for Codex, `.opencode/skills` for OpenCode, and `.dsh/skills`
for DeepSeek. OpenCode can reuse Claude/Codex copies; DeepSeek can reuse the
Codex copy. Skills are loaded on demand by the assistant. Installed skill
directories are excluded from Ken's code index and text search so their example
code does not compete with the project implementation.

Reinstall replaces older content under the same eight skill names; it does not
install a second generation alongside them. It updates unchanged Ken-owned
bundles, removes obsolete owned references, and reports local customizations
without overwriting them. Uninstall removes unchanged owned files and preserves
edited bundles and extra user files. Ownership is tracked in
`.ken/installed-skills.json`; existing unowned skills are never adopted.
`ken install --no-wire` skips skills as well as hooks and MCP wiring. Installing
skills does not enable source contracts or automatic checks.

See [installation design and verified host contracts](../docs/design/assistant-skills.md)
and the [skill rewrite and validation report](../docs/validation/skills-learning-2026-09-22/README.md).

### Eagerly build embeddings

For better first-run semantic ranking, especially on projects where initial context quality matters, force the initial embedding pass:

```sh
ken install --embed .
```

This is recommended when you can afford the extra install time. The cost scales with the repository, and the ceiling is lower than you would expect: the **Linux kernel 7.1-rc2** — 101 084 files walked, 65 907 parsed, 771 563 symbols extracted — indexes in **219 s on a Ryzen 9 8945HS laptop**. On very large projects, cap the eager pass while still structurally indexing the whole repo:

```sh
ken install --embed --embed-limit 5000 .
```

You can combine assistant selection and eager embeddings:

```sh
ken install --codex --embed .
ken install --claude --embed .
```

### Install CLI and wire a project in one step

From a ken checkout, `install.sh` can install the CLI and then run `ken install` for a project:

```sh
./install.sh --project /path/to/my-project
./install.sh --project /path/to/my-project --codex --embed
```

## Search defaults and embedding models

New projects use **`minishlab/potion-code-16M-v2`**, a 256-dimensional static
Model2Vec code embedding (about 32 MB of weights). Normal `search-files`,
`search-symbols` and MCP `ken_find` semantic requests use the complete measured
configuration: static and lexical retrieval, CodeRankEmbed INT8 source context,
local Spanish expansion, numeric owner/piece ranking and Ettin 68M reranking.
Everything runs locally on CPU, without PyTorch or a GPU requirement.

The first semantic request prepares missing public pinned models and source
indexes. To perform setup explicitly before searching:

```sh
ken retrieval prepare --path /path/to/project
ken search-symbols 'Where is a value validated before storage?' --path /path/to/project
ken search-files 'Which module handles configuration?' --piece-kind module --path /path/to/project
```

CLI and MCP return compact text by default: the requested piece, path, source
ranges and numbered code. `--piece-kind class|module|symbol|file` makes the
requested unit explicit; `auto` infers it. `--json` or MCP
`output_format="json"` changes presentation while keeping the same search engine.
See [actual CLI and MCP output examples](../docs/validation/compact-output-2026-10-16-best-default/EXAMPLES.md).

Current observations on 200 queries per cohort:

| Cohort | Correct requested piece at top1 | Recall@10 |
| --- | ---: | ---: |
| Exposed development | 191/200 (95.5%) | 197/200 (98.5%) |
| Independent additional queries | 177/200 (88.5%) | 198/200 (99%) |

The independent result **does not meet the 90% goal**. Development tuning continues
and another untouched reserve is required for validation. The cohorts use the
same eight repositories and do not demonstrate new-repository generalization.
The independent prepared CPU run measured p50 2.54 s, p95 3.74 s and peak 1.81 GiB RSS;
model preparation/indexing is separate. Full methodology, per-type results and
receipts are in the [search validation journal](../docs/validation/search-engine-top1-2026-10-14/scoring-internals/PUBLIC-DEFAULT-V140-V145.md).

Existing project embedding pins and explicit user choices remain available.
Semantic search prepares its registered passage/context representations separately
so it never compares incompatible vector dimensions. To control the embedding
used by future project indexes, or explicitly reembed an existing index:

```sh
ken default-model
ken default-model --clear
ken default-model BAAI/bge-m3
ken reembed --model minishlab/potion-code-16M-v2
```

### Optional model backends and accelerators

The complete measured search pipeline currently uses CPU execution. Automatic
selection of a validated faster accelerator for that pipeline is still pending.
The dynamic Ettin graph failed a source-free CoreML compilation probe on this Mac;
no CoreML speedup is claimed.

Explicit fastembed and sentence-transformers index backends retain their existing
GPU detection and CPU fallback. `ken-rank[gpu]` supports compatible CUDA/ROCm ONNX
installations on Linux/Windows; `ken-rank[torch]` supports CUDA or Apple Silicon
MPS. These optional backends do not change the measured complete search profile.
Their device control is `KEN_EMBED_DEVICE=auto|cpu|gpu|cuda|mps`.

Earlier static-Qwen, multilingual and heavy-transformer comparisons are preserved
in [historical embedding controls](../docs/validation/embedding-history-before-best-default.md).
Their metrics use different tasks and cannot be compared directly with the
requested-piece benchmark above.

## Where the vectors live

Since 0.9.0 the vectors are **not** in `ken.db`. They live in `.ken/vectors/` as memory-mapped, fixed-size segment files, and each row in SQLite carries a `vec_slot` pointing at one. The relational half — paths, symbols, imports, sessions, findings — stays where it was.

This is not cosmetic. On a Linux 7.1-rc2 index (101 083 files, 771 563 symbols), `ken rank` took **21.3 s**, of which the actual arithmetic was 0.138 s. The rest was deserialising 771 563 Python row objects and 2.9 GB of blobs to feed one matrix-vector product. Mapping them instead:

| | before | after |
| --- | --- | --- |
| `ken rank`, end to end | 21.3 s | **1.82 s** |
| fuzzy channel | 20.4 s | 0.374 s |
| lexical channel | 22.6 s | 0.126 s |
| `ken.db` | 4.10 GB | **214 MB** |

Ranked output is unchanged: top-k overlap 1.000 across a 12-query set, with scores drifting 5.1e-03 on ~7 from float32 rounding.

Worth saying plainly, because the obvious suspect was wrong: **SQLite was never the bottleneck.** Measured over the same 2.9 GB, it handed over the vector column at 906 MB/s against 1.5 GB/s for a raw flat file — within 1.7×. Swapping the database engine would have bought 3%.

### Migrating an existing project

An index built before 0.9.0 keeps working untouched — every read falls back to the inline column for rows without a slot, so it is correct, just slow. Convert it when convenient:

```sh
ken vectors migrate      # move the vectors out, then VACUUM the freed pages
ken vectors verify       # expect 0 leaked / 0 out-of-range / 0 double-booked
```

Stop the daemon first (`ken serve --stop`): the migration takes SQLite's write lock in batches, and a running daemon can hit its 5 s busy timeout. It is idempotent and resumable — an interrupted run leaves a partly-converted index that still answers correctly, and re-running finishes it.

`ken install --embed .` and `ken reembed` also migrate, so if you were going to run either anyway there is nothing extra to do.

Timing: 2 m 21 s for the kernel's 872 000 vectors. A normal project is seconds.

### The rest of `ken vectors`

```sh
ken vectors              # sizes and how many vectors are still inline
ken vectors verify       # cross-check slots against rows
ken vectors compact      # renumber live vectors densely, reclaim leaked slots
```

`compact` is for maintenance, not migration: it rebuilds the store into a dense prefix and drops the tail, reclaiming slots stranded by a crash between a vector's write and its commit. `verify` tells you whether there are any — usually zero.

Segment files are preallocated and sparse, so a space holding a few thousand vectors reports 256 MB of apparent size against ~17 MB of real blocks; `ken vectors` reports the blocks.

## Tell the assistant to use ken

Ken's MCP tools describe their inputs and return compact code locations and
source by default. Project instructions explain when to search, when to read,
and which findings to preserve. Use English for natural-language code searches;
the assistant can translate your request and answer in your preferred language.

Interactive installation offers to add the following guidance to `AGENTS.md`:

```text
$ ken install . --embed
...
Append Ken instructions to AGENTS.md? [Y/n]:
```

Press Enter to accept, or `n` to skip. For scripts, use `--agents-md` or
`--no-agents-md`; without a terminal, installation does not prompt or add project
instructions unless explicitly requested. `--no-wire` also skips instructions.
The managed section preserves existing project content, avoids duplicate blocks,
and preserves local edits. Uninstall removes only unchanged sections Ken owns.

When installing Claude Code integration, Ken also adds `@AGENTS.md` to
`CLAUDE.md` when needed, preserving existing instructions. This keeps the shared
guidance visible when that file takes precedence over `AGENTS.md` in Claude Code.

You can also add the recommended guidance yourself:

```md
## Code intelligence: ken

Use Ken to locate code and reuse project findings. If a `<context-rank>` block
already names the relevant file, read it before searching again.

Write natural-language code-search queries in **English**, translating the
user's intent yourself. Keep identifiers, paths, quoted source, regexes and
KQL unchanged. Reply to the user in their preferred language.

Start with one focused `ken_find(query=..., scope=...)`: `symbols` for a
function or class, `files` for a file or module, `wiring` for an entry point,
and `text` with `literal=true` for exact source. State the requested piece;
use `piece_kind="class"`, `"module"`, `"symbol"` or `"file"` when known.
Use `purpose="tests"` for tests and distinguish test cases from test helpers.

Read the returned code to verify a match. Compact results are the default;
use `ken_read` for more source and `full=true` only when debugging a ranking.
After two unhelpful searches, read the likeliest file or use a literal search.

Before editing an unfamiliar file, check `ken_recall(path=...)`. For a shared
change, inspect `ken_related(..., relation="blast_radius")` and its tests.
Save non-obvious findings with `ken_remember`, anchored to the relevant file
or symbol; include evidence, assumptions and a recheck step for conclusions.
```

The shell commands (`ken rank`, `ken search-files`, `ken search-symbols`, and `ken explain`) expose the same ideas for humans or agents without MCP, and `ken tools <name>` runs any MCP tool directly (see [Run MCP tools from the shell](#run-mcp-tools-from-the-shell)). For assistants with MCP available, the MCP tools are the preferred path because they return compact, actionable text by default and feed ken's local task memory. Use `output_format="json"` for native structured results.

## Use ken directly

The hooks run automatically when the assistant is active, but the CLI is useful for checking what ken sees:

```sh
ken status .
ken rank "where is codex install wiring handled"
ken rank --verbose 2 "how does predictive ranking work"
ken explain "why did src/ken/cli.py appear"
ken search-files "semantic file retrieval"
ken search-symbols "merge codex hooks"
```

You can save and recall project-specific findings:

```sh
ken remember "codex wiring" "Use ken install --codex . to repair invalid hooks."
ken recall "codex hook repair"
```

Findings can also carry a justification, evidence files and file/tree dependencies
through `ken_remember(..., justification={...})` or `ken tools remember`.
The existing session and prompt hooks surface compact dependency validity, and
`ken_recall(topic="…", detail="answer", max_chars=1800)` starts with a whole
conclusion, source references, assumptions and input validity. Expand with
`detail="full"` or read the relevant symbol when evidence is missing or stale;
`summary` adds a short rationale. See
[justified programming memory](../docs/design/justified-memory.md) for the contract,
examples and limits. Unchanged dependencies do not establish that a conclusion
is true or that its assumptions still apply.

## Run MCP tools from the shell

Every tool the ken MCP server exposes is also runnable directly with `ken tools`, so you can use the structured code-intelligence tools (call graph, blast radius, co-change, wiring, clones, …) without an assistant in the loop. The list, descriptions, and parameters are read live from the same MCP surface, so `ken tools` never drifts from what the agent sees.

```sh
ken tools                                       # list every tool with a one-line summary
ken tools find --help                           # show one tool's parameters
ken tools find "MY_ENV_VAR" --scope text --literal   # required params are positional, options are --flags
ken tools related src/ken/cli.py blast_radius
ken tools read src/ken/search.py --include symbols imports
ken tools who "Who stores reusable findings?" --path src/ken
```

The tool name may be given with or without the `ken_` prefix (`find` or `ken_find`). Required parameters are positional in schema order — `ken_related` takes `target` then `relation`. Results print as compact text with locations and numbered source by default. `ken tools --json read ...` or `--output-format json` after the tool name requests native JSON. The older global `--compact` keeps its single-line JSON meaning. `--path /repo` before the tool name selects another checkout. See [all output examples](../docs/validation/compact-output-2026-10-16/EXAMPLES.md).

`ken_who` answers responsibility questions with ranked symbol hypotheses, current
documentation, evidence from names and call expressions, and explicit assumptions.
Its confidence score is a heuristic, not a calibrated probability. Optional
`--hypotheses "Store reusable findings"` supplies an alternative formulation,
useful when the question and documentation use different terminology or languages.
See [responsibility questions and confidence](../docs/design/responsibility.md).

`ken_query` stores complete KQL2 modules in the project's `.ken/ken.db`.
Save a tested file with `ken kql2 query.kql --save`, then run it with
`ken kql2 --saved project.module --query entry --path src`. Saved patterns resolve
through ordinary `import/use`; CLI and MCP use the same prepared sessions.
MCP execution uses `ken_find(scope="structure", query_language="kql/2",
saved_query="project.module", query_name="entry")`. List/show/update/delete are
available through `ken_query` and `ken tools query`. See
[saved modules and revision handling](../src/ken/skills/references/kql2/saved-modules.md).

`ken_rule` registers KQL2 source contracts with passing/failing examples;
`ken_check` validates the current code, keeps evidence receipts, and compares
regressions or resolutions. `ken_related(..., relation="checks")` finds applicable
contracts; `ken_remember(..., check_run="...")` binds a memory to a check.
Validated rules can opt into bounded background edit checks through Ken's
existing hooks. See [source contracts, MCP/CLI examples and limits](../docs/design/source-contract-tools.md).

`ken code-check` investigates one Python call contract with KQL2 candidates,
normal-path evidence, and explicit uncertainty about unresolved helpers. The
same operation is exposed as `ken_code_check` for agents and through
`ken tools code_check`. For example, `ken code-check GraphIndex.close
'self.store.close()' --when self.owns_store=true` resolves a unique function
under `src/`; an ambiguous name returns exact file selectors. Unknown results
include `next_checks` with conditional bounds for the unresolved calls worth
inspecting. See [commands, results, and limits](../docs/design/code-reasoning.md).

When the function is unknown, `ken code-find 'os.fsync -> os.replace' --in
src/ken/vectors.py` first finds direct KQL2 candidates and then checks each
candidate's normal paths. Agents can use `ken_code_find`. Search coverage and
unmodeled paths remain visible; a complete direct search does not exclude
wrappers without a direct KQL2 match.

`ken_related` also exposes `impact` (result consumers and related tests), `roles`
(call chains and structural role hypotheses), and `available` (explicit Python
access expressions with outstanding compatibility obligations). For example:

```sh
ken tools related 'src/ken/checks/report.py::query_view' impact --path src/ken/checks --depth 3
```

Inspections follow explicit imports; same-named functions in unrelated files do
not establish a dependency. Memories retain per-rule freshness, including imported
dependencies. Compact recall preserves whole conclusions or offers an explicit
expansion when the character budget is too small. See [program inspection and
coding workflows](../docs/design/code-inspection.md).

File-path arguments handled by these tools are confined to that selected
project root. Relative paths are resolved from the root; absolute paths are
accepted only when they remain inside it. Traversal such as `../outside.py` and
symbolic links that resolve outside the project are rejected. This applies to
the shared tool surface used by both MCP clients and `ken tools`.

## Codex hook setup

After `ken install --codex .`, start Codex in the project and run `/hooks` to enable the project hooks. Codex only loads project-local hooks after the project is trusted, so also approve the trust prompt when Codex asks.

You can mark the project as trusted manually in `~/.codex/config.toml`:

```toml
[projects."/abs/path/to/my-project"]
trust_level = "trusted"
```

## OpenCode setup

After `ken install --opencode .`, OpenCode picks up the `ken` MCP server automatically the next time it starts in the project — no extra step on your side. OpenCode reads `opencode.json` / `opencode.jsonc` straight from the project root and merges `ken`'s block with whatever you already have (model, providers, commands, sibling MCP servers, all preserved). Run `opencode mcp list` to confirm the server is registered.

If you wired multiple assistants into the same project, the OpenCode MCP entry lives alongside the Claude and Codex hooks with no interaction between them.

## Uninstall

```sh
ken uninstall .
ken uninstall --keep-db .
```

`ken uninstall .` removes hooks, MCP entries, and the local `.ken/` index. Use `--keep-db` if you want to keep `.ken/ken.db` for later.

## License

ken is released under the MIT License. See [LICENSE](../LICENSE).

## Structural code analysis

Ken can query a tree-sitter IR graph, scan 23 GoF pattern signatures, summarize
patterns by directory, and check a catalogue of source-level bug signatures:

```sh
ken structural patterns --path .
ken structural bugs --path .
ken structural search --path . --query-file search.kenq
ken structural catalog
```

Queries support typed selectors, regex, named roles, graph paths, cardinalities,
variants and evidence-based ranking. Results distinguish structural matches,
missing semantic evidence and exhausted query budgets. The content-addressed
cache defaults to 500 MB; use `--cache-mb 0` to disable it. MCP clients use
`ken_find` with `scope="structure"`, `"patterns"` or `"bugs"`.

See [the current query guide](../docs/structural-queries.md) for syntax, examples,
language coverage, precision limits, cache configuration and tests. All 23 GoF
concepts have canonical queries tested against Python, Java and TypeScript source;
[the coverage matrix](../docs/gof-coverage.md) distinguishes executable variants from
planned ones. Matches remain structural candidates, not proof of design intent.

Structural searches support [KenQL and named queries](../docs/structural-queries.md),
with [declarative pattern files](../src/ken/structural/patterns).
