# Estudio de autoría y enseñanza de KQL2

Solicitud: investigar prompting y skills públicas, y mejorar las skills KQL2
para que un agente formule consultas útiles y sostenga sus conclusiones con
evidencia. La evaluación debe distinguir calidad del resultado de longitud o
apariencia del documento.

## Referentes consultados

No existe una clasificación que demuestre cuáles son las mejores skills para
KQL2. Se eligieron fuentes primarias y ejemplos mantenidos por sus autores,
con instrucciones inspeccionables, referencias y mecanismos de validación.
Consulta: 2026-10-14. Los enlaces a ramas principales pueden evolucionar.

| Fuente | Práctica transferible | Aplicación prevista |
| --- | --- | --- |
| [OpenAI: Build skills](https://learn.chatgpt.com/docs/build-skills) | Descubrimiento por nombre/descripción y carga progresiva de instrucciones | Mantener un punto de entrada pequeño con rutas concretas |
| [OpenAI: Rethinking skills and prompts](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra) | Evitar activación demasiado amplia e instrucciones que compiten con la tarea | Separar búsqueda relacional de análisis especializado de rutas |
| [OpenAI: Prompt engineering](https://developers.openai.com/api/docs/guides/prompt-engineering) | Ejemplos de entradas y salidas diversas para enseñar el patrón esperado | Conservar positivos, negativos cercanos y testigos verificables |
| [OpenAI: Testing Agent Skills Systematically with Evals](https://developers.openai.com/blog/eval-skills) | Puntuar el resultado y la trayectoria; incluir controles negativos | Comparar consultas ejecutadas, conclusiones y errores antes/después |
| [Anthropic: Skill authoring best practices](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices) | Baseline antes de documentación extensa y mejora por uso observado | Probar tareas con agentes independientes antes de editar |
| [Agent Skills: Best practices](https://agentskills.io/skill-creation/best-practices) | Unidades coherentes, detalle moderado y referencias condicionadas a la necesidad | Enseñar decisiones y recuperación en vez de añadir un manual monolítico |
| [OpenAI: gh-fix-ci](https://github.com/openai/skills/blob/main/skills/.curated/gh-fix-ci/SKILL.md) | Entrada concreta, herramienta ejecutable y manejo de fallos conocidos | Mostrar una invocación completa y el siguiente paso ante errores |
| [Anthropic: skill-creator](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md) | Iteración con tareas y evaluación cualitativa y cuantitativa | Conservar resultados y límites, sin inferir mejora de una reescritura |
| [Vercel: react-best-practices](https://github.com/vercel-labs/agent-skills/blob/main/skills/react-best-practices/SKILL.md) | Índice por problema y ejemplos incorrectos/corregidos en referencias | Seleccionar la relación necesaria antes de cargar recetas |

Las decisiones de permisos y los triggers de esos productos no se trasladan
automáticamente a Ken. La recomendación de ser conciso tampoco implica quitar
invariantes de cobertura, identidad o incertidumbre.

## Baseline congelado y criterios

Se capturaron los bundles instalables actuales, sus recursos compartidos y sus
SHA-256 antes de modificar las skills. Se conservan también los cambios que ya
existían en `ken-find-code-patterns` y `ken-investigate-bug`.

Tres agentes independientes resuelven seis tareas, usando sólo el bundle
capturado y pequeños proyectos temporales. Ejecutan consultas en la CLI real;
no se ejecuta el código de un proyecto real ni se habilitan reglas. No es una
medición estadística de todos los modelos ni una prueba de activación implícita.

| Tarea | Resultado observable esperado |
| --- | --- |
| Retorno de `storage.persist` | Distinguir valor devuelto, alias, descarte, sobrescritura y target homónimo; entregar consultas y ubicaciones |
| Ausencia por clase | Encontrar `write` sin `close` propio, sin que el `close` ajeno oculte el caso |
| Orden en todas las rutas | Diferenciar testigo existencial de obligación universal; evaluar rama condicional y orden inverso |
| Presupuesto de sesión automática | Interpretar correctamente total 124 ms, preparación 120 ms y consulta preparada 4 ms con timeout 10 ms |
| Resultado vacío con unknowns | No concluir ausencia; localizar la relación sin resolver con un siguiente paso concreto |
| Regla de regresión | No permitir que un wrapper correcto oculte otro incorrecto; validar ejemplos mixtos y declarar límites estáticos |

Se registran referencias abiertas, programas intentados, errores, respuestas y
límites. Una limitación del motor se separa de un error de autoría. El objetivo
es mejorar la ayuda que recibe el agente, sin atribuir a la skill capacidades
que el motor no ofrece.

## Seguimiento

- [x] Investigar fuentes primarias y ejemplos públicos.
- [x] Congelar bundles, fixtures, preguntas y criterios antes de editar.
- [x] Observar baseline y anotar fallos o fricciones concretas.
- [x] Cambiar sólo instrucciones y recursos justificados por esa evidencia.
- [x] Validar cada skill modificada antes de continuar con la siguiente.
- [x] Ejecutar ejemplos literales, controles negativos y empaquetado.
- [x] Repetir tareas independientes con las skills nuevas y revisar diferencias.
- [x] Registrar resultados reales, alcance y límites; actualizar instalación propia.

## Observaciones del baseline

Los agentes resolvieron retorno con aliases y target homónimo, ausencia por
clase, interpretación de unknowns y distinción entre orden existencial y todas
las rutas. No se atribuye a una nueva redacción una corrección de esos resultados:
las skills existentes ya enseñaban esas decisiones.

Fricciones observadas antes de editar:

- En la recuperación de candidatos, un agente trasladó `call $target {}` fuera
  de `body` y recibió `incompatible selector types for $target`. Lo corrigió
  conservando BODY. Falta una consulta completa de recuperación en ese punto.
- Otro agente necesitó consultar `--help` para conciliar el presupuesto de la
  CLI automática con un README que todavía incluía preparación en el timeout.
  Respondió correctamente; se debe corregir la referencia, no presumir fallo
  de comprensión ni inventar otra semántica.
- La regla genérica de ausencia de retorno produjo unknowns o un error de
  capacidad. El agente no la presentó como certificación. Una regla posterior
  acotada a un wrapper validó 8/8 casos, incluido un vecino bueno y una rama
  incorrecta que demuestra su límite existencial. No equivale a resolver el
  contrato general original. Hubo un mensaje del evaluador para cerrar el
  ensayo y exigir que esa acotación permaneciera explícita.

Las entradas principales tenían 1223, 1199 y 867 palabras. Los primeros dos
incluían grandes bloques repetidos de contratos de rutas, sus priors y detalles
de dispatch. Se conservarán en una referencia específica, accesible cuando la
pregunta realmente requiera ese análisis. Esta reorganización mide contexto
inicial, no demuestra por sí sola una mejora estadística del razonamiento.

## Cambio realizado y resultado

`ken-find-code-patterns` pasa de 1223 a 540 palabras y presenta la decisión de
relación/quantificador antes de las referencias. El detalle de contratos de
rutas se conserva en `path-contracts.md`, compartido entre los tres autores de
KQL2. `ken-investigate-bug` pasa de 1199 a 930 palabras, y la skill de regresiones
añade el límite concreto observado al intentar negar BODY. No se cambiaron las
otras cinco skills ni las capacidades del motor.

La receta de recuperación ahora es un programa completo, ejecutado contra el
fixture junto a descartes y sobrescrituras. El agente nuevo resolvió la tarea de
valores sin el error de selector observado en el baseline. El agente de tiempos
respondió desde la referencia corregida sin necesitar conciliarla con `--help`.
Clases, unknowns y orden ya se resolvían correctamente y siguieron correctos.
La regla general sobre todos los wrappers sigue sin certificación; ambos
ensayos conservaron ese límite, y el nuevo probó además un gate de rutas sobre
un inventario explícito. Ese gate tampoco incluye wrappers futuros por sí solo.

La revisión independiente recuperó una premisa de independencia entre priors
que se había perdido al extraer texto; se verificó con `worlds.py` y se restauró.
Después pasaron **49 tests** de ejemplos, controles negativos, referencias y
empaquetado. Las tres skills pasaron validación de metadata y se actualizaron
en `.agents/skills`; las otras cinco quedaron sin cambios.

Evidencia, bundles congelados, preguntas, consultas, respuestas y límites:
[informe de validación](../../validation/kql2-skills-2026-10-14/README.md).
Son seis tareas de desarrollo, una pareja antes/después, no un benchmark
estadístico ni una prueba de todos los modelos o de activación implícita.
