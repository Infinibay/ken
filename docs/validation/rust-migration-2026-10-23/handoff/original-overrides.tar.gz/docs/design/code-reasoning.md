# Reason about a Python source contract

When the responsible function is unknown, start with one contract and a source
scope:

```sh
ken code-find 'os.fsync -> os.replace' --in src/ken/vectors.py
```

`code-find` uses one KQL2 search to locate direct call candidates, follows one
hop to callers in the same Python file (top-level functions or methods of the
same top-level class) and through explicit project-local `from` imports, then
checks the requested all-path contract in each candidate's current source.
On this repository it finds `_atomic_write` as `all_paths_called`, with the
`os.replace` witness at line 206. It also lists `compact` as `unknown`: KQL2
locates a `replace` call at line 829, but that candidate alone does not establish
the all-path contract. The default response shows candidate call sites, decisive
path evidence, and the first blockers. `--full` adds the KQL2 query and path
traces. For agents, the same operation is `ken_code_find`; from a shell it is
also `ken tools code_find 'os.fsync -> os.replace' --search-path src/ken/vectors.py`.

For example, `ken code-find os.replace --in src/ken/checks/store.py` finds
`Store.write` as a direct candidate and `Store.save_rule` as its same-class
caller. The latter is `unknown` with a conditional `os.replace` witness inside
`write`. `candidate_kind`, `via`, and `delegate_call_locations` explain how the
caller entered the result. The direct KQL2 search has its own `coverage`; the
bounded same-file and imported caller searches report `expansion_coverage` and
`import_expansion_coverage` separately.

For example, if `pkg/helper.py` declares
`forward(item): return persist(item)` and `pkg/writer.py` imports it as
`send`, `ken code-find 'return persist(user)' --in pkg` can locate
`pkg/writer.py::save` when its body returns `send(user)`. The result marks it
`imported_caller`, links it to `pkg/helper.py::forward` through `via`, and
reports whether the return value is forwarded on all modeled normal paths.
Only an explicit, uniquely bound import whose module and symbol match the
seed qualifies. A same-named function from another module or a local binding
that hides the imported name does not qualify.
On this repository, a scoped `os.replace` search also finds
`install_skills` via its explicit import of `write_atomic`. Its path result is
`unknown`, so the import link is useful for investigation without claiming an
all-path call.

The search accepts `return self.lookup(key)` as well. Its direct KQL2 relation
finds `Lookup.__getitem__` in `graph_source.py`; path analysis verifies the
guarded normal return. `--in` accepts a project directory or one Python file
and defaults to `src/` when present. `--max-candidates` bounds KQL2 rows and
each caller expansion separately; each coverage object exposes truncation.
`--limit` changes only how many analyzed matches are displayed. A returned
`selector` can be passed to `ken code-check` for branch assumptions or effect
priors. The caller expansion currently covers one same-file or explicit-import
hop from each direct seed. Deeper, dynamic-import, module-attribute, and
otherwise indirect wrappers may still be absent, even when all coverage
objects are complete;
`contract_search_exhaustive` is therefore false.
An imported caller requires its direct KQL2 seed to be within the requested
scope. A single-file `--in` that excludes the imported helper does not find
that helper as a seed; choose the containing package directory for this search.
Before asking indexed KQL2 to acquire a directory, a Python AST inventory
retains only files with the requested call name (and the root name of a dotted
target). The result reports examined, filtered, and selected file counts.
Inventory parse/read failures make coverage incomplete. In this checkout, a
wide `os.fsync -> os.replace` search of `src/ken` selected nine of 311 Python
files and completed in about ten seconds on its first filtered run; the unfiltered
indexed search exhausted a 15-second budget during preparation. These are
observations from this checkout, not a general latency guarantee.

`ken code-check` answers two narrow, source-backed questions about a selected
Python function: does every modeled normal path call a target, optionally after
another call, or does every modeled normal return forward a target call's
value? KQL2 finds direct same-function candidates. Both path interpreters
follow uniquely bound project-local helpers and imports; the return interpreter
also follows local assignments and aliases. A candidate is a location to inspect, while a
path witness is evidence about the requested source-level relationship.

Run this from the project root:

```sh
ken code-check _atomic_write \
  'os.fsync -> os.replace(_, path)'
```

The result identifies two witnessed normal paths and the ordered call at line
206 for the source version used in this repository. `_` accepts any first
argument; `path` names the selected function's parameter. `--full` adds path
traces, the KQL2 query, coverage, and dependency hashes. `--out receipt.json`
saves that result with the source SHA-256. A short name searches current Python
source under `src/` when that directory exists, otherwise under the project
root. It must identify exactly one function. Use `--in DIR` to choose a search
directory, or `path.py::Class.method` to select an exact file. Ambiguous names
return concrete selectors instead of choosing one silently.

Use a lexical qualname such as `src/pkg/writer.py::Writer.save` when several
functions share a basename. The path interpreter selects that exact method.
If KQL2 sees several same-named owners in the file and cannot attribute its
direct-call candidate to the selected class, `candidate_call` is `unknown`
with `ambiguous_target`; it does not change the separately reported path
analysis.

Branch preconditions can make an ownership question precise. This checked
the real `GraphIndex.close` method under the declared owning branch:

```sh
ken code-check GraphIndex.close \
  'self.store.close()' --when self.owns_store=true
```

The result witnesses `self.store.close()` at line 414 on its one modeled
normal path. The branch condition is supplied by the investigator; it is not
inferred as a fact about all callers.

A dotted target may also name a local variable. The real
`AcquisitionLock.close` gives another ordered question:

```sh
ken code-check src/ken/structural_store/acquisition.py::AcquisitionLock.close \
  'fcntl.flock -> handle.close()' --when 'self.handle is not None=true'
```

On the guarded branch, the result witnesses `handle.close()` after the
unlock call. A dotted name rooted at an imported module is treated more
strictly: reassigning that module name locally does not prove a call on the
original module. A local name only matches in the selected function, not in a
helper that happens to reuse its spelling. Argument names in a contract
refer to the selected function's parameters or eligible module literals; use `_` for an
unconstrained argument or
omit the argument list when the value is named only by a local variable.

The same interface is available to agents as `ken_code_check` and in the shell
through `ken tools code_check`. For example:

```sh
ken tools code_check src/ken/vectors.py::_atomic_write \
  'os.fsync -> os.replace(_, path)'
```

To ask whether a wrapper returns the value of a call, use `return` in the
contract. In Ken, `Lookup.__getitem__` stores `self.lookup(key)`, raises when
that value is absent, and returns it on the normal route:

```sh
ken code-check src/ken/structural_store/graph_source.py::Lookup.__getitem__ \
  'return self.lookup(key)'
```

KQL2 finds the produced-to-returned value relation across the terminal raise
guard; the path analysis independently reports the producer at line 19 and
normal return at line 22. A caught raise inside `try` remains unsupported.

`return_analysis.status` reports `all_paths_return_value`, `missing_path`, or
`unknown`. Its producer and return locations identify the source witness;
`return save(user)` also checks the named arguments. In a wrapper containing
`value = save(user); return value`, the local alias preserves the witness.
`save(user); return 0` and `value = save(user); value = 0; return value` have a
missing path. A branch that returns `0` on one side also has a missing path
unless a matching `--when` condition selects the forwarding side.

The return question also works across a unique local helper. Given
`forward(value): return save(value)` and
`api(user): return forward(user)`, the path evidence points to `save` inside
`forward` and to the return in `api`; the root argument `user` is tracked
through `value`. If another branch returns `delegate(user)`, only that branch
remains uncertain. A declared `--effect-prior delegate=0.35` then gives a
modeled 0.35 chance for the all-path obligation, conditional on that assumption.
The probability is not learned from the code. `dependencies` records the hashes
of followed imported files for review.

Both path interpreters can also follow a same-class `self.__private(...)`
method when the class is locally unique, undecorated, has no base class or
visible method-slot write, and the receiver still denotes the original
instance. The result exposes a `source_local_private_method_binding` premise
with the method and call site. It is a source-level premise: deliberate
external mutation of Python's mangled slot is outside this model. A normal
public method such as `self._check_time()` remains dynamically dispatchable.
For a unique, undecorated public method in a class with a stable local
definition, the call-path interpreter now checks its body under an explicit
dispatch choice. It does not claim that the local body ran. Given:

```python
import os

class Writer:
    def save(self, src, dst):
        self.publish(src, dst)

    def publish(self, src, dst):
        os.replace(src, dst)
```

`ken code-check writer.py::Writer.save 'os.replace(src, dst)'` reports
`unknown`. Its `conditional_matches` locates `os.replace` inside
`Writer.publish` with a guard naming the local dispatch choice;
`matched_locations` contains only unconditional evidence. `next_checks`
shows that selecting the local method gives bounds 1–1, while selecting
another implementation leaves 0–1. An investigator can state an assumption:

```sh
ken code-check writer.py::Writer.save 'os.replace(src, dst)' \
  --effect-prior Writer.publish=0.7
```

The resulting 0.7–1 interval means the local method is assumed to be selected
with probability 0.7 and the behavior of any other implementation is unknown.
It is not a probability learned from the source, nor the probability that
`os.replace` succeeds. The full effect key is
`dispatch:Writer.publish@writer.py:5`; it is useful when the same method has
multiple call sites. The distinct `override:publish@writer.py:5` effect asks
whether a different implementation calls the target; inspecting the local
method does not answer that question. A decorator, visible method-slot
rebinding, complex body, or unsupported control flow keeps the local method a
candidate rather than a conditional proof. Nested private delegation retains
the dispatch choice. The finite-world model treats that choice as stable for
one source call site across its analyzed paths; rebinding it between runtime
invocations is outside the model.
In this repository, `Store.save_rule` calls `self.write`, whose local body
calls `os.replace`. The following real command returns `unknown` with a
0.7–1 interval; the compact answer shows one conditional match in
`Store.write`, even though earlier `self.path` calls have their own dispatch
choices:

```sh
ken code-check src/ken/checks/store.py::Store.save_rule os.replace \
  --effect-prior Store.write=0.7
```

Nested calls inside expressions are retained as opaque possible effects, so
they need not erase a later source witness. Their effects remain unknown until
inspected. Equivalent guard combinations on the same witness are simplified;
distinct possible call sites remain separate.

The call-path interpreter also handles annotated and augmented assignments.
It preserves supported calls in an assignment's value while forgetting aliases
or values that the assignment may change. `for` and `while` bodies are opaque
regions: they retain unknown effects and possible function returns, forget
possibly written bindings, and keep the possibility that `break` skips `else`.
A call in the body is not a guaranteed witness because the loop may be empty.
A later explicit call can still establish a normal-path obligation when no
possible return or receiver change defeats it. This support does not extend
the separate return-value interpreter or establish loop-body runtime behavior.

For example, the current `rebuild_finding_graph` source establishes
`recompute_finding_edges -> set_meta` despite earlier loops. It does not establish
SQLite effects. The more precise contract
`recompute_finding_edges -> set_meta(conn, _META_VERSION, _)` now binds the key
to its unique literal definition in that source module. A definition, its value
and location appear as a `source_local_constant_binding` premise. Matching is
by the admitted value, so two constants with equal values are interchangeable
for this filter. The comparison assumes no external mutation or reflection
beyond the followed source; visible writes invalidate the premise. Reassigned,
shadowed, imported or computed definitions are not admitted. Both call and
return-value arguments use this binding rule. `_` leaves an argument unchecked,
and expressions such as `str(FINDINGS_GRAPH_VERSION)` remain unsupported.
The inverse order remains unknown, which neither affirms nor negates that
inverse contract. See the [source replay](../validation/code-constants-2026-09-23/README.md).

For `Fingerprints._file` in Ken, `ken code-check ... time.monotonic` stays
`unknown`, but `method_candidates` points to `Fingerprints._check_time` at its
declaration and the two call sites. Reading that method is the next useful
step; its presence alone does not show which implementation ran. The compact
answer prioritizes such candidates and control-flow blockers. Use `--full`
for all unresolved effects and path traces.

`candidate_return` separately reports whether KQL2 found a direct produced-to-
returned-value relation in the same function using the call's basename. It
does not check arguments or receiver identity; the path analysis does. This
candidate may be `unknown` when KQL2's value flow or coverage is incomplete,
even when the bounded source interpreter witnesses the return. Neither
observation should silently override the other. An absent direct candidate
does not rule out a target call inside a helper or a flow across control
structures that this BODY pattern does not cover; `absence_exhaustive` is
therefore false even when source coverage is complete. A returned unresolved helper
gets a `callee_return_value_effect` in `next_checks`; a prior for that site
means the investigator's assumed chance that its returned value comes from
the requested target. The return interpreter follows unique, undecorated
project-local helpers and the constrained private-method case above. It also
checks a unique public method body under a dispatch choice. For a wrapper
`return self.forward(user)` whose local `forward(item)` returns
`persist(item)`, this command gives a 0.7–1 bound:

```sh
ken code-check writer.py::Writer.save 'return persist(user)' \
  --effect-prior Writer.forward=0.7
```

`conditional_producers` identifies the `persist` call and its required local
dispatch; `producer_locations` contains only unconditional witnesses. The
same condition is retained through `value = self.forward(user); return value`
and through private delegation. A different runtime implementation remains
unknown. If the wrapper discards that value and returns a constant, both
dispatch alternatives fail the return-value contract. Shadowed names, cycles,
transformations, loops, and `try/finally` remain uncertain. Unsupported control
flow stays `unknown` rather than
becoming a proof.

An unresolved helper is **not** assumed to satisfy or violate a contract.
For `def save(src, dst, publish): publish(src, dst)`, this asks what follows
if an investigator estimates a 60% chance that `publish` calls `os.replace`:

```sh
ken code-check writer.py::save 'os.replace(src, dst)' \
  --effect-prior publish=0.6
```

With no other possible caller, the modeled chance that every normal path has
the target call is 0.6. For `os.fsync -> os.replace(src, dst)` over the same
function, the range is 0–0.6: calling `replace` does not establish that the
helper called `fsync` first. If another unresolved helper could also call the
target, the result instead reports an interval and names the calls that keep
it wide. The priors are explicit investigator assumptions, independent across
distinct effect keys; they are not learned bug probabilities. When two
unresolved call sites share a short name, use the full keys shown in
`unresolved_effects` (for example, `method:publish@src/writer.py:42`) rather
than an ambiguous shorthand. Each source site has its own world variable;
the independence of supplied priors across sites is a modeling assumption,
not a fact inferred from the code.

Without a prior, an unresolved call remains unknown. `next_checks` points to
up to three callees worth inspecting and shows conditional probability bounds
if each one does or does not make the target call. For a lone `publish(src,
dst)` call, confirming that `publish` makes the target call changes the bound
to 1–1; confirming that it does not changes the bound to 0–0. These are
conditional code-world results, not inferred probabilities. If other calls or
call order remain unknown, the bounds stay wider.

The response keeps several conclusions separate:

- `candidate_call` is KQL2's direct same-function observation. Its absence
  does not rule out a call inside a followed helper. Its `owner_locations`
  point to candidate functions, while `matched_locations` in the path result
  point to unconditional followed calls that satisfy the contract.
  `conditional_matches` names calls witnessed only under a stated dispatch
  choice.
- `producer_locations` and `returned_locations` show unconditional value-flow
  witnesses. `conditional_producers` and `conditional_returned_locations`
  attach the dispatch choices needed for a public method's returned value.
- `resolved_evidence` counts path witnesses found in source. Its
  `analysis_complete` field means the modeled path traversal finished, not
  that all external helper effects are known.
- `status` is `all_paths_called` for a call contract or
  `all_paths_return_value` for a return contract, otherwise `missing_path` or
  `unknown` under the open-world source model. An exact probability or
  `probability_bounds` additionally depends on declared effect priors.
- `uncertain_calls` and `order_uncertainty` locate missing relationships.
  `next_checks` prioritizes unresolved target-call effects that could narrow
  the finite-world result. `--full` exposes the traces needed to review them.

The analysis is bounded to normal completion paths. It does not prove calls
succeed at runtime, model exceptional exits completely, infer effects from
unavailable libraries, or learn prior probabilities. Unsupported syntax and
incomplete KQL2 coverage remain explicit uncertainty. Read the implicated
code and reproduce behavior before reporting a bug. Source files and followed
imports are hashed, and files outside the selected project root are rejected.
Generator functions are explicitly unknown for call and return obligations:
calling one creates a generator object without executing its body, and partial
consumption may never reach a later `close()` or `return` statement.
Decorated entry functions are unknown because a decorator can replace the body.
Async entry functions remain unknown until an explicit awaited-execution
contract is available; calling one only creates a coroutine object.
An assignment that changes the receiver *after* a witnessed unordered target
call cannot erase that witness; before the call, it remains uncertain. Thus
`IRCache.close` proves `self.conn.close()` on its guarded branch even though it
subsequently resets `self.conn` to `None`.
The current interpreter caps one question at 64 modeled paths and eight
delegation levels; the finite-world calculation enumerates at most 12
nontrivial declared priors and undeclared dispatch choices together. Known-true
and known-false assumptions do not consume that enumeration limit. A cap
at the root produces an unknown result rather than a proof. If a nested local
helper exceeds the path budget, its body becomes an opaque effect and the
caller can continue. That effect cannot supply a guaranteed target-call witness.

The public Python entry point is
`CodeInvestigation.from_python_symbol(project_root=..., path=..., symbol=...).check(contract)`
in `ken.code_reasoning`; `CodeDiscovery(project_root).find(contract)` discovers
candidate functions first. `CallContract` and `ReturnContract` own the two
user-facing contract forms;
`PythonSymbol` owns source identity; `KqlProbe` owns direct KQL2 evidence;
`PythonCallInventory` narrows the file inventory and `KqlCandidateCatalog`
binds search rows to current source symbols;
`LocalMethodCatalog` separates candidate method declarations from locally
stable private bindings;
`ModuleConstants` admits scoped literal definitions and withdraws premises
contradicted by writes in followed helpers;
`CallPaths`/`PythonCallInterpreter` and `ReturnPaths`/`PythonReturnInterpreter`
own their respective source traversals; `StatementRegion` collects possible
writes and exits when a call-path region is opaque; `ObligationWorldModel` owns shared
probability bounds. `LocalFunctionCatalog` identifies uniquely bound helpers
for return analysis, and `LocalImportResolver` pins imported source. These roles keep a new contract
operator or source-language adapter from having to change the KQL2 evidence
or world calculation. The linguistic graph experiment remains separate and
is not imported by the packaged tool.
