"""An ordinary file action finds memory without a topic in the user prompt."""

from argparse import Namespace
import json

import pytest

from ken import hook
from ken.daemon.server import DaemonState, _handle_session_start, _handle_tool_pre
from ken.memory import remember


@pytest.fixture
def session(tmp_path, monkeypatch):
    # No embeddings, ranking model, network or executing historical commands.
    monkeypatch.setattr('ken.memory.get_embedder', lambda: None)
    (tmp_path / '.ken').mkdir()
    (tmp_path / 'src').mkdir()
    (tmp_path / 'other').mkdir()
    for path in ('src/client.py', 'other/client.py', 'src/store.py'):
        (tmp_path / path).write_text('VERSION = 1\n')
    state = DaemonState(tmp_path, 'test')
    state.session_start('coding')
    yield state
    state.conn.close()


def save(state, topic='http retry', path='src/client.py', *, kind='observation', absolute=False):
    result = remember(state.conn, topic, 'HTTPError llega al reintento por heredar URLError.',
        project_root=state.project_root,
        anchors={'file': str(state.project_root / path) if absolute else path},
        justification={'kind': kind, 'rationale': 'Conclusión previa de una investigación del cliente.',
                       'recheck': 'Revisar el manejador de excepciones vigente.', 'evidence': [{'path': path}],
                       'assumptions': ['Sólo el cliente local.']})
    assert result['ok'], result


def read(state, path='src/client.py', **options):
    return _handle_tool_pre(state, {'session_id': 'coding', 'tool': 'Read',
                                   'input': {'file_path': path}, 'include_context': True, **options})


@pytest.mark.parametrize('absolute_anchor', [False, True])
def test_action_delivers_whole_answer_without_topic_query(session, absolute_anchor):
    save(session, absolute=absolute_anchor)
    block = read(session, str(session.project_root / 'src/client.py'))
    assert 'HTTPError llega al reintento por heredar URLError.' in block
    assert 'Fuentes declaradas sin cambios' in block
    assert 'Sólo el cliente local.' in block
    assert read(session) == ''


def test_relevant_edit_reopens_view_but_unrelated_edit_does_not(session):
    save(session)
    first = read(session)
    assert 'HTTPError llega al reintento' in first
    (session.project_root / 'other/client.py').write_text('VERSION = 2\n')
    assert read(session) == ''
    (session.project_root / 'src/client.py').write_text('VERSION = 2\n')
    block = read(session)
    assert 'REVISAR:' in block and 'http retry' in block and 'src/client.py' in block
    assert 'HTTPError llega al reintento' not in block
    assert len(block) < len(first)
    assert read(session) == ''


def test_evidence_paths_do_not_displace_the_reusable_answer(session):
    from ken.knowledge.delivery import for_paths
    from ken.knowledge.records import for_topics

    evidence = []
    directory = session.project_root.joinpath(*["archived-proof-" + "x" * 90] * 4)
    directory.mkdir(parents=True)
    for i in range(4):
        path = directory / f"receipt-{i}.json"
        path.write_text("{}")
        evidence.append({"path": path.relative_to(session.project_root).as_posix()})
    conclusion = "The worker closes SQLite only after its last operation."
    saved = remember(session.conn, "worker lifetime", conclusion,
        project_root=session.project_root, anchors={"file": "src/client.py"},
        justification={"kind": "observation", "rationale": "Recorded lifecycle review.", "evidence": evidence,
                       "assumptions": ["One lifecycle controller."]})
    assert saved["ok"], saved
    block = for_paths(session.conn, ["src/client.py"], root=session.project_root, max_chars=500)
    assert conclusion in block and "One lifecycle controller." in block
    assert "Fuentes declaradas sin cambios" in block and 'detail="full"' in block
    assert not any(item["path"] in block for item in evidence)
    record = for_topics(session.conn, ["worker lifetime"], root=session.project_root)[0]
    assert {item["path"] for item in record["justification"]["evidence"]} == {item["path"] for item in evidence}


def test_compaction_keeps_stale_conclusion_behind_explicit_recall(session):
    save(session)
    assert read(session)
    (session.project_root / 'src/client.py').write_text('VERSION = 2\n')
    assert 'REVISAR:' in read(session)
    _, restored = _handle_session_start(session, 'coding', source='compact')
    assert 'HTTPError llega al reintento' not in restored
    assert 'Conclusión anterior' in restored and 'REVISAR:' in restored
    assert 'ken_recall' in restored and 'detail="full"' in restored


def test_first_stale_delivery_does_not_suppress_a_later_current_answer(session):
    save(session)
    path = session.project_root / 'src/client.py'
    path.write_text('VERSION = 2\n')
    stale = read(session)
    assert 'HTTPError llega al reintento' not in stale
    assert 'REVISAR:' in stale and 'ken_recall' in stale
    assert read(session) == ''
    # Withheld content was never in context. Restoring the declared version
    # must deliver the entire conclusion, not just a freshness notification.
    path.write_text('VERSION = 1\n')
    fresh = read(session)
    assert 'HTTPError llega al reintento por heredar URLError.' in fresh
    assert 'Sólo el cliente local.' in fresh
    assert read(session) == ''


def test_new_conditions_require_a_whole_answer_even_when_conclusion_is_same(session):
    save(session)
    assert read(session)
    assert remember(session.conn, 'http retry', 'HTTPError llega al reintento por heredar URLError.',
        project_root=session.project_root, anchors={'file': 'src/client.py'},
        justification={'kind': 'observation', 'rationale': 'Alcance corregido.',
                       'evidence': [{'path': 'src/client.py'}],
                       'assumptions': ['Sólo para el POST de inicio.']})['ok']
    block = read(session)
    assert 'HTTPError llega al reintento' in block
    assert 'Sólo para el POST de inicio.' in block


def test_notice_that_does_not_fit_remains_pending(session):
    from ken.knowledge.context import render_brief

    save(session)
    seen = {}
    assert render_brief(session.conn, ['http retry'], root=session.project_root, seen=seen)
    previous = dict(seen)
    (session.project_root / 'src/client.py').write_text('VERSION = 2\n')
    assert render_brief(session.conn, ['http retry'], root=session.project_root, seen=seen, max_chars=20) == ''
    assert seen == previous
    block = render_brief(session.conn, ['http retry'], root=session.project_root, seen=seen)
    assert 'REVISAR:' in block and 'HTTPError llega' not in block


def test_changed_check_outcome_is_not_hidden_by_a_validity_notice(session, monkeypatch):
    from ken.knowledge.context import render_brief

    hit = {'topic': 'public contract', 'content': 'La condición debe comprobarse.',
           'justification': {'kind': 'observation'},
           'validity': {'state': 'unchanged', 'checks': [
               {'status': 'passed', 'validity': 'unchanged', 'rules': ['contract']} ]}}
    monkeypatch.setattr('ken.knowledge.context.for_topics', lambda *args, **kwargs: [hit])
    seen = {}
    assert 'La condición' in render_brief(session.conn, ['public contract'], root=session.project_root, seen=seen)
    hit['validity']['checks'][0]['status'] = 'failed'
    block = render_brief(session.conn, ['public contract'], root=session.project_root, seen=seen)
    assert 'La condición' in block and 'Comprobación: failed' in block


def test_same_basename_is_not_same_file(session):
    save(session)
    assert read(session, 'other/client.py') == ''
    assert read(session, 'client.py') == ''
    assert read(session)


@pytest.mark.parametrize('directory', ['src', 'other/../src'])
def test_shell_working_directory_selects_the_actual_file(session, directory):
    save(session)
    block = _handle_tool_pre(session, {'session_id': 'coding', 'tool': 'functions.exec_command',
        'include_context': True, 'input': {'cmd': 'cat client.py', 'workdir': directory}})
    assert 'HTTPError llega al reintento' in block


def test_hook_subdirectory_is_preserved_for_read_action(session, monkeypatch, capsys):
    save(session)
    monkeypatch.setattr(hook._paths, 'find_project_root', lambda: session.project_root)
    monkeypatch.setattr(hook, '_read_hook_payload', lambda: {
        'session_id': 'coding', 'tool_name': 'Read', 'tool_input': {'file_path': 'client.py'},
        'cwd': str(session.project_root / 'src')})
    monkeypatch.setattr(hook.client, 'post', lambda root, path, body: {'context_block': _handle_tool_pre(session, body)})
    hook.dispatch_hook(Namespace(hook_cmd='tool-call', phase='pre'))
    assert 'HTTPError llega al reintento' in capsys.readouterr().out


def test_legacy_client_does_not_consume_undelivered_memory(session):
    save(session)
    assert read(session, include_context=False) == ''
    assert read(session)


def test_deleted_file_keeps_warning_and_hypothesis_label(session):
    save(session, kind='hypothesis')
    (session.project_root / 'src/client.py').unlink()
    block = read(session)
    assert 'Hipótesis' in block and 'REVISAR:' in block


def test_multi_file_patch_delivers_both_file_memories(session):
    save(session)
    save(session, 'store constraint', 'src/store.py')
    block = _handle_tool_pre(session, {'session_id': 'coding', 'tool': 'functions.apply_patch',
        'include_context': True, 'input': '*** Begin Patch\n*** Update File: src/client.py\n@@\n'
        '*** Update File: src/store.py\n@@\n*** End Patch'})
    assert 'http retry' in block and 'store constraint' in block


def test_compaction_redelivers_previously_used_memory(session):
    save(session)
    assert read(session)
    _, block = _handle_session_start(session, 'coding', source='compact')
    assert 'HTTPError llega al reintento por heredar URLError.' in block


def test_directories_and_other_workspaces_are_not_candidates(session, tmp_path):
    save(session)
    assert read(session, 'src') == ''
    assert read(session, str(tmp_path.parent / 'client.py')) == ''
    assert read(session, '.ken/ken.db') == ''


def test_hook_shim_delivers_context_in_host_protocol(session, monkeypatch, capsys):
    save(session)
    monkeypatch.setattr(hook._paths, 'find_project_root', lambda: session.project_root)
    monkeypatch.setattr(hook, '_read_hook_payload', lambda: {
        'session_id': 'coding', 'tool_name': 'Read', 'tool_input': {'file_path': 'src/client.py'}})
    def transport(root, path, body):
        assert root == session.project_root and path == '/tools/pre'
        return {'context_block': _handle_tool_pre(session, body)}
    monkeypatch.setattr(hook.client, 'post', transport)
    assert hook.dispatch_hook(Namespace(hook_cmd='tool-call', phase='pre')) == 0
    output = json.loads(capsys.readouterr().out)['hookSpecificOutput']
    assert output['hookEventName'] == 'PreToolUse'
    assert 'HTTPError llega al reintento' in output['additionalContext']


def test_delivery_failure_does_not_block_tool_or_lose_trace(session, monkeypatch):
    def broken(*args, **kwargs):
        raise RuntimeError('memory unavailable')
    monkeypatch.setattr('ken.knowledge.delivery.for_paths', broken)
    assert read(session) == ''
    row = session.conn.execute("SELECT content FROM cr_contexts WHERE kind='tool_call_pre'").fetchone()
    assert json.loads(row[0])['target'] == 'src/client.py'


def test_many_stale_dependencies_produce_a_bounded_review_reference():
    from ken.knowledge.context import brief_text

    record = {'topic': 'Diagnóstico del cliente', 'kind': 'observation',
              'conclusion': 'No reintentar respuestas HTTP sin revisar la causa.',
              'validity': {'state': 'stale', 'issues': [f'src/dependency_{i}.py: dependency check budget exhausted' for i in range(12)]},
              'sources': [{'path': f'src/dependency_{i}.py'} for i in range(12)], 'assumptions': []}
    text = brief_text(record)
    assert len(text) < 800
    assert record['conclusion'] not in text and 'REVISAR:' in text
    assert '10 incidencias más' in text
    assert 'detail="full"' in text


@pytest.mark.parametrize('state', ['stale', 'unknown'])
def test_automatic_rank_brief_withholds_unreviewed_conclusions_but_recall_keeps_them(state):
    from ken.knowledge.context import answer, brief_line, brief_text

    hit = {'topic': 'previous bug', 'content': 'This version closes a live connection.',
           'justification': {'kind': 'observation', 'recheck': 'Check the current worker lifetime.'},
           'validity': {'state': state, 'issues': ['src/worker.py']}}
    record = answer(hit)
    assert record['conclusion'] == hit['content']
    assert hit['content'] not in brief_text(record)
    assert hit['content'] not in brief_line(hit)
    assert 'REVISAR:' in brief_text(record) and 'Check the current worker lifetime.' in brief_text(record)
