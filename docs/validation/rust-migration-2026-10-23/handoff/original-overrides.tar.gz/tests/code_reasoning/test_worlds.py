"""Effect-prior names must identify one reproducible code-world variable."""

from __future__ import annotations

import pytest

from ken.code_reasoning.call_worlds import CallWorldModel
from ken.code_reasoning.path_interpreter import CallPath


def _path(effect):
    """Make one normal path dependent on a single unresolved callee."""
    return CallPath(frozenset(), possible=frozenset({effect}))


def test_same_named_imports_require_full_prior_keys():
    """One shorthand must not silently assign independent imported effects."""
    paths = [
        _path("function:external@pkg/a.py"),
        _path("function:external@pkg/b.py"),
    ]
    with pytest.raises(ValueError, match="Ambiguous effect prior"):
        CallWorldModel(paths, {"external": 0.6})
    worlds = CallWorldModel(
        paths,
        {
            "function:external@pkg/a.py": 0.4,
            "function:external@pkg/b.py": 0.7,
        },
    )
    assert worlds.probability()[0] == pytest.approx(0.28)


def test_duplicate_alias_and_full_key_do_not_override_each_other():
    """A single effect cannot acquire two incompatible priors by accident."""
    with pytest.raises(ValueError, match="both names"):
        CallWorldModel(
            [_path("function:publish")],
            {"publish": 0.6, "function:publish": 0.8},
        )


def test_boolean_prior_is_not_a_probability():
    """JSON true must not be accepted as the numeric probability one."""
    with pytest.raises(ValueError, match="probabilities"):
        CallWorldModel([_path("function:publish")], {"publish": True})


def test_known_effects_do_not_consume_the_stochastic_world_limit():
    """Observed true/false effects need no Bernoulli enumeration."""
    effects = [f"function:step{i}" for i in range(14)]
    paths = [_path(effect) for effect in effects]
    priors = {effect: 0.5 for effect in effects[:12]}
    priors[effects[12]] = 1.0
    priors[effects[13]] = 1.0
    bounds, _ = CallWorldModel(paths, priors).probability_bounds()
    assert bounds == pytest.approx((0.5**12, 0.5**12))

    priors[effects[13]] = 0.0
    bounds, _ = CallWorldModel(paths, priors).probability_bounds()
    assert bounds == (0.0, 0.0)


def test_guarded_dispatch_uses_local_witness_without_claiming_global_proof():
    """A local method body proves a call only if runtime dispatch selects it."""
    dispatch = "dispatch:Writer.publish@writer.py:4"
    override = "override:publish@writer.py:4"
    paths = [
        CallPath(frozenset(), called=True, guards=((dispatch, True),)),
        CallPath(
            frozenset(),
            possible=frozenset({override}),
            guards=((dispatch, False),),
        ),
    ]
    worlds = CallWorldModel(paths, {"Writer.publish": 0.7})
    assert worlds.status() == "unknown"
    assert worlds.probability_bounds()[0] == pytest.approx((0.7, 1.0))
    assert CallWorldModel(paths).probability_bounds()[0] == (0.0, 1.0)
    fully_assumed = CallWorldModel(
        paths, {"Writer.publish": 0.7, "publish": 0.2}
    )
    assert fully_assumed.probability()[0] == pytest.approx(0.76)


def test_guarded_dispatch_can_expose_a_conditional_counterexample():
    """The local method can fail while another implementation remains open."""
    dispatch = "dispatch:Writer.publish@writer.py:4"
    override = "override:publish@writer.py:4"
    paths = [
        CallPath(frozenset(), guards=((dispatch, True),)),
        CallPath(
            frozenset(),
            possible=frozenset({override}),
            guards=((dispatch, False),),
        ),
    ]
    worlds = CallWorldModel(paths, {"Writer.publish": 0.7})
    assert worlds.status() == "unknown"
    assert worlds.probability_bounds()[0] == pytest.approx((0.0, 0.3))


def test_one_dispatch_world_is_shared_by_all_paths_using_its_site():
    """A repeated guard denotes one choice, rather than independent coins."""
    dispatch = "dispatch:Writer.publish@writer.py:4"
    paths = [
        CallPath(frozenset(), called=True, guards=((dispatch, True),)),
        CallPath(frozenset(), called=True, guards=((dispatch, True),)),
        CallPath(frozenset(), guards=((dispatch, False),)),
    ]
    assert CallWorldModel(paths, {"Writer.publish": 0.8}).probability_bounds()[0] == (
        0.8,
        0.8,
    )
