"""A returned call value is a different obligation from merely making a call."""

from __future__ import annotations

import json

import pytest

from ken.cli import main
from ken.code_reasoning import CodeInvestigation


def _question(tmp_path, body):
    """Bind a current wrapper to one small source fixture."""
    (tmp_path / "writer.py").write_text(
        f"def produce(user):\n    return user\ndef wrapper(user):\n    {body}\n"
    )
    return CodeInvestigation.from_selector(project_root=tmp_path, selector="wrapper")


@pytest.mark.parametrize(
    ("body", "return_line", "producer_line"),
    [
        ("return produce(user)", 4, 4),
        ("value = produce(user)\n    return value", 5, 4),
        ("value = produce(user)\n    alias = value\n    return alias", 6, 4),
    ],
)
def test_direct_and_aliased_returns_are_witnessed(
    tmp_path, body, return_line, producer_line
):
    """KQL2 and source paths agree on direct value forwarding."""
    result = _question(tmp_path, body).check("return produce(user)")
    analysis = result["return_analysis"]
    assert result["schema"] == "ken-code-return-investigation/1"
    assert result["candidate_return"]["state"] == "present"
    assert analysis["status"] == "all_paths_return_value"
    assert analysis["returned_locations"] == [
        {"path": "writer.py", "line": return_line}
    ]
    assert analysis["producer_locations"] == [
        {"path": "writer.py", "line": producer_line}
    ]


def test_discard_and_overwrite_are_counterexamples(tmp_path):
    """Calling produce is insufficient when its value does not reach return."""
    for body in (
        "produce(user)\n    return 0",
        "value = produce(user)\n    value = 0\n    return value",
    ):
        result = _question(tmp_path, body).check("return produce(user)")
        assert result["candidate_return"]["state"] == "absent"
        assert result["return_analysis"]["status"] == "missing_path"
        assert result["return_analysis"]["probability_all_paths_return_value"] == 0.0


def test_unresolved_callee_still_has_a_local_return_witness(tmp_path):
    """A call's source result flows to return without resolving its target."""
    (tmp_path / "writer.py").write_text(
        "from external_module import produce\n"
        "def wrapper(user):\n"
        "    return produce(user)\n"
    )
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    ).check("return produce(user)")
    assert result["candidate_return"]["state"] == "present"
    assert result["return_analysis"]["status"] == "all_paths_return_value"


def test_local_helper_forwards_the_value_and_root_argument(tmp_path):
    """A known helper can discharge a wrapper's return obligation."""
    (tmp_path / "writer.py").write_text(
        "def produce(user):\n    return user\n"
        "def forward(value):\n    return produce(value)\n"
        "def wrapper(user):\n    candidate = user\n    return forward(candidate)\n"
    )
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    ).check("return produce(user)")
    assert result["candidate_return"]["state"] == "absent"
    assert result["candidate_return"]["absence_exhaustive"] is False
    analysis = result["return_analysis"]
    assert analysis["status"] == "all_paths_return_value"
    assert analysis["producer_locations"] == [{"path": "writer.py", "line": 4}]
    assert analysis["returned_locations"] == [{"path": "writer.py", "line": 7}]


def test_local_helper_counterexamples_include_wrong_argument_and_branch(tmp_path):
    """A helper call alone does not imply the requested value is returned."""
    (tmp_path / "writer.py").write_text(
        "def produce(user):\n    return user\n"
        "def forward(value):\n"
        "    if value is None:\n        return 0\n"
        "    return produce(value)\n"
        "def wrapper(user):\n    return forward(user)\n"
    )
    question = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    )
    assert question.check("return produce(user)")["return_analysis"]["status"] == (
        "missing_path"
    )
    (tmp_path / "writer.py").write_text(
        "def produce(user):\n    return user\n"
        "def forward(value):\n    return produce(value)\n"
        "def wrapper(user, other):\n    return forward(other)\n"
    )
    different_argument = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    ).check("return produce(user)")
    assert different_argument["return_analysis"]["status"] == "missing_path"


def test_project_imported_helper_is_followed_and_versioned(tmp_path):
    """An explicit local import provides a source-backed return witness."""
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "helper.py").write_text(
        "def forward(value):\n    return produce(value)\n"
    )
    (package / "writer.py").write_text(
        "from .helper import forward\ndef wrapper(user):\n    return forward(user)\n"
    )
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="pkg/writer.py::wrapper"
    ).check("return produce(user)")
    analysis = result["return_analysis"]
    assert analysis["status"] == "all_paths_return_value"
    assert analysis["producer_locations"] == [{"path": "pkg/helper.py", "line": 2}]
    assert analysis["dependencies"][0]["path"] == "pkg/helper.py"


def test_recursive_helper_remains_unknown(tmp_path):
    """Cycles must not become a false forwarding proof."""
    (tmp_path / "writer.py").write_text(
        "def forward(value):\n    return forward(value)\n"
        "def wrapper(user):\n    return forward(user)\n"
    )
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    ).check("return produce(user)")
    assert result["return_analysis"]["status"] == "unknown"
    assert "delegation_cycle_or_depth" in result["return_analysis"]["unsupported"]


@pytest.mark.parametrize(
    "source",
    [
        (
            "def forward(value):\n    return produce(value)\n"
            "def wrapper(user, forward):\n    return forward(user)\n"
        ),
        (
            "def decorate(fn):\n    return lambda value: 0\n"
            "@decorate\ndef forward(value):\n    return produce(value)\n"
            "def wrapper(user):\n    return forward(user)\n"
        ),
    ],
)
def test_shadowed_or_decorated_helper_is_not_trusted(tmp_path, source):
    """A known name alone does not establish which function executes."""
    (tmp_path / "writer.py").write_text(source)
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    ).check("return produce(user)")
    assert result["return_analysis"]["status"] == "unknown"


def test_known_helper_and_unknown_callee_share_one_code_world(tmp_path):
    """Exact helper evidence removes only the uncertainty it resolves."""
    (tmp_path / "writer.py").write_text(
        "def produce(user):\n    return user\n"
        "def forward(value):\n    return produce(value)\n"
        "def wrapper(user, delegate, choose):\n"
        "    if choose:\n        return forward(user)\n"
        "    return delegate(user)\n"
    )
    question = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    )
    initial = question.check("return produce(user)")["return_analysis"]
    assert initial["status"] == "unknown"
    assert initial["resolved_evidence"]["witnessed_paths"] == 1
    assert initial["unresolved_effects"] == ["function:delegate@writer.py:8"]
    conditioned = question.check(
        "return produce(user)", effect_priors={"delegate": 0.35}
    )["return_analysis"]
    assert conditioned["probability_all_paths_return_value"] == pytest.approx(0.35)
    assert conditioned["probability_model"] == "independent_call_site_effects"


def test_branch_precondition_selects_the_forwarding_path(tmp_path):
    """A conditional return is not silently generalized to all callers."""
    (tmp_path / "writer.py").write_text(
        "def produce(user):\n    return user\n"
        "def wrapper(user, enabled):\n"
        "    if enabled:\n        return produce(user)\n"
        "    return 0\n"
    )
    question = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    )
    assert question.check("return produce(user)")["return_analysis"]["status"] == (
        "missing_path"
    )
    selected = question.check("return produce(user)", when={"enabled": True})[
        "return_analysis"
    ]
    assert selected["status"] == "all_paths_return_value"
    assert selected["when"] == {"enabled": True}


def test_unknown_returning_helper_has_conditional_worlds(tmp_path):
    """A delegated return stays unknown until its effect is inspected."""
    (tmp_path / "writer.py").write_text(
        "def wrapper(user, delegate):\n    return delegate(user)\n"
    )
    question = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="wrapper"
    )
    initial = question.check("return produce(user)")["return_analysis"]
    assert initial["status"] == "unknown"
    assert initial["probability_bounds"] == {"lower": 0.0, "upper": 1.0}
    assert initial["next_checks"] == [
        {
            "kind": "callee_return_value_effect",
            "effect": "function:delegate@writer.py:2",
            "locations": [{"path": "writer.py", "line": 2}],
            "if_return_value_absent": {"lower": 0.0, "upper": 0.0},
            "if_return_value_present": {"lower": 1.0, "upper": 1.0},
        }
    ]
    conditioned = question.check(
        "return produce(user)", effect_priors={"delegate": 0.6}
    )["return_analysis"]
    assert conditioned["probability_all_paths_return_value"] == pytest.approx(0.6)


def test_cli_and_mcp_accept_the_return_contract(tmp_path, capsys, monkeypatch):
    """Humans and agents use the same return-value question."""
    from ken.mcp import server

    _question(tmp_path, "return produce(user)")
    assert (
        main(["code-check", "wrapper", "return produce(user)", "--root", str(tmp_path)])
        == 0
    )
    cli = json.loads(capsys.readouterr().out)
    monkeypatch.setattr(server, "_PROJECT_ROOT", tmp_path)
    mcp = server.ken_code_check("wrapper", "return produce(user)")
    assert cli["return_analysis"]["status"] == "all_paths_return_value"
    assert mcp["return_analysis"]["status"] == "all_paths_return_value"


def test_unsupported_control_flow_never_becomes_a_return_proof(tmp_path):
    """Try/finally requires more modeling before proving all returns."""
    result = _question(
        tmp_path,
        "try:\n        pass\n    finally:\n        return produce(user)",
    ).check("return produce(user)")
    assert result["return_analysis"]["status"] == "unknown"
    assert "Try:4" in result["return_analysis"]["unsupported"]
