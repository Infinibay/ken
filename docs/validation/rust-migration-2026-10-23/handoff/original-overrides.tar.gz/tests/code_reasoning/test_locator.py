"""Short code questions must resolve one live source without guessing."""

from __future__ import annotations

import json

import pytest

from ken.cli import main
from ken.code_reasoning import CodeInvestigation


def test_short_selector_prefers_the_project_source_root(tmp_path, capsys):
    """A validation copy outside src cannot steal a unique source question."""
    source = tmp_path / "src" / "pkg"
    source.mkdir(parents=True)
    (source / "writer.py").write_text("def save():\n    publish()\n")
    copy = tmp_path / "docs" / "validation"
    copy.mkdir(parents=True)
    (copy / "writer.py").write_text("def save():\n    backup()\n")

    assert main(["code-check", "save", "publish", "--root", str(tmp_path)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["source"]["path"] == "src/pkg/writer.py"
    assert result["call_analysis"]["status"] == "all_paths_called"


def test_ambiguous_selector_lists_exact_alternatives(tmp_path, capsys):
    """Duplicate callable names require an explicit file or narrower scope."""
    source = tmp_path / "src"
    source.mkdir()
    (source / "first.py").write_text("def save():\n    publish()\n")
    (source / "second.py").write_text("def save():\n    publish()\n")

    assert main(["code-check", "save", "publish", "--root", str(tmp_path)]) == 2
    error = json.loads(capsys.readouterr().err)["error"]
    assert "Ambiguous" in error
    assert "src/first.py::save" in error
    assert "src/second.py::save" in error


def test_scoped_selector_finds_current_code_outside_src(tmp_path):
    """An explicit scope finds live tests without widening source discovery."""
    (tmp_path / "src").mkdir()
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "helper.py").write_text("def verify():\n    check()\n")
    with pytest.raises(ValueError, match="No Python function"):
        CodeInvestigation.from_selector(project_root=tmp_path, selector="verify")
    result = CodeInvestigation.from_selector(
        project_root=tmp_path, selector="verify", search_path="tests"
    ).check("check")
    assert result["source"]["path"] == "tests/helper.py"
    assert result["call_analysis"]["status"] == "all_paths_called"


def test_scoped_selector_rejects_paths_outside_project(tmp_path):
    """The discovery scope cannot read an arbitrary directory outside root."""
    with pytest.raises(ValueError, match="inside the project"):
        CodeInvestigation.from_selector(
            project_root=tmp_path, selector="save", search_path=".."
        )


def test_short_selector_mcp_uses_the_same_source_resolution(tmp_path, monkeypatch):
    """Agents get the same short-name behavior as the shell interface."""
    from ken.mcp import server

    source = tmp_path / "src"
    source.mkdir()
    (source / "writer.py").write_text("def save():\n    publish()\n")
    monkeypatch.setattr(server, "_PROJECT_ROOT", tmp_path)
    result = server.ken_code_check("save", "publish")
    assert result["source"]["path"] == "src/writer.py"
    assert result["call_analysis"]["status"] == "all_paths_called"
