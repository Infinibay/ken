"""Same-class method calls must be traced only with a safe local binding."""

from __future__ import annotations

import json

import pytest

from ken.cli import main
from ken.code_reasoning import CodeInvestigation


def _check(tmp_path, source: str, contract: str):
    """Investigate Writer.save from one current Python source file."""
    (tmp_path / "writer.py").write_text(source)
    return CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check(contract)


def test_private_method_delegation_witnesses_target_and_root_arguments(tmp_path):
    """The selected class's private method carries the caller's values."""
    result = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.__publish(src, dst)\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert result["candidate_call"]["state"] == "absent"
    assert result["call_analysis"]["status"] == "all_paths_called"
    assert result["call_analysis"]["matched_locations"] == [
        {"path": "writer.py", "line": 6}
    ]
    assert result["call_analysis"]["binding_assumptions"] == [
        {
            "kind": "source_local_private_method_binding",
            "method": "Writer.__publish",
            "path": "writer.py",
            "line": 4,
        }
    ]


def test_private_method_wrong_argument_order_is_not_a_witness(tmp_path):
    """A helper name alone cannot satisfy an argument-specific contract."""
    result = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.__publish(dst, src)\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert result["call_analysis"]["status"] == "missing_path"


def test_public_method_remains_dispatch_uncertainty(tmp_path):
    """A subclass can override a normal same-class method."""
    result = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert result["call_analysis"]["status"] == "unknown"
    assert result["call_analysis"]["method_candidates"] == [
        {
            "method": "Writer.publish",
            "path": "writer.py",
            "declaration_line": 5,
            "call_line": 4,
        }
    ]
    assert result["call_analysis"]["probability_bounds"] == {
        "lower": 0.0,
        "upper": 1.0,
    }
    assert result["call_analysis"]["matched_locations"] == []
    assert result["call_analysis"]["conditional_matches"] == [
        {
            "path": "writer.py",
            "line": 6,
            "when": [
                {
                    "effect": "dispatch:Writer.publish@writer.py:4",
                    "selected": True,
                }
            ],
        }
    ]
    assumed = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)", effect_priors={"Writer.publish": 0.7})
    assert assumed["call_analysis"]["probability_bounds"] == {
        "lower": 0.7,
        "upper": 1.0,
    }
    assert result["call_analysis"]["next_checks"][0]["kind"] == "dispatch_choice"
    assert result["call_analysis"]["next_checks"][1]["kind"] == (
        "alternate_implementation_effect"
    )


def test_public_method_local_violation_bounds_the_other_dispatch(tmp_path):
    """A nonmatching local body contributes no false lower probability."""
    source = (
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(dst, src)\n"
    )
    (tmp_path / "writer.py").write_text(source)
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)", effect_priors={"Writer.publish": 0.7})[
        "call_analysis"
    ]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == pytest.approx({
        "lower": 0.0,
        "upper": 0.3,
    })
    assert analysis["matched_locations"] == []
    assert analysis["conditional_matches"] == []


def test_private_delegation_preserves_a_nested_public_dispatch_choice(tmp_path):
    """A private helper must not discard a public method's source guard."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.__delegate(src, dst)\n"
        "    def __delegate(self, src, dst):\n"
        "        self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)", effect_priors={"Writer.publish": 0.7})[
        "call_analysis"
    ]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == {"lower": 0.7, "upper": 1.0}
    assert analysis["conditional_matches"][0]["line"] == 8


def test_prior_direct_witness_is_not_mislabeled_conditional(tmp_path):
    """A later uncertain dispatch cannot weaken an earlier direct call."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        os.replace(src, dst)\n"
        "        self.publish()\n"
        "    def publish(self):\n"
        "        pass\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)")["call_analysis"]
    assert analysis["status"] == "all_paths_called"
    assert analysis["matched_locations"] == [{"path": "writer.py", "line": 4}]
    assert analysis["conditional_matches"] == []


def test_prior_ordered_witness_is_not_mislabeled_conditional(tmp_path):
    """An order proof keeps its location before a later dispatch choice."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        os.fsync(1)\n"
        "        os.replace(src, dst)\n"
        "        self.publish()\n"
        "    def publish(self):\n"
        "        pass\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.fsync -> os.replace(src, dst)")["call_analysis"]
    assert analysis["status"] == "all_paths_called"
    assert analysis["ordered_locations"] == [{"path": "writer.py", "line": 5}]
    assert analysis["conditional_ordered_locations"] == []


def test_dispatch_check_precedes_equally_informative_context_exit(tmp_path):
    """The source-backed choice should be shown before opaque exit effects."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        with self.lock:\n"
        "            self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)")["call_analysis"]
    assert analysis["next_checks"][0]["kind"] == "dispatch_choice"


def test_two_public_calls_combine_their_declared_dispatch_chances(tmp_path):
    """Distinct call sites provide independent routes to one target call."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.first(src, dst)\n"
        "        self.second(src, dst)\n"
        "    def first(self, src, dst):\n"
        "        os.replace(src, dst)\n"
        "    def second(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check(
        "os.replace(src, dst)",
        effect_priors={"Writer.first": 0.7, "Writer.second": 0.6},
    )["call_analysis"]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == pytest.approx(
        {"lower": 0.88, "upper": 1.0}
    )


def test_nested_expression_before_public_call_remains_a_bounded_effect(tmp_path):
    """An opaque nested call need not erase a later conditional witness."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst, flag):\n"
        "        current = self.read() if flag else None\n"
        "        self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)", effect_priors={"Writer.publish": 0.7})[
        "call_analysis"
    ]
    assert analysis["status"] == "unknown"
    assert analysis["unsupported"] == []
    assert analysis["probability_bounds"] == {"lower": 0.7, "upper": 1.0}


def test_irrelevant_prior_dispatch_does_not_repeat_the_same_witness(tmp_path):
    """The answer keeps only dispatch choices needed by this call site."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.prepare()\n"
        "        self.publish(src, dst)\n"
        "    def prepare(self):\n"
        "        pass\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)")["call_analysis"]
    assert analysis["conditional_matches"] == [
        {
            "path": "writer.py",
            "line": 9,
            "when": [
                {
                    "effect": "dispatch:Writer.publish@writer.py:5",
                    "selected": True,
                }
            ],
        }
    ]


def test_two_possible_calls_at_one_body_line_keep_alternative_guards(tmp_path):
    """Either selected invocation can witness a shared method-body line."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.publish(src, dst)\n"
        "        self.publish(src, dst)\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)")["call_analysis"]
    assert analysis["matched_locations"] == []
    assert {
        choice["when"][0]["effect"]
        for choice in analysis["conditional_matches"]
    } == {
        "dispatch:Writer.publish@writer.py:4",
        "dispatch:Writer.publish@writer.py:5",
    }


def test_decorated_public_method_has_no_local_dispatch_branch(tmp_path):
    """A decorator can replace the apparent local body before dispatch."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.publish(src, dst)\n"
        "    @wrapper\n"
        "    def publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("os.replace(src, dst)")["call_analysis"]
    assert analysis["status"] == "unknown"
    assert analysis["conditional_matches"] == []
    assert analysis["matched_locations"] == []


def test_private_method_rebinding_and_decorators_keep_uncertainty(tmp_path):
    """A source override or a wrapper invalidates direct body delegation."""
    rebound = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst, replacement):\n"
        "        self.__publish = replacement\n"
        "        self.__publish(src, dst)\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert rebound["call_analysis"]["status"] == "unknown"

    decorated = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.__publish(src, dst)\n"
        "    @wrapper\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert decorated["call_analysis"]["status"] == "unknown"


def test_class_body_rebinding_prevents_private_body_proof(tmp_path):
    """A later class assignment replaces a declaration before instances exist."""
    result = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, src, dst):\n"
        "        self.__publish(src, dst)\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n"
        "    __publish = replacement\n",
        "os.replace(src, dst)",
    )
    assert result["call_analysis"]["status"] == "unknown"
    assert result["call_analysis"]["matched_locations"] == []


def test_rebound_self_does_not_select_the_local_private_body(tmp_path):
    """The receiver expression must still denote the original instance."""
    result = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    def save(self, other, src, dst):\n"
        "        self = other\n"
        "        self.__publish(src, dst)\n"
        "    def __publish(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert result["call_analysis"]["status"] == "unknown"


def test_private_method_return_forwards_value_through_bound_arguments(tmp_path):
    """A private forwarding method can explain a returned value's origin."""
    result = _check(
        tmp_path,
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.__forward(user)\n"
        "    def __forward(self, item):\n"
        "        return persist(item)\n",
        "return persist(user)",
    )
    assert result["return_analysis"]["status"] == "all_paths_return_value"
    assert result["return_analysis"]["producer_locations"] == [
        {"path": "writer.py", "line": 5}
    ]
    assert result["return_analysis"]["binding_assumptions"] == [
        {
            "kind": "source_local_private_method_binding",
            "method": "Writer.__forward",
            "path": "writer.py",
            "line": 3,
        }
    ]


def test_public_method_return_keeps_dispatch_uncertainty(tmp_path):
    """A local public method body is only one possible runtime dispatch."""
    result = _check(
        tmp_path,
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n",
        "return persist(user)",
    )
    assert result["return_analysis"]["status"] == "unknown"
    assert result["return_analysis"]["method_candidates"] == [
        {
            "method": "Writer.forward",
            "path": "writer.py",
            "declaration_line": 4,
            "call_line": 3,
        }
    ]
    assert result["return_analysis"]["producer_locations"] == []
    assert result["return_analysis"]["conditional_producers"] == [
        {
            "path": "writer.py",
            "line": 5,
            "when": [
                {
                    "effect": "dispatch:Writer.forward@writer.py:3",
                    "selected": True,
                }
            ],
        }
    ]
    assert result["return_analysis"]["next_checks"][0] == {
        "kind": "dispatch_choice",
        "method": "Writer.forward",
        "effect": "dispatch:Writer.forward@writer.py:3",
        "locations": [{"path": "writer.py", "line": 3}],
        "if_other_selected": {"lower": 0.0, "upper": 1.0},
        "if_local_selected": {"lower": 1.0, "upper": 1.0},
    }
    assumed = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("return persist(user)", effect_priors={"Writer.forward": 0.7})[
        "return_analysis"
    ]
    assert assumed["probability_bounds"] == {"lower": 0.7, "upper": 1.0}


def test_public_return_method_local_counterexample_keeps_override_open(tmp_path):
    """A local constant return does not say what an override returns."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return 0\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("return persist(user)", effect_priors={"Writer.forward": 0.7})[
        "return_analysis"
    ]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == pytest.approx(
        {"lower": 0.0, "upper": 0.3}
    )
    assert analysis["producer_locations"] == []


def test_public_return_provenance_survives_assignment_and_later_dispatch(tmp_path):
    """A later unrelated method choice cannot change an earlier value source."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        value = self.forward(user)\n"
        "        other = self.prepare()\n"
        "        return value\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
        "    def prepare(self):\n"
        "        return 0\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("return persist(user)", effect_priors={"Writer.forward": 0.7})[
        "return_analysis"
    ]
    assert analysis["probability_bounds"] == {"lower": 0.7, "upper": 1.0}
    assert analysis["conditional_producers"] == [
        {
            "path": "writer.py",
            "line": 7,
            "when": [
                {
                    "effect": "dispatch:Writer.forward@writer.py:3",
                    "selected": True,
                }
            ],
        }
    ]
    assert analysis["conditional_returned_locations"][0]["line"] == 5


def test_private_return_delegation_preserves_public_dispatch_guard(tmp_path):
    """A private forwarding hop must keep the inner public choice visible."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.__delegate(user)\n"
        "    def __delegate(self, item):\n"
        "        return self.forward(item)\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("return persist(user)", effect_priors={"Writer.forward": 0.7})[
        "return_analysis"
    ]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == {"lower": 0.7, "upper": 1.0}
    assert analysis["conditional_producers"][0]["line"] == 7


def test_cli_reports_a_conditional_public_return_without_full_traces(
    tmp_path, capsys
):
    """The ordinary command exposes the source condition and its bounds."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
    )
    exit_code = main(
        [
            "code-check",
            "writer.py::Writer.save",
            "return persist(user)",
            "--root",
            str(tmp_path),
            "--effect-prior",
            "Writer.forward=0.7",
        ]
    )
    answer = json.loads(capsys.readouterr().out)["return_analysis"]
    assert exit_code == 0
    assert answer["status"] == "unknown"
    assert answer["probability_bounds"] == {"lower": 0.7, "upper": 1.0}
    assert answer["conditional_producers"][0]["line"] == 5


def test_discarded_public_method_value_is_a_counterexample_in_all_worlds(tmp_path):
    """Neither local nor alternate dispatch can repair a discarded value."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        value = self.forward(user)\n"
        "        return 0\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
    )
    analysis = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Writer.save"
    ).check("return persist(user)")["return_analysis"]
    assert analysis["status"] == "missing_path"
    assert analysis["probability_all_paths_return_value"] == 0.0


def test_decorated_entry_method_does_not_prove_its_body_runs(tmp_path):
    """A decorator may replace the selected method at the public boundary."""
    called = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    @wrapper\n"
        "    def save(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert called["call_analysis"]["status"] == "unknown"
    assert "decorated_function" in called["call_analysis"]["unsupported"]

    returned = _check(
        tmp_path,
        "class Writer:\n"
        "    @wrapper\n"
        "    def save(self, user):\n"
        "        return persist(user)\n",
        "return persist(user)",
    )
    assert returned["return_analysis"]["status"] == "unknown"
    assert "decorated_function" in returned["return_analysis"]["unsupported"]


def test_async_entry_needs_an_awaited_execution_contract(tmp_path):
    """Calling a coroutine function does not run its source body eagerly."""
    called = _check(
        tmp_path,
        "import os\n"
        "class Writer:\n"
        "    async def save(self, src, dst):\n"
        "        os.replace(src, dst)\n",
        "os.replace(src, dst)",
    )
    assert called["call_analysis"]["status"] == "unknown"
    assert "coroutine_function" in called["call_analysis"]["unsupported"]

    returned = _check(
        tmp_path,
        "class Writer:\n"
        "    async def save(self, user):\n"
        "        return persist(user)\n",
        "return persist(user)",
    )
    assert returned["return_analysis"]["status"] == "unknown"
    assert "coroutine_function" in returned["return_analysis"]["unsupported"]
