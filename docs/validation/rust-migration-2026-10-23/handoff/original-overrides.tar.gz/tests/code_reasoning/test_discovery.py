"""Discover source candidates before checking their code obligations."""

from __future__ import annotations

import json

import pytest

from ken.cli import main
from ken.code_reasoning import CodeDiscovery, CodeInvestigation


def test_direct_candidates_become_ranked_source_conclusions(tmp_path):
    """KQL2 discovery feeds proof and counterexample paths without repeat queries."""
    (tmp_path / "writer.py").write_text(
        "import os\n"
        "def always(src, dst):\n"
        "    os.replace(src, dst)\n"
        "def sometimes(src, dst, enabled):\n"
        "    if enabled:\n"
        "        os.replace(src, dst)\n"
        "def wrapper(src, dst):\n"
        "    always(src, dst)\n"
    )
    result = CodeDiscovery(tmp_path).find("os.replace", search_path="writer.py")

    assert result["schema"] == "ken-code-discovery/1"
    assert result["candidate_source"] == "kql2_seeded_local_callers"
    assert result["coverage"]["complete"] is True
    assert result["contract_search_exhaustive"] is False
    assert result["candidates_found"] == 3
    assert [
        (item["source"]["symbol"], item["analysis"]["status"])
        for item in result["matches"]
    ] == [
        ("always", "all_paths_called"),
        ("wrapper", "all_paths_called"),
        ("sometimes", "missing_path"),
    ]
    assert result["matches"][0]["analysis"]["matched_locations"] == [
        {"path": "writer.py", "line": 3}
    ]
    assert result["matches"][0]["direct_call_locations"] == [
        {"path": "writer.py", "line": 3}
    ]
    assert result["matches"][1]["candidate_kind"] == "same_file_caller"
    assert result["matches"][1]["via"] == ["writer.py::always"]


def test_direct_kql_seed_discovers_a_top_level_return_wrapper(tmp_path):
    """A file-local helper leads to the public argument vocabulary."""
    (tmp_path / "writer.py").write_text(
        "def forward(item):\n"
        "    return persist(item)\n"
        "def save(user):\n"
        "    return forward(user)\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="writer.py"
    )
    match = next(
        item for item in result["matches"] if item["selector"] == "writer.py::save"
    )
    assert match["candidate_kind"] == "same_file_caller"
    assert match["via"] == ["writer.py::forward"]
    assert match["analysis"]["status"] == "all_paths_return_value"


def test_direct_seed_discovers_explicitly_imported_return_wrapper(tmp_path):
    """An aliased import can lead from a direct helper to a public caller."""
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "helper.py").write_text(
        "def forward(item):\n    return persist(item)\n"
    )
    (package / "writer.py").write_text(
        "from .helper import forward as send\n"
        "def save(user):\n    return send(user)\n"
    )

    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="pkg"
    )
    match = next(
        item for item in result["matches"]
        if item["selector"] == "pkg/writer.py::save"
    )
    assert match["candidate_kind"] == "imported_caller"
    assert match["via"] == ["pkg/helper.py::forward"]
    assert match["delegate_call_locations"] == [{"path": "pkg/writer.py", "line": 3}]
    assert match["analysis"]["status"] == "all_paths_return_value"
    assert result["import_expansion_coverage"]["complete"] is True


def test_import_caller_requires_matching_module_and_unshadowed_name(tmp_path):
    """A same-named function in another module or local binding is not a caller."""
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "helper.py").write_text(
        "def forward(item):\n    return persist(item)\n"
    )
    (package / "other.py").write_text("def forward(item):\n    return item\n")
    (package / "decoy.py").write_text(
        "from .other import forward\n"
        "def save(user):\n    return forward(user)\n"
    )
    (package / "shadow.py").write_text(
        "from .helper import forward\n"
        "def save(user, forward):\n    return forward(user)\n"
    )
    (package / "rebound.py").write_text(
        "from .helper import forward\n"
        "forward = lambda value: value\n"
        "def save(user):\n    return forward(user)\n"
    )
    (package / "deferred.py").write_text(
        "from .helper import forward\n"
        "def save(users):\n    return (forward(user) for user in users)\n"
    )

    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="pkg"
    )
    assert all(item["candidate_kind"] != "imported_caller" for item in result["matches"])
    assert result["import_expansion_coverage"]["complete"] is True


def test_import_caller_expansion_respects_file_scope(tmp_path):
    """A requested file cannot silently add callers from its sibling files."""
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "helper.py").write_text(
        "def forward(item):\n    return persist(item)\n"
    )
    (package / "writer.py").write_text(
        "from .helper import forward\n"
        "def save(user):\n    return forward(user)\n"
    )

    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="pkg/helper.py"
    )
    assert result["imported_candidates_found"] == 0
    assert all(item["selector"] != "pkg/writer.py::save" for item in result["matches"])


def test_import_caller_resolves_src_layout_absolute_import(tmp_path):
    """Absolute package imports in a src-layout project reach the right file."""
    package = tmp_path / "src" / "pkg"
    package.mkdir(parents=True)
    (package / "helper.py").write_text(
        "def forward(item):\n    return persist(item)\n"
    )
    (package / "writer.py").write_text(
        "from pkg.helper import forward as send\n"
        "def save(user):\n    return send(user)\n"
    )

    result = CodeDiscovery(tmp_path).find("return persist(user)")
    match = next(
        item for item in result["matches"]
        if item["selector"] == "src/pkg/writer.py::save"
    )
    assert match["analysis"]["status"] == "all_paths_return_value"
    assert match["via"] == ["src/pkg/helper.py::forward"]


def test_return_discovery_uses_value_flow_candidate_and_path_evidence(tmp_path):
    """A guarded return is findable without knowing the function name."""
    (tmp_path / "lookup.py").write_text(
        "def lookup(key):\n"
        "    return key\n"
        "def get(key):\n"
        "    value = lookup(key)\n"
        "    if value is None:\n"
        "        raise KeyError(key)\n"
        "    return value\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "return lookup(key)", search_path="lookup.py"
    )

    assert result["coverage"]["complete"] is True
    assert result["candidates_found"] == 1
    match = result["matches"][0]
    assert match["source"]["symbol"] == "get"
    assert match["analysis"]["status"] == "all_paths_return_value"
    assert match["analysis"]["producer_locations"] == [
        {"path": "lookup.py", "line": 4}
    ]


def test_direct_kql_seed_discovers_a_same_class_public_return_wrapper(tmp_path):
    """A user can find the caller whose argument names match the question."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="writer.py"
    )
    assert result["direct_candidates_found"] == 1
    assert result["expanded_candidates_found"] == 1
    assert result["expansion_coverage"]["complete"] is True
    match = next(
        item for item in result["matches"] if item["selector"] == "writer.py::Writer.save"
    )
    assert match["candidate_kind"] == "same_class_caller"
    assert match["via"] == ["writer.py::Writer.forward"]
    assert match["delegate_call_locations"] == [{"path": "writer.py", "line": 3}]
    assert match["analysis"]["status"] == "unknown"
    assert match["analysis"]["conditional_producers"][0]["line"] == 5


def test_caller_expansion_stays_in_own_class_and_ignores_deferred_bodies(tmp_path):
    """A same-named method elsewhere is not the KQL2 seed's caller."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def deferred(self, user):\n"
        "        def later():\n"
        "            return self.forward(user)\n"
        "        return 0\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
        "class Other:\n"
        "    def save(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return 0\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="writer.py"
    )
    assert [item["selector"] for item in result["matches"]] == [
        "writer.py::Writer.save"
    ]
    assert result["expanded_candidates_found"] == 1


def test_caller_expansion_limit_reports_incomplete_caller_coverage(tmp_path):
    """A KQL2 row cap must not hide a separate caller-expansion cap."""
    (tmp_path / "writer.py").write_text(
        "class Writer:\n"
        "    def first(self, user):\n"
        "        return self.forward(user)\n"
        "    def second(self, user):\n"
        "        return self.forward(user)\n"
        "    def forward(self, item):\n"
        "        return persist(item)\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "return persist(user)", search_path="writer.py", max_candidates=1
    )
    assert result["direct_candidates_found"] == 1
    assert result["expanded_candidates_found"] == 1
    assert result["expansion_coverage"]["complete"] is False
    assert result["expansion_coverage"]["results_truncated"] is True


def test_cli_find_reports_incomplete_candidate_limit(tmp_path, capsys):
    """The public command never presents a capped KQL search as exhaustive."""
    (tmp_path / "writer.py").write_text(
        "def first(close):\n    close()\n"
        "def second(close):\n    close()\n"
    )
    assert main(
        [
            "code-find",
            "close",
            "--root",
            str(tmp_path),
            "--in",
            "writer.py",
            "--max-candidates",
            "1",
        ]
    ) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["candidates_found"] == 1
    assert result["coverage"]["complete"] is False
    assert result["coverage"]["results_truncated"] is True
    assert len(result["matches"]) == 1


def test_source_change_after_candidate_search_rejects_stale_conclusion(
    tmp_path, monkeypatch
):
    """Reasoning is tied to exactly the bytes observed by KQL2."""
    source = tmp_path / "writer.py"
    source.write_text("def save(close):\n    close()\n")
    from ken.kql2 import service

    original = service.search

    def changed(*args, **kwargs):
        result = original(*args, **kwargs)
        source.write_text("def save(close):\n    pass\n")
        return result

    monkeypatch.setattr(service, "search", changed)
    with pytest.raises(ValueError, match="KQL source snapshot differs"):
        CodeDiscovery(tmp_path).find("close", search_path="writer.py")


def test_mcp_exposes_compact_discovery_with_real_locations(tmp_path, monkeypatch):
    """An agent can discover and then inspect a selected source contract."""
    from ken.mcp import server

    (tmp_path / "writer.py").write_text(
        "def save(close):\n    close()\n"
    )
    monkeypatch.setattr(server, "_PROJECT_ROOT", tmp_path)
    result = server.ken_code_find("close", search_path="writer.py")
    assert any(tool.name == "ken_code_find" for tool in server.list_tools())
    assert result["matches"][0]["selector"] == "writer.py::save"
    assert result["matches"][0]["direct_call_locations"] == [
        {"path": "writer.py", "line": 2}
    ]
    assert result["matches"][0]["analysis"] == {
        "status": "all_paths_called",
        "path_count": 1,
        "analysis_complete": True,
        "matched_locations": [{"path": "writer.py", "line": 2}],
        "probability_all_paths_called": 1.0,
    }


def test_generator_call_is_a_candidate_but_not_an_eager_proof(tmp_path):
    """Creating a generator does not execute its later cleanup call."""
    (tmp_path / "stream.py").write_text(
        "def stream(handle):\n    yield 1\n    handle.close()\n"
    )
    checked = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="stream.py", symbol="stream"
    ).check("handle.close()")
    assert checked["call_analysis"]["status"] == "unknown"
    assert "generator_function" in checked["call_analysis"]["unsupported"]

    discovered = CodeDiscovery(tmp_path).find(
        "handle.close()", search_path="stream.py"
    )
    match = discovered["matches"][0]
    assert match["direct_call_locations"] == [{"path": "stream.py", "line": 3}]
    assert match["analysis"]["status"] == "unknown"
    assert match["analysis"]["blockers"] == ["generator_function"]


def test_generator_return_does_not_prove_a_wrapper_return(tmp_path):
    """A generator's StopIteration value is not the value of calling it."""
    (tmp_path / "stream.py").write_text(
        "def stream(save):\n    yield 1\n    return save()\n"
    )
    checked = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="stream.py", symbol="stream"
    ).check("return save()")
    assert checked["return_analysis"]["status"] == "unknown"
    assert "generator_function" in checked["return_analysis"]["unsupported"]


def test_directory_search_acquires_only_python_files_with_named_calls(
    tmp_path, monkeypatch
):
    """A wide direct search avoids indexing files that cannot contain a hit."""
    source = tmp_path / "src"
    source.mkdir()
    for index in range(60):
        (source / f"noise_{index}.py").write_text(f"def unrelated_{index}(): pass\n")
    (source / "writer.py").write_text(
        "def save(close):\n    close()\n"
    )
    from ken.kql2 import service

    original = service.search
    observed = []

    def record(*args, **kwargs):
        observed.append(kwargs["source_paths"])
        return original(*args, **kwargs)

    monkeypatch.setattr(service, "search", record)
    result = CodeDiscovery(tmp_path).find("close")
    assert observed == [["src/writer.py"]]
    assert result["coverage"]["complete"] is True
    assert result["coverage"]["prefiltered_files"] == 60
    assert result["matches"][0]["selector"] == "src/writer.py::save"


def test_empty_direct_inventory_remains_a_bounded_non_exhaustive_answer(tmp_path):
    """No direct call spelling is not a proof that a wrapper cannot delegate."""
    (tmp_path / "wrapper.py").write_text("def wrapper(run):\n    run()\n")
    result = CodeDiscovery(tmp_path).find("close", search_path="wrapper.py")
    assert result["candidates_found"] == 0
    assert result["coverage"]["complete"] is True
    assert result["contract_search_exhaustive"] is False


def test_dotted_target_prefilter_excludes_unrelated_receivers(tmp_path, monkeypatch):
    """A different receiver's same-named call is not a direct target candidate."""
    (tmp_path / "wanted.py").write_text(
        "import os\ndef publish(src, dst):\n    os.replace(src, dst)\n"
    )
    (tmp_path / "decoy.py").write_text(
        "def publish(other, src, dst):\n    other.replace(src, dst)\n"
    )
    from ken.kql2 import service

    original = service.search
    observed = []

    def record(*args, **kwargs):
        observed.append(kwargs["source_paths"])
        return original(*args, **kwargs)

    monkeypatch.setattr(service, "search", record)
    result = CodeDiscovery(tmp_path).find("os.replace")
    assert observed == [["wanted.py"]]
    assert [item["selector"] for item in result["matches"]] == [
        "wanted.py::publish"
    ]


def test_dotted_receiver_alias_remains_in_candidate_inventory(tmp_path):
    """Root-name filtering must keep an alias of the requested parameter."""
    (tmp_path / "writer.py").write_text(
        "def close(self):\n"
        "    handle = self.handle\n"
        "    handle.close()\n"
    )
    result = CodeDiscovery(tmp_path).find(
        "self.handle.close()", search_path="writer.py"
    )
    assert result["candidates_found"] == 1
    assert result["matches"][0]["analysis"]["status"] == "all_paths_called"
