"""The packaged interface must preserve source evidence and honest worlds."""

from __future__ import annotations

import json

import pytest

from ken.cli import main
from ken.code_reasoning import CodeInvestigation


def _investigation(tmp_path, content, *, symbol="save"):
    """Create one versioned source question in an uninstalled project."""
    (tmp_path / "writer.py").write_text(content)
    return CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol=symbol
    )


def test_cli_checks_a_direct_ordered_contract(tmp_path, capsys):
    """One Ken command combines KQL2 coverage with a witnessed path."""
    (tmp_path / "writer.py").write_text(
        "import os\ndef save(src, dst):\n    os.fsync(1)\n    os.replace(src, dst)\n"
    )
    exit_code = main(
        [
            "code-check",
            "writer.py::save",
            "os.fsync -> os.replace(src, dst)",
            "--root",
            str(tmp_path),
        ]
    )
    result = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert result["schema"] == "ken-code-investigation/1"
    assert result["candidate_call"]["state"] == "present"
    assert result["candidate_call"]["coverage_complete"] is True
    assert result["candidate_call"]["owner_locations"] == [
        {"path": "writer.py", "line": 2, "kind": "CALLABLE", "name": "save"}
    ]
    assert result["call_analysis"]["status"] == "all_paths_called"
    assert result["call_analysis"]["ordered_locations"] == [
        {"path": "writer.py", "line": 4}
    ]


def test_ordered_prior_bounds_a_hidden_predecessor(tmp_path):
    """Target-call probability never proves an unobserved earlier fsync."""
    investigation = _investigation(
        tmp_path,
        "def save(src, dst, publish):\n    publish(src, dst)\n",
    )
    result = investigation.check(
        "os.fsync -> os.replace(src, dst)", effect_priors={"publish": 0.6}
    )
    analysis = result["call_analysis"]
    assert result["candidate_call"]["state"] == "absent"
    assert analysis["status"] == "unknown"
    assert analysis["probability_all_paths_called"] is None
    assert analysis["probability_bounds"] == pytest.approx({"lower": 0.0, "upper": 0.6})
    assert analysis["order_uncertainty"] == {
        "possible_predecessors": [],
        "calls_requiring_internal_order": ["function:publish@writer.py:2"],
    }
    assert analysis["uncertain_calls"] == [
        {"path": "writer.py", "line": 2, "effect": "function:publish@writer.py:2"}
    ]


def test_partial_priors_keep_unmodeled_alternatives_visible(tmp_path):
    """A second injected publisher widens an otherwise exact 0.6 result."""
    investigation = _investigation(
        tmp_path,
        "def save(src, dst, publish, backup):\n"
        "    publish(src, dst)\n    backup(src, dst)\n",
    )
    result = investigation.check("os.replace(src, dst)", effect_priors={"publish": 0.6})
    analysis = result["call_analysis"]
    assert analysis["probability_all_paths_called"] is None
    assert analysis["probability_bounds"] == pytest.approx({"lower": 0.6, "upper": 1.0})
    assert analysis["unassumed_effects"] == ["function:backup@writer.py:3"]
    assert analysis["next_checks"] == [
        {
            "kind": "callee_target_effect",
            "effect": "function:backup@writer.py:3",
            "locations": [{"path": "writer.py", "line": 3}],
            "if_target_absent": {"lower": 0.6, "upper": 0.6},
            "if_target_present": {"lower": 1.0, "upper": 1.0},
        }
    ]


def test_unknown_callee_explains_what_to_inspect_without_a_prior(tmp_path):
    """Conditional worlds guide investigation without inventing a probability."""
    investigation = _investigation(
        tmp_path,
        "def save(src, dst, publish):\n    publish(src, dst)\n",
    )
    analysis = investigation.check("os.replace(src, dst)")["call_analysis"]
    assert analysis["status"] == "unknown"
    assert analysis["probability_bounds"] == {"lower": 0.0, "upper": 1.0}
    assert analysis["next_checks"] == [
        {
            "kind": "callee_target_effect",
            "effect": "function:publish@writer.py:2",
            "locations": [{"path": "writer.py", "line": 2}],
            "if_target_absent": {"lower": 0.0, "upper": 0.0},
            "if_target_present": {"lower": 1.0, "upper": 1.0},
        }
    ]


def test_same_named_unresolved_calls_have_distinct_world_variables(tmp_path):
    """A callee-name prior cannot silently collapse separate source calls."""
    investigation = _investigation(
        tmp_path,
        "def save(first, second):\n    first.publish()\n    second.publish()\n",
    )
    initial = investigation.check("os.replace")["call_analysis"]
    assert initial["unresolved_effects"] == [
        "method:publish@writer.py:2",
        "method:publish@writer.py:3",
    ]
    with pytest.raises(ValueError, match="Ambiguous effect prior"):
        investigation.check("os.replace", effect_priors={"publish": 0.6})
    conditioned = investigation.check(
        "os.replace",
        effect_priors={
            "method:publish@writer.py:2": 0.4,
            "method:publish@writer.py:3": 0.7,
        },
    )["call_analysis"]
    assert conditioned["probability_all_paths_called"] == pytest.approx(0.82)
    assert conditioned["probability_model"] == "independent_call_site_effects"


def test_nested_unknown_call_names_the_callee_to_inspect(tmp_path):
    """An alias passed into a wrapper yields a useful source-level next check."""
    investigation = _investigation(
        tmp_path,
        "class Cursor:\n"
        "    def fetchone(self):\n"
        "        return self.connection.call(self.cursor.fetchone)\n",
        symbol="Cursor.fetchone",
    )
    analysis = investigation.check("self.cursor.close()")["call_analysis"]
    assert analysis["status"] == "unknown"
    assert analysis["next_checks"][0]["effect"] == (
        "call:self.connection.call@writer.py:3"
    )
    assert analysis["next_checks"][0]["locations"] == [{"path": "writer.py", "line": 3}]


def test_explicit_import_supplies_a_witness_despite_absent_local_candidate(tmp_path):
    """Same-function KQL absence does not hide a resolved local delegation."""
    package = tmp_path / "pkg"
    package.mkdir()
    (package / "__init__.py").write_text("")
    (package / "publish.py").write_text(
        "import os\ndef publish(src, dst):\n    os.replace(src, dst)\n"
    )
    (package / "writer.py").write_text(
        "from .publish import publish\ndef save(src, dst):\n    publish(src, dst)\n"
    )
    investigation = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="pkg/writer.py", symbol="save"
    )
    result = investigation.check("os.replace(src, dst)")
    assert result["candidate_call"]["state"] == "absent"
    assert result["call_analysis"]["status"] == "all_paths_called"
    assert result["call_analysis"]["matched_locations"] == [
        {"path": "pkg/publish.py", "line": 3}
    ]
    assert result["call_analysis"]["dependencies"][0]["path"] == "pkg/publish.py"


@pytest.mark.parametrize(
    ("body", "expected_evidence"),
    [
        ("os.fsync(1)\n    os.replace(src, src)", "argument_mismatches"),
        ("os.replace(src, dst)\n    os.fsync(1)", "out_of_order_locations"),
    ],
)
def test_source_mutations_are_candidates_not_false_proofs(
    tmp_path, body, expected_evidence
):
    """An argument or order mutation loses its all-path witness."""
    investigation = _investigation(
        tmp_path, f"import os\ndef save(src, dst):\n    {body}\n"
    )
    result = investigation.check("os.fsync -> os.replace(src, dst)")
    analysis = result["call_analysis"]
    assert analysis["status"] == "missing_path"
    assert analysis["probability_all_paths_called"] == 0.0
    assert analysis[expected_evidence]


def test_source_change_after_selection_invalidates_question(tmp_path):
    """A source-bound answer cannot silently reuse a stale function."""
    investigation = _investigation(tmp_path, "def save():\n    publish()\n")
    (tmp_path / "writer.py").write_text("def save():\n    backup()\n")
    with pytest.raises(ValueError, match="changed"):
        investigation.check("publish")


def test_incomplete_kql_does_not_suppress_source_path_evidence(tmp_path, monkeypatch):
    """A bounded KQL timeout is not absence or a failed path analysis."""
    from ken.kql2 import service

    investigation = _investigation(
        tmp_path,
        "import os\ndef save(src, dst):\n    os.replace(src, dst)\n",
    )
    monkeypatch.setattr(
        service,
        "search",
        lambda *args, **kwargs: {
            "complete": False,
            "coverage_complete": False,
            "analysis": {},
            "rows": [],
            "reason": "budget_exhausted",
        },
    )
    result = investigation.check("os.replace(src, dst)")
    assert result["candidate_call"]["state"] == "unknown"
    assert result["candidate_call"]["reason"] == "budget_exhausted"
    assert result["call_analysis"]["status"] == "all_paths_called"


def test_qualified_method_distinguishes_same_named_owners(tmp_path):
    """A method selector binds path reasoning to one class, not a basename."""
    (tmp_path / "writer.py").write_text(
        "class First:\n"
        "    def save(self):\n        self.conn.close()\n"
        "class Second:\n"
        "    def save(self, flag):\n"
        "        if flag:\n            self.conn.close()\n"
    )
    with pytest.raises(ValueError, match="exactly one"):
        CodeInvestigation.from_python_symbol(
            project_root=tmp_path, path="writer.py", symbol="save"
        )
    first = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="First.save"
    ).check("self.conn.close()")
    second = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="Second.save"
    ).check("self.conn.close()")
    assert first["call_analysis"]["status"] == "all_paths_called"
    assert second["call_analysis"]["status"] == "missing_path"
    assert first["candidate_call"]["state"] == "unknown"
    assert second["candidate_call"]["state"] == "unknown"
    assert first["candidate_call"]["reason"] == "ambiguous_target"


def test_local_variable_calls_can_satisfy_an_ordered_contract(tmp_path):
    """A local handle is a valid lexical target even though it is not a parameter."""
    investigation = _investigation(
        tmp_path,
        "import fcntl\n"
        "class Lock:\n"
        "    def close(self):\n"
        "        if self.handle is not None:\n"
        "            handle, self.handle = self.handle, None\n"
        "            try:\n"
        "                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)\n"
        "            finally:\n"
        "                handle.close()\n",
        symbol="Lock.close",
    )
    result = investigation.check(
        "fcntl.flock -> handle.close()", when={"self.handle is not None": True}
    )
    analysis = result["call_analysis"]
    assert analysis["status"] == "all_paths_called"
    assert analysis["matched_locations"] == [{"path": "writer.py", "line": 9}]
    assert analysis["ordered_locations"] == [{"path": "writer.py", "line": 9}]


def test_same_spelling_in_a_helper_is_not_the_roots_local_target(tmp_path):
    """A helper's unrelated local handle cannot witness the root local's call."""
    investigation = _investigation(
        tmp_path,
        "def helper(other):\n"
        "    handle = other\n"
        "    handle.close()\n"
        "def save(other):\n"
        "    handle = other\n"
        "    helper(other)\n",
    )
    analysis = investigation.check("handle.close()")["call_analysis"]
    assert analysis["status"] != "all_paths_called"
    assert analysis["matched_locations"] == []


def test_rebound_import_is_not_a_witness_to_the_module_contract(tmp_path):
    """A local object named os must not prove a call on the imported module."""
    investigation = _investigation(
        tmp_path,
        "import os\n"
        "def save(src, dst, replacement):\n"
        "    os = replacement\n"
        "    os.replace(src, dst)\n",
    )
    analysis = investigation.check("os.replace(src, dst)")["call_analysis"]
    assert analysis["status"] != "all_paths_called"
    assert analysis["matched_locations"] == []


def test_shadowed_module_cannot_witness_an_order_precondition(tmp_path):
    """A parameter named os is not the imported module in an ordered query."""
    investigation = _investigation(
        tmp_path,
        "import os\ndef save(os, handle):\n    os.fsync(1)\n    handle.close()\n",
    )
    analysis = investigation.check("os.fsync -> handle.close()")["call_analysis"]
    assert analysis["status"] != "all_paths_called"
    assert analysis["ordered_locations"] == []


def test_receiver_reset_after_witness_does_not_erase_the_call(tmp_path):
    """A post-close assignment cannot change whether close was already called."""
    investigation = _investigation(
        tmp_path,
        "class Cache:\n"
        "    def close(self):\n"
        "        if self.conn is not None:\n"
        "            self.conn.close()\n"
        "            self.conn = None\n",
        symbol="Cache.close",
    )
    called = investigation.check(
        "self.conn.close()", when={"self.conn is not None": True}
    )["call_analysis"]
    missing = investigation.check("self.conn.close()")["call_analysis"]
    assert called["status"] == "all_paths_called"
    assert called["matched_locations"] == [{"path": "writer.py", "line": 4}]
    assert missing["status"] == "missing_path"


def test_receiver_reset_before_target_keeps_the_result_uncertain(tmp_path):
    """An untracked receiver reassignment before the call still blocks a proof."""
    investigation = _investigation(
        tmp_path,
        "class Cache:\n"
        "    def close(self):\n"
        "        self.conn = None\n"
        "        self.conn.close()\n",
        symbol="Cache.close",
    )
    analysis = investigation.check("self.conn.close()")["call_analysis"]
    assert analysis["status"] == "unknown"
    assert "assignment:3" in analysis["unsupported"]


def test_kql_does_not_attribute_a_sibling_method_hit(tmp_path):
    """One same-named KQL hit cannot identify which class owns the call."""
    (tmp_path / "writer.py").write_text(
        "class First:\n    def save(self):\n        pass\n"
        "class Second:\n    def save(self):\n        self.conn.close()\n"
    )
    result = CodeInvestigation.from_python_symbol(
        project_root=tmp_path, path="writer.py", symbol="First.save"
    ).check("self.conn.close()")
    assert result["candidate_call"]["state"] == "unknown"
    assert result["candidate_call"]["reason"] == "ambiguous_target"
    assert result["call_analysis"]["status"] == "missing_path"


def test_cli_saves_a_receipt_and_rejects_invalid_assumptions(tmp_path, capsys):
    """CLI output is replayable, and malformed priors fail before analysis."""
    (tmp_path / "writer.py").write_text(
        "def save(src, dst, publish):\n    publish(src, dst)\n"
    )
    receipt = tmp_path / "output" / "receipt.json"
    args = [
        "code-check",
        "writer.py::save",
        "os.replace(src, dst)",
        "--root",
        str(tmp_path),
        "--effect-prior",
        "publish=0.6",
    ]
    assert main([*args, "--out", str(receipt)]) == 0
    saved = json.loads(receipt.read_text())
    assert saved["source"]["sha256"]
    assert saved["call_analysis"]["probability_all_paths_called"] == pytest.approx(0.6)
    assert "probability_bounds" not in saved["call_analysis"]
    capsys.readouterr()
    assert main([*args, "--effect-prior", "publish=0.2"]) == 2
    assert "distinct NAME=VALUE" in capsys.readouterr().err


def test_mcp_tool_uses_the_same_source_question(tmp_path, monkeypatch):
    """An agent can ask the packaged reasoner without a shell adapter."""
    from ken.mcp import server

    (tmp_path / "writer.py").write_text(
        "def save(src, dst, publish):\n    publish(src, dst)\n"
    )
    monkeypatch.setattr(server, "_PROJECT_ROOT", tmp_path)
    result = server.ken_code_check(
        "writer.py::save",
        "os.fsync -> os.replace(src, dst)",
        effect_priors={"publish": 0.6},
    )
    assert any(tool.name == "ken_code_check" for tool in server.list_tools())
    assert result["schema"] == "ken-code-investigation/1"
    assert result["call_analysis"]["probability_bounds"] == pytest.approx(
        {"lower": 0.0, "upper": 0.6}
    )
    assert server.ken_code_check("writer.py", "os.replace")["ok"] is False
