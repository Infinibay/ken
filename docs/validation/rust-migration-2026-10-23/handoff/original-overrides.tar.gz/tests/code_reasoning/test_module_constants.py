"""Argument-specific call contracts must distinguish source-bound metadata keys."""

from pathlib import Path

import pytest

from ken.code_reasoning import CodeInvestigation


def investigate(tmp_path, source, contract, symbol="rebuild"):
    (tmp_path / "storage.py").write_text(source)
    return CodeInvestigation.from_selector(
        project_root=tmp_path, selector=f"storage.py::{symbol}"
    ).check(contract)


def test_named_key_selects_the_correct_call_and_records_its_definition(tmp_path):
    source = '''VERSION = "graph_version"
NOTE = "graph_note"
def rebuild(conn):
    set_meta(conn, NOTE, "started")
    recompute(conn)
    set_meta(conn, VERSION, 2)
'''
    result = investigate(tmp_path, source, "recompute -> set_meta(conn, VERSION, _)")
    analysis = result["call_analysis"]
    assert analysis["status"] == "all_paths_called"
    assert analysis["matched_locations"] == [{"path": "storage.py", "line": 6}]
    assert analysis["argument_mismatches"] == [{"path": "storage.py", "line": 4}]
    binding = next(p for p in analysis["binding_assumptions"] if p.get("name") == "VERSION")
    assert binding == {"kind": "source_local_constant_binding", "name": "VERSION",
                       "value": "'graph_version'", "path": "storage.py", "line": 1}
    wrong = investigate(tmp_path, source, "recompute -> set_meta(conn, NOTE, _)")
    assert wrong["call_analysis"]["status"] != "all_paths_called"


@pytest.mark.parametrize("contract", ["set_meta(conn, VERSION, _)", "set_meta(conn, 'graph_version', _)"])
def test_constant_flows_through_local_alias_and_helper_parameter(tmp_path, contract):
    result = investigate(tmp_path, '''VERSION: str = "graph_version"
def publish(conn, key):
    set_meta(conn, key, 2)
def rebuild(conn):
    key = VERSION
    publish(conn, key)
''', contract)
    assert result["call_analysis"]["status"] == "all_paths_called"


def test_return_contract_uses_the_same_constant_binding(tmp_path):
    result = investigate(tmp_path, '''VERSION = "graph_version"
def rebuild(conn):
    return get_meta(conn, VERSION)
''', "return get_meta(conn, VERSION)")
    assert result["return_analysis"]["status"] == "all_paths_return_value"
    assert result["return_analysis"]["binding_assumptions"][0]["name"] == "VERSION"


def test_parameter_shadowing_keeps_root_parameter_identity(tmp_path):
    result = investigate(tmp_path, '''VERSION = "graph_version"
def rebuild(conn, VERSION):
    set_meta(conn, VERSION, 2)
''', "set_meta(conn, VERSION, _)")
    assert result["call_analysis"]["status"] == "all_paths_called"
    assert not result["call_analysis"].get("binding_assumptions")


@pytest.mark.parametrize("extra", [
    'VERSION = "other"\n',
    'if condition:\n    VERSION = "other"\n',
    'def mutate():\n    global VERSION\n    VERSION = "other"\n',
    'from elsewhere import *\n',
    'globals()["VERSION"] = "other"\n',
    'def mutate(module):\n    module.VERSION = "other"\n',
    'def mutate(module):\n    setattr(module, "VERSION", "other")\n',
])
def test_ambiguous_or_mutated_module_definition_cannot_prove_named_argument(tmp_path, extra):
    source = 'VERSION = "graph_version"\n' + extra + 'def rebuild(conn):\n    set_meta(conn, VERSION, 2)\n'
    with pytest.raises(ValueError, match="module literal constants"):
        investigate(tmp_path, source, "set_meta(conn, VERSION, _)")
    result = investigate(tmp_path, source, "set_meta(conn, 'graph_version', _)")
    assert result["call_analysis"]["status"] != "all_paths_called"


@pytest.mark.parametrize("declaration", [
    'VERSION = "other"',
    'from elsewhere import VERSION',
    'class VERSION:\n        pass',
    'del VERSION',
])
def test_function_local_bindings_never_fall_back_to_the_module(tmp_path, declaration):
    source = 'VERSION = "graph_version"\ndef rebuild(conn):\n    ' + declaration + '\n    set_meta(conn, VERSION, 2)\n'
    with pytest.raises(ValueError, match="module literal constants"):
        investigate(tmp_path, source, "set_meta(conn, VERSION, _)")


def test_enclosing_binding_is_not_confused_with_module_constant(tmp_path):
    source = '''VERSION = "graph_version"
def outer():
    VERSION = "other"
    def rebuild(conn):
        set_meta(conn, VERSION, 2)
'''
    result = investigate(tmp_path, source, "set_meta(conn, 'graph_version', _)", "outer.rebuild")
    assert result["call_analysis"]["status"] != "all_paths_called"


def test_imported_helper_uses_its_own_constants_and_pins_their_file(tmp_path):
    (tmp_path / "helper.py").write_text('VERSION = "other"\ndef publish(conn):\n    set_meta(conn, VERSION, 2)\n')
    source = 'from helper import publish\nVERSION = "graph_version"\ndef rebuild(conn):\n    publish(conn)\n'
    result = investigate(tmp_path, source, "set_meta(conn, VERSION, _)")
    assert result["call_analysis"]["status"] != "all_paths_called"
    helper = tmp_path / "helper.py"
    helper.write_text(helper.read_text().replace('"other"', '"graph_version"'))
    result = investigate(tmp_path, source, "set_meta(conn, VERSION, _)")
    assert result["call_analysis"]["status"] == "all_paths_called"
    assert result["call_analysis"]["dependencies"][0]["path"] == "helper.py"
    assert {p["path"] for p in result["call_analysis"]["binding_assumptions"]} == {"storage.py", "helper.py"}


def test_real_rebuild_selects_version_write_not_note_write():
    root = Path(__file__).resolve().parents[2]
    result = CodeInvestigation.from_selector(project_root=root,
        selector="src/ken/findings_graph.py::rebuild_finding_graph"
    ).check("recompute_finding_edges -> set_meta(conn, _META_VERSION, _)")
    analysis = result["call_analysis"]
    assert analysis["status"] == "all_paths_called"
    source = (root / "src/ken/findings_graph.py").read_text().splitlines()
    assert all("_META_VERSION" in source[p["line"] - 1] for p in analysis["matched_locations"])


@pytest.mark.parametrize("returns", [False, True])
def test_followed_helper_cannot_silently_rebind_a_constant(tmp_path, returns):
    (tmp_path / "helper.py").write_text('def mutate(module):\n    module.VERSION = "other"\n')
    source = '''from helper import mutate
import storage
VERSION = "graph_version"
def rebuild(conn):
    mutate(storage)
    return set_meta(conn, VERSION, 2)
'''
    result = investigate(tmp_path, source, ("return " if returns else "") + "set_meta(conn, VERSION, _)")
    analysis = result["return_analysis" if returns else "call_analysis"]
    assert analysis["status"] == "unknown"


def test_caller_write_invalidates_constant_in_imported_helper(tmp_path):
    (tmp_path / "helper.py").write_text('VERSION = "graph_version"\ndef publish(conn):\n    set_meta(conn, VERSION, 2)\n')
    source = '''import helper
from helper import publish
def rebuild(conn):
    helper.VERSION = "other"
    publish(conn)
'''
    result = investigate(tmp_path, source, "set_meta(conn, 'graph_version', _)")
    assert result["call_analysis"]["status"] == "unknown"
