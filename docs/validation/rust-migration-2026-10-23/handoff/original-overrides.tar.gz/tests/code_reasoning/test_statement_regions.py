"""Normal-call obligations across ordinary assignments and loop regions."""

from pathlib import Path

import pytest

from ken.code_reasoning import CodeInvestigation


def check(tmp_path, body, contract, parameters="items, conn", prefix=""):
    (tmp_path / "flow.py").write_text(prefix + "def work(" + parameters + "):\n" + body)
    return CodeInvestigation.from_selector(project_root=tmp_path, selector="flow.py::work").check(contract)["call_analysis"]


def test_annotation_preserves_alias_and_does_not_execute_annotation(tmp_path):
    analysis = check(tmp_path, "    alias: annotation() = conn\n    alias.close()\n", "conn.close")
    assert analysis["status"] == "all_paths_called"
    assert check(tmp_path, "    value: annotation()\n", "annotation")["status"] == "missing_path"


def test_augmented_assignment_keeps_rhs_call_but_forgets_previous_argument_value(tmp_path):
    assert check(tmp_path, "    total = 0\n    total += conn.close()\n", "conn.close")["status"] == "all_paths_called"
    result = check(tmp_path, "    value = items\n    value += 1\n    publish(value)\n", "publish(items)")
    assert result["status"] == "unknown"


@pytest.mark.parametrize("assignment", ["total += (conn := item)", "total: int = (conn := item)"])
def test_expression_binding_cannot_keep_an_old_receiver_alias(tmp_path, assignment):
    result = check(tmp_path, "    total = 0\n    item = 1\n    " + assignment + "\n    conn.close()\n", "conn.close")
    assert result["status"] != "all_paths_called"


@pytest.mark.parametrize("loop", ["for item in items:", "while items:"])
def test_call_after_loop_is_witnessed_without_unrolling_iterations(tmp_path, loop):
    result = check(tmp_path, "    " + loop + "\n        count: int = 0\n        count += 1\n    conn.close()\n", "conn.close")
    assert result["status"] == "all_paths_called"


@pytest.mark.parametrize("body", [
    "    for item in items:\n        if item:\n            return\n    conn.close()\n",
    "    for conn in items:\n        pass\n    conn.close()\n",
    "    for item in items:\n        conn = item\n    conn.close()\n",
    "    for item in items:\n        conn.close()\n",
    "    for item in items:\n        def change(value=(conn := item)):\n            pass\n    conn.close()\n",
    "    for item in items:\n        def change():\n            nonlocal conn\n            conn = item\n        change()\n    conn.close()\n",
    "    for item in items:\n        class Change:\n            nonlocal conn\n            conn = item\n    conn.close()\n",
])
def test_loop_exit_and_rebinding_do_not_invent_a_guarantee(tmp_path, body):
    assert check(tmp_path, body, "conn.close")["status"] != "all_paths_called"


def test_loop_else_may_be_skipped_by_break(tmp_path):
    body = "    for item in items:\n        if item:\n            break\n    else:\n        conn.close()\n"
    assert check(tmp_path, body, "conn.close")["status"] != "all_paths_called"
    body = "    for item in items:\n        pass\n    else:\n        conn.close()\n"
    assert check(tmp_path, body, "conn.close")["status"] == "all_paths_called"


def test_loop_return_inside_local_helper_does_not_exit_caller(tmp_path):
    helper = "def scan(items):\n    for item in items:\n        if item:\n            return item\n"
    result = check(tmp_path, "    scan(items)\n    conn.close()\n", "conn.close", prefix=helper)
    assert result["status"] == "all_paths_called"


def test_order_across_loop_is_preserved_but_body_call_is_not_a_predecessor_proof(tmp_path):
    body = "    conn.flush()\n    for item in items:\n        total: int = 0\n        total += 1\n    conn.close()\n"
    assert check(tmp_path, body, "conn.flush -> conn.close")["status"] == "all_paths_called"
    body = "    for item in items:\n        conn.flush()\n    conn.close()\n"
    assert check(tmp_path, body, "conn.flush -> conn.close")["status"] != "all_paths_called"


def test_real_finding_rebuild_reaches_version_write_after_recomputing_edges():
    root = Path(__file__).resolve().parents[2]
    result = CodeInvestigation.from_selector(project_root=root,
        selector="src/ken/findings_graph.py::rebuild_finding_graph").check("recompute_finding_edges -> set_meta")
    assert result["call_analysis"]["status"] == "all_paths_called"


def test_large_helper_does_not_erase_caller_but_cannot_supply_a_witness(tmp_path):
    helper = "def expand(items):\n" + "".join(f"    if items[{i}]:\n        publish()\n" for i in range(10))
    result = check(tmp_path, "    expand(items)\n    publish()\n", "publish", prefix=helper)
    assert result["status"] == "all_paths_called"
    result = check(tmp_path, "    expand(items)\n", "publish", prefix=helper)
    assert result["status"] == "unknown"
    assert any("bounded_helper:expand" in effect for effect in result["unresolved_effects"])


def test_root_path_exhaustion_still_blocks_a_conclusion(tmp_path):
    body = "".join(f"    if items[{i}]:\n        publish()\n" for i in range(10))
    result = check(tmp_path, body + "    publish()\n", "publish")
    assert result["status"] == "unknown" and result["unsupported"] == ["path_limit"]


@pytest.mark.parametrize("body,proven", [
    ("    flush()\n    for item in items:\n        value: int = item\n        value += 1\n    publish()\n", True),
    ("    flush()\n    for item in items:\n        if item:\n            return\n    publish()\n", False),
    ("    for item in items:\n        flush()\n    publish()\n", False),
    ("    flush()\n    for item in items:\n        if item:\n            break\n    else:\n        publish()\n", False),
])
def test_order_conclusions_agree_with_executed_empty_and_nonempty_loops(tmp_path, body, proven):
    result = check(tmp_path, body, "flush -> publish", parameters="items")
    assert (result["status"] == "all_paths_called") is proven
    outcomes = []
    for items in ([], [0], [1], [0, 1], [1, 0]):
        events = []
        namespace = {"flush": lambda: events.append("flush"), "publish": lambda: events.append("publish")}
        exec(compile("def work(items):\n" + body, "flow.py", "exec"), namespace)
        namespace["work"](items)
        outcomes.append(any(event == "publish" and "flush" in events[:index] for index, event in enumerate(events)))
    assert all(outcomes) is proven
