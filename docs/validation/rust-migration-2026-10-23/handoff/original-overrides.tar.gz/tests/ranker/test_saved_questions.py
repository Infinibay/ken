"""Question identity locates candidates without claiming semantic equivalence."""

import json

import numpy as np

from ken.embedder import vec_to_blob
from ken.ranker import rank
from ken.ranker.channels import finding_scores


def save(conn, topic, tags, embedding=None):
    conn.execute(
        "INSERT INTO cr_findings(topic, content, tags, embedding, created_at, updated_at) VALUES (?,?,?,?,1,1)",
        (topic, "A structured conclusion with its own assumptions.", json.dumps(tags), embedding),
    )


def test_repeated_question_survives_missing_or_unrelated_embedding(conn):
    query = np.array([1.0, 0.0], dtype=np.float32)
    save(conn, "missing", ["question:What does Earth have?"])
    save(conn, "unrelated", ["question:What does Earth have?"], vec_to_blob(-query))
    result = rank(conn, agent_id="test", current_iteration=0,
                  prompt="What does Earth have?", prompt_embedding=query)
    assert {hit.topic for hit in result.findings} == {"missing", "unrelated"}
    assert all(hit.reason == "question:exact" for hit in result.findings)


def test_question_matching_preserves_negation_and_identifier_case(conn):
    query = np.array([1.0, 0.0], dtype=np.float32)
    save(conn, "upper", ["question:Does File.close release the handle?"])
    assert not finding_scores(conn, query, prompt="Does File.close not release the handle?")
    assert not finding_scores(conn, query, prompt="Does file.close release the handle?")
    assert not finding_scores(conn, query, prompt="")
    assert finding_scores(conn, query, prompt=" Does File.close release the handle? ")


def test_semantic_candidates_still_work_and_exact_match_is_not_duplicated(conn):
    query = np.array([1.0, 0.0], dtype=np.float32)
    save(conn, "exact", ["question:query"], vec_to_blob(query))
    save(conn, "semantic", [], vec_to_blob(query))
    hits = finding_scores(conn, query, prompt="query")
    assert [hit.topic for hit in hits].count("exact") == 1
    assert {hit.topic for hit in hits} == {"exact", "semantic"}
    assert any(hit.reason.startswith("finding:") for hit in hits)
