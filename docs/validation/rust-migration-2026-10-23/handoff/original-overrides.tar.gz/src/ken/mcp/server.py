"""stdio MCP server — entrypoint for ``ken mcp``.

Built on the official ``mcp`` Python SDK v2. The old ``FastMCP`` class
was renamed to ``MCPServer``; the decorator API (``@mcp.tool()``) is the
same shape it always was, so every tool below is a plain function with
type annotations and a docstring — same surface ken has exposed since
0.x. The CLI passthrough (``ken tools ...``) reads from a parallel
registry populated alongside the SDK registration, so it does not need
to spin up the stdio server to list tools.
"""

from __future__ import annotations

import inspect
import logging
import sqlite3
import sys
import types
import typing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

try:
    from mcp.server import MCPServer
except ImportError as _exc:
    from importlib.metadata import PackageNotFoundError, version as _pkg_version

    try:
        _installed = _pkg_version("mcp")
    except PackageNotFoundError:
        _installed = "not installed"

    sys.stderr.write(
        "ken mcp: this build of ken needs the `mcp` Python SDK >= 2.0, but the\n"
        f"environment only has `{_installed}` installed (reason: {_exc}).\n"
        "The MCP server cannot start with that version — `mcp.server.MCPServer`\n"
        "only exists in mcp 2.x; mcp 1.x still ships the older `FastMCP` API.\n"
        "\n"
        "This typically happens when an older ken-rank (0.10.0 or earlier,\n"
        "with the wrong `mcp>=1.0` pin in 0.10.0) was installed before the\n"
        "fix landed. Fix it with:\n"
        "\n"
        "    uv tool install --reinstall ken-rank\n"
        "    # or, for pipx:\n"
        "    pipx reinstall ken-rank\n"
        "    # or, for plain pip:\n"
        "    pip install --upgrade --force-reinstall ken-rank\n"
        "\n"
        "Then restart the assistant that hosts the MCP server (Claude Code,\n"
        "Codex, OpenCode, …) so it respawns the `ken mcp` process.\n"
    )
    sys.stderr.flush()
    raise SystemExit(1) from _exc

from ken import _paths
from ken.clones import clones
from ken.cochange import cochange
from ken.codeflow import callgraph, type_hierarchy, wiring
from ken.db import connect
from ken.graphtools import architecture, blast_radius
from ken.grep import grep
from ken.intent import intent_history
from ken.memory import forget, list_findings, recall, remember
from ken.profile import profile
from ken.search import (
    changed_context,
    file_neighbors,
    file_outline,
    file_snippets,
    file_symbols,
    find_tests,
    module_graph,
    project_overview,
    search_files,
    search_symbols,
    symbol_detail,
)

logger = logging.getLogger("ken.mcp")

# Each `ken mcp` is a *single project* server — coding agents launch
# one instance per workspace. The project root is resolved once at
# startup; if it's not a ken project we fail fast so the user sees
# a clear error in their MCP logs.
_PROJECT_ROOT: Path | None = None

mcp = MCPServer("ken")


def run(start: Path) -> int:
    """Resolve the project root, then hand control to the MCP stdio loop."""
    global _PROJECT_ROOT
    root = _paths.find_project_root(start.resolve()) or start.resolve()
    if not _paths.meta_path(root).is_file():
        print(f"ken mcp: no .ken project at {root}", file=sys.stderr)
        return 1
    _PROJECT_ROOT = root
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    from ken.kql2.process import prepare_process

    prepare_process(freeze=True)
    logger.info("ken mcp ready project_root=%s", root)
    mcp.run(transport="stdio")
    return 0


# ---- CLI tool registry --------------------------------------------------
#
# ``ken tools ...`` (the shell-side passthrough) reads tool names,
# descriptions, and parameter schemas from this registry so it does not
# need to spin up the MCP stdio loop just to print ``--help`` text. We
# mirror each ``@mcp.tool()`` registration into ``_REGISTRY`` via the
# ``_register`` helper below.


@dataclass
class ToolDef:
    """Lightweight record of a registered MCP tool.

    Mirrors the public surface of the old ``fastmcp.Tool`` object that
    ``ken tools ...`` was reading via ``mcp._tool_manager.list_tools()``:
    ``name``, ``description``, ``parameters`` (JSON schema), ``fn``, and
    ``is_async``.
    """

    name: str
    description: str
    fn: Callable[..., Any]
    is_async: bool
    parameters: dict[str, Any]
    input_schema: dict[str, Any]


_REGISTRY: dict[str, ToolDef] = {}


def _register(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Build a ``ToolDef`` from a function and stash it in ``_REGISTRY``.

    The function name becomes the tool name (callers use the
    ``ken_foo`` convention themselves). The JSON schema is derived from
    the function's signature — annotations become ``properties``,
    parameters with defaults become optional, the rest required. This is
    the same shape the SDK derives internally, so any agent that reads
    those schemas sees the same surface either way.
    """
    sig = inspect.signature(fn)
    # Resolve string annotations (``from __future__ import annotations``
    # makes every annotation a forward-reference string at runtime; we
    # need the real type object to map it to a JSON schema).
    # ``inspect.get_annotations(..., eval_str=True)`` evaluates those
    # strings against the function's own ``__globals__``, which is what
    # the SDK does internally to build its own tool schema.
    try:
        hints = inspect.get_annotations(fn, eval_str=True)
    except Exception:
        # Fallback for unresolvable forward refs: leave the annotation as-is.
        hints = {}
    properties: dict[str, Any] = {}
    required: list[str] = []
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        annotation = hints.get(name, param.annotation)
        prop, has_default = _annotation_to_schema(param, annotation)
        if prop is None:
            continue
        if not has_default:
            required.append(name)
        properties[name] = prop

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required

    _REGISTRY[fn.__name__] = ToolDef(
        name=fn.__name__,
        description=(fn.__doc__ or "").strip(),
        fn=fn,
        is_async=inspect.iscoroutinefunction(fn),
        parameters=schema,
        input_schema=schema,
    )
    return fn


def ken_tool(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Register ``fn`` as both an MCP tool and a CLI-passthrough tool."""
    from ken.mcp.presentation import present_tool

    public = present_tool(fn, root=lambda: _PROJECT_ROOT)
    mcp.add_tool(public, structured_output=False)
    _register(public)
    return fn


def list_tools() -> list[ToolDef]:
    """Snapshot of every registered tool, in insertion order."""
    return list(_REGISTRY.values())


# ── JSON-Schema derivation ─────────────────────────────────────────────
#
# Mirrors what the SDK's MCPServer does internally — narrowly, only for
# the annotation shapes ken actually uses (``str``, ``int``, ``float``,
# ``bool``, ``list[...]``, ``dict[...]``, ``X | None`` / ``Optional[X]``).

_PRIMITIVE_JSON_TYPE = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
}


def _annotation_to_schema(
    param: inspect.Parameter,
    annotation: Any | None = None,
) -> tuple[dict[str, Any] | None, bool]:
    """Return ``(schema_dict, has_default)`` for a single function parameter.

    ``has_default`` is True when the parameter is optional in the JSON
    schema sense — either it has a Python default or its annotation is
    ``Optional[X]`` / ``X | None``. Returns ``(None, True)`` for
    ``*args`` / ``**kwargs`` / ``self``, which are not part of the schema.

    ``annotation`` overrides ``param.annotation`` when given — callers that
    already resolved string forward references (e.g. from
    ``inspect.get_annotations(eval_str=True)``) pass the resolved type here
    so this helper doesn't have to know about module globals.
    """
    if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
        return None, True

    has_default = param.default is not inspect.Parameter.empty
    if annotation is None:
        annotation = param.annotation

    core, is_optional = _unwrap_optional(annotation)
    if is_optional:
        has_default = True

    if core is inspect.Parameter.empty or core is None:
        schema: dict[str, Any] = {}
    elif core in _PRIMITIVE_JSON_TYPE:
        schema = {"type": _PRIMITIVE_JSON_TYPE[core]}
    elif origin := typing.get_origin(core):
        if origin is typing.Literal:
            schema = _literal_schema(core)
        elif origin in (list, typing.List):
            schema = {"type": "array", "items": _items_schema(typing.get_args(core))}
        elif origin in (dict, typing.Dict):
            schema = {"type": "object"}
        else:
            schema = {}
    elif isinstance(core, type):
        schema = {"type": "string"}  # named types → opaque string for the agent
    else:
        schema = {}

    if param.default is not inspect.Parameter.empty and param.default is not None:
        schema["default"] = param.default

    return schema, has_default


def _unwrap_optional(annotation: Any) -> tuple[Any, bool]:
    """Return ``(inner, is_optional)`` for ``X | None`` / ``Optional[X]`` / ``None``."""
    if annotation is None or annotation is type(None):
        return type(None), True
    origin = typing.get_origin(annotation)
    # Both spellings of a union reach here. ``Optional[X]`` reports
    # ``typing.Union``; PEP 604's ``X | None`` reports ``types.UnionType``,
    # a genuinely different object until Python 3.14 unifies them. Matching
    # only the first silently degrades every ``X | None`` parameter to an
    # empty schema.
    if origin is typing.Union or origin is types.UnionType:
        args = [a for a in typing.get_args(annotation) if a is not type(None)]
        if len(args) == 1 and len(typing.get_args(annotation)) > 1:
            return args[0], True
        return annotation, False
    return annotation, False


def _literal_schema(core: Any) -> dict[str, Any]:
    """``Literal[...]`` → a JSON ``enum``, typed when the values agree.

    A closed set of values is the difference between a menu and free-form
    generation. Without the ``enum``, an agent has to guess what a mode
    argument accepts from prose that a host's description compression may
    already have trimmed — which is strictly worse than having been handed
    separate named tools.
    """
    values = list(typing.get_args(core))
    schema: dict[str, Any] = {"enum": values}
    kinds = {type(v) for v in values}
    if len(kinds) == 1:
        only = kinds.pop()
        if only in _PRIMITIVE_JSON_TYPE:
            schema["type"] = _PRIMITIVE_JSON_TYPE[only]
    return schema


def _items_schema(args: tuple[Any, ...]) -> dict[str, Any]:
    if not args:
        return {}
    inner, _ = _unwrap_optional(args[0])
    if inner in _PRIMITIVE_JSON_TYPE:
        return {"type": _PRIMITIVE_JSON_TYPE[inner]}
    if typing.get_origin(inner) is dict:
        return {"type": "object"}
    if typing.get_origin(inner) is list:
        return {"type": "array", "items": _items_schema(typing.get_args(inner))}
    if typing.get_origin(inner) is typing.Literal:
        # ``list[Literal[...]]`` — the element enum is the only place that
        # says which values the list may hold.
        return _literal_schema(inner)
    return {}


def _conn() -> sqlite3.Connection:
    if _PROJECT_ROOT is None:
        raise RuntimeError("MCP server not initialised — call run() first")
    return connect(_paths.db_path(_PROJECT_ROOT))


def _project_relative_path(path: str) -> str:
    """Validate a tool path and return its canonical index representation."""
    if _PROJECT_ROOT is None:
        raise RuntimeError("MCP server not initialised — call run() first")
    resolved = _paths.resolve_project_path(_PROJECT_ROOT, path)
    return resolved.relative_to(_PROJECT_ROOT.resolve()).as_posix()


# ---- MCP server tools ----------------------------------------------
#
# Same surface as before — same names, same docstrings, same parameter
# annotations and defaults. Only the registration mechanism changed
# (``@mcp.tool()`` now lives on ``MCPServer`` instead of ``FastMCP``);
# the bodies are byte-for-byte identical to the pre-migration server.


def _impl_ken_search_files(query: str, limit: int = 8) -> list[dict]:
    """Search the project's indexed files for ones semantically relevant to *query*.

    Cosine similarity against per-file embeddings (built from each
    file's language + base name + top symbol names — same shape the
    ranker's fuzzy channel uses). Returns the top *limit* hits with
    their score and a short symbol outline.

    When *query* is a bare identifier (``cochange``, ``reembed``) the semantic
    order is fused with a literal path match, and files matching it exactly are
    listed first with ``match: "exact"``. ``score`` stays the cosine either
    way, so with a literal match present the list is not in score order.
    """
    with _conn() as conn:
        return search_files(conn, query, limit=limit, project_root=_PROJECT_ROOT)


def _impl_ken_search_symbols(query: str, limit: int = 10) -> list[dict]:
    """Search the project's indexed symbols (functions, classes, methods) for
    ones semantically relevant to *query*.

    Cosine similarity against per-symbol embeddings (built from
    ``"{kind} {name} — {docstring_first_line}"``). Returns the top
    *limit* hits with their location and one-line doc.

    When *query* is a bare identifier the semantic order is fused with a
    literal name match: symbols named exactly that come first
    (``match: "exact"``), then partial matches (``"qualified"`` for a method of
    a class, ``"tokens"`` for a shared-word name) traded off against
    similarity. Without this a query like ``blast_radius`` returns
    ``test_blast_radius_reverse_reachability`` above the function itself.
    ``score`` remains the cosine, so the list is not in score order when a
    literal match is present. Prose queries are pure similarity, unchanged.
    """
    with _conn() as conn:
        return search_symbols(conn, query, limit=limit, project_root=_PROJECT_ROOT)


def _impl_ken_file_symbols(path: str, include_docstrings: bool = True) -> dict:
    """Return the indexed symbol structure for one file.

    *path* is the project-relative file path stored in Ken's index, such
    as ``src/ken/search.py``. Returns all symbols ordered by source line
    with kind, name, qualified name, start/end lines, and optionally the
    first docstring/comment line captured by the parser.
    """
    with _conn() as conn:
        return file_symbols(
            conn,
            path,
            include_docstrings=include_docstrings,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_file_outline(
    path: str,
    include_symbols: bool = True,
    include_imports: bool = True,
    include_docstrings: bool = True,
) -> dict:
    """Return a structural outline for one indexed file.

    Includes language, symbol count, optional symbols, optional imports,
    optional reverse imports, and optional first-line docstrings.
    """
    with _conn() as conn:
        return file_outline(
            conn,
            path,
            include_symbols=include_symbols,
            include_imports=include_imports,
            include_docstrings=include_docstrings,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_file_neighbors(path: str, limit: int = 20) -> dict:
    """Return files directly related to *path*.

    Uses resolved internal imports, reverse imports, and test-file
    heuristics to suggest files worth inspecting alongside the target.
    """
    with _conn() as conn:
        return file_neighbors(conn, path, limit=limit, project_root=_PROJECT_ROOT)


def _impl_ken_symbol_detail(path: str, qualname: str, include_snippet: bool = False) -> dict:
    """Return metadata for one symbol in one file, optionally with source."""
    with _conn() as conn:
        return symbol_detail(
            conn,
            path,
            qualname,
            include_snippet=include_snippet,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_module_graph(path: str, depth: int = 1, limit: int = 100) -> dict:
    """Return a bounded local import graph around one indexed file.

    ``limit`` caps *nodes*. Every returned edge has both endpoints in ``nodes``,
    so the graph is always well-formed; when the cap cut the neighbourhood
    short, a ``truncated`` block reports how many edges that dropped.
    """
    with _conn() as conn:
        return module_graph(
            conn, path, depth=depth, limit=limit, project_root=_PROJECT_ROOT
        )


def _impl_ken_find_tests(path: str, limit: int = 20) -> dict:
    """Return likely test files for an indexed source file, best evidence first.

    Each candidate accumulates every channel that fired, and ``score`` ranks
    them: being named by the ecosystem's convention (``test_x``, ``x_test``,
    ``x.spec.ts``, ``XTest.java``) counts far more than merely importing the
    target — for a widely-imported module like ``db.py`` almost every test does
    that. Name matching is on whole tokens, so ``cli.py`` does not pull in
    ``test_client.py``.
    """
    with _conn() as conn:
        return find_tests(conn, path, limit=limit, project_root=_PROJECT_ROOT)


def _impl_ken_changed_context() -> dict:
    """Return current git changes enriched with indexed symbols and tests."""
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return changed_context(conn, _PROJECT_ROOT)


def _impl_ken_file_snippets(
    path: str,
    symbols: list[str] | None = None,
    start_line: int | None = None,
    end_line: int | None = None,
    max_chars: int = 12000,
) -> dict:
    """Return source snippets for selected symbols or a line range."""
    with _conn() as conn:
        return file_snippets(
            conn,
            path,
            symbols=symbols,
            start_line=start_line,
            end_line=end_line,
            max_chars=max_chars,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_project_overview(depth: int = 2, limit: int = 20) -> dict:
    """Return a compact structural overview of the indexed project."""
    with _conn() as conn:
        return project_overview(conn, depth=depth, limit=limit)


def _impl_ken_remember(
    topic: str,
    content: str,
    tags: list[str] | None = None,
    kind: str | None = None,
    anchors: dict[str, str] | None = None,
    justification: dict[str, Any] | None = None,
) -> dict:
    """Write a finding for future sessions to recall.

    *topic* is a short lookup key (unique — re-using a topic updates
    the existing row). *content* is the body — usually a few sentences
    capturing a fact you don't want to re-derive next time. *kind* can
    explicitly classify the note as finding, persistent_rule,
    experimental_finding, or hypothesis. *anchors* declares what the note
    is about so it can be recalled by that instead of by a query.
    """
    live = {k: v for k, v in (anchors or {}).items() if (v or "").strip()}
    with _conn() as conn:
        return remember(conn, topic, content, tags=tags, kind=kind,
                        anchors=live or None, justification=justification,
                        project_root=_PROJECT_ROOT)


def _impl_ken_forget(topic: str) -> dict:
    """Delete a saved finding by exact *topic*.

    Use ``ken_findings`` or ``ken_recall`` first if you need to discover
    the exact topic. Returns ``deleted=0`` when no finding matched.
    """
    with _conn() as conn:
        return forget(conn, topic)


def _impl_ken_findings(limit: int = 20, tag: str | None = None) -> list[dict]:
    """List recent saved findings, optionally filtering by exact tag."""
    with _conn() as conn:
        return list_findings(conn, limit=limit, tag=tag)


def _impl_ken_recall(query: str, limit: int = 5, min_score: float = 0.25) -> list[dict]:
    """Search previously-saved findings by semantic similarity to *query*.

    Results below *min_score* are omitted. Set ``min_score=0`` to inspect
    nearest neighbors even when they are likely noise.
    """
    with _conn() as conn:
        return recall(conn, query, limit=limit, min_score=min_score)


def _impl_ken_related_findings(
    topic: str,
    limit: int = 8,
    min_weight: float = 0.3,
) -> dict:
    """Saved findings related to *topic* in the findings knowledge graph.

    Links are deterministic and evidence-cited: two findings connect when they
    reference the same file/symbol (``shared_file`` / ``shared_symbol`` — exact),
    share meaningful tags (``shared_tag``), or are close in embedding space
    (``semantic`` — approximate). *topic* resolves by exact match, else the top
    ``ken_recall`` hit. Neighbors are ranked evidence-backed-first, then by
    weight; each carries its per-edge evidence. Returns empty rather than guessing.
    """
    with _conn() as conn:
        from ken.findings_graph import related_findings

        return related_findings(conn, topic, limit=limit, min_weight=min_weight)


def _impl_ken_file_findings(path: str, expand: bool = False, limit: int = 15) -> dict:
    """Durable findings that reference *path* — "what do we already know here?".

    Uses the finding→code bridge: each saved finding's prose is resolved to
    indexed ``ci_files`` paths, so this surfaces accumulated knowledge about a
    file before you edit it. With ``expand=True``, also returns findings one hop
    away in the graph. Resolution is index-based, so it lags a just-deleted file
    until the next reindex.
    """
    with _conn() as conn:
        from ken.findings_graph import file_findings

        return file_findings(
            conn, path, expand=expand, limit=limit, project_root=_PROJECT_ROOT
        )


def _impl_ken_cochange(
    path: str,
    min_confidence: float = 0.4,
    min_support: int = 3,
    min_llr: float = 3.841,
    limit: int = 15,
) -> dict:
    """Files historically changed together with *path* — including hidden coupling.

    Mines git commit history as market-basket transactions (support /
    confidence / lift with recency decay) and **subtracts the import graph**,
    so the headline is the logical coupling imports can't see: schema <->
    migration, code <-> config, parallel implementations. Partners with no
    import edge are flagged ``hidden_coupling`` and sorted first. Returns an
    empty list rather than guessing when evidence is below threshold.

    Statistics are computed within the target file's own repo (``scope``), so a
    workspace of sibling repos does not inflate lift. Per partner:

    * ``confidence`` — P(partner changes | target changes), recency-weighted.
    * ``confidence_low`` — Wilson 95% lower bound on that probability from the
      raw counts. Read this, not ``confidence``, when support is small.
    * ``lift`` — how many times more often than chance they co-change.
    * ``llr`` — Dunning G², a χ²(1) significance score. Pairs below *min_llr*
      (default 3.841 = p<0.05) are dropped as indistinguishable from chance,
      however high their lift. Pass ``min_llr=0`` to see them anyway.
    * ``strength`` — the ranking key: confidence discounted by evidence thinness.
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return cochange(
            conn,
            path,
            min_confidence=min_confidence,
            min_support=min_support,
            min_llr=min_llr,
            limit=limit,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_blast_radius(path: str, max_hops: int = 4) -> dict:
    """Files likely affected by editing *path*, with per-channel evidence.

    Reverse import reachability (transitive importers + hop distance) unioned
    with test heuristics and git co-change. Every impacted file lists its
    evidence ("imports(hop 2)", "test-of", "co-changed 8x") — never a fused
    black-box score. Reports unresolved-import coverage as an explicit lower
    bound, so the agent knows the result is a floor, not a ceiling.
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return blast_radius(conn, path, max_hops=max_hops, project_root=_PROJECT_ROOT)


def _impl_ken_architecture(depth: int = 2, limit: int = 20) -> dict:
    """Subsystems, layers, dependency cycles, and load-bearing hubs of the project.

    Graph algorithms over the resolved import graph: Tarjan SCC (import
    cycles — exact), topological layering (approximate), label-propagation
    communities, and PageRank hubs + reverse-PageRank foundations. Every
    result carries an ``edge_coverage`` header ("resolves 140/210 imports")
    so the agent calibrates: cycles are high-trust, layers/communities degrade
    as unresolved imports rise.

    Output is bounded for large monorepos: ``limit`` caps items per list and
    files listed per item (cycles/clusters/layers report a ``size`` plus a
    capped sample), and ``depth`` is how many layers carry file samples (deeper
    layers are size-only). A ``summary`` reports the full counts. Raise either
    to see more.
    """
    with _conn() as conn:
        return architecture(conn, depth=depth, limit=limit)


def _impl_ken_profile(path: str, granularity: str = "file", top_terms: int = 12) -> dict:
    """What a file/package is *for* and what distinguishes it from its siblings.

    Weighted log-odds-ratio with an informative Dirichlet prior (Monroe et
    al.) over the file's symbol names, qualnames, and docstrings — every term
    is a real, verifiable token from the index, not a generated summary. Set
    ``granularity='dir'`` to profile a whole package. Reports evidence
    strength so thin directories are flagged.
    """
    with _conn() as conn:
        return profile(conn, path, granularity=granularity, top_terms=top_terms)


def _impl_ken_clones(
    path: str | None = None,
    qualname: str | None = None,
    min_similarity: float = 0.75,
    limit: int = 10,
) -> dict:
    """Find near-duplicate / copy-pasted symbols (MinHash + LSH over token shingles).

    With *path* (and optionally *qualname*), returns clones of that symbol.
    Without a path, returns the strongest duplicate pairs project-wide. Purely
    lexical set-similarity — no embeddings, no LLM. Anti-boilerplate floor
    keeps tiny identical stubs from flooding results.

    MinHash + LSH only *retrieve* candidates; the reported ``similarity`` is
    the exact Jaccard of the token-shingle sets, so it can be compared against
    *min_similarity* directly. ``containment`` is the share of the smaller
    symbol found in the larger one — near 1.0 with a lower similarity means one
    body was pasted verbatim into something bigger. Banding adapts to
    *min_similarity*, so lowering it genuinely widens the search.
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return clones(
            conn,
            path,
            qualname=qualname,
            min_similarity=min_similarity,
            limit=limit,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_intent_history(query: str, k_prompts: int = 12, limit: int = 15) -> dict:
    """Which files a request *like this one* historically ended up touching.

    Relevance-by-outcome: finds the nearest historical ``user_prompt`` turns by
    embedding cosine, then tallies the files those sessions touched (weighted by
    prompt similarity x interaction weight). Distinct from ``ken_search_files``
    (content match) — this routes by what past similar work actually did.
    Returns the matched prompts so you see *why* each file was routed.
    """
    with _conn() as conn:
        return intent_history(
            conn, query, k_prompts=k_prompts, limit=limit, project_root=_PROJECT_ROOT
        )


def _impl_ken_grep(
    query: str, mode: str = "literal", language: str | None = None, limit: int = 20
) -> dict:
    """Exact-literal or BM25-ranked search over the live worktree.

    ``mode='literal'`` (default): exact substring match scanned fresh from
    disk, with line-cited snippets — never stale. ``mode='bm25'``: ranked
    relevance via an FTS5 index whose tokenizer preserves identifier
    characters (``_ . -``) so ``MY_ENV_VAR`` and ``os.path`` are findable.
    Optional ``language`` filter (e.g. "python").
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return grep(
            conn,
            query,
            mode=mode,
            language=language,
            limit=limit,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_callgraph(
    qualname: str,
    path: str | None = None,
    direction: str = "both",
    min_confidence: str = "T2",
    limit: int = 50,
) -> dict:
    """Who calls *qualname* and what it calls — precision-tiered call graph.

    Extracts real call-sites from the AST (no token scans) and resolves each
    to a symbol only in confidence tiers: **T1** = same-file or repo-unique
    name; **T2** = name resolves to a single imported file; **T3** = ambiguous,
    reported as an unresolved call-site, never argmax'd into a false edge.
    ``direction`` is callers | callees | both. Works for any tree-sitter
    language ken indexes (Python, JS/TS, Go, Rust, Java, C, Dart, …).
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return callgraph(
            conn,
            qualname,
            path=path,
            direction=direction,
            min_confidence=min_confidence,
            limit=limit,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_wiring(
    query: str | None = None, trigger_kind: str | None = None, limit: int = 50
) -> dict:
    """How features are wired up: routes / CLI / env-var triggers -> handler symbols.

    Extracts decorator/registration nodes (``@app.route``, ``@click.command``)
    and ``os.environ``/``getenv`` reads from the AST, binding each to its
    enclosing symbol by line range. Recognises Flask/NestJS/Spring-style route
    decorators and annotations across languages. Filter by ``trigger_kind``
    (route | cli | env | decorator) or a substring ``query``. Line-cited.
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return wiring(
            conn,
            query=query,
            trigger_kind=trigger_kind,
            limit=limit,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_type_hierarchy(
    qualname: str, direction: str = "sub", with_overrides: bool = True
) -> dict:
    """Subclasses / ancestors of a class, with best-effort override detection.

    Extracts ``class X(Base)`` clauses from the AST and walks the transitive
    closure: ``direction='sub'`` lists descendants, ``'super'`` lists ancestors
    (including unresolved external bases like ``BaseModel``, kept verbatim).
    With ``with_overrides``, flags subclasses that redefine a method name of the
    target class (best-effort — ignores signatures). Works across OO languages
    ken indexes (Python, JS/TS, Java, Dart).
    """
    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        return type_hierarchy(
            conn,
            qualname,
            direction=direction,
            with_overrides=with_overrides,
            project_root=_PROJECT_ROOT,
        )


def _impl_ken_rank(query: str = "", verbose: int = 1, max_chars: int = 0) -> dict:
    """Re-render the context-rank for the current session at a chosen verbosity.

    The default ``<context-rank>`` block injected before each user
    prompt is intentionally terse. Call this when you want more detail:

    * ``verbose=0`` — same compact list-only format as the auto-injected
      block.
    * ``verbose=1`` — top 5 files with a 3-line outline of each and a
      ranked symbols section.
    * ``verbose=2`` — top 8 files with a 12-line outline of each plus
      symbols. Largest payload.

    Set ``max_chars`` to a positive integer to cap the rendered block
    by dropping whole interior lines while preserving valid tags.

    With *query* empty (default), this re-renders the ranker's cached
    output for the most recent prompt — cheap, no recomputation. Pass
    a *query* to run the ranker against that intent without reactive
    session carry-over.
    """
    from ken.daemon import client as daemon_client

    assert _PROJECT_ROOT is not None
    resp = daemon_client.post(
        _PROJECT_ROOT,
        "/rank",
        {"query": query, "verbose": int(verbose), "max_chars": int(max_chars)},
    )
    if resp is None:
        return {"ok": False, "error": "daemon unreachable"}
    return resp


def _impl_ken_explain_rank(query: str = "") -> dict:
    """Per-channel breakdown of the ranker for a query (or the last prompt).

    Returns each channel's raw output (traceback/explicit / reactive /
    predictive / fuzzy / lexical / findings), the merged pre-boost scores, the per-boost
    score deltas (symbol-file affinity, freshness, co-occurrence, test/import
    affinity, dismissal penalty), and the final
    ordering. Use this when "why didn't file X show up?" or "where did
    that score come from?" matters more than the rendered block.

    *query* defaults to the most recent prompt in the active session.
    """
    from ken.daemon import client as daemon_client

    assert _PROJECT_ROOT is not None
    resp = daemon_client.post(_PROJECT_ROOT, "/explain", {"query": query})
    if resp is None:
        return {"ok": False, "error": "daemon unreachable"}
    return resp


def _impl_ken_dismiss(target: str, reason: str = "") -> dict:
    """Explicit "this file wasn't what I was looking for" signal.

    Records a ``dismissed`` interaction against the current active
    session — the predictive ranker will treat this target as a negative
    example for similar prompts in future sessions.
    Requires a running daemon with an active hook-backed session.
    """
    from ken.daemon import client as daemon_client

    assert _PROJECT_ROOT is not None
    health = daemon_client.health(_PROJECT_ROOT)
    if not health or health.get("sessions_active", 0) == 0:
        return {
            "ok": False,
            "error": (
                "no active session — open a coding agent inside the project "
                "and try again"
            ),
        }
    resp = daemon_client.post(
        _PROJECT_ROOT,
        "/interactions/dismiss",
        {"target": target, "reason": reason},
    )
    if resp is None:
        return {"ok": False, "error": "daemon unreachable"}
    return resp


# ─────────────────────────────────────────────────────────────────────────
# The public surface: six tools over the thirty implementations above.
#
# Thirty tools is a menu no one can read. Anthropic's test for a toolset is
# whether *a human engineer* could say unambiguously which one to reach for,
# and ``ken_file_symbols`` / ``ken_file_outline`` / ``ken_symbol_detail`` /
# ``ken_file_snippets`` fail it — four names for "tell me about this file",
# separated only by which fields come back.
#
# The split is deliberate and it is not "merge everything":
#
#   * PROJECTIONS — the same data in different shapes — collapse into a
#     selection argument. That is ``ken_read``.
#   * ALGORITHMS — where ken decides what matters, using channel fusion,
#     personalised PageRank, per-turn decay, co-change LLR, MinHash — stay
#     NAMED, as closed enums. Their whole value is that the caller does not
#     need to know how they work, so the model picks *which* algorithm and
#     never *how to rank*.
#
# Ranking is therefore never something the model expresses. There is no
# ``order_by`` anywhere in this surface, by design.
#
# ``ken_remember`` is separate from ``ken_recall`` for a reason that outlives
# taste: hosts gate read-only agent tiers on a tool's read-only-ness, so
# folding writes into the retrieval tool behind an ``action=`` argument would
# hand a write capability to every read-only tier that has it.


@ken_tool
def ken_find(
    query: str = "",
    scope: Literal["files", "symbols", "text", "tests", "wiring", "intent", "structure", "patterns", "bugs"] = "files",
    limit: int | None = None,
    literal: bool = False,
    language: str = "",
    path: str = ".",
    cache_mb: float | None = None,
    timeout_ms: int | None = None,
    rules: list[str] | None = None,
    collections: list[str] | None = None,
    tags: list[str] | None = None,
    rule_files: list[str] | None = None,
    evidence_mode: Literal["strict", "possible"] = "strict",
    full: bool = False,
    query_language: Literal["kenql/1", "kql/2"] = "kenql/1",
    libraries: dict[str, str] | None = None,
    saved_query: str | None = None,
    query_name: str | None = None,
    response_format: Literal["auto", "legacy", "evidence", "compact"] = "auto",
    purpose: Literal["auto", "implementation", "usage", "tests", "documentation"] = "auto",
    max_chars: int = 12000,
    piece_kind: Literal["auto", "class", "module", "symbol", "file"] = "auto",
) -> Any:
    """Find code by meaning, text, structure, design patterns, or bug signatures.

    Write natural-language code-search queries in English; translate the user's
    intent yourself and reply in their preferred language. Preserve identifiers,
    paths, quoted source, literal text, regexes and KQL exactly. State whether
    the requested piece is a class, module, function or file; use piece_kind
    when known. Distinguish a test case from a helper used by tests.

    *scope* picks what is searched:

    * ``files``   — semantic match over per-file embeddings.
    * ``symbols`` — semantic match over per-symbol embeddings; a bare
      identifier also fuses in an exact-name match.
    * ``text``    — the live worktree. BM25-ranked by default, or exact
      substring when *literal* is true. Never stale: read from disk.
    * ``tests``   — the tests that cover *query* read as a path.
    * ``wiring``  — routes, CLI commands and env-var triggers that reach a
      handler.
    * ``intent``  — which files requests *like this one* historically ended
      up touching. Answers "where does work like this usually land?".

    * ``structure`` — unified graph search: inline *query* or saved *rules*,
      *collections*, *tags*. Load shared libraries with *rule_files*.
    * ``patterns`` — comma-separated GoF catalogue ids, or empty for all 23.
    * ``bugs`` — source-level bug signatures (query filters rule ids).

    Structural scopes read live files under *path*. Cache defaults to 500 MB;
    set *cache_mb=0* to disable. Results include evidence, uncertainty and budgets.

    Structural scopes are unlimited by default: every rule runs to completion,
    so an empty ``findings``/``matches`` list means "searched and not found"
    rather than "budget exhausted". Pass *limit* or *timeout_ms* to cap matches
    or latency when a host needs a bound.

    Structural results are compact by default -- what was found, where, with what
    confidence. Set *full=True* for the verbatim result with evidence trees,
    per-rule outcomes and directory rollups.

    *language* filters ``text`` results (e.g. "python").
    For KQL2 use scope="structure", query_language="kql/2" and an inline
    versioned query, or *saved_query* naming a module saved with ken_query.
    *query_name* chooses an entry when a module declares several queries.
    Imports resolve registered patterns automatically; explicit *libraries*
    override registry modules. *libraries* maps module names to KQL2 source text; results
    retain coverage and budget status. Saved TOML selectors still use KQL1.

    Files/symbols use the complete best search configuration by default.
    piece_kind="auto" infers class/module/symbol/file; an explicit value overrides it.
    For files/symbols, response_format="evidence" uses the prepared retrieval
    profile and returns owners with source-verified snippets, ranges, source
    hashes and explicit truncation. purpose="auto" infers the requested role;
    an explicit purpose overrides it. max_chars bounds the complete JSON response.
    response_format="compact" returns the same locations and verified code as
    plain text, with separate ranges for disjoint snippets and no scores or hashes.
    Legacy responses preserve their cosine score and existing shape.
    """
    if response_format in ("auto", "compact") and scope in ("files", "symbols"):
        if literal or query_language != "kenql/1":
            raise ValueError("semantic search requires nonliteral scope=files or symbols")
        from contextlib import closing
        from ken.retrieval.public import find_best, render
        from ken.retrieval.connections import project_connection
        assert _PROJECT_ROOT is not None
        with project_connection(_PROJECT_ROOT) as conn:
            response = find_best(conn, _PROJECT_ROOT, query, scope=scope, purpose=purpose,
                limit=10 if limit is None else limit, max_chars=max_chars, explain=full, piece_kind=piece_kind)
        return render(response, diagnostics=full) if response_format == "compact" else response
    if piece_kind != "auto":
        raise ValueError("piece_kind requires the default or compact files/symbols search")
    if response_format in ("evidence", "compact"):
        if literal or scope not in ("files", "symbols") or query_language != "kenql/1":
            raise ValueError("evidence responses require nonliteral scope=files or symbols")
        from contextlib import closing
        from ken.retrieval.public import find, render
        assert _PROJECT_ROOT is not None
        with closing(_conn()) as conn:
            response = find(conn, _PROJECT_ROOT, query, scope=scope, purpose=purpose,
                            limit=10 if limit is None else limit, max_chars=max_chars, explain=full)
        return render(response) if response_format == "compact" else response
    if purpose != "auto":
        raise ValueError("purpose requires response_format=evidence or compact")
    if query_language == 'kql/2':
        if scope != 'structure' or any((rules, collections, tags, rule_files)):
            raise ValueError('KQL2 requires a structural query; TOML migration is separate')
        if evidence_mode != 'strict':
            raise ValueError('KQL2 evidence modes are expressed by the query, not the KQL1 flag')
        from ken.kql2.automatic import search as search_kql2
        from ken.checks.report import query_view
        assert _PROJECT_ROOT is not None
        named = {}
        if saved_query is not None:
            named['saved_query'] = saved_query
        if query_name is not None:
            named['query_name'] = query_name
        result = search_kql2(_PROJECT_ROOT, query or None, path=path, cache_mb=cache_mb,
                           timeout_ms=timeout_ms, max_rows=limit,
                           libraries=libraries, **named)
        return query_view(result, full=full)
    if libraries or saved_query is not None or query_name is not None:
        raise ValueError('libraries, saved_query and query_name require query_language=kql/2')
    if scope != "structure" and any((rules, collections, tags, rule_files)):
        raise ValueError("saved rule selectors require scope=structure")
    ranked_limit = 10 if limit is None else limit
    if scope in {"structure", "patterns", "bugs"}:
        if scope == "structure" and rules:
            from ken.checks.store import Store
            from ken.checks.integration import search as search_checks
            assert _PROJECT_ROOT is not None
            known = {r["definition"]["id"] for r in Store(_PROJECT_ROOT).rules()}
            if set(rules) & known:
                if set(rules) - known or any((query, collections, tags, rule_files)):
                    raise ValueError("search registered check rules separately from catalog selectors")
                return search_checks(_PROJECT_ROOT, rules, path=path, timeout_ms=timeout_ms or 10000,
                                     max_rows=limit or 100, full=full)
        from ken.structural import report, service
        from ken.structural.query import QueryBudget
        assert _PROJECT_ROOT is not None
        budget = QueryBudget(max_matches=limit, timeout_ms=timeout_ms)
        detail = "full" if full else "compact"
        if scope == "structure":
            return report.present(service.search(_PROJECT_ROOT, query, path=path, cache_mb=cache_mb, budget=budget,
                                                 rule_ids=rules, collections=collections, tags=tags,
                                                 rule_files=rule_files, evidence_mode=evidence_mode),
                                  kind="structure", detail=detail)
        if scope == "patterns":
            names = [name.strip() for name in query.split(",") if name.strip()]
            return report.present(service.patterns(_PROJECT_ROOT, names, path=path, cache_mb=cache_mb, budget=budget),
                                  kind="patterns", detail=detail)
        result = service.bugs(_PROJECT_ROOT, path=path, cache_mb=cache_mb, budget=budget)
        if query:
            result["findings"] = [f for f in result["findings"] if query in f["id"]]
        return report.present(result, kind="bugs", detail=detail)
    if scope == "files":
        return _impl_ken_search_files(query, limit=ranked_limit)
    if scope == "symbols":
        return _impl_ken_search_symbols(query, limit=ranked_limit)
    if scope == "text":
        return _impl_ken_grep(
            query,
            mode="literal" if literal else "bm25",
            language=language,
            limit=ranked_limit,
        )
    if scope == "tests":
        return _impl_ken_find_tests(_project_relative_path(query), limit=ranked_limit)
    if scope == "wiring":
        return _impl_ken_wiring(query=query, limit=ranked_limit)
    if scope == "intent":
        return _impl_ken_intent_history(query, limit=ranked_limit)
    return {
        "ok": False,
        "error": f"unknown scope {scope!r}",
        "scopes": ["files", "symbols", "text", "tests", "wiring", "intent", "structure", "patterns", "bugs"],
    }


@ken_tool
def ken_query(
    action: Literal["save", "list", "show", "delete"] = "list",
    module: str = "",
    source: str = "",
    description: str | None = None,
    expected_revision: str | None = None,
    prefix: str = "",
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Save and discover reusable KQL2 modules in the project's Ken DB.

    save takes complete versioned source with a module declaration and queries
    or patterns; save imported modules first. show returns source and revision.
    Replacing source requires the current expected_revision from show; identical
    saves are idempotent. delete refuses modules imported by another saved module.
    list returns metadata with prefix/limit/offset pagination. Saving checks syntax
    and imports; execution checks backend support. Execute with ken_find using
    scope="structure", query_language="kql/2", saved_query=module and optional
    query_name. Inline queries can import saved patterns and use them normally.
    These modules are reusable searches, not validated/enabled source contracts;
    use ken_rule for contracts with passing and failing examples.
    """
    from ken.kql2.registry import ModuleRegistry, module_tree

    assert _PROJECT_ROOT is not None
    registry = ModuleRegistry(_PROJECT_ROOT)
    if action == 'save':
        if module and module_tree(source).module != module:
            raise ValueError('module conflicts with source declaration')
        return registry.save(source, description=description, expected_revision=expected_revision).to_dict()
    if action == 'list':
        if not 1 <= limit <= 200 or offset < 0:
            raise ValueError('limit must be 1..200 and offset must be nonnegative')
        records = [record for record in registry.list_modules() if record.module.startswith(prefix)]
        return {'modules':[record.to_dict() for record in records[offset:offset + limit]],
                'total':len(records), 'offset':offset, 'limit':limit}
    if not module:
        raise ValueError('show/delete requires module')
    if action == 'show':
        return registry.get(module).to_dict(source=True)
    if action == 'delete':
        registry.delete(module, expected_revision=expected_revision)
        return {'deleted':module}
    raise ValueError('action must be save/list/show/delete')


@ken_tool
def ken_rule(
    action: Literal["list", "create", "show", "update", "validate", "enable", "disable"] = "list",
    rule_id: str = "",
    definition: dict[str, Any] | None = None,
    automatic: bool | None = None,
    timeout_ms: int = 30000,
    full: bool = False,
) -> dict:
    """Author and validate reusable KQL2 source contracts.

    create/update take a complete definition: {id, query, description, path?: ".",
    expectation?: "no_matches"|"some_match", libraries?: {module: source},
    examples?: [{name, files: {relative_path: source_text}, expect: "pass"|"fail"|"unknown"}]}.
    Query is explicit versioned KQL2, not natural language. no_matches checks for
    zero violations; some_match requires at least one witness, not every entity.
    Examples are parsed in isolated temporary projects, never executed as code.
    New/updated rules are drafts. validate requires passing AND failing examples;
    enable requires successful validation for this definition and engine.
    enable(automatic=true) opts this rule into bounded edit/turn-end checks.
    show(full=true) exposes the full query, examples and validation evidence.
    """
    from ken.checks.rules import manage
    assert _PROJECT_ROOT is not None
    return manage(_PROJECT_ROOT, action, rule_id=rule_id, definition=definition,
                  automatic=automatic, timeout_ms=timeout_ms, full=full)


@ken_tool
def ken_check(
    rules: list[str] | None = None,
    path: str = ".",
    scope: Literal["project", "changes"] = "project",
    compare: str = "",
    run_id: str = "",
    timeout_ms: int = 10000,
    max_rows: int = 100,
    full: bool = False,
) -> dict:
    """Check source contracts and retain an immutable, reusable receipt.

    Defaults to enabled validated rules. Explicit rules may include drafts for
    diagnostics. path and scope="changes" SELECT relevant rules; each rule still
    runs over its entire declared path, preserving its proof scope. changes
    includes staged, unstaged and untracked Git paths. compare is a prior run ID
    or "last"; regressions/resolutions require comparable determinate results.
    run_id retrieves a historical receipt without rerunning queries.
    Status is pass/fail/unknown/not_applicable. Timeout, missing coverage,
    uncertain candidates or truncation cannot certify a passing check.
    timeout_ms bounds preparation and execution; full retains queries' evidence,
    snapshots and coverage. Source contracts are not runtime guarantees.
    Use ken_remember(check_run=run_id) to attach the receipt to a memory.
    """
    from ken.checks.service import check
    assert _PROJECT_ROOT is not None
    return check(_PROJECT_ROOT, rules=rules, path=path, scope=scope, compare=compare,
                 run_id=run_id, timeout_ms=timeout_ms, max_rows=max_rows, full=full)


@ken_tool
def ken_code_find(
    contract: str,
    search_path: str | None = None,
    limit: int = 10,
    max_candidates: int = 100,
    full: bool = False,
    timeout_ms: int = 15000,
) -> dict:
    """Find Python functions with a direct KQL2 candidate and check each one.

    contract may be ``os.fsync -> os.replace`` or ``return save(user)``.
    The default scope is src/ when present; search_path can select a project
    directory or one Python file. Results distinguish path witnesses,
    counterexamples, and unresolved paths. Discovery includes only direct
    KQL2 candidates: helpers and wrappers may be absent, even with complete
    source coverage. Use ken_code_check on a returned selector for assumptions
    about one function. full includes source traces and the generated query.
    """
    from ken.code_reasoning import CodeDiscovery

    assert _PROJECT_ROOT is not None
    try:
        return CodeDiscovery(_PROJECT_ROOT).find(
            contract,
            search_path=search_path,
            limit=limit,
            max_candidates=max_candidates,
            timeout_ms=timeout_ms,
            detail="full" if full else "answer",
        )
    except (ValueError, OSError) as exc:
        return {"ok": False, "error": str(exc)}


@ken_tool
def ken_code_check(
    selector: str,
    contract: str,
    when: dict[str, bool] | None = None,
    effect_priors: dict[str, float] | None = None,
    full: bool = False,
    timeout_ms: int = 15000,
    search_path: str | None = None,
) -> dict:
    """Investigate a Python call or returned-value contract.

    selector is a unique function name, Class.method, or path.py::function.
    Short names search src/ by default when present; search_path narrows or
    changes that discovery directory. contract may be
    os.replace(src, dst), os.fsync -> os.replace(src, dst), or
    return save(user). KQL2 finds direct same-function candidates;
    source-path analysis checks normal paths and reports witnesses, missing
    paths, or uncertainty. Return contracts track direct calls and local
    assignment aliases, not arbitrary transformations. effect_priors are
    investigator assumptions about unresolved callees satisfying the requested
    contract, not learned bug probabilities. For ordered contracts, a target-call prior alone does
    not prove the predecessor occurred first. The result includes probability
    bounds, source locations, and coverage. full includes path traces and
    the KQL2 query. Only normal completion paths are modeled.
    """
    from ken.code_reasoning import CodeInvestigation

    assert _PROJECT_ROOT is not None
    try:
        return CodeInvestigation.from_selector(
            project_root=_PROJECT_ROOT,
            selector=selector,
            search_path=search_path,
        ).check(
            contract,
            when=when,
            effect_priors=effect_priors,
            timeout_ms=timeout_ms,
            detail="full" if full else "answer",
        )
    except (ValueError, OSError) as exc:
        return {"ok": False, "error": str(exc)}


@ken_tool
def ken_who(
    question: str,
    path: str = ".",
    hypotheses: list[str] | None = None,
    limit: int = 3,
    include_tests: bool = False,
    full: bool = False,
    verify: bool = True,
    timeout_ms: int = 3000,
) -> dict:
    """Who is responsible? Find modules, classes, methods and functions by documentation.

    Write the natural-language question in English, translating the user's
    intent yourself. Preserve exact identifiers, paths and quoted source;
    reply to the user in their preferred language.

    Combines documentation, name and call-site reasoners, with counterevidence
    and explicit assumptions. Confidence is an uncalibrated ranking score, NOT
    a probability or proof that code implements the documented behavior.
    Searches current code documentation through the code index, not saved findings.
    Returns compact candidates and relevant caveats by default. *full* includes
    all reasoner contributions, assumptions, source hashes and coverage details.

    *hypotheses* optionally supplies up to three alternative formulations of
    the responsibility, e.g. English terms for English docs. Their equivalence
    to the question is an assumption, not inferred fact. *path* narrows the
    search before ranking. Tests are excluded unless *include_tests* is true.
    Current source is checked; retrieval is bounded and may miss unindexed code.
    verify additionally observes call sites and returned-call occurrences with
    scoped KQL2 queries (timeout_ms total). It does not change heuristic scores
    or prove the prose claim. verify=false omits this structural observation.
    """
    from ken.responsibility.service import who
    from ken.responsibility.report import render

    assert _PROJECT_ROOT is not None
    with _conn() as conn:
        result = who(conn, _PROJECT_ROOT, question, path=path, hypotheses=hypotheses,
                     limit=limit, include_tests=include_tests)
        if verify:
            from ken.responsibility.structure import enrich
            result = enrich(_PROJECT_ROOT, result, timeout_ms=timeout_ms)
        return render(result, full=full)


@ken_tool
def ken_read(
    path: str,
    include: list[Literal["symbols", "imports", "docstrings", "source", "profile"]] | None = None,
    qualname: str = "",
    start_line: int = 0,
    end_line: int = 0,
    max_chars: int = 0,
) -> dict:
    """Read an indexed file's structure, and optionally its source. Pick
    fields with *include*: symbols, imports, docstrings, source, profile.

    *include* selects what comes back — any of ``symbols``, ``imports``,
    ``docstrings``, ``source``, ``profile``. Defaults to ``["symbols"]``.

    ``source`` needs somewhere to read from: pass *qualname* for one symbol,
    or *start_line*/*end_line* for a range. ``profile`` answers what the file
    is *for* and how it differs from its siblings, which is the question you
    have before you know which symbol you want.
    """
    path = _project_relative_path(path)
    include = list(include or ["symbols"])
    want = set(include)
    unknown = want - {"symbols", "imports", "docstrings", "source", "profile"}
    if unknown:
        return {
            "ok": False,
            "error": f"unknown include values: {sorted(unknown)}",
            "include": ["symbols", "imports", "docstrings", "source", "profile"],
        }

    result: dict[str, Any] = {"ok": True, "path": path}
    docstrings = "docstrings" in want

    if qualname and want & {"symbols", "docstrings"}:
        result["symbol"] = _impl_ken_symbol_detail(
            path, qualname, include_snippet="source" in want,
        )
    elif want & {"symbols", "imports"}:
        result["outline"] = _impl_ken_file_outline(
            path,
            include_symbols="symbols" in want,
            include_imports="imports" in want,
            include_docstrings=docstrings,
        )
    elif docstrings:
        result["symbols"] = _impl_ken_file_symbols(path, include_docstrings=True)

    if "source" in want and "symbol" not in result:
        result["source"] = _impl_ken_file_snippets(
            path,
            symbols=[qualname] if qualname else None,
            start_line=start_line or None,
            end_line=end_line or None,
            max_chars=max_chars or 12000,
        )
    if "profile" in want:
        result["profile"] = _impl_ken_profile(path)
    return result


@ken_tool
def ken_related(
    target: str,
    relation: Literal[
        "neighbors", "imports", "callers", "callees", "subtypes",
        "supertypes", "cochange", "blast_radius", "clones", "checks",
        "impact", "roles", "available",
    ],
    limit: int = 10,
    depth: int = 1,
    min_confidence: float = 0.0,
    path: str = ".",
    timeout_ms: int = 10000,
    full: bool = False,
    from_path: str = "",
) -> Any:
    """What else is connected to *target*, by a named relationship:
    neighbors, imports, callers, callees, subtypes, supertypes, cochange,
    blast_radius, clones. Each is a distinct algorithm, not a filter.

    *target* is a file path, or a symbol qualname for the call and type
    relations. Each *relation* is a distinct algorithm, not a filter:

    * ``neighbors``    — files ken ranks as directly related.
    * ``imports``      — the local import graph around a file, *depth* hops.
    * ``callers`` / ``callees`` — the call graph for a symbol.
    * ``subtypes`` / ``supertypes`` — the type hierarchy, with overrides.
    * ``cochange``     — files historically committed together, scored by
      log-likelihood ratio. Surfaces coupling that imports do not show.
    * ``blast_radius`` — what a change here is likely to break. *depth* is
      the hop limit.
    * ``clones``       — near-duplicate code, by MinHash over token shingles.
    * ``checks``       — applicable source contracts and latest receipts with
      live input validity. Reads saved evidence; does not execute KQL queries.
    * ``impact``       — live KQL result consumers, returned-value propagation,
      and tests that use the target. Use file::qualname to disambiguate symbols.
    * ``roles``        — observed call chains with explicit structural role hypotheses.
    * ``available``    — explicit Python access expressions from from_path to a
      callable, with unresolved typing, initialization and shadowing obligations.
      For impact/roles, path sets the analysis scope, timeout_ms its total budget,
      full includes the underlying queries' observations. Unresolved calls stay unknown.
    """
    if relation in {"impact", "roles", "available"}:
        from ken.inspection.service import inspect
        assert _PROJECT_ROOT is not None
        result = inspect(_PROJECT_ROOT, target, relation=relation, path=path,
                         depth=depth, limit=limit, timeout_ms=timeout_ms, full=full,
                         from_path=from_path)
        if relation == "impact":
            from ken.checks.integration import related
            targets = result.get("targets", [])
            result["contracts"] = [related(_PROJECT_ROOT, p, limit=limit)
                                   for p in sorted({t["path"] for t in targets})]
        return result
    if relation == "neighbors":
        return _impl_ken_file_neighbors(_project_relative_path(target), limit=limit)
    if relation == "imports":
        return _impl_ken_module_graph(
            _project_relative_path(target), depth=depth, limit=limit
        )
    if relation in ("callers", "callees"):
        return _impl_ken_callgraph(
            target, direction=relation, min_confidence=min_confidence, limit=limit,
        )
    if relation in ("subtypes", "supertypes"):
        return _impl_ken_type_hierarchy(
            target,
            direction="down" if relation == "subtypes" else "up",
            with_overrides=True,
        )
    if relation == "cochange":
        return _impl_ken_cochange(
            _project_relative_path(target),
            min_confidence=min_confidence,
            limit=limit,
        )
    if relation == "blast_radius":
        path = _project_relative_path(target)
        result = _impl_ken_blast_radius(path, max_hops=max(1, depth))
        from ken.checks.integration import related
        assert _PROJECT_ROOT is not None
        result["contracts"] = related(_PROJECT_ROOT, path, limit=limit)
        return result
    if relation == "checks":
        from ken.checks.integration import related
        assert _PROJECT_ROOT is not None
        return related(_PROJECT_ROOT, _project_relative_path(target), limit=limit)
    if relation == "clones":
        return _impl_ken_clones(path=_project_relative_path(target), limit=limit)
    return {
        "ok": False,
        "error": f"unknown relation {relation!r}",
        "relations": [
            "neighbors", "imports", "callers", "callees", "subtypes",
            "supertypes", "cochange", "blast_radius", "clones", "checks",
            "impact", "roles", "available",
        ],
    }


@ken_tool
def ken_rank(
    scope: Literal["session", "changes", "project", "architecture"] = "session",
    query: str = "",
    verbose: int = 1,
    explain: bool = False,
    max_chars: int = 0,
) -> Any:
    """What matters right now — ken's own answer, not a search. Scopes:
    session (the work in progress), changes (the git diff), project
    (orientation), architecture (subsystems and cycles).

    For a natural-language query override, use English and preserve exact
    identifiers, paths and quoted source. Leave query empty to reuse the current
    session; this guidance does not require rewriting stored session context.
    Reply to the user in their preferred language.

    This is the ranker: several channels fused into one ordering, including
    what this session has touched and how recently, what sessions like it
    historically went on to touch, and what was named outright. None of that
    is expressible as a query, which is why this tool exists.

    *scope* picks the question:

    * ``session``      — what matters for the work in progress. Leave *query*
      empty to rank against the current session; pass one to rank against a
      different intent instead.
    * ``changes``      — the current git diff, enriched with the symbols and
      tests it touches.
    * ``project``      — languages, layout and the directories that carry the
      weight. For orienting in an unfamiliar repository.
    * ``architecture`` — subsystems, layers, dependency cycles and hubs.

    *verbose* goes 0 (list only), 1 (outlines), 2 (fullest). *explain* returns
    the per-channel breakdown instead of the ranking, which is how you find
    out *why* something ranked where it did.
    """
    if scope == "session":
        if explain:
            return _impl_ken_explain_rank(query=query)
        return _impl_ken_rank(query=query, verbose=verbose, max_chars=max_chars)
    if scope == "changes":
        return _impl_ken_changed_context()
    if scope == "project":
        return _impl_ken_project_overview(limit=max(1, verbose) * 10)
    if scope == "architecture":
        return _impl_ken_architecture(limit=max(1, verbose) * 10)
    return {
        "ok": False,
        "error": f"unknown scope {scope!r}",
        "scopes": ["session", "changes", "project", "architecture"],
    }


@ken_tool
def ken_reason_record(
    source: str,
    facts: list[dict[str, Any]] | None = None,
    rules: list[dict[str, Any]] | None = None,
    evidence: str = "",
    context: str = "main",
    retract: bool = False,
) -> Any:
    """Persist premises for reasoning, with a stable source ID and evidence.

    An atom is {predicate, subject, object, negative?: bool, scope?: str}.
    Supply stable entity/sense IDs; identical spellings do not prove identity.
    Rules are {body: [atoms], head: atom}, with one to three premises;
    variables such as ?x are allowed only in rule subject/object positions.
    Builtins support type, subclass and all/<predicate>. No implicit verb
    transitivity or negation-as-failure. Evidence is an attributed source,
    not an assertion that Ken independently verified it. Reusing a source
    replaces its bundle and invalidates dependent context reasoning.
    retract=true removes that bundle. Contexts never share premises implicitly.
    Use ken_remember for notes that have not been formalized.
    """
    from ken.reasoning.store import Memory

    assert _PROJECT_ROOT is not None
    try:
        return Memory(_paths.ken_dir(_PROJECT_ROOT) / "reasoning.sqlite").record(
            source, context=context, facts=facts, rules=rules, evidence=evidence, retract=retract)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}


@ken_tool
def ken_reason(
    question: str,
    goal: dict[str, Any] | None = None,
    context: str = "main",
    budget: int = 1000,
    seed: int = 7,
    assumptions: list[dict[str, Any]] | None = None,
) -> Any:
    """Ask persistent Ken reasoning; repeated/resumed queries reuse prior work.

    question is the human-readable request; goal is its explicit interpretation:
    {predicate, subject, object, negative?: bool, scope?: str}. Use ?answer
    in subject or object for a variable query. Interpret senses/referents before
    calling: lexical similarity is not a logical rule. Without goal, retrieve
    candidate Ken memories for interpretation; they are not automatically facts.
    Returns support/opposition, proof/source links, incomplete-search coverage
    and conditional candidates for missing evidence. Scores are not probability.
    Ground assumptions create an isolated additive world, never base facts.
    Call again to resume a budget-limited search. A completed unchanged context
    needs zero new inference work, including after restart. No external tools
    are run. Use ken_calculate for arithmetic and record tool results explicitly.
    """
    from ken.reasoning.store import Memory

    assert _PROJECT_ROOT is not None
    if not question.strip() or len(question) > 4000:
        return {"ok": False, "error": "question must contain 1..4000 characters"}
    if goal is None:
        return {"status": "needs_interpretation", "question": question,
                "candidates": ken_recall(query=question, limit=5),
                "note": "These are retrieval candidates, not premises. Supply a scoped goal and record supported premises."}
    try:
        return Memory(_paths.ken_dir(_PROJECT_ROOT) / "reasoning.sqlite").ask(
            goal, context=context, budget=budget, seed=seed, assumptions=assumptions) | {"question": question}
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}


@ken_tool
def ken_calculate(expression: str) -> Any:
    """Calculate exact rational arithmetic with + - * / ** and parentheses.

    Bounded numeric expressions only: no names, code, tools, symbolic algebra,
    or units. Returns an exact result, not an automatically stored premise.
    """
    from ken.reasoning.arithmetic import calculate

    try:
        return calculate(expression)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}


@ken_tool
def ken_recall(
    query: str = "",
    path: str = "",
    topic: str = "",
    tag: str = "",
    limit: int = 5,
    min_score: float = 0.0,
    anchor_file: str = "",
    anchor_symbol: str = "",
    anchor_tool: str = "",
    anchor_error: str = "",
    detail: Literal["full", "summary", "answer"] = "full",
    max_chars: int = 3000,
) -> Any:
    """Recall what earlier sessions in this project already worked out.

    Check here before re-deriving something: findings persist across
    sessions and across harnesses. The arguments are ways in, most specific
    first — the ``anchor_*`` set returns memories declared to fire on a
    file, symbol, tool or error message, *topic* walks the findings graph
    from a known finding, *path* returns everything known about a file,
    *query* searches by meaning, *tag* filters exactly. With none of them,
    returns the most recent findings.

    The ``anchor_*`` arguments answer "what should I know before doing
    this?" and combine with OR — pass every anchor the action has and get
    back whatever fires on any of them. ``anchor_error`` matches as a
    substring of the message you pass.

    Justified findings include live dependency validity: unchanged, stale,
    unknown or untracked. Unchanged does not verify truth, assumptions or
    completeness. detail="summary" returns a bounded memories/omitted envelope
    (max_chars=300..20000); full preserves existing shapes and includes the
    focused finding for topic lookups, its rationale and evidence references.
    Start with detail="answer" for a reusable conclusion, input validity,
    assumptions and source references. An exact topic then reads only that
    finding. Reuse it if the question and assumptions fit unchanged inputs;
    expand to full or read the missing source only when needed. Stale/unknown
    inputs require review. No structural query is run automatically by recall.
    """
    from ken.knowledge.context import recall_view

    if detail not in {"full", "summary", "answer"} or not 300 <= max_chars <= 20000:
        return {"ok": False, "error": "detail must be full/summary/answer; max_chars must be 300..20000"}
    if detail == "answer" and topic and not any((anchor_file, anchor_symbol, anchor_tool, anchor_error)):
        from ken.knowledge.context import compact
        from ken.knowledge.records import for_topics

        with _conn() as conn:
            hits = for_topics(conn, [topic], root=_PROJECT_ROOT)
            return compact(hits, max_chars, detail="answer")
    result = _select_memories(query, path, topic, tag, limit, min_score,
                              anchor_file, anchor_symbol, anchor_tool, anchor_error)
    with _conn() as conn:
        return recall_view(conn, result, root=_PROJECT_ROOT, detail=detail, max_chars=max_chars)


def _select_memories(query, path, topic, tag, limit, min_score,
                     anchor_file, anchor_symbol, anchor_tool, anchor_error):
    anchors = {
        "file": anchor_file, "symbol": anchor_symbol,
        "tool": anchor_tool, "error": anchor_error,
    }
    if any(v.strip() for v in anchors.values()):
        from ken.memory import recall_by_anchor

        with _conn() as conn:
            return recall_by_anchor(conn, anchors, limit=limit)
    if topic:
        return _impl_ken_related_findings(topic, limit=limit)
    if path:
        return _impl_ken_file_findings(path, limit=limit)
    if query:
        return _impl_ken_recall(query, limit=limit, min_score=min_score)
    return _impl_ken_findings(limit=limit, tag=tag or None)


@ken_tool
def ken_remember(
    topic: str,
    content: str = "",
    action: Literal["save", "forget", "dismiss"] = "save",
    tags: list[str] | None = None,
    reason: str = "",
    anchor_file: str = "",
    anchor_symbol: str = "",
    anchor_tool: str = "",
    anchor_error: str = "",
    justification: dict[str, Any] | None = None,
    check_run: str = "",
) -> Any:
    """Persist a finding so the next session starts knowing it. *action*
    is save (default), forget (delete by topic), or dismiss (mark a path
    irrelevant to the current ranking).

    Worth saving: non-obvious facts you had to dig for — why something is
    the way it is, a constraint that is not visible in the code, a trap. Not
    worth saving: what the code already says plainly.

    *action* is ``save`` (default), ``forget`` to delete a finding by topic,
    or ``dismiss`` to tell the ranker that *topic* — read as a path — is not
    relevant to the current work.

    The ``anchor_*`` arguments declare what the memory is *about*, so it can
    be found by the thing that provokes it rather than by someone thinking
    to search: ``anchor_file`` and ``anchor_symbol`` name code,
    ``anchor_tool`` a command or tool name, ``anchor_error`` a substring of
    an error message. Several may be set; the memory fires on any of them.

    Optional justification records why the conclusion follows:
    {kind: observation|decision|hypothesis|derivation, rationale: str,
     evidence: [{path, note?, sha256?}], assumptions: [str], recheck: str,
     dependencies: [{kind: file|tree, path, pattern?, sha256?}]}.
    Evidence files are dependencies automatically. Paths stay in the project.
    Ken captures SHA-256 now; supply sha256 to bind an earlier observation and
    reject changes before saving. Trees include new/deleted matching files;
    pattern defaults to * and matches relative paths recursively. Declare the
    search scope for absence/completeness claims. Assumptions are never verified.
    Hooks surface concise validity; no commands or LLM run during recall.
    Overwriting without justification removes any previous justification.
    check_run attaches a ken_check receipt. Its source/rule/engine inputs must
    still match. Recall checks freshness without rerunning KQL or asserting
    that the note's prose follows from the selected source contracts.
    """
    if action == "save":
        if not content.strip():
            return {"ok": False, "error": "content is required when saving a finding"}
        if check_run:
            from ken.checks.integration import justification as from_check
            assert _PROJECT_ROOT is not None
            justification = from_check(_PROJECT_ROOT, check_run, justification)
        return _impl_ken_remember(
            topic, content, tags=tags,
            anchors={
                "file": anchor_file, "symbol": anchor_symbol,
                "tool": anchor_tool, "error": anchor_error,
            },
            justification=justification,
        )
    if action == "forget":
        return _impl_ken_forget(topic)
    if action == "dismiss":
        return _impl_ken_dismiss(topic, reason=reason)
    return {
        "ok": False,
        "error": f"unknown action {action!r}",
        "actions": ["save", "forget", "dismiss"],
    }
