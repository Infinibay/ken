"""Find source-backed callers of direct KQL2 seeds through explicit imports."""

from __future__ import annotations

import ast
from hashlib import sha256
from pathlib import Path
from time import monotonic

from ken.gitignore_filter import iter_files

from .call_inventory import PythonCallInventory
from .caller_expansion import DiscoveryCandidate, ExpansionBatch, _LocalCalls
from .candidate_catalog import SourceCandidate
from .code_source import PythonSymbol
from .local_functions import LocalFunctionCatalog
from .local_imports import LocalImportResolver


class ImportedCallerExpansion:
    """Discover one caller hop through unique project-local from-imports."""

    def __init__(self, project_root: Path):
        """Constrain inspected imports and caller files to one project."""
        self.root = Path(project_root).resolve()

    def expand(
        self,
        seeds: tuple[SourceCandidate, ...],
        *,
        scope: str,
        limit: int,
        timeout_ms: int,
    ) -> ExpansionBatch:
        """Check actual import bindings and call bodies within a bounded scope."""
        eligible = {
            (seed.source.path, seed.source.symbol): seed
            for seed in seeds
            if len(seed.source.symbol.split(".")) == 1
        }
        skipped: list[dict[str, object]] = []
        examined_files = 0
        prefiltered_files = 0
        parsed_files = 0
        coverage: dict[str, object] = {
            "relation": "explicit_import_callers_one_hop",
            "complete": True,
            "examined_files": 0,
            "prefiltered_files": 0,
            "parsed_files": 0,
            "ineligible_seeds": len(seeds) - len(eligible),
            "skipped": skipped,
            "results_truncated": False,
        }
        if not eligible:
            return ExpansionBatch((), coverage)
        for seed in eligible.values():
            seed.source.assert_current()
        resolver = LocalImportResolver(self.root)
        names = {symbol.encode("utf-8") for _, symbol in eligible}
        found: dict[tuple[str, str], DiscoveryCandidate] = {}
        direct_keys = {(seed.source.path, seed.source.symbol) for seed in seeds}
        target = self.root / scope
        files = [Path(scope)] if target.is_file() else iter_files(self.root, path=scope)
        started = monotonic()

        for relative in files:
            if relative.suffix != ".py":
                continue
            if (monotonic() - started) * 1000 >= timeout_ms:
                skipped.append(
                    {"path": relative.as_posix(), "reason": "timeout_ms"}
                )
                break
            path = relative.as_posix()
            try:
                content = (self.root / relative).read_bytes()
                if len(content) > PythonCallInventory.MAX_SOURCE_BYTES:
                    skipped.append(
                        {"path": path, "reason": "max_file_bytes"}
                    )
                    continue
                examined_files += 1
                if not any(name in content for name in names):
                    prefiltered_files += 1
                    continue
                tree = ast.parse(content.decode("utf-8"), filename=path)
            except (OSError, UnicodeError, SyntaxError) as exc:
                skipped.append(
                    {"path": path, "reason": f"source_error:{type(exc).__name__}"}
                )
                continue
            parsed_files += 1
            try:
                imports = self._seed_imports(path, tree, eligible, resolver)
            except (OSError, UnicodeError, SyntaxError) as exc:
                skipped.append(
                    {"path": path, "reason": f"import_error:{type(exc).__name__}"}
                )
                continue
            if not imports:
                continue
            for symbol, function in self._callers(tree):
                local_bindings = LocalFunctionCatalog._local_bindings(function)
                for local_name, seed in imports.items():
                    if local_name in local_bindings:
                        continue
                    sites = tuple(sorted(_LocalCalls(function, local_name).lines))
                    if not sites:
                        continue
                    key = (path, symbol)
                    if key in direct_keys:
                        continue
                    via = f"{seed.source.path}::{seed.source.symbol}"
                    previous = found.get(key)
                    if previous is not None:
                        found[key] = DiscoveryCandidate(
                            previous.source,
                            previous.line,
                            previous.kind,
                            delegate_sites=tuple(
                                sorted(set(previous.delegate_sites) | set(sites))
                            ),
                            via=tuple(sorted(set(previous.via) | {via})),
                        )
                        continue
                    if len(found) >= limit:
                        coverage["results_truncated"] = True
                        continue
                    try:
                        source = PythonSymbol.from_python(
                            project_root=self.root, path=path, symbol=symbol
                        )
                    except (ValueError, OSError, SyntaxError, UnicodeError):
                        skipped.append(
                            {"path": path, "symbol": symbol, "reason": "ambiguous_caller"}
                        )
                        continue
                    if source.source_sha256 != sha256(content).hexdigest():
                        raise ValueError("Imported caller source changed during discovery")
                    found[key] = DiscoveryCandidate(
                        source,
                        function.lineno,
                        "imported_caller",
                        delegate_sites=sites,
                        via=(via,),
                    )
        coverage["examined_files"] = examined_files
        coverage["prefiltered_files"] = prefiltered_files
        coverage["parsed_files"] = parsed_files
        resolver.assert_current()
        for seed in eligible.values():
            seed.source.assert_current()
        for candidate in found.values():
            candidate.source.assert_current()
        coverage["complete"] = not skipped and not coverage["results_truncated"]
        return ExpansionBatch(tuple(found.values()), coverage)

    @staticmethod
    def _seed_imports(
        path: str,
        tree: ast.Module,
        eligible: dict[tuple[str, str], SourceCandidate],
        resolver: LocalImportResolver,
    ) -> dict[str, SourceCandidate]:
        """Map only unique imports proven to refer to a KQL2 seed."""
        imported = {}
        names = {symbol for _, symbol in eligible}
        for statement in tree.body:
            if not isinstance(statement, ast.ImportFrom):
                continue
            module_path = resolver.module_path(path, statement)
            if module_path is None:
                continue
            for alias in statement.names:
                if alias.name not in names or (module_path, alias.name) not in eligible:
                    continue
                local_name = alias.asname or alias.name
                selected = resolver.resolve(path, local_name)
                if selected is None or selected.node.decorator_list:
                    continue
                seed = eligible.get((selected.path, selected.symbol))
                if seed is not None and selected.path != path:
                    imported[local_name] = seed
        return imported

    @staticmethod
    def _callers(
        tree: ast.Module,
    ) -> list[tuple[str, ast.FunctionDef | ast.AsyncFunctionDef]]:
        """Enumerate top-level functions and methods in top-level classes."""
        callers = []
        for statement in tree.body:
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
                callers.append((statement.name, statement))
            elif isinstance(statement, ast.ClassDef):
                callers.extend(
                    (f"{statement.name}.{method.name}", method)
                    for method in statement.body
                    if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
                )
        return callers
