"""Resolve a short Python function name to one current project source file."""

from __future__ import annotations

import ast
import re
from pathlib import Path

from ken.gitignore_filter import iter_files

from .code_source import PythonSymbol, matching_functions


class PythonSymbolLocator:
    """Find a unique live Python function before binding an investigation."""

    def __init__(self, project_root: Path, *, search_path: str | None = None):
        """Use the conventional source directory unless a scope is supplied."""
        self.root = Path(project_root).resolve()
        self.search_path = search_path

    def resolve(self, selector: str) -> PythonSymbol:
        """Accept ``path.py::name`` or a unique name under the search scope."""
        if not isinstance(selector, str) or not selector:
            raise ValueError("Expected a Python function selector")
        path, separator, symbol = selector.rpartition("::")
        if separator:
            if not path or not symbol:
                raise ValueError("Expected path.py::function or a function name")
            return PythonSymbol.from_python(
                project_root=self.root, path=path, symbol=symbol
            )
        if not all(part.isidentifier() for part in selector.split(".")):
            raise ValueError("Expected path.py::function or a function name")
        scope = self._scope()
        basename = selector.rsplit(".", 1)[-1]
        declaration = re.compile(rf"\bdef\s+{re.escape(basename)}\b")
        choices: list[tuple[str, str]] = []
        for relative in iter_files(self.root, path=scope.relative_to(self.root)):
            if relative.suffix != ".py":
                continue
            source = self.root / relative
            try:
                source.resolve().relative_to(self.root)
                content = source.read_text(encoding="utf-8")
            except (OSError, UnicodeError, ValueError):
                continue
            if declaration.search(content) is None:
                continue
            try:
                functions = matching_functions(ast.parse(content), selector)
            except SyntaxError:
                continue
            choices.extend((relative.as_posix(), name) for name, _ in functions)
        label = scope.relative_to(self.root).as_posix()
        if not choices:
            raise ValueError(
                f"No Python function named {selector!r} under {label}; "
                "use --in DIR or path.py::function"
            )
        if len(choices) != 1:
            examples = ", ".join(
                f"{path}::{name}" for path, name in sorted(choices)[:5]
            )
            raise ValueError(
                f"Ambiguous Python function {selector!r} under {label} "
                f"({len(choices)} matches): {examples}"
            )
        path, name = choices[0]
        return PythonSymbol.from_python(project_root=self.root, path=path, symbol=name)

    def _scope(self) -> Path:
        """Validate the live discovery directory without widening silently."""
        default = "src" if (self.root / "src").is_dir() else "."
        scope = (self.root / (self.search_path or default)).resolve()
        try:
            scope.relative_to(self.root)
        except ValueError as exc:
            raise ValueError("Search path must stay inside the project") from exc
        if not scope.is_dir():
            raise ValueError("Search path must be a project directory")
        return scope
