"""Bounded abstract interpretation of Python call paths and local delegation."""

from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass, field, replace

from .call_arguments import CallArguments, SymbolicValues
from .code_source import function_is_generator, select_function
from .effect_site import EffectSite
from .local_imports import module_bound_names
from .local_methods import LocalMethodCatalog
from .module_constants import ModuleConstants, ModuleMutationContext
from .statement_region import StatementRegion


@dataclass(frozen=True)
class CallPath:
    """One normal path with call evidence, unknown effects, and dispatch guards."""

    aliases: frozenset[str]
    values: SymbolicValues = field(default_factory=SymbolicValues)
    called: bool = False
    possible: frozenset[str] = frozenset()
    upper_possible: frozenset[str] = frozenset()
    possible_predecessors: frozenset[str] = frozenset()
    guards: tuple[tuple[str, bool], ...] = ()
    trace: tuple[str, ...] = ()
    unsupported: tuple[str, ...] = ()
    returned: bool = False

    @property
    def satisfied(self) -> bool:
        """Expose the witnessed target call to the shared finite-world model."""
        return self.called


class PythonCallInterpreter:
    """Enumerate normal-return paths for one target call in a Python module."""

    def __init__(
        self,
        tree,
        target,
        receiver,
        when,
        max_paths,
        *,
        module_path=None,
        import_resolver=None,
        visited=frozenset(),
        arguments: CallArguments | None = None,
        after: str | None = None,
        constant_context=None,
    ):
        """Index local helpers, imports, and branch assumptions for one run."""
        self.tree = tree
        self.target = target
        self.receiver = receiver
        self.when = dict(when)
        self.max_paths = max_paths
        self.module_path = module_path
        self.import_resolver = import_resolver
        self.arguments = arguments
        self.constant_mutations = (
            constant_context.mutation_context
            if constant_context is not None
            else ModuleMutationContext()
        )
        self.constants = ModuleConstants(
            tree,
            module_path,
            mutation_context=self.constant_mutations,
        )
        self.argument_constants: frozenset[str] = frozenset()
        self.after = after
        self.imported_context = bool(visited)
        self.visited = frozenset(visited)
        self.local_methods = LocalMethodCatalog(tree)
        self.current_function = None
        self.module_imports: set[str] = set()
        self.module_rebound = set()
        helpers: dict[str, list[ast.FunctionDef | ast.AsyncFunctionDef]] = {}
        binding_counts: Counter[str] = Counter()
        for node in tree.body:
            binding_counts.update(module_bound_names(node))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                helpers.setdefault(node.name, []).append(node)
                self.module_rebound.add(node.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name.split(".", 1)[0]
                    if name in self.module_imports:
                        self.module_rebound.add(name)
                    self.module_imports.add(name)
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    name = alias.asname or alias.name
                    if name in self.module_imports:
                        self.module_rebound.add(name)
                    self.module_imports.add(name)
            else:
                self.module_rebound.update(module_bound_names(node))
        self.helpers = {
            name: nodes[0]
            for name, nodes in helpers.items()
            if len(nodes) == 1 and binding_counts[name] == 1
        }
        self.shadowed: dict[str, set[str]] = {}
        self.used_when: set[str] = set()

    def paths_for(self, symbol, *, function=None, values=None):
        """Interpret one selected function and reject unused branch assumptions."""
        if function is None:
            function = select_function(self.tree, symbol)
        if self.arguments is not None and not self.imported_context:
            self.argument_constants = self.arguments.required_roots
            self.arguments = self.arguments.bound_to(function, self.constants.available(function))
        if self.receiver is not None and self.receiver.split(".", 1)[
            0
        ] not in self._parameters(function):
            raise ValueError("Parameter is not declared by the selected symbol")
        if function.decorator_list:
            return [
                CallPath(
                    self._initial_aliases(),
                    values=values or SymbolicValues.identity(function),
                    unsupported=("decorated_function",),
                )
            ]
        if function_is_generator(function):
            if self.when:
                raise ValueError("A branch precondition did not match a source condition")
            return [
                CallPath(
                    self._initial_aliases(),
                    values=values or SymbolicValues.identity(function),
                    unsupported=("generator_function",),
                )
            ]
        if isinstance(function, ast.AsyncFunctionDef) and not self.imported_context:
            return [
                CallPath(
                    self._initial_aliases(),
                    values=values or SymbolicValues.identity(function),
                    unsupported=("coroutine_function",),
                )
            ]
        identity = (self.module_path, symbol)
        if identity in self.visited or len(self.visited) >= 8:
            return [
                CallPath(
                    self._initial_aliases(), unsupported=("import_cycle_or_depth",)
                )
            ]
        self.visited = self.visited | {identity}
        try:
            paths = self._function(
                function,
                self.receiver,
                (function.name,),
                values or SymbolicValues.identity(function),
            )
        except OverflowError:
            paths = [CallPath(self._initial_aliases(), unsupported=("path_limit",))]
        if set(self.when) - self.used_when:
            raise ValueError("A branch precondition did not match a source condition")
        return self.constants.validate(paths)

    def _initial_aliases(self):
        """Track a receiver only when the target is receiver-specific."""
        return frozenset({self.receiver}) if self.receiver is not None else frozenset()

    @staticmethod
    def _parameters(node):
        """Return positional and keyword-only parameter names of a function."""
        return [
            arg.arg
            for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
        ]

    @classmethod
    def _shadowed_names(cls, node):
        """Find names whose local binding may hide a module-level helper."""
        names = set(cls._parameters(node))
        for child in ast.walk(node):
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                names.add(child.id)
            elif isinstance(child, (ast.Import, ast.ImportFrom)):
                names.update(
                    alias.asname or alias.name.split(".", 1)[0] for alias in child.names
                )
            elif (
                isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
                and child is not node
            ):
                names.add(child.name)
        return names

    def _function(self, node, parameter, stack, values):
        """Evaluate one local function under a tracked argument binding."""
        self.shadowed[node.name] = self._shadowed_names(node)
        previous = self.current_function
        self.current_function = node
        traces = ()
        if self.arguments is not None:
            values, traces = self.constants.bind(node, values,
                expected=self.argument_constants if len(stack) == 1 else ())
        initial = CallPath(frozenset({parameter}) if parameter is not None else frozenset(), values=values, trace=traces)
        try:
            return self._block(node.body, [initial], stack)
        except OverflowError:
            if len(stack) == 1:
                raise
            # A callee that exceeds the path budget has unknown effects, like
            # an unresolved external call. It cannot return from its caller.
            # Preserve the caller's continuation instead of discarding it.
            return [self._possible(initial, f"bounded_helper:{node.name}", node.lineno)]
        finally:
            self.current_function = previous

    def _block(self, statements, paths, stack):
        """Advance every active normal path through a sequence of statements."""
        for statement in statements:
            paths = [
                successor
                for path in paths
                for successor in (
                    [path] if path.returned else self._step(statement, path, stack)
                )
            ]
            if len(paths) > self.max_paths:
                raise OverflowError("call path limit")
        return paths

    def _step(self, statement, path, stack):
        """Interpret one supported Python statement conservatively."""
        line = getattr(statement, "lineno", 0)
        if isinstance(statement, ast.AnnAssign):
            # Function-local annotations are not evaluated. A value, when
            # present, follows ordinary assignment semantics.
            if statement.value is not None:
                assignment = ast.copy_location(ast.Assign(targets=[statement.target], value=statement.value), statement)
                return self._step(assignment, path, stack)
            if self._contains_relevant_call(statement.target, path.aliases):
                return [self._possible(path, "annotation_target", line)]
            return [path]
        if isinstance(statement, ast.AugAssign):
            # Reading/storing the target and the operator can invoke user code.
            # Preserve a direct RHS call, but never preserve its previous value.
            path = self._forget_targets(path, StatementRegion([statement.value]).targets)
            path = self._possible(path, "augmented_target", line)
            outcomes = (self._call(statement.value, path, stack)
                        if isinstance(statement.value, ast.Call) else [path])
            return [self._forget_targets(self._possible(item, "augmented_operation", line), [statement.target])
                    for item in outcomes]
        if isinstance(statement, (ast.For, ast.While)):
            return self._loop(statement, path, stack)
        if isinstance(statement, ast.Expr):
            if isinstance(statement.value, ast.Call):
                return self._call(statement.value, path, stack)
            if isinstance(statement.value, ast.Await) and isinstance(
                statement.value.value, ast.Call
            ):
                return self._call(statement.value.value, path, stack, awaited=True)
            if self._contains_relevant_call(statement.value, path.aliases):
                return [self._possible(path, "expression_calls", line)]
            return [path]
        if isinstance(statement, ast.Return):
            outcomes = (
                self._call(statement.value, path, stack)
                if isinstance(statement.value, ast.Call)
                else self._call(statement.value.value, path, stack, awaited=True)
                if isinstance(statement.value, ast.Await)
                and isinstance(statement.value.value, ast.Call)
                else [path]
            )
            if self._contains_relevant_call(statement.value, path.aliases) and not (
                isinstance(statement.value, ast.Call)
                or isinstance(statement.value, ast.Await)
                and isinstance(statement.value.value, ast.Call)
            ):
                outcomes = [
                    self._possible(item, "expression_calls", line) for item in outcomes
                ]
            return [
                replace(item, returned=True, trace=item.trace + (f"return:{line}",))
                for item in outcomes
            ]
        if isinstance(statement, ast.Assign):
            path = self._forget_targets(path, StatementRegion([statement.value]).targets)
            outcomes = (
                self._call(statement.value, path, stack)
                if isinstance(statement.value, ast.Call)
                else [path]
            )
            if self._contains_relevant_call(
                statement.value, path.aliases
            ) and not isinstance(statement.value, ast.Call):
                outcomes = [
                    self._possible(item, "expression_calls", line) for item in outcomes
                ]
            if any(self._contains_relevant_call(target, path.aliases) for target in statement.targets):
                outcomes = [self._possible(item, "assignment_target", line) for item in outcomes]
            results = []
            for item in outcomes:
                aliases = set(item.aliases)
                value_is_alias = self._is_alias(statement.value, item.aliases)
                resolved_value = item.values.resolve(statement.value)
                values = item.values
                unresolved_target = False
                for target in statement.targets:
                    values = values.assign(target, resolved_value)
                    if isinstance(target, ast.Name):
                        aliases.discard(target.id)
                        if value_is_alias:
                            aliases.add(target.id)
                    elif self.receiver is None:
                        continue
                    elif self._is_alias(target, item.aliases) or not isinstance(
                        target, ast.Attribute
                    ):
                        unresolved_target = True
                if unresolved_target and not (item.called and self.after is None):
                    results.append(self._unsupported(item, f"assignment:{line}"))
                else:
                    results.append(
                        replace(item, aliases=frozenset(aliases), values=values)
                    )
            return results
        if isinstance(statement, ast.If):
            if any(isinstance(node, ast.Call) for node in ast.walk(statement.test)):
                path = self._possible(path, "condition_calls", line)
            branches = (statement.body, statement.orelse)
            if isinstance(statement.test, ast.Constant) and isinstance(
                statement.test.value, bool
            ):
                branches = (branches[0 if statement.test.value else 1],)
            else:
                condition = ast.unparse(statement.test)
                if condition in self.when:
                    self.used_when.add(condition)
                    branches = (branches[0 if self.when[condition] else 1],)
                elif isinstance(statement.test, ast.UnaryOp) and isinstance(
                    statement.test.op, ast.Not
                ):
                    operand = ast.unparse(statement.test.operand)
                    if operand in self.when:
                        self.used_when.add(operand)
                        branches = (branches[1 if self.when[operand] else 0],)
            return [
                outcome
                for index, branch in enumerate(branches)
                for outcome in self._block(
                    branch,
                    [replace(path, trace=path.trace + (f"if:{line}:{index}",))],
                    stack,
                )
            ]
        if isinstance(statement, ast.Try):
            body = self._block(statement.body, [path], stack)
            normal = [item for item in body if not item.returned]
            returned = [item for item in body if item.returned]
            normal = self._block(statement.orelse, normal, stack)
            handled = [
                outcome
                for handler in statement.handlers
                for outcome in self._block(handler.body, [path], stack)
            ]
            before_finally = normal + returned + handled
            return [
                replace(outcome, returned=outcome.returned or item.returned)
                for item in before_finally
                for outcome in self._block(
                    statement.finalbody,
                    [replace(item, returned=False)],
                    stack,
                )
            ]
        if isinstance(statement, (ast.With, ast.AsyncWith)):
            entered = [path]
            for item in statement.items:
                if isinstance(item.context_expr, ast.Call):
                    entered = [
                        outcome
                        for entry in entered
                        for outcome in self._call(item.context_expr, entry, stack)
                    ]
                elif self._contains_relevant_call(item.context_expr, path.aliases):
                    entered = [
                        self._unsupported(entry, f"context_expr:{line}")
                        for entry in entered
                    ]
            body = self._block(statement.body, entered, stack)
            return [self._possible(item, "context_exit", line) for item in body]
        if isinstance(statement, ast.Raise):
            return []
        if isinstance(statement, (ast.Pass, ast.Import, ast.ImportFrom)):
            return [path]
        return [self._unsupported(path, f"{type(statement).__name__}:{line}")]

    @staticmethod
    def _forget_targets(path, targets):
        """Discard receiver aliases and values that an opaque region may replace."""
        aliases, values = set(path.aliases), path.values
        for target in targets:
            values = values.assign(target, None)
            if isinstance(target, (ast.Name, ast.Attribute)):
                spelling = ast.unparse(target)
                aliases = {alias for alias in aliases if alias != spelling and not alias.startswith(spelling + ".")}
        return replace(path, aliases=frozenset(aliases), values=values)

    def _loop(self, statement, path, stack):
        """Overapproximate iteration effects and exits, without claiming body witnesses.

        Zero iterations remain possible: a body call is never a witness. Body
        returns can bypass following statements; writes invalidate bindings;
        break can bypass else. Iteration
        and body effects stay unknown rather than being unrolled a fixed count.
        """
        line = statement.lineno
        head = statement.iter if isinstance(statement, ast.For) else statement.test
        entered = self._forget_targets(path, StatementRegion([head]).targets)
        entered = self._possible(entered, "loop_iteration", line)
        nodes = [*statement.body]
        if isinstance(statement, ast.For):
            nodes.insert(0, statement.target)
        region = StatementRegion(nodes)
        iterated = self._forget_targets(self._possible(entered, "loop_body", line), region.targets)
        # Join zero and nonzero iterations by forgetting every possible write
        # and retaining only unknown body effects. Keeping two copies here
        # would multiply paths without adding any proved body-call witness.
        normal = self._block(statement.orelse, [iterated], stack)
        if region.may_break and statement.orelse:
            normal.append(iterated)
        if region.may_return:
            normal.append(replace(iterated, returned=True, trace=iterated.trace + (f"loop_return:{line}",)))
        return normal

    def _call(self, call, path, stack, *, awaited=False):
        """Resolve a target or local helper; retain other calls as worlds."""
        line = call.lineno
        function = call.func
        is_predecessor = self.after is not None and self._matches_predecessor(
            function, path, stack
        )
        if is_predecessor:
            path = replace(
                path,
                trace=path.trace + (f"before:{self.after}:{self.module_path}:{line}",),
            )
        if self._matches_target(function, path.aliases, stack):
            if self.after is not None and any(
                isinstance(child, ast.Call)
                and self._matches_predecessor(child.func, path, stack)
                for argument in (*call.args, *(item.value for item in call.keywords))
                for child in ast.walk(argument)
            ):
                return [
                    self._unsupported(
                        path, f"nested_predecessor:{self.module_path}:{line}"
                    )
                ]
            if self.arguments is not None:
                match = self.arguments.matches(call, path.values)
                if match is None:
                    return [
                        self._unsupported(
                            path, f"arguments_unknown:{self.module_path}:{line}"
                        )
                    ]
                if not match:
                    return [
                        replace(
                            path,
                            trace=path.trace
                            + (f"args_mismatch:{self.module_path}:{line}",),
                        )
                    ]
            return [
                replace(
                    path,
                    called=True,
                    trace=path.trace
                    + (f"call:{self.target}:{self.module_path}:{line}",),
                )
            ]
        if is_predecessor and isinstance(function, ast.Attribute):
            return [path]
        if self.receiver is None and self.current_function is not None:
            method = self.local_methods.resolve(
                self.current_function, call, path.values
            )
            if method is not None and method.symbol not in stack:
                if isinstance(method.node, ast.AsyncFunctionDef) and not awaited:
                    return [self._unsupported(path, f"unawaited_async:{line}")]
                if isinstance(method.node, ast.FunctionDef) and awaited:
                    return [self._unsupported(path, f"awaited_sync:{line}")]
                if function_is_generator(method.node):
                    return [self._unsupported(path, f"generator_helper:{line}")]
                outcomes = self._function(
                    method.node,
                    None,
                    stack + (method.symbol,),
                    SymbolicValues.for_bound_method(
                        method.node, call, path.values
                    ),
                )
                if outcomes:
                    return [
                        replace(
                            path,
                            called=path.called or item.called,
                            possible=path.possible | item.possible,
                            guards=path.guards + item.guards,
                            unsupported=path.unsupported + item.unsupported,
                            trace=path.trace
                            + (
                                f"private_binding:{method.symbol}:"
                                f"{self.module_path}:{line}",
                            )
                            + (f"delegate:{method.symbol}:{line}",)
                            + item.trace,
                        )
                        for item in outcomes
                    ]
        if self.current_function is not None:
            candidate = self.local_methods.candidate(
                self.current_function, call, path.values
            )
            if candidate is not None:
                path = replace(
                    path,
                    trace=path.trace
                    + (
                        f"candidate_method:{candidate.symbol}:"
                        f"{self.module_path}:{candidate.node.lineno}:{line}",
                    ),
                )
                if (
                    self.receiver is None
                    and candidate.symbol not in stack
                    and self.local_methods.conditional(
                        self.current_function, call, path.values
                    ) is not None
                    and not function_is_generator(candidate.node)
                    and (
                        isinstance(candidate.node, ast.AsyncFunctionDef) == awaited
                    )
                ):
                    local = self._function(
                        candidate.node,
                        None,
                        stack + (candidate.symbol,),
                        SymbolicValues.for_bound_method(
                            candidate.node, call, path.values
                        ),
                    )
                    if local and not any(item.unsupported for item in local):
                        dispatch = EffectSite(
                            f"dispatch:{candidate.symbol}", self.module_path, line
                        ).key()
                        selected = [
                            replace(
                                path,
                                called=path.called or item.called,
                                possible=path.possible | item.possible,
                                guards=path.guards
                                + ((dispatch, True),)
                                + item.guards,
                                trace=path.trace
                                + (f"dispatch_local:{dispatch}:{line}",)
                                + item.trace,
                            )
                            for item in local
                        ]
                        alternative = self._possible(
                            replace(
                                path,
                                guards=path.guards + ((dispatch, False),),
                                trace=path.trace
                                + (f"dispatch_other:{dispatch}:{line}",),
                            ),
                            f"override:{function.attr}",
                            line,
                        )
                        return selected + [alternative]
        if (
            self.receiver is not None
            and isinstance(function, ast.Attribute)
            and self._is_alias(function.value, path.aliases)
        ):
            return [self._possible(path, f"method:{function.attr}", line)]
        passed = [
            index
            for index, argument in enumerate(call.args)
            if self._is_alias(argument, path.aliases)
        ]
        passed_keywords = [
            keyword.arg
            for keyword in call.keywords
            if self._is_alias(keyword.value, path.aliases)
        ]
        if self.receiver is not None and not passed and not passed_keywords:
            if self._contains_relevant_call(call, path.aliases):
                return [self._possible(path, self._callee_effect(function), line)]
            return [path]
        if isinstance(function, ast.Name):
            helper = (
                None
                if function.id in self.shadowed.get(stack[-1], ())
                else self.helpers.get(function.id)
            )
            if (
                helper is not None
                and helper.name not in stack
                and (self.receiver is None or len(passed) + len(passed_keywords) == 1)
            ):
                if isinstance(helper, ast.AsyncFunctionDef) and not awaited:
                    return [self._unsupported(path, f"unawaited_async:{line}")]
                if isinstance(helper, ast.FunctionDef) and awaited:
                    return [self._unsupported(path, f"awaited_sync:{line}")]
                if any(
                    isinstance(node, (ast.Yield, ast.YieldFrom))
                    for statement in helper.body
                    for node in ast.walk(statement)
                ):
                    return [self._unsupported(path, f"generator_helper:{line}")]
                parameters = self._parameters(helper)
                parameter = (
                    None
                    if self.receiver is None
                    else parameters[passed[0]]
                    if passed and passed[0] < len(parameters)
                    else passed_keywords[0]
                    if passed_keywords and passed_keywords[0] in parameters
                    else None
                )
                if parameter is not None or self.receiver is None:
                    outcomes = self._function(
                        helper,
                        parameter,
                        stack + (helper.name,),
                        SymbolicValues.for_call(helper, call, path.values),
                    )
                    if outcomes:
                        return [
                            replace(
                                path,
                                called=path.called or item.called,
                                possible=path.possible | item.possible,
                                guards=path.guards + item.guards,
                                unsupported=path.unsupported + item.unsupported,
                                trace=path.trace
                                + (f"delegate:{helper.name}:{line}",)
                                + item.trace,
                            )
                            for item in outcomes
                        ]
            imported = (
                self.import_resolver.resolve(self.module_path, function.id)
                if self.import_resolver is not None
                and self.module_path is not None
                and function.id not in self.shadowed.get(stack[-1], ())
                else None
            )
            if imported is not None:
                if isinstance(imported.node, ast.AsyncFunctionDef) and not awaited:
                    return [self._unsupported(path, f"unawaited_async:{line}")]
                if isinstance(imported.node, ast.FunctionDef) and awaited:
                    return [self._unsupported(path, f"awaited_sync:{line}")]
                if any(
                    isinstance(node, (ast.Yield, ast.YieldFrom))
                    for statement in imported.node.body
                    for node in ast.walk(statement)
                ):
                    return [self._unsupported(path, f"generator_helper:{line}")]
                parameter = self._import_parameter(imported, passed, passed_keywords)
                if self.receiver is None or parameter is not None:
                    delegate = PythonCallInterpreter(
                        imported.tree,
                        self.target,
                        parameter,
                        {},
                        self.max_paths,
                        module_path=imported.path,
                        import_resolver=self.import_resolver,
                        visited=self.visited,
                        arguments=self.arguments,
                        after=self.after,
                        constant_context=self.constants,
                    )
                    outcomes = delegate.paths_for(
                        imported.symbol,
                        function=imported.node,
                        values=SymbolicValues.for_call(
                            imported.node, call, path.values
                        ),
                    )
                    return [
                        replace(
                            path,
                            called=path.called or item.called,
                            possible=path.possible | item.possible,
                            guards=path.guards + item.guards,
                            unsupported=path.unsupported + item.unsupported,
                            trace=path.trace
                            + (f"delegate:{imported.path}:{imported.symbol}:{line}",)
                            + item.trace,
                        )
                        for item in outcomes
                    ]
            if self.receiver is None or passed or passed_keywords:
                if is_predecessor:
                    return [path]
                return [self._possible(path, f"function:{function.id}", line)]
            return [path]
        if (
            self.receiver is None
            or passed
            or passed_keywords
            or self._contains_relevant_call(call, path.aliases)
        ):
            if is_predecessor:
                return [path]
            effect = (
                f"method:{function.attr}"
                if isinstance(function, ast.Attribute)
                else self._callee_effect(function)
            )
            return [self._possible(path, effect, line)]
        return [path]

    def _matches_target(self, function, aliases, stack):
        """Correlate the requested call with an optional receiver."""
        if self.receiver is not None:
            return (
                isinstance(function, ast.Attribute)
                and function.attr == self.target
                and self._is_alias(function.value, aliases)
            )
        return self._matches_named_target(function, self.target, stack)

    def _matches_named_target(self, function, name, stack):
        """Match imports across helpers but local names only in their root scope."""
        if "." in name:
            root = name.split(".", 1)[0]
            if root in self.module_imports:
                if root in self.module_rebound or root in self.shadowed.get(
                    stack[-1], ()
                ):
                    return False
            elif len(stack) != 1 or self.imported_context:
                return False
            return ast.unparse(function) == name
        return (
            isinstance(function, ast.Name)
            and function.id == name
            or isinstance(function, ast.Attribute)
            and function.attr == name
        )

    def _matches_predecessor(self, function, path, stack):
        """Match an imported call or a source-bound receiver call."""
        if self._matches_named_target(function, self.after, stack):
            return True
        if "." not in self.after or not isinstance(function, ast.Attribute):
            return False
        receiver, method = self.after.rsplit(".", 1)
        if receiver.split(".", 1)[0] in self.module_imports:
            return False
        return (
            function.attr == method and path.values.resolve(function.value) == receiver
        )

    def _import_parameter(self, imported, passed, passed_keywords):
        """Map a tracked receiver through a call into an imported function."""
        if self.receiver is None:
            return None
        if len(passed) + len(passed_keywords) != 1:
            return None
        parameters = self._parameters(imported.node)
        if passed and passed[0] < len(parameters):
            return parameters[passed[0]]
        if passed_keywords and passed_keywords[0] in parameters:
            return passed_keywords[0]
        return None

    def _contains_relevant_call(self, node, aliases):
        """Notice nested calls that could satisfy the requested target."""
        return node is not None and any(
            isinstance(child, ast.Call)
            and (
                self.receiver is None
                or any(self._is_alias(value, aliases) for value in ast.walk(child))
            )
            for child in ast.walk(node)
        )

    @staticmethod
    def _is_alias(node, aliases):
        """Match a tracked name or member expression exactly."""
        return (
            isinstance(node, (ast.Name, ast.Attribute)) and ast.unparse(node) in aliases
        )

    def _possible(self, path, effect, line):
        """Give an unresolved source call one identity across its path worlds."""
        effect = EffectSite(effect, self.module_path, line).key()
        return replace(
            path,
            possible=path.possible | {effect},
            trace=path.trace + (f"unknown:{effect}:{line}",),
        )

    @staticmethod
    def _callee_effect(function):
        """Name a nested unresolved call without collapsing it to a line only."""
        if isinstance(function, (ast.Name, ast.Attribute)):
            spelling = ast.unparse(function)
            if len(spelling) <= 96:
                return f"call:{spelling}"
        return "call:dynamic"

    @staticmethod
    def _unsupported(path, reason):
        """Preserve an unsupported syntax obligation rather than invent a path."""
        return replace(path, unsupported=path.unsupported + (reason,))
