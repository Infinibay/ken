"""All-path return-value provenance over a versioned Python function."""

from __future__ import annotations

import ast
import math

from .call_arguments import CallArguments
from .code_source import PythonSymbol
from .guarded_evidence import GuardedEvidence
from .local_imports import LocalImportResolver
from .local_methods import local_method_candidates, private_binding_assumptions
from .module_constants import constant_binding_assumptions
from .next_evidence import NextEvidence
from .return_contract import ReturnContract
from .return_interpreter import PythonReturnInterpreter
from .worlds import ObligationWorldModel


class ReturnPaths:
    """Join return-path witnesses with finite worlds for unresolved callees."""

    def __init__(
        self,
        source: PythonSymbol,
        contract: ReturnContract,
        *,
        when=None,
        max_paths: int = 64,
    ):
        """Bind a return contract and boolean branch assumptions to source."""
        if any(not isinstance(value, bool) for value in (when or {}).values()):
            raise ValueError("Branch preconditions must be booleans")
        if not isinstance(max_paths, int) or max_paths < 1:
            raise ValueError("max_paths must be a positive integer")
        self.source = source
        self.contract = contract
        self.when = dict(when or {})
        self.max_paths = max_paths

    def analyze(self, *, effect_priors=None):
        """Report every modeled return and bound unresolved value forwarding."""
        self.source.assert_current()
        target, receiver = self.contract.for_source(self.source)
        tree = ast.parse((self.source.project_root / self.source.path).read_text())
        imports = LocalImportResolver(self.source.project_root)
        arguments = (
            CallArguments(self.contract.call.arguments)
            if self.contract.call.arguments is not None
            else None
        )
        paths = PythonReturnInterpreter(
            tree,
            target,
            receiver,
            arguments,
            self.when,
            self.source.path,
            max_paths=self.max_paths,
            import_resolver=imports,
        ).paths_for(self.source.symbol)
        self.source.assert_current()
        imports.assert_current()
        worlds = ObligationWorldModel(paths, effect_priors)
        bounds, assumptions = worlds.probability_bounds()
        probability = (
            bounds[0]
            if bounds is not None
            and math.isclose(bounds[0], bounds[1], rel_tol=0.0, abs_tol=1e-12)
            else None
        )
        status = worlds.status()
        if status == "all_paths_satisfied":
            status = "all_paths_return_value"
        return {
            "schema": "ken-return-paths/1",
            "status": status,
            "resolved_evidence": self._resolved_evidence(paths),
            "scope": "normal_completion_only",
            "source_path": self.source.path,
            "target": self.contract.call.target,
            "arguments": (list(arguments.expected) if arguments is not None else None),
            "when": dict(self.when),
            "dependencies": imports.dependencies(self.source.path),
            "paths": [
                {
                    "satisfied": path.satisfied,
                    "possible_returns": sorted(path.possible),
                    "guards": [
                        {"effect": effect, "selected": selected}
                        for effect, selected in path.guards
                    ],
                    "trace": list(path.trace),
                    "unsupported": list(path.unsupported),
                    "producer": self._location(path.producer),
                    "return_site": self._location(path.return_site),
                }
                for path in paths
            ],
            "unresolved_effects": list(worlds.effects),
            "binding_assumptions": private_binding_assumptions(paths) + constant_binding_assumptions(paths),
            "method_candidates": local_method_candidates(paths),
            "probability_all_paths_return_value": probability,
            "probability_bounds": (
                {"lower": bounds[0], "upper": bounds[1]} if bounds is not None else None
            ),
            "effect_priors": assumptions,
            "probability_model": (
                "independent_dispatch_and_call_site_assumptions"
                if any(key.startswith("dispatch:") for key in assumptions)
                else "independent_call_site_effects"
                if assumptions
                else None
            ),
            "unassumed_effects": [
                effect for effect in worlds.effects if effect not in assumptions
            ],
            "next_checks": NextEvidence(
                paths, worlds, self.source.path, outcome="return_value"
            ).suggest(),
            "limits": [
                "Only modeled normal completion paths are analyzed.",
                "A returned source value is not proof of runtime success.",
                "Literal module bindings assume no external mutation or reflection beyond followed source; visible writes invalidate them.",
                "Unknown-callee priors are investigator assumptions, not learned probabilities.",
                "Declared call-site and dispatch priors are treated as independent.",
                "Public-method return evidence is conditional on selecting that local body.",
                "A dispatch choice is stable per source call site in this model; runtime rebinding between invocations is outside scope.",
                "Complex expressions, try/finally and loops remain explicit uncertainty.",
                "Only unique project-local helpers and imports are followed.",
            ],
        }

    @staticmethod
    def summary(result):
        """Show decisive returned-value evidence without routine path traces."""
        paths = result["paths"]
        producers = ReturnPaths._guarded_locations(paths, "producer")
        returned = ReturnPaths._guarded_locations(paths, "return_site")
        summary = {
            "schema": result["schema"],
            "status": result["status"],
            "resolved_evidence": result["resolved_evidence"],
            "scope": result["scope"],
            "target": result["target"],
            "arguments": result["arguments"],
            "when": result["when"],
            "dependencies": result["dependencies"],
            "path_count": len(paths),
            "producer_locations": producers.unconditional(),
            "conditional_producers": producers.conditional(),
            "returned_locations": returned.unconditional(),
            "conditional_returned_locations": returned.conditional(),
            "probability_all_paths_return_value": result[
                "probability_all_paths_return_value"
            ],
            "effect_priors": result["effect_priors"],
            "probability_model": result["probability_model"],
        }
        if result["binding_assumptions"]:
            summary["binding_assumptions"] = result["binding_assumptions"]
        if result["method_candidates"]:
            summary["method_candidates"] = result["method_candidates"]
        if (
            result["probability_all_paths_return_value"] is None
            and result["probability_bounds"] is not None
        ):
            summary["probability_bounds"] = result["probability_bounds"]
        if result["status"] == "missing_path":
            counterexample = min(
                (
                    path
                    for path in paths
                    if not path["satisfied"] and not path["possible_returns"]
                ),
                key=lambda path: bool(path["guards"]),
            )
            summary["counterexample"] = counterexample["trace"]
            if counterexample["guards"]:
                summary["counterexample_guards"] = counterexample["guards"]
                summary["counterexample_coverage"] = "all_dispatch_worlds"
        if result["status"] == "unknown":
            unsupported = sorted(
                {reason for path in paths for reason in path["unsupported"]}
            )
            summary["unsupported"] = unsupported[:5]
            if len(unsupported) > 5:
                summary["more_unsupported"] = len(unsupported) - 5
            if not unsupported:
                effects = result["unresolved_effects"]
                summary["unresolved_effects"] = effects[:5]
                if len(effects) > 5:
                    summary["more_unresolved_effects"] = len(effects) - 5
                summary["next_checks"] = result["next_checks"]
                if result["unassumed_effects"] and result["effect_priors"]:
                    summary["unassumed_effects"] = result["unassumed_effects"]
        return summary

    @staticmethod
    def _location(value):
        """Present a source tuple as a stable path-and-line witness."""
        return {"path": value[0], "line": value[1]} if value else None

    @staticmethod
    def _guarded_locations(paths, key):
        """Group witnessed locations by the dispatch choices needed for them."""
        evidence = GuardedEvidence()
        for path in paths:
            if not path["satisfied"] or path[key] is None:
                continue
            location = path[key]
            evidence.add(
                location["path"],
                location["line"],
                ((item["effect"], item["selected"]) for item in path["guards"]),
            )
        return evidence

    @staticmethod
    def _resolved_evidence(paths):
        """Count direct forwarding witnesses apart from possible callees."""
        witnessed = sum(path.satisfied for path in paths)
        complete = bool(paths) and not any(path.unsupported for path in paths)
        return {
            "status": (
                "all_paths_witnessed"
                if witnessed == len(paths) and complete
                else "incomplete"
                if not complete
                else "some_paths_unwitnessed"
            ),
            "analysis_complete": complete,
            "witnessed_paths": witnessed,
            "unwitnessed_paths": len(paths) - witnessed,
        }
