"""Call-contract vocabulary over the shared finite source-world model."""

from __future__ import annotations

from .worlds import ObligationWorldModel


class CallWorldModel(ObligationWorldModel):
    """Preserve call-specific status names for the public contract result."""

    def status(self):
        """Name a satisfied source obligation as an all-path target call."""
        status = super().status()
        return "all_paths_called" if status == "all_paths_satisfied" else status
