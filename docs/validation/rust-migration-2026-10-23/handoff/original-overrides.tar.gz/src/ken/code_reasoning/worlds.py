"""Finite worlds for source obligations with unknown effects and path guards."""

from __future__ import annotations

import itertools
import math
from collections import Counter

from .effect_site import EffectSite


class ObligationWorldModel:
    """Evaluate an all-path obligation under effect and dispatch assumptions."""

    def __init__(self, paths, priors=None):
        """Accept observed priors but model only effects on unwitnessed paths."""
        self.paths = tuple(paths)
        available_effects = {
            effect
            for path in self.paths
            for effect in (
                path.possible | path.upper_possible | path.possible_predecessors
            )
        } | {
            effect
            for path in self.paths
            for effect, _ in path.guards
        }
        self.guard_effects = frozenset(
            effect
            for path in self.paths
            for effect, _ in path.guards
        )
        self.effects = tuple(
            sorted(
                {
                    effect
                    for path in self.paths
                    if not path.satisfied
                    for effect in (
                        path.possible
                        | (
                            frozenset()
                            if path.possible_predecessors
                            else path.upper_possible
                        )
                    )
                }
                | {
                    effect
                    for path in self.paths
                    if not path.satisfied
                    for effect, _ in path.guards
                }
            )
        )
        self.priors = dict(priors or {})
        known = available_effects | {
            self._short_name(effect) for effect in available_effects
        }
        if set(self.priors) - known:
            raise ValueError("An effect prior did not match an unresolved call")
        aliases = Counter(self._short_name(effect) for effect in available_effects)
        if any(count > 1 and alias in self.priors for alias, count in aliases.items()):
            raise ValueError("Ambiguous effect prior; use a full effect key")
        if any(
            effect in self.priors
            and self._short_name(effect) in self.priors
            and effect != self._short_name(effect)
            for effect in available_effects
        ):
            raise ValueError("An effect prior was supplied by both names")
        if any(
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(value)
            or not 0 <= value <= 1
            for value in self.priors.values()
        ):
            raise ValueError("Effect priors must be probabilities")

    @staticmethod
    def _short_name(effect):
        """Allow a callee name as a concise alias for its full effect key."""
        return EffectSite.short_name(effect)

    def status(self):
        """Distinguish a proof, a counterexample path, and unresolved effects."""
        if not self.paths or any(path.unsupported for path in self.paths):
            return "unknown"
        if all(path.satisfied for path in self.paths):
            return "all_paths_satisfied"
        if any(not path.guards and self._missing(path) for path in self.paths):
            return "missing_path"
        if not self.guard_effects:
            return "unknown"
        if len(self.guard_effects) > 12:
            return "unknown"
        always, possible = self._unknown_guard_bounds(
            {}, tuple(sorted(self.guard_effects))
        )
        if always:
            return "all_paths_satisfied"
        if not possible:
            return "missing_path"
        return "unknown"

    def probability(self):
        """Return an exact probability only when the bounds coincide."""
        bounds, assumptions = self.probability_bounds()
        if bounds is None or not math.isclose(
            bounds[0], bounds[1], rel_tol=0.0, abs_tol=1e-12
        ):
            return None, assumptions
        return bounds[0], assumptions

    def probability_bounds(self):
        """Enumerate declared priors and extremize unknown guarded worlds."""
        if not self.paths or any(path.unsupported for path in self.paths):
            return None, {}
        if all(path.satisfied for path in self.paths):
            return (1.0, 1.0), {}
        if any(not path.guards and self._missing(path) for path in self.paths):
            return (0.0, 0.0), {}
        assumptions = {}
        for effect in self.effects:
            probability = self.priors.get(
                effect, self.priors.get(self._short_name(effect))
            )
            if probability is not None:
                assumptions[effect] = float(probability)
        variable_effects = tuple(
            effect for effect, chance in assumptions.items() if 0.0 < chance < 1.0
        )
        unassumed_guards = tuple(sorted(self.guard_effects - assumptions.keys()))
        if len(variable_effects) + len(unassumed_guards) > 12:
            return None, assumptions
        fixed = {
            effect: chance == 1.0
            for effect, chance in assumptions.items()
            if chance in {0.0, 1.0}
        }
        lower = 0.0
        upper = 0.0
        for assignment in itertools.product(
            (False, True), repeat=len(variable_effects)
        ):
            world = fixed | dict(zip(variable_effects, assignment, strict=True))
            mass = math.prod(
                assumptions[effect] if truth else 1 - assumptions[effect]
                for effect, truth in zip(variable_effects, assignment, strict=True)
            )
            pessimistic, optimistic = self._unknown_guard_bounds(
                world, unassumed_guards
            )
            if pessimistic:
                lower += mass
            if optimistic:
                upper += mass
        return (min(1.0, lower), min(1.0, upper)), assumptions

    def _unknown_guard_bounds(self, world, guards):
        """Use one coherent dispatch choice across every guarded path."""
        always_satisfies = True
        can_satisfy = False
        for choices in itertools.product((False, True), repeat=len(guards)):
            selected = world | dict(zip(guards, choices, strict=True))
            always_satisfies &= self._world_satisfies(
                selected, unknown_truth=False, optimistic=False
            )
            can_satisfy |= self._world_satisfies(
                selected, unknown_truth=True, optimistic=True
            )
            if not always_satisfies and can_satisfy:
                break
        return always_satisfies, can_satisfy

    @staticmethod
    def _missing(path):
        """Recognize a path with neither a witness nor a possible one."""
        return not (
            path.satisfied
            or path.possible
            or path.upper_possible
            or path.possible_predecessors
        )

    def _world_satisfies(self, world, *, unknown_truth, optimistic):
        """Evaluate path obligations in pessimistic or optimistic worlds."""
        return all(
            not all(world[effect] == selected for effect, selected in path.guards)
            or path.satisfied
            or optimistic
            and bool(path.possible_predecessors)
            or any(
                world.get(effect, unknown_truth)
                for effect in (
                    path.possible | path.upper_possible if optimistic else path.possible
                )
            )
            for path in self.paths
        )
