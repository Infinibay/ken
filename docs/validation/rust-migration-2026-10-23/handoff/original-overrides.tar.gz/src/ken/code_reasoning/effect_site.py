"""Stable identities and readable locations for unresolved call-site effects."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EffectSite:
    """One unresolved source call, shared only across paths through that site."""

    label: str
    path: str | None
    line: int

    def key(self) -> str:
        """Encode the callee label and source location for finite worlds."""
        return f"{self.label}@{self.path or '<source>'}:{self.line}"

    @staticmethod
    def short_name(key: str) -> str:
        """Use a callee-only prior only when it identifies one effect site."""
        return key.split("@", 1)[0].split(":")[-1]

    @staticmethod
    def source_path(key: str, fallback: str) -> str:
        """Locate an effect inside a followed import or the selected file."""
        suffix = key.split("@", 1)[-1]
        candidate = suffix.rsplit(":", 1)[0]
        return candidate if candidate.endswith(".py") else fallback
