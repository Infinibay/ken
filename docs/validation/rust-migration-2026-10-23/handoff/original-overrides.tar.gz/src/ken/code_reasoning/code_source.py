"""Bind one Python function to the exact source bytes used for analysis."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path


def function_is_generator(
    function: ast.FunctionDef | ast.AsyncFunctionDef,
) -> bool:
    """Detect an outer yield without attributing nested functions' yields."""

    def contains_yield(node: ast.AST) -> bool:
        if isinstance(node, (ast.Yield, ast.YieldFrom)):
            return True
        if isinstance(
            node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
        ):
            return False
        return any(contains_yield(child) for child in ast.iter_child_nodes(node))

    return any(contains_yield(statement) for statement in function.body)


class _FunctionSelector(ast.NodeVisitor):
    """Find Python functions by lexical qualname without importing modules."""

    def __init__(self, symbol: str):
        """Match a full lexical path or a unique simple function name."""
        self.symbol = symbol
        self.parts: list[str] = []
        self.matches: list[tuple[str, ast.FunctionDef | ast.AsyncFunctionDef]] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Include enclosing class names in method identities."""
        self.parts.append(node.name)
        self.generic_visit(node)
        self.parts.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        """Record matching functions and descend into nested definitions."""
        qualified = ".".join((*self.parts, node.name))
        if qualified == self.symbol or (
            "." not in self.symbol and node.name == self.symbol
        ):
            self.matches.append((qualified, node))
        self.parts.append(node.name)
        self.generic_visit(node)
        self.parts.pop()

    visit_AsyncFunctionDef = visit_FunctionDef


def matching_functions(
    tree: ast.Module, symbol: str
) -> list[tuple[str, ast.FunctionDef | ast.AsyncFunctionDef]]:
    """Find lexical function identities matching a qualname or basename."""
    if not symbol or not all(part.isidentifier() for part in symbol.split(".")):
        raise ValueError("Symbol must be a function name or lexical qualname")
    selector = _FunctionSelector(symbol)
    selector.visit(tree)
    return selector.matches


def select_function(
    tree: ast.Module, symbol: str
) -> ast.FunctionDef | ast.AsyncFunctionDef:
    """Select exactly one function by lexical qualname or unique basename."""
    matches = matching_functions(tree, symbol)
    if len(matches) != 1:
        raise ValueError("Symbol must name exactly one Python function")
    return matches[0][1]


@dataclass(frozen=True)
class PythonSymbol:
    """One unique Python function selected from a versioned project file."""

    project_root: Path
    path: str
    symbol: str
    source_sha256: str

    @classmethod
    def from_python(cls, *, project_root, path, symbol):
        """Select a function without importing code or requiring a docstring."""
        root, relative, content, _ = cls._load(project_root, path, symbol)
        return cls(root, relative, symbol, sha256(content).hexdigest())

    @staticmethod
    def _load(project_root, path, symbol):
        """Read and uniquely select one function inside a project boundary."""
        root = Path(project_root).resolve()
        source = (root / path).resolve()
        source.relative_to(root)
        if source.suffix != ".py" or not source.is_file():
            raise ValueError("Expected one Python source file inside the project")
        content = source.read_bytes()
        tree = ast.parse(content.decode("utf-8"), filename=str(source))
        function = select_function(tree, symbol)
        return root, source.relative_to(root).as_posix(), content, function

    def assert_current(self):
        """Reject a file changed after its function was selected."""
        source = self.project_root / self.path
        if sha256(source.read_bytes()).hexdigest() != self.source_sha256:
            raise ValueError("Code source changed after symbol selection")

    def parameters(self) -> frozenset[str]:
        """List names a source-bound contract may refer to as receivers."""
        self.assert_current()
        _, _, _, function = self._load(self.project_root, self.path, self.symbol)
        self.assert_current()
        return frozenset(
            argument.arg
            for argument in (
                *function.args.posonlyargs,
                *function.args.args,
                *function.args.kwonlyargs,
            )
        )

    def basename_is_unique(self) -> bool:
        """Check whether KQL2's basename can identify this source symbol."""
        self.assert_current()
        tree = ast.parse((self.project_root / self.path).read_text())
        basename = self.symbol.rsplit(".", 1)[-1]
        count = sum(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == basename
            for node in ast.walk(tree)
        )
        self.assert_current()
        return count == 1

    def validate_observation(self, observation):
        """Require KQL2 to have read the same source bytes and symbol."""
        local_name = self.symbol.rsplit(".", 1)[-1]
        if observation.path != self.path or observation.expected_symbol != local_name:
            raise ValueError("KQL observation belongs to a different symbol")
        if observation.source_hash is None and observation.state == "unknown":
            self.assert_current()
            return
        if observation.source_hash != self.source_sha256:
            raise ValueError("KQL source snapshot differs from selected code")
        self.assert_current()

    def data(self):
        """Return compact source provenance for a result receipt."""
        return {
            "path": self.path,
            "symbol": self.symbol,
            "sha256": self.source_sha256,
        }
