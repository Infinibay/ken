"""Present source witnesses under the smallest sufficient dispatch choices."""

from __future__ import annotations

from collections.abc import Iterable


Guard = tuple[str, bool]


class GuardedEvidence:
    """Collect locations and simplify alternative Boolean guard paths."""

    def __init__(self):
        """Start with no source locations or dispatch conditions."""
        self._cubes: dict[tuple[str, int], set[frozenset[Guard]]] = {}

    def add(self, path: str, line: int, guards: Iterable[Guard]) -> None:
        """Record one witness and the choices active when it occurred."""
        conditions = tuple(guards)
        choices: dict[str, bool] = {}
        for effect, selected in conditions:
            if effect in choices and choices[effect] != selected:
                return
            choices[effect] = selected
        self._cubes.setdefault((path, line), set()).add(frozenset(conditions))

    def records(self) -> list[tuple[str, int, tuple[tuple[str, bool], ...]]]:
        """Return source locations with redundant guard combinations removed."""
        return sorted(
            (path, line, tuple(sorted(cube)))
            for (path, line), cubes in self._cubes.items()
            for cube in self._minimal_cubes(cubes)
        )

    def unconditional(self) -> list[dict]:
        """List witnesses that require no public-method dispatch choice."""
        return [
            {"path": path, "line": line}
            for path, line, guards in self.records()
            if not guards
        ]

    def conditional(self) -> list[dict]:
        """List each sufficient set of dispatch choices for a witness."""
        return [
            {
                "path": path,
                "line": line,
                "when": [
                    {"effect": effect, "selected": selected}
                    for effect, selected in guards
                ],
            }
            for path, line, guards in self.records()
            if guards
        ]

    @staticmethod
    def _minimal_cubes(cubes):
        """Merge complementary choices while preserving distinct routes."""
        cubes = set(cubes)
        while True:
            expanded = set(cubes)
            for left in cubes:
                for right in cubes:
                    if len(left) != len(right):
                        continue
                    difference = left ^ right
                    if len(difference) != 2:
                        continue
                    first, second = tuple(difference)
                    if first[0] == second[0] and first[1] != second[1]:
                        expanded.add(left & right)
            reduced = {
                cube
                for cube in expanded
                if not any(other < cube for other in expanded)
            }
            if reduced == cubes:
                return reduced
            cubes = reduced
