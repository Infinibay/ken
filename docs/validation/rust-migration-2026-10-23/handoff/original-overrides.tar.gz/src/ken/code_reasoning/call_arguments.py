"""Small symbolic vocabulary for source-level call argument contracts."""

from __future__ import annotations

import ast
from dataclasses import dataclass


def _canonical(node: ast.AST) -> str:
    """Name only expressions whose value can be compared without execution."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{_canonical(node.value)}.{node.attr}"
    if isinstance(node, ast.Constant) and isinstance(
        node.value, (str, int, float, bool, type(None))
    ):
        return repr(node.value)
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.USub)
        and isinstance(node.operand, ast.Constant)
        and isinstance(node.operand.value, (int, float))
    ):
        return repr(-node.operand.value)
    raise ValueError("Call arguments support names, attributes, and literals")


@dataclass(frozen=True)
class SymbolicValues:
    """Known source expressions for the current function's local names."""

    bindings: tuple[tuple[str, str | None], ...] = ()

    @classmethod
    def identity(
        cls, function: ast.FunctionDef | ast.AsyncFunctionDef
    ) -> SymbolicValues:
        """Name each root parameter by its caller-visible expression."""
        names = (
            *function.args.posonlyargs,
            *function.args.args,
            *function.args.kwonlyargs,
        )
        return cls(tuple((argument.arg, argument.arg) for argument in names))

    @classmethod
    def for_call(
        cls,
        function: ast.FunctionDef | ast.AsyncFunctionDef,
        call: ast.Call,
        caller: SymbolicValues,
    ) -> SymbolicValues:
        """Bind a helper's formals to known expressions at its call site."""
        positional = (*function.args.posonlyargs, *function.args.args)
        keyword_only = function.args.kwonlyargs
        bindings: dict[str, str | None] = {
            argument.arg: None for argument in (*positional, *keyword_only)
        }
        if len(call.args) > len(positional) or any(
            isinstance(argument, ast.Starred) for argument in call.args
        ):
            return cls(tuple(bindings.items()))
        used: set[str] = set()
        for parameter, argument in zip(positional, call.args, strict=False):
            bindings[parameter.arg] = caller.resolve(argument)
            used.add(parameter.arg)
        for keyword in call.keywords:
            if (
                keyword.arg is None
                or keyword.arg not in bindings
                or keyword.arg in used
            ):
                return cls(tuple((name, None) for name in bindings))
            bindings[keyword.arg] = caller.resolve(keyword.value)
            used.add(keyword.arg)
        return cls(tuple(bindings.items()))

    @classmethod
    def for_bound_method(
        cls,
        function: ast.FunctionDef | ast.AsyncFunctionDef,
        call: ast.Call,
        caller: SymbolicValues,
    ) -> SymbolicValues:
        """Bind the implicit receiver before explicit method arguments."""
        if not isinstance(call.func, ast.Attribute):
            raise ValueError("Expected an attribute call for a bound method")
        bound_call = ast.Call(
            func=call.func,
            args=[call.func.value, *call.args],
            keywords=call.keywords,
        )
        return cls.for_call(function, bound_call, caller)

    def resolve(self, expression: ast.AST) -> str | None:
        """Resolve a simple expression into root-symbol vocabulary if known."""
        if isinstance(expression, ast.Name):
            return dict(self.bindings).get(expression.id)
        if isinstance(expression, ast.Attribute):
            base = self.resolve(expression.value)
            if base is None:
                return None
            member = f"{base}.{expression.attr}"
            return dict(self.bindings).get(member, member)
        try:
            return _canonical(expression)
        except ValueError:
            return None

    def assign(self, target: ast.AST, value: str | None) -> SymbolicValues:
        """Update or invalidate local names affected by one assignment."""
        bindings = dict(self.bindings)
        if isinstance(target, ast.Name):
            bindings[target.id] = value
        elif isinstance(target, ast.Attribute):
            member = self.resolve(target)
            if member is not None:
                bindings[member] = None
        else:
            for node in ast.walk(target):
                if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                    bindings[node.id] = None
        return SymbolicValues(tuple(bindings.items()))


class CallArguments:
    """Check whether a target call uses declared root-source expressions."""

    def __init__(self, expressions: tuple[str, ...] | list[str]):
        """Validate a compact ordered list of expected argument expressions."""
        if not isinstance(expressions, (tuple, list)) or any(
            not isinstance(expression, str) for expression in expressions
        ):
            raise ValueError("Call arguments must be a list of expressions")
        try:
            parsed = tuple(
                ast.parse(expression, mode="eval").body for expression in expressions
            )
            self.expected = tuple(_canonical(expression) for expression in parsed)
            self.required_roots = frozenset(
                node.id
                for expression in parsed
                for node in ast.walk(expression)
                if isinstance(node, ast.Name) and node.id != "_"
            )
        except SyntaxError as exc:
            raise ValueError("Invalid call argument expression") from exc

    def validate_parameters(
        self, function: ast.FunctionDef | ast.AsyncFunctionDef
    ) -> None:
        """Reject misspelled caller names before treating them as violations."""
        known = {
            argument.arg
            for argument in (
                *function.args.posonlyargs,
                *function.args.args,
                *function.args.kwonlyargs,
            )
        }
        if self.required_roots - known:
            raise ValueError("Call argument names must be root function parameters")

    def bound_to(
        self,
        function: ast.FunctionDef | ast.AsyncFunctionDef,
        constants: dict[str, str],
    ) -> CallArguments:
        """Resolve bare constant names in the root contract without execution."""
        bound = CallArguments(
            [constants.get(expression, expression) for expression in self.expected]
        )
        try:
            bound.validate_parameters(function)
        except ValueError as exc:
            raise ValueError(
                "Call argument names must be root function parameters or unshadowed module literal constants"
            ) from exc
        return bound

    def matches(self, call: ast.Call, values: SymbolicValues) -> bool | None:
        """Return match, mismatch, or unknown for a source-level call."""
        if call.keywords or any(isinstance(arg, ast.Starred) for arg in call.args):
            return None
        if len(call.args) != len(self.expected):
            return False
        actual = tuple(
            "_" if expected == "_" else values.resolve(argument)
            for expected, argument in zip(self.expected, call.args, strict=True)
        )
        if any(value is None for value in actual):
            return None
        return actual == self.expected
