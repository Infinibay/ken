"""Resolve explicit local Python function imports without executing modules."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path


@dataclass(frozen=True)
class ImportedFunction:
    """One uniquely imported top-level function and its versioned module."""

    path: str
    symbol: str
    tree: ast.Module
    node: ast.FunctionDef | ast.AsyncFunctionDef


class _ModuleBindings(ast.NodeVisitor):
    """Collect bindings that can replace a name at module scope."""

    def __init__(self):
        """Start an empty set of names for one top-level statement."""
        self.names: set[str] = set()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """A function binds its name, not its local body bindings."""
        self.names.add(node.name)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """An async function binds its name, not its local body bindings."""
        self.names.add(node.name)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """A class binds its name, not names introduced by its body."""
        self.names.add(node.name)

    def visit_Import(self, node: ast.Import) -> None:
        """Record names introduced by a direct import."""
        self.names.update(
            alias.asname or alias.name.split(".", 1)[0] for alias in node.names
        )

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Record names introduced by a from-import."""
        self.names.update(alias.asname or alias.name for alias in node.names)

    def visit_Name(self, node: ast.Name) -> None:
        """Record assignments and deletions in module-level control flow."""
        if isinstance(node.ctx, (ast.Store, ast.Del)):
            self.names.add(node.id)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        """Include the temporary exception binding before visiting its body."""
        if node.name:
            self.names.add(node.name)
        self.generic_visit(node)


def module_bound_names(statement: ast.stmt) -> set[str]:
    """Return names one top-level statement may bind, including its branches."""
    bindings = _ModuleBindings()
    bindings.visit(statement)
    return bindings.names


class LocalImportResolver:
    """Find only explicit project-local imports and verify every file read."""

    def __init__(self, project_root: Path):
        """Keep a project boundary and an audit of imported source bytes."""
        self.project_root = Path(project_root).resolve()
        self._modules: dict[str, tuple[ast.Module, str]] = {}

    def resolve(self, importer_path: str, local_name: str) -> ImportedFunction | None:
        """Resolve one module-level ``from x import f`` to a unique function."""
        tree = self._read(importer_path)[0]
        bindings = [
            (node, alias)
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
            if alias.name != "*" and (alias.asname or alias.name) == local_name
        ]
        if len(bindings) != 1 or self._other_binding(tree, local_name, bindings[0][0]):
            return None
        declaration, alias = bindings[0]
        module_path = self.module_path(importer_path, declaration)
        if module_path is None:
            return None
        imported_tree = self._read(module_path)[0]
        symbols = [
            node
            for node in imported_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == alias.name
        ]
        if len(symbols) != 1 or self._other_binding(
            imported_tree, alias.name, symbols[0]
        ):
            return None
        return ImportedFunction(module_path, alias.name, imported_tree, symbols[0])

    def dependencies(self, root_path: str) -> list[dict[str, str]]:
        """List imported files and the hashes used for this analysis."""
        return [
            {"path": path, "sha256": digest}
            for path, (_, digest) in sorted(self._modules.items())
            if path != root_path
        ]

    def module_tree(self, path: str) -> ast.Module:
        """Read a versioned module for source consumers other than functions."""
        return self._read(path)[0]

    def assert_current(self) -> None:
        """Reject results if any imported file changed after it was parsed."""
        for path, (_, expected) in self._modules.items():
            source = self.project_root / path
            try:
                actual = sha256(source.read_bytes()).hexdigest()
            except OSError as exc:
                raise ValueError(f"Imported source changed: {path}") from exc
            if actual != expected:
                raise ValueError(f"Imported source changed: {path}")

    def _read(self, path: str) -> tuple[ast.Module, str]:
        """Parse a project file once and pin its exact source digest."""
        if path not in self._modules:
            source = self.project_root / path
            content = source.read_bytes()
            digest = sha256(content).hexdigest()
            self._modules[path] = (
                ast.parse(content.decode("utf-8"), filename=path),
                digest,
            )
        return self._modules[path]

    def module_path(self, importer_path: str, node: ast.ImportFrom) -> str | None:
        """Map an import to a unique project or src-layout Python module."""
        if node.module is None:
            return None
        parent = Path(importer_path).parent
        if node.level:
            if len(parent.parts) < node.level:
                return None
            for _ in range(node.level - 1):
                parent = parent.parent
            parts = parent.parts + tuple(node.module.split("."))
        else:
            parts = tuple(node.module.split("."))
        roots = (self.project_root,) if node.level else (
            self.project_root,
            self.project_root / "src",
        )
        matches = []
        for root in roots:
            candidate = root.joinpath(*parts).with_suffix(".py").resolve()
            try:
                relative = candidate.relative_to(self.project_root)
            except ValueError:
                continue
            if candidate.is_file():
                matches.append(relative.as_posix())
        return matches[0] if len(set(matches)) == 1 else None

    @staticmethod
    def _other_binding(tree: ast.Module, name: str, selected: ast.stmt) -> bool:
        """Avoid claiming an import or function shadowed at module scope."""
        for node in tree.body:
            if node is selected:
                continue
            if name in module_bound_names(node):
                return True
        return False
