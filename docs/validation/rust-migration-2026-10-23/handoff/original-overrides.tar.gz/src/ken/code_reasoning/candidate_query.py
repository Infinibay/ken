"""Build KQL2 source-candidate queries from readable code contracts."""

from __future__ import annotations

from .call_contract import CallContract
from .return_contract import ReturnContract


class CandidateQuery:
    """Express a direct code relationship without claiming the full contract."""

    @staticmethod
    def for_contract(
        contract: CallContract | ReturnContract,
        *,
        symbol: str | None = None,
        include_call_site: bool = False,
    ) -> str:
        """Optionally limit a direct candidate to one callable basename."""
        if symbol is not None and not symbol.isidentifier():
            raise ValueError("Candidate symbol must be an identifier")
        if isinstance(contract, ReturnContract):
            return CandidateQuery.return_value(contract.call.target, symbol=symbol)
        return CandidateQuery.call(
            contract.target, symbol=symbol, include_call_site=include_call_site
        )

    @staticmethod
    def call(
        target: str, *, symbol: str | None = None, include_call_site: bool = False
    ) -> str:
        """Locate owners containing a call with the requested basename."""
        name = target.rsplit(".", 1)[-1]
        owner_name = f'name:"{symbol}"; ' if symbol else ""
        projection = "$owner, $site" if include_call_site else "$owner"
        return f'''language "kql/2"; module ken.code_calls;
query local_call {{
  callable $owner {{ {owner_name}
    call $site {{ name:"{name}"; }}
  }}
  select {projection};
}}'''

    @staticmethod
    def return_value(target: str, *, symbol: str | None = None) -> str:
        """Locate direct produced-to-returned value relationships."""
        name = target.rsplit(".", 1)[-1]
        owner_name = f'name:"{symbol}"; ' if symbol else ""
        return f'''language "kql/2"; module ken.code_returns;
query returned_call {{
  callable $owner {{ {owner_name}body {{
    let $value = call $site {{ name:"{name}"; resolution:any; }};
    return $value;
  }} }}
  select $owner;
}}'''
