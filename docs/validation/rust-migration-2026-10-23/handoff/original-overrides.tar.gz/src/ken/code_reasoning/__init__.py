"""Source-bound, probabilistic investigations of Python code contracts.

KQL2 supplies direct candidates; bounded Python interpreters check normal
call and returned-value paths. Investigator priors constrain unresolved callees
without turning source patterns into runtime guarantees.
"""

from .call_contract import CallContract
from .code_discovery import CodeDiscovery
from .code_investigation import CodeInvestigation
from .return_contract import ReturnContract

__all__ = ["CallContract", "CodeDiscovery", "CodeInvestigation", "ReturnContract"]
