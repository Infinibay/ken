"""Expand KQL2's direct witnesses to bounded local callers."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path

from .candidate_catalog import SourceCandidate
from .code_source import PythonSymbol
from .local_functions import LocalFunctionCatalog


@dataclass(frozen=True)
class DiscoveryCandidate:
    """One source symbol and the direct or delegated reason to check it."""

    source: PythonSymbol
    line: int
    kind: str
    call_sites: tuple[int, ...] = ()
    delegate_sites: tuple[int, ...] = ()
    via: tuple[str, ...] = ()

    @classmethod
    def direct(cls, candidate: SourceCandidate) -> DiscoveryCandidate:
        """Keep a verified KQL2 owner as the seed of source expansion."""
        return cls(
            candidate.source,
            candidate.line,
            "kql2_direct",
            call_sites=candidate.call_sites,
        )


@dataclass(frozen=True)
class ExpansionBatch:
    """Source-pinned caller candidates and their bounded search coverage."""

    candidates: tuple[DiscoveryCandidate, ...]
    coverage: dict


class _LocalCalls(ast.NodeVisitor):
    """Locate immediate file-local or same-receiver calls in one body."""

    def __init__(
        self,
        function: ast.FunctionDef | ast.AsyncFunctionDef,
        name: str,
        *,
        receiver: str | None = None,
    ):
        """Ignore nested declarations that the caller does not execute here."""
        self.receiver = receiver
        self.name = name
        self.root = function
        self.lines: set[int] = set()
        self.visit(function)

    def visit_FunctionDef(self, node):
        """Enter the selected body without attributing nested function calls."""
        if node is self.root:
            self.generic_visit(node)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        """Skip methods declared in a nested class, not invoked by this body."""

    def visit_Lambda(self, node):
        """A lambda body is deferred until the lambda is called."""

    def visit_GeneratorExp(self, node):
        """A generator expression does not call its body when constructed."""

    def visit_Call(self, node: ast.Call):
        """Record a direct call to the KQL2 seed in the selected body."""
        function = node.func
        if (
            (
                self.receiver is None
                and isinstance(function, ast.Name)
                and function.id == self.name
            )
            or (
                self.receiver is not None
                and isinstance(function, ast.Attribute)
                and function.attr == self.name
                and isinstance(function.value, ast.Name)
                and function.value.id == self.receiver
            )
        ):
            self.lines.add(node.lineno)
        self.generic_visit(node)


class LocalCallerExpansion:
    """Discover one file-local caller hop from verified KQL2 seeds."""

    def __init__(self, project_root: Path):
        """Keep every inspected caller inside one project root."""
        self.root = Path(project_root).resolve()

    def expand(
        self, seeds: tuple[SourceCandidate, ...], *, limit: int
    ) -> ExpansionBatch:
        """Inspect only seed files and preserve each seed's source snapshot."""
        found: dict[tuple[str, str], DiscoveryCandidate] = {}
        direct_keys = {(seed.source.path, seed.source.symbol) for seed in seeds}
        scanned = set()
        skipped = []
        truncated = False
        ineligible = 0
        parsed = {}
        for seed in seeds:
            source = seed.source
            parts = source.symbol.split(".")
            if len(parts) not in {1, 2}:
                ineligible += 1
                continue
            scanned.add(source.path)
            if source.path not in parsed:
                content = (self.root / source.path).read_bytes()
                digest = sha256(content).hexdigest()
                if digest != source.source_sha256:
                    raise ValueError("KQL source snapshot differs from selected code")
                try:
                    tree = ast.parse(content.decode("utf-8"), filename=source.path)
                except (SyntaxError, UnicodeError):
                    skipped.append({"path": source.path, "reason": "invalid_python"})
                    continue
                parsed[source.path] = (tree, digest)
            tree, digest = parsed[source.path]
            if digest != source.source_sha256:
                raise ValueError("KQL source snapshot differs from selected code")
            if len(parts) == 1:
                declarations = tree.body
                kind = "same_file_caller"
            else:
                owner = next(
                    (
                        node
                        for node in tree.body
                        if isinstance(node, ast.ClassDef) and node.name == parts[0]
                    ),
                    None,
                )
                if owner is None:
                    ineligible += 1
                    continue
                declarations = owner.body
                kind = "same_class_caller"
            for method in declarations:
                if not isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                symbol = (
                    method.name if len(parts) == 1 else f"{parts[0]}.{method.name}"
                )
                if symbol == source.symbol:
                    continue
                if len(parts) == 1:
                    if parts[0] in LocalFunctionCatalog._local_bindings(method):
                        continue
                    calls = _LocalCalls(method, parts[0])
                else:
                    parameters = (*method.args.posonlyargs, *method.args.args)
                    receiver = parameters[0].arg if parameters else ""
                    calls = _LocalCalls(method, parts[1], receiver=receiver)
                sites = tuple(sorted(calls.lines))
                if not sites:
                    continue
                key = (source.path, symbol)
                if key in direct_keys:
                    continue
                via = f"{source.path}::{source.symbol}"
                if key in found:
                    previous = found[key]
                    found[key] = DiscoveryCandidate(
                        previous.source,
                        previous.line,
                        previous.kind,
                        delegate_sites=tuple(
                            sorted(set(previous.delegate_sites) | set(sites))
                        ),
                        via=tuple(sorted(set(previous.via) | {via})),
                    )
                    continue
                if len(found) >= limit:
                    truncated = True
                    continue
                try:
                    selected = PythonSymbol.from_python(
                        project_root=self.root, path=source.path, symbol=symbol
                    )
                except ValueError:
                    source.assert_current()
                    skipped.append(
                        {
                            "path": source.path,
                            "symbol": symbol,
                            "reason": "ambiguous_caller",
                        }
                    )
                    continue
                if selected.source_sha256 != source.source_sha256:
                    raise ValueError("KQL source snapshot differs from selected code")
                found[key] = DiscoveryCandidate(
                    selected,
                    method.lineno,
                    kind,
                    delegate_sites=sites,
                    via=(via,),
                )
            source.assert_current()
        return ExpansionBatch(
            tuple(found.values()),
            {
                "relation": "same_file_function_or_class_callers_one_hop",
                "complete": not skipped and not truncated,
                "scanned_files": len(scanned),
                "ineligible_seeds": ineligible,
                "skipped": skipped,
                "results_truncated": truncated,
            },
        )
