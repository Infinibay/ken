"""Locate same-class bodies and distinguish stable from guarded bindings."""

from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass

from .call_arguments import SymbolicValues
from .local_imports import module_bound_names


@dataclass(frozen=True)
class SourceMethod:
    """One same-class declaration, which may still dispatch dynamically."""

    class_name: str
    node: ast.FunctionDef | ast.AsyncFunctionDef

    @property
    def symbol(self) -> str:
        """Name the declaration without confusing same-named other classes."""
        return f"{self.class_name}.{self.node.name}"


class LocalMethodCatalog:
    """Separate method candidates, stable private bodies, and guarded public bodies."""

    def __init__(self, tree: ast.Module):
        """Index unique classes and classify which method bodies can be inspected."""
        counts = Counter(
            name for statement in tree.body for name in module_bound_names(statement)
        )
        rebound_names = self._rebound_names(tree)
        self.owners: dict[int, ast.ClassDef] = {}
        self.candidates: dict[int, dict[str, SourceMethod]] = {}
        self.methods: dict[int, dict[str, SourceMethod]] = {}
        self.conditional_methods: dict[int, dict[str, SourceMethod]] = {}
        for declaration in tree.body:
            if (
                not isinstance(declaration, ast.ClassDef)
                or counts[declaration.name] != 1
            ):
                continue
            method_nodes = [
                item
                for item in declaration.body
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            ]
            method_counts = Counter(
                name
                for item in declaration.body
                for name in module_bound_names(item)
            )
            available = {}
            conditional = {}
            candidates = {}
            safe_class = not (
                declaration.decorator_list
                or declaration.bases
                or declaration.keywords
                or any(item.name == "__getattribute__" for item in method_nodes)
            )
            for method in method_nodes:
                self.owners[id(method)] = declaration
                if method_counts[method.name] == 1:
                    candidates[method.name] = SourceMethod(
                        declaration.name, method
                    )
                if (
                    safe_class
                    and method_counts[method.name] == 1
                    and not method.decorator_list
                    and method.name not in rebound_names
                    and f"_{declaration.name}{method.name}" not in rebound_names
                ):
                    source_method = SourceMethod(declaration.name, method)
                    if self._private(method.name):
                        available[method.name] = source_method
                    else:
                        conditional[method.name] = source_method
            self.candidates[id(declaration)] = candidates
            self.methods[id(declaration)] = available
            self.conditional_methods[id(declaration)] = conditional

    def candidate(
        self,
        caller: ast.FunctionDef | ast.AsyncFunctionDef,
        call: ast.Call,
        values: SymbolicValues,
    ) -> SourceMethod | None:
        """Locate one same-class method without asserting runtime dispatch."""
        function = call.func
        owner = self.owners.get(id(caller))
        if (
            owner is None
            or not isinstance(function, ast.Attribute)
            or not isinstance(function.value, ast.Name)
        ):
            return None
        parameters = (*caller.args.posonlyargs, *caller.args.args)
        if (
            not parameters
            or function.value.id != parameters[0].arg
            or values.resolve(function.value) != parameters[0].arg
        ):
            return None
        return self.candidates[id(owner)].get(function.attr)

    def resolve(
        self,
        caller: ast.FunctionDef | ast.AsyncFunctionDef,
        call: ast.Call,
        values: SymbolicValues,
    ) -> SourceMethod | None:
        """Return the callee only for ``self.__private(...)`` in its class."""
        candidate = self.candidate(caller, call, values)
        if candidate is None or not self._private(candidate.node.name):
            return None
        owner = self.owners[id(caller)]
        return self.methods[id(owner)].get(candidate.node.name)

    def conditional(
        self,
        caller: ast.FunctionDef | ast.AsyncFunctionDef,
        call: ast.Call,
        values: SymbolicValues,
    ) -> SourceMethod | None:
        """Offer a safe public body only under an explicit dispatch choice."""
        candidate = self.candidate(caller, call, values)
        if candidate is None:
            return None
        owner = self.owners[id(caller)]
        return self.conditional_methods[id(owner)].get(candidate.node.name)

    @staticmethod
    def _private(name: str) -> bool:
        """Accept Python's name-mangled form, not a public or dunder method."""
        return name.startswith("__") and not name.endswith("__")

    @staticmethod
    def _rebound_names(tree: ast.Module) -> set[str]:
        """Index visibly written or deleted attribute names once per module."""
        names = set()
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Attribute)
                and isinstance(node.ctx, (ast.Store, ast.Del))
            ):
                names.add(node.attr)
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id in {"setattr", "delattr"}
                and len(node.args) >= 2
                and isinstance(node.args[1], ast.Constant)
                and isinstance(node.args[1].value, str)
            ):
                names.add(node.args[1].value)
        return names


def private_binding_assumptions(paths) -> list[dict]:
    """Present source-local private dispatch premises carried by path traces."""
    assumptions = set()
    for path in paths:
        for event in path.trace:
            if not event.startswith("private_binding:"):
                continue
            symbol, source, line = event.removeprefix("private_binding:").rsplit(
                ":", 2
            )
            assumptions.add((symbol, source, int(line)))
    return [
        {
            "kind": "source_local_private_method_binding",
            "method": symbol,
            "path": source,
            "line": line,
        }
        for symbol, source, line in sorted(assumptions)
    ]


def local_method_candidates(paths) -> list[dict]:
    """Expose plausible method declarations without treating them as effects."""
    candidates = set()
    for path in paths:
        for event in path.trace:
            if not event.startswith("candidate_method:"):
                continue
            symbol, source, declaration, call = event.removeprefix(
                "candidate_method:"
            ).rsplit(":", 3)
            candidates.add((symbol, source, int(declaration), int(call)))
    return [
        {
            "method": symbol,
            "path": source,
            "declaration_line": declaration,
            "call_line": call,
        }
        for symbol, source, declaration, call in sorted(candidates)
    ]
