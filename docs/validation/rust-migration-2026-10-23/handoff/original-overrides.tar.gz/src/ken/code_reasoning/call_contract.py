"""Human-sized syntax for one source-level call obligation."""

from __future__ import annotations

import ast
from dataclasses import dataclass

from .call_arguments import CallArguments
from .code_source import PythonSymbol


@dataclass(frozen=True)
class CallContract:
    """A target call, optional arguments, and optional predecessor."""

    target: str
    arguments: tuple[str, ...] | None = None
    after: str | None = None

    @classmethod
    def parse(cls, text: str) -> CallContract:
        """Parse ``os.fsync -> os.replace(_, path)`` without running code."""
        if not isinstance(text, str) or not text.strip():
            raise ValueError("Unsupported call contract")
        expression = text.strip()
        before = None
        if "->" in expression:
            left, right = expression.split("->", 1)
            candidate = left.strip()
            if cls._identifier_path(candidate):
                before, expression = candidate, right.strip()
        try:
            parsed = ast.parse(expression, mode="eval").body
        except SyntaxError as exc:
            raise ValueError("Unsupported call contract") from exc
        if isinstance(parsed, ast.Call):
            if parsed.keywords or any(
                isinstance(argument, ast.Starred) for argument in parsed.args
            ):
                raise ValueError("Unsupported call contract")
            target_node = parsed.func
            arguments = tuple(ast.unparse(argument) for argument in parsed.args)
            arguments = CallArguments(arguments).expected
        else:
            target_node = parsed
            arguments = None
        target = ast.unparse(target_node)
        if not cls._identifier_path(target) or before == target:
            raise ValueError("Unsupported call contract")
        return cls(target, arguments, before)

    def for_source(self, source: PythonSymbol) -> tuple[str, str | None]:
        """Bind a member call to a selected function parameter when possible."""
        if "." not in self.target:
            return self.target, None
        receiver, method = self.target.rsplit(".", 1)
        if receiver.split(".", 1)[0] in source.parameters():
            return method, receiver
        return self.target, None

    @staticmethod
    def _identifier_path(value: str) -> bool:
        """Accept only simple dotted Python names as call targets."""
        return bool(value) and all(part.isidentifier() for part in value.split("."))
