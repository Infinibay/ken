"""Identify project-local functions safe to inspect at a call site."""

from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass

from .local_imports import LocalImportResolver, module_bound_names


@dataclass(frozen=True)
class SourceFunction:
    """One uniquely bound function and the source module that defines it."""

    path: str
    tree: ast.Module
    node: ast.FunctionDef | ast.AsyncFunctionDef

    @property
    def identity(self) -> tuple[str, str]:
        """Distinguish same-named helpers in different project files."""
        return self.path, self.node.name


class LocalFunctionCatalog:
    """Resolve unique top-level helpers while respecting caller shadowing."""

    def __init__(
        self,
        tree: ast.Module,
        module_path: str,
        imports: LocalImportResolver,
    ):
        """Index declarations once and keep import reads versioned."""
        self.tree = tree
        self.module_path = module_path
        self.imports = imports
        counts = Counter(
            name for statement in tree.body for name in module_bound_names(statement)
        )
        self.helpers = {
            statement.name: statement
            for statement in tree.body
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef))
            and counts[statement.name] == 1
        }

    def resolve(
        self, caller: ast.FunctionDef | ast.AsyncFunctionDef, name: str
    ) -> SourceFunction | None:
        """Return one unshadowed local or explicit project-imported function."""
        if name in self._local_bindings(caller):
            return None
        local = self.helpers.get(name)
        if local is not None:
            return (
                SourceFunction(self.module_path, self.tree, local)
                if not local.decorator_list
                else None
            )
        imported = self.imports.resolve(self.module_path, name)
        if imported is None or imported.node.decorator_list:
            return None
        return SourceFunction(imported.path, imported.tree, imported.node)

    @staticmethod
    def _local_bindings(function: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
        """List names whose function-local binding can hide a module helper."""
        names = {
            argument.arg
            for argument in (
                *function.args.posonlyargs,
                *function.args.args,
                *function.args.kwonlyargs,
            )
        }
        for child in ast.walk(function):
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                names.add(child.id)
            elif isinstance(child, ast.Nonlocal):
                names.update(child.names)
            elif (
                isinstance(child, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar))
                and child.name
            ):
                names.add(child.name)
            elif isinstance(child, ast.MatchMapping) and child.rest:
                names.add(child.rest)
            elif isinstance(child, (ast.Import, ast.ImportFrom)):
                names.update(
                    alias.asname or alias.name.split(".", 1)[0] for alias in child.names
                )
            elif (
                isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
                and child is not function
            ):
                names.add(child.name)
        return names
