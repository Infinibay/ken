"""Choose unresolved calls whose inspection can narrow a code conclusion."""

from __future__ import annotations

from .effect_site import EffectSite
from .worlds import ObligationWorldModel


class NextEvidence:
    """Compare finite worlds before and after resolving one unknown callee."""

    MAX_EXAMINED_EFFECTS = 24

    def __init__(
        self,
        paths,
        worlds: ObligationWorldModel,
        source_path: str,
        *,
        outcome: str = "target",
    ):
        """Keep path traces and declared priors tied to one source question."""
        if outcome not in {"target", "return_value"}:
            raise ValueError("Unknown evidence outcome")
        self.paths = tuple(paths)
        self.worlds = worlds
        self.source_path = source_path
        self.outcome = outcome

    def suggest(self, *, limit: int = 3) -> list[dict]:
        """Rank source calls by how much either observed effect narrows bounds."""
        if self.worlds.status() != "unknown":
            return []
        baseline, assumptions = self.worlds.probability_bounds()
        if baseline is None:
            return []
        width = baseline[1] - baseline[0]
        suggestions = []
        candidates = [
            effect for effect in self.worlds.effects if effect not in assumptions
        ]
        candidates.sort(key=lambda effect: (-self._path_count(effect), effect))
        for effect in candidates[: self.MAX_EXAMINED_EFFECTS]:
            absent = self._conditional_bounds(assumptions, effect, 0.0)
            present = self._conditional_bounds(assumptions, effect, 1.0)
            if absent is None or present is None:
                continue
            change = max(
                width - (absent[1] - absent[0]),
                width - (present[1] - present[0]),
            )
            if change <= 1e-12:
                continue
            if effect.startswith("dispatch:"):
                suggestions.append(
                    (
                        change,
                        0,
                        {
                            "kind": "dispatch_choice",
                            "method": effect.split("@", 1)[0].removeprefix("dispatch:"),
                            "effect": effect,
                            "locations": self._locations(effect),
                            "if_other_selected": self._box(absent),
                            "if_local_selected": self._box(present),
                        },
                    )
                )
                continue
            suggestions.append(
                (
                    change,
                    1,
                    {
                        "kind": (
                            "alternate_implementation_effect"
                            if effect.startswith("override:")
                            else f"callee_{self.outcome}_effect"
                        ),
                        "effect": effect,
                        "locations": self._locations(effect),
                        f"if_{self.outcome}_absent": self._box(absent),
                        f"if_{self.outcome}_present": self._box(present),
                    },
                )
            )
        suggestions.sort(key=lambda item: (-item[0], item[1], item[2]["effect"]))
        return [item for _, _, item in suggestions[:limit]]

    def _path_count(self, effect):
        """Prioritize effects that occur on more unresolved paths."""
        return sum(
            not path.satisfied
            and (
                effect in path.possible | path.upper_possible
                or effect in {name for name, _ in path.guards}
            )
            for path in self.paths
        )

    def _conditional_bounds(self, assumptions, effect, probability):
        """Re-evaluate worlds after one inspected callee is known either way."""
        conditioned = ObligationWorldModel(
            self.paths, {**assumptions, effect: probability}
        )
        bounds, _ = conditioned.probability_bounds()
        return bounds

    def _locations(self, effect):
        """Find call sites that can change an unwitnessed normal path."""
        if effect.startswith("dispatch:"):
            return [
                {
                    "path": EffectSite.source_path(effect, self.source_path),
                    "line": int(effect.rsplit(":", 1)[-1]),
                }
            ]
        locations = set()
        for path in self.paths:
            if path.satisfied or effect not in path.possible | path.upper_possible:
                continue
            for event in path.trace:
                if not event.startswith("unknown:"):
                    continue
                recorded, line = event.removeprefix("unknown:").rsplit(":", 1)
                if recorded != effect:
                    continue
                source = EffectSite.source_path(effect, self.source_path)
                locations.add((source, int(line)))
        return [{"path": path, "line": line} for path, line in sorted(locations)]

    @staticmethod
    def _box(bounds):
        """Name the lower and upper chance under declared assumptions."""
        return {"lower": bounds[0], "upper": bounds[1]}
