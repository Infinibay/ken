"""Interpret call-event order without mixing it into Python AST traversal."""

from __future__ import annotations

from dataclasses import replace

from .path_interpreter import CallPath


class CallOrder:
    """Require one matching target call after a predecessor on every path."""

    def __init__(self, predecessor: str, target: str):
        """Name the two lexical call events that form the ordered contract."""
        self.predecessor = predecessor
        self.target = target

    def apply(self, paths: list[CallPath]) -> list[CallPath]:
        """Qualify target events by prior predecessor evidence per path."""
        return [self._qualify(path) for path in paths]

    def _qualify(self, path: CallPath) -> CallPath:
        """Separate witnessed order from weaker hidden-order possibilities."""
        seen_predecessor = False
        unknown_before_predecessor = set()
        possible_predecessors = set()
        possible_after_predecessor = set()
        qualified = False
        annotated = []
        for event in path.trace:
            annotated.append(event)
            if event.startswith(f"before:{self.predecessor}:"):
                seen_predecessor = True
            elif event.startswith("unknown:"):
                effect = event.removeprefix("unknown:").rsplit(":", 1)[0]
                if seen_predecessor:
                    possible_after_predecessor.add(effect)
                else:
                    unknown_before_predecessor.add(effect)
            elif event.startswith(f"call:{self.target}:"):
                location = event.removeprefix(f"call:{self.target}:")
                if seen_predecessor:
                    qualified = True
                    annotated.append(f"ordered:{location}")
                else:
                    possible_predecessors.update(unknown_before_predecessor)
                    annotated.append(f"out_of_order:{location}")
        if qualified:
            return replace(path, called=True, trace=tuple(annotated))
        return replace(
            path,
            called=False,
            possible=frozenset(possible_after_predecessor),
            upper_possible=path.possible,
            possible_predecessors=frozenset(possible_predecessors),
            trace=tuple(annotated),
        )
