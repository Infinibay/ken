"""Bounded Python paths for the value a function actually returns."""

from __future__ import annotations

import ast
from dataclasses import dataclass, replace
import typing

from .call_arguments import CallArguments, SymbolicValues
from .module_constants import ModuleConstants, ModuleMutationContext
from .code_source import function_is_generator, select_function
from .effect_site import EffectSite
from .local_functions import LocalFunctionCatalog, SourceFunction
from .local_imports import module_bound_names
from .local_methods import LocalMethodCatalog


@dataclass(frozen=True)
class ReturnOrigin:
    """Known target value, another value, or an unresolved callee result."""

    kind: str
    producer: tuple[str, int] | None = None
    effects: frozenset[str] = frozenset()
    unsupported: tuple[str, ...] = ()


OTHER = ReturnOrigin("other")


@dataclass(frozen=True)
class ReturnPath:
    """One normal path's local value provenance and returned obligation."""

    values: SymbolicValues
    bindings: tuple[tuple[str, ReturnOrigin], ...] = ()
    satisfied: bool = False
    possible: frozenset[str] = frozenset()
    upper_possible: frozenset[str] = frozenset()
    possible_predecessors: frozenset[str] = frozenset()
    guards: tuple[tuple[str, bool], ...] = ()
    trace: tuple[str, ...] = ()
    unsupported: tuple[str, ...] = ()
    returned: bool = False
    producer: tuple[str, int] | None = None
    return_site: tuple[str, int] | None = None

    def origin(self, name: str) -> ReturnOrigin:
        """Read the current local binding, never an earlier assignment."""
        return dict(self.bindings).get(name, OTHER)

    def bind(self, name: str, origin: ReturnOrigin) -> ReturnPath:
        """Replace one local's provenance after a source assignment."""
        bindings = dict(self.bindings)
        bindings[name] = origin
        return replace(self, bindings=tuple(bindings.items()))


class PythonReturnInterpreter:
    """Follow local assignments and returns without executing Python code."""

    def __init__(
        self,
        tree: ast.Module,
        target: str,
        receiver: str | None,
        arguments: CallArguments | None,
        when: dict[str, bool],
        module_path: str,
        *,
        max_paths: int = 64,
        import_resolver,
        visited: frozenset[tuple[str, str]] = frozenset(),
        constant_context=None,
    ):
        """Bind one lexical call target and branch assumptions to a module."""
        self.tree = tree
        self.target = target
        self.receiver = receiver
        self.arguments = arguments
        self.constant_mutations = (
            constant_context.mutation_context
            if constant_context is not None
            else ModuleMutationContext()
        )
        self.constants = ModuleConstants(
            tree, module_path, mutation_context=self.constant_mutations
        )
        self.when = dict(when)
        self.module_path = module_path
        self.max_paths = max_paths
        self.import_resolver = import_resolver
        self.catalog = LocalFunctionCatalog(tree, module_path, import_resolver)
        self.local_methods = LocalMethodCatalog(tree)
        self.visited = visited
        self.used_when: set[str] = set()
        self.module_imports: set[str] = set()
        self.module_rebound: set[str] = set()
        for node in tree.body:
            if isinstance(node, ast.Import):
                names = (
                    alias.asname or alias.name.split(".", 1)[0] for alias in node.names
                )
                self.module_imports.update(names)
            elif isinstance(node, ast.ImportFrom):
                self.module_imports.update(
                    alias.asname or alias.name for alias in node.names
                )
            else:
                self.module_rebound.update(module_bound_names(node))
        self.local_bindings: set[str] = set()
        self.current_function: ast.FunctionDef | ast.AsyncFunctionDef | None = None

    def paths_for(
        self,
        symbol: str,
        *,
        function: ast.FunctionDef | ast.AsyncFunctionDef | None = None,
        values: SymbolicValues | None = None,
    ) -> list[ReturnPath]:
        """Enumerate bounded normal completion paths of one selected function."""
        if function is None:
            function = select_function(self.tree, symbol)
        expected_constants: frozenset[str] = frozenset()
        if self.arguments is not None and not self.visited:
            expected_constants = self.arguments.required_roots
            self.arguments = self.arguments.bound_to(function, self.constants.available(function))
        if function.decorator_list:
            return [
                ReturnPath(
                    values or SymbolicValues.identity(function),
                    unsupported=("decorated_function",),
                )
            ]
        if function_is_generator(function):
            if self.when:
                raise ValueError("A branch precondition did not match a source condition")
            return [
                ReturnPath(
                    values or SymbolicValues.identity(function),
                    unsupported=("generator_function",),
                )
            ]
        if isinstance(function, ast.AsyncFunctionDef) and not self.visited:
            return [
                ReturnPath(
                    values or SymbolicValues.identity(function),
                    unsupported=("coroutine_function",),
                )
            ]
        identity = (self.module_path, symbol)
        if identity in self.visited or len(self.visited) >= 8:
            return [
                ReturnPath(
                    values or SymbolicValues.identity(function),
                    unsupported=("delegation_cycle_or_depth",),
                )
            ]
        self.visited = self.visited | {identity}
        self.current_function = function
        self.local_bindings = {
            argument.arg
            for argument in (
                *function.args.posonlyargs,
                *function.args.args,
                *function.args.kwonlyargs,
            )
        }
        self.local_bindings.update(
            node.id
            for node in ast.walk(function)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store)
        )
        bound_values = values or SymbolicValues.identity(function)
        traces: tuple[str, ...] = ()
        if self.arguments is not None:
            bound_values, traces = self.constants.bind(function, bound_values, expected=expected_constants)
        initial = ReturnPath(bound_values, trace=traces)
        try:
            paths = self._block(function.body, [initial])
        except OverflowError:
            paths = [replace(initial, unsupported=("path_limit",))]
        if set(self.when) - self.used_when:
            raise ValueError("A branch precondition did not match a source condition")
        return typing.cast("list[ReturnPath]", self.constants.validate(paths))

    def _block(self, statements, paths):
        """Advance every active path through a statement sequence."""
        for statement in statements:
            paths = [
                successor
                for path in paths
                for successor in (
                    [path] if path.returned else self._step(statement, path)
                )
            ]
            if len(paths) > self.max_paths:
                raise OverflowError("return path limit")
        return paths

    def _step(self, statement, path):
        """Interpret only statements whose return provenance is explicit."""
        line = getattr(statement, "lineno", 0)
        if isinstance(statement, ast.Return):
            return [
                replace(
                    item,
                    satisfied=origin.kind == "target",
                    possible=item.possible | origin.effects,
                    unsupported=item.unsupported + origin.unsupported,
                    returned=True,
                    producer=origin.producer if origin.kind == "target" else None,
                    return_site=(self.module_path, line),
                    trace=item.trace + (f"return:{self.module_path}:{line}",),
                )
                for item, origin in self._value(statement.value, path)
            ]
        if isinstance(statement, ast.Assign):
            resolved = path.values.resolve(statement.value)
            outcomes = []
            for item, origin in self._value(statement.value, path):
                values = item.values
                for target in statement.targets:
                    if not isinstance(target, ast.Name):
                        item = self._unsupported(item, f"assignment:{line}")
                        break
                    item = item.bind(target.id, origin)
                    values = values.assign(target, resolved)
                outcomes.append(replace(item, values=values))
            return outcomes
        if isinstance(statement, ast.If):
            if any(isinstance(node, ast.Call) for node in ast.walk(statement.test)):
                path = self._unsupported(path, f"condition_call:{line}")
            branches = (statement.body, statement.orelse)
            if isinstance(statement.test, ast.Constant) and isinstance(
                statement.test.value, bool
            ):
                branches = (branches[0 if statement.test.value else 1],)
            else:
                condition = ast.unparse(statement.test)
                if condition in self.when:
                    self.used_when.add(condition)
                    branches = (branches[0 if self.when[condition] else 1],)
                elif isinstance(statement.test, ast.UnaryOp) and isinstance(
                    statement.test.op, ast.Not
                ):
                    operand = ast.unparse(statement.test.operand)
                    if operand in self.when:
                        self.used_when.add(operand)
                        branches = (branches[1 if self.when[operand] else 0],)
            return [
                outcome
                for index, branch in enumerate(branches)
                for outcome in self._block(
                    branch,
                    [replace(path, trace=path.trace + (f"if:{line}:{index}",))],
                )
            ]
        if isinstance(statement, ast.Raise):
            return []
        if isinstance(statement, ast.Expr):
            if isinstance(statement.value, ast.Call):
                if self.constants.used:
                    # A discarded result is irrelevant to return provenance,
                    # but a followed helper may invalidate a module premise.
                    return [replace(item, trace=item.trace + (f"discard:{line}",))
                            for item, _origin in self._value(statement.value, path)]
                return [replace(path, trace=path.trace + (f"discard:{line}",))]
            if any(isinstance(node, ast.Call) for node in ast.walk(statement.value)):
                return [self._unsupported(path, f"nested_call:{line}")]
            return [path]
        if isinstance(
            statement,
            (
                ast.Pass,
                ast.Import,
                ast.ImportFrom,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            return [path]
        return [self._unsupported(path, f"{type(statement).__name__}:{line}")]

    def _value(self, expression, path):
        """Enumerate possible producers of an assigned or returned value."""
        if expression is None:
            return [(path, OTHER)]
        if isinstance(expression, ast.Name):
            return [(path, path.origin(expression.id))]
        if isinstance(expression, ast.Call):
            return self._call_origin(expression, path)
        if isinstance(expression, ast.Await) and isinstance(expression.value, ast.Call):
            return self._call_origin(expression.value, path, awaited=True)
        if isinstance(expression, ast.Constant):
            return [(path, OTHER)]
        return [(self._unsupported(path, f"expression:{expression.lineno}"), OTHER)]

    def _call_origin(self, call: ast.Call, path: ReturnPath, *, awaited=False):
        """Witness the target call or name a callee whose return is unknown."""
        line = call.lineno
        if self._matches_target(call.func, path.values):
            if self.arguments is not None:
                match = self.arguments.matches(call, path.values)
                if match is None:
                    return [
                        (self._unsupported(path, f"arguments_unknown:{line}"), OTHER)
                    ]
                if not match:
                    return [(path, OTHER)]
            return [
                (
                    replace(
                        path,
                        trace=path.trace + (f"produce:{self.module_path}:{line}",),
                    ),
                    ReturnOrigin("target", producer=(self.module_path, line)),
                )
            ]
        if isinstance(call.func, ast.Name):
            assert self.current_function is not None
            helper = self.catalog.resolve(self.current_function, call.func.id)
            if helper is not None:
                return self._delegate(call, path, helper, awaited=awaited)
            label = f"function:{call.func.id}"
        elif isinstance(call.func, ast.Attribute):
            assert self.current_function is not None
            method = self.local_methods.resolve(
                self.current_function, call, path.values
            )
            if method is not None:
                return self._delegate(
                    call,
                    path,
                    SourceFunction(self.module_path, self.tree, method.node),
                    awaited=awaited,
                    symbol=method.symbol,
                    bound_method=True,
                )
            candidate = self.local_methods.candidate(
                self.current_function, call, path.values
            )
            if candidate is not None:
                path = replace(
                    path,
                    trace=path.trace
                    + (
                        f"candidate_method:{candidate.symbol}:"
                        f"{self.module_path}:{candidate.node.lineno}:{line}",
                    ),
                )
                conditional = self.local_methods.conditional(
                    self.current_function, call, path.values
                )
                if conditional is not None:
                    dispatch = EffectSite(
                        f"dispatch:{candidate.symbol}", self.module_path, line
                    ).key()
                    selected = self._delegate(
                        call,
                        replace(
                            path,
                            guards=path.guards + ((dispatch, True),),
                            trace=path.trace
                            + (f"dispatch_local:{dispatch}:{line}",),
                        ),
                        SourceFunction(self.module_path, self.tree, conditional.node),
                        awaited=awaited,
                        symbol=conditional.symbol,
                        bound_method=True,
                        private_binding=False,
                    )
                    if selected and not any(
                        origin.unsupported for _, origin in selected
                    ):
                        override = EffectSite(
                            f"override:{call.func.attr}", self.module_path, line
                        ).key()
                        alternative = (
                            replace(
                                path,
                                guards=path.guards + ((dispatch, False),),
                                trace=path.trace
                                + (f"dispatch_other:{dispatch}:{line}",)
                                + (f"unknown:{override}:{line}",),
                            ),
                            ReturnOrigin(
                                "unknown", effects=frozenset({override})
                            ),
                        )
                        return selected + [alternative]
            label = f"method:{call.func.attr}"
        else:
            label = "call:dynamic"
        effect = EffectSite(label, self.module_path, line).key()
        return [
            (
                replace(path, trace=path.trace + (f"unknown:{effect}:{line}",)),
                ReturnOrigin("unknown", effects=frozenset({effect})),
            )
        ]

    def _delegate(
        self,
        call,
        path,
        helper,
        *,
        awaited,
        symbol=None,
        bound_method=False,
        private_binding=True,
    ):
        """Interpret a uniquely known helper's returned value at this site."""
        line = call.lineno
        if isinstance(helper.node, ast.AsyncFunctionDef) != awaited:
            return [
                (path, ReturnOrigin("unknown", unsupported=(f"await_mismatch:{line}",)))
            ]
        if function_is_generator(helper.node):
            return [
                (
                    path,
                    ReturnOrigin("unknown", unsupported=(f"generator_helper:{line}",)),
                )
            ]
        child = PythonReturnInterpreter(
            helper.tree,
            self.target,
            self.receiver,
            self.arguments,
            {},
            helper.path,
            max_paths=self.max_paths,
            import_resolver=self.import_resolver,
            visited=self.visited,
            constant_context=self.constants,
        )
        outcomes = child.paths_for(
            symbol or helper.node.name,
            function=helper.node,
            values=(
                SymbolicValues.for_bound_method(helper.node, call, path.values)
                if bound_method
                else SymbolicValues.for_call(helper.node, call, path.values)
            ),
        )
        return [
            (
                replace(
                    path,
                    trace=path.trace
                    + (
                        (
                            f"private_binding:{symbol}:{helper.path}:{line}",
                        )
                        if bound_method and private_binding
                        else ()
                    )
                    + (f"delegate:{helper.path}:{symbol or helper.node.name}:{line}",)
                    + outcome.trace,
                    guards=path.guards + outcome.guards,
                ),
                self._delegated_origin(outcome),
            )
            for outcome in outcomes
        ]

    @staticmethod
    def _delegated_origin(outcome: ReturnPath) -> ReturnOrigin:
        """Carry a helper's value provenance, not its internal path state."""
        if outcome.unsupported:
            return ReturnOrigin("unknown", unsupported=outcome.unsupported)
        if outcome.satisfied:
            return ReturnOrigin("target", producer=outcome.producer)
        if outcome.possible:
            return ReturnOrigin("unknown", effects=outcome.possible)
        return OTHER

    def _matches_target(self, function, values: SymbolicValues) -> bool:
        """Match a lexical target without claiming a rebound module import."""
        if self.receiver is not None:
            return (
                isinstance(function, ast.Attribute)
                and function.attr == self.target
                and values.resolve(function.value) == self.receiver
            )
        if "." in self.target:
            root = self.target.split(".", 1)[0]
            if root in self.module_imports and (
                root in self.module_rebound or root in self.local_bindings
            ):
                return False
            return ast.unparse(function) == self.target
        return (
            isinstance(function, ast.Name)
            and function.id == self.target
            or isinstance(function, ast.Attribute)
            and function.attr == self.target
        )

    @staticmethod
    def _unsupported(path: ReturnPath, reason: str) -> ReturnPath:
        """Keep unsupported semantics explicit instead of inventing a return."""
        return replace(path, unsupported=path.unsupported + (reason,))
