"""One code contract investigated through KQL2 and source-bound worlds."""

from __future__ import annotations

from dataclasses import replace
from hashlib import sha256

from .candidate_query import CandidateQuery
from .call_contract import CallContract
from .call_paths import CallPaths
from .code_evidence import KqlProbe
from .code_locator import PythonSymbolLocator
from .code_source import PythonSymbol
from .return_contract import ReturnContract
from .return_investigation import ReturnInvestigation


class CodeInvestigation:
    """Investigate a call contract through KQL2 and versioned source paths."""

    def __init__(self, source: PythonSymbol):
        """Bind subsequent contracts to one versioned Python function."""
        self.source = source

    @classmethod
    def from_python_symbol(cls, *, project_root, path, symbol):
        """Select one function without importing its module or parsing prose."""
        return cls(
            PythonSymbol.from_python(
                project_root=project_root, path=path, symbol=symbol
            )
        )

    @classmethod
    def from_selector(cls, *, project_root, selector, search_path=None):
        """Resolve one short or file-qualified selector against live source."""
        source = PythonSymbolLocator(project_root, search_path=search_path).resolve(
            selector
        )
        return cls(source)

    def check(self, contract: str | CallContract | ReturnContract, **options):
        """Evaluate a call or returned-value contract against this source."""
        specification: CallContract | ReturnContract
        if isinstance(contract, ReturnContract) or (
            isinstance(contract, str) and contract.strip().startswith("return ")
        ):
            specification = (
                ReturnContract.parse(contract)
                if isinstance(contract, str)
                else contract
            )
            return ReturnInvestigation(self.source).check(specification, **options)
        specification = (
            CallContract.parse(contract) if isinstance(contract, str) else contract
        )
        if not isinstance(specification, CallContract):
            raise TypeError("Expected a call contract")
        target, receiver = specification.for_source(self.source)
        return self.check_call(
            target,
            receiver=receiver,
            arguments=specification.arguments,
            after=specification.after,
            **options,
        )

    def check_call(
        self,
        target,
        *,
        receiver=None,
        arguments=None,
        after=None,
        when=None,
        effect_priors=None,
        cache_mb=None,
        timeout_ms=None,
        detail="answer",
        hypothesis=None,
    ):
        """Correlate KQL2 candidates, source paths, and declared effect priors."""
        if detail not in {"answer", "full"}:
            raise ValueError("detail must be 'answer' or 'full'")
        self.source.assert_current()
        paths = CallPaths(
            self.source,
            target,
            receiver=receiver,
            arguments=arguments,
            after=after,
            when=when,
        )
        question_id = (
            hypothesis
            or "investigation:"
            + sha256(
                repr(
                    (
                        self.source.path,
                        self.source.symbol,
                        self.source.source_sha256,
                        target,
                        receiver,
                        tuple(arguments) if arguments is not None else None,
                        after,
                        tuple(sorted((when or {}).items())),
                    )
                ).encode()
            ).hexdigest()[:24]
        )
        local_name = self.source.symbol.rsplit(".", 1)[-1]
        query = CandidateQuery.call(target, symbol=local_name)
        observation = KqlProbe(
            query,
            self.source.path,
            question_id,
            expected_symbol=local_name,
        ).run(self.source.project_root, cache_mb=cache_mb, timeout_ms=timeout_ms)
        if not self.source.basename_is_unique():
            observation = replace(
                observation, state="unknown", reason="ambiguous_target"
            )
        self.source.validate_observation(observation)
        analysis = paths.analyze(effect_priors=effect_priors)
        self.source.assert_current()
        candidate = observation.summary()
        candidate["relation"] = "same_callable_only"
        result = {
            "schema": "ken-code-investigation/1",
            "source": self.source.data(),
            "receiver_binding": "declared_by_caller" if receiver else None,
            "candidate_call": candidate,
            "call_analysis": (
                analysis if detail == "full" else CallPaths.summary(analysis)
            ),
        }
        if detail == "full":
            result["candidate_call"] = observation.data() | {
                "relation": "same_callable_only"
            }
        return result
