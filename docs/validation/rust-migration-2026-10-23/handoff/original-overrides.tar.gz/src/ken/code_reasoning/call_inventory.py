"""Cheap, complete Python call-name inventory before indexed KQL2 acquisition."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from time import monotonic

from ken.gitignore_filter import iter_files


@dataclass(frozen=True)
class CallInventory:
    """Files that can satisfy a direct KQL2 call-name selector."""

    source_paths: tuple[str, ...]
    examined_files: int
    prefiltered_files: int
    skipped: tuple[dict, ...]
    elapsed_ms: float

    @property
    def complete(self) -> bool:
        """Say whether every eligible Python file was inspected."""
        return not self.skipped


class PythonCallInventory:
    """Select files by AST call spelling without building the structural IR."""

    MAX_SOURCE_BYTES = 2_000_000

    def __init__(self, project_root: Path):
        """Constrain source reads to one project root."""
        self.root = Path(project_root).resolve()

    def scan(self, scope: str, target_call: str, *, timeout_ms: int) -> CallInventory:
        """Include files with the call name and a dotted target's root name."""
        call_name = target_call.rsplit(".", 1)[-1]
        root_name = target_call.split(".", 1)[0] if "." in target_call else None
        if not call_name.isidentifier():
            raise ValueError("Call name must be an identifier")
        started = monotonic()
        target = self.root / scope
        files = (
            [Path(scope)]
            if target.is_file()
            else iter_files(self.root, path=scope)
        )
        source_paths = []
        skipped = []
        examined = 0
        prefiltered = 0
        for relative in files:
            if relative.suffix != ".py":
                continue
            if (monotonic() - started) * 1000 >= timeout_ms:
                skipped.append({"path": relative.as_posix(), "reason": "timeout_ms"})
                break
            path = (self.root / relative).resolve()
            try:
                path.relative_to(self.root)
                with path.open("rb") as handle:
                    content = handle.read(self.MAX_SOURCE_BYTES + 1)
                if len(content) > self.MAX_SOURCE_BYTES:
                    skipped.append(
                        {"path": relative.as_posix(), "reason": "max_file_bytes"}
                    )
                    continue
                tree = ast.parse(content.decode("utf-8"), filename=str(relative))
            except (OSError, ValueError, UnicodeError, SyntaxError) as exc:
                skipped.append(
                    {
                        "path": relative.as_posix(),
                        "reason": f"inventory_error:{type(exc).__name__}",
                    }
                )
                continue
            examined += 1
            named_call = any(
                self._call_name(node.func) == call_name
                for node in ast.walk(tree)
                if isinstance(node, ast.Call)
            )
            root_visible = root_name is None or any(
                isinstance(node, ast.Name) and node.id == root_name
                for node in ast.walk(tree)
            )
            if named_call and root_visible:
                source_paths.append(relative.as_posix())
            else:
                prefiltered += 1
        return CallInventory(
            tuple(sorted(source_paths)),
            examined,
            prefiltered,
            tuple(skipped),
            (monotonic() - started) * 1000,
        )

    @staticmethod
    def _call_name(function: ast.expr) -> str | None:
        """Read the lexical name KQL2 exposes on a direct Python call."""
        if isinstance(function, ast.Name):
            return function.id
        if isinstance(function, ast.Attribute):
            return function.attr
        return None
