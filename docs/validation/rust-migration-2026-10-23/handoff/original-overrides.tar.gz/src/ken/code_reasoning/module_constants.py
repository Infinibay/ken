"""Literal module bindings admitted as explicit source-local premises."""

from __future__ import annotations

import ast
from collections import Counter
from dataclasses import replace
from collections.abc import Iterable
import json
import math
import typing

from .call_arguments import SymbolicValues
from .local_imports import module_bound_names


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .path_interpreter import CallPath
    from .return_interpreter import ReturnPath


class ModuleMutationContext:
    """Shared invalidation state for a root module and its followed helpers."""

    def __init__(self):
        """Start with no named writes and no reflection-like module mutation."""
        self.names: set[str] = set()
        self.dynamic = False

    def absorb(self, names: Iterable[str], *, dynamic: bool) -> None:
        """Accumulate invalidations instead of replacing the inherited state."""
        self.names.update(names)
        self.dynamic = self.dynamic or dynamic


class ModuleConstants:
    """Identify unique literal definitions and keep their scope and evidence."""

    def __init__(
        self,
        tree: ast.Module,
        path: str,
        *,
        context: ModuleConstants | None = None,
        mutation_context: ModuleMutationContext | None = None,
    ):
        self.path = path
        if context is not None and mutation_context is not None:
            raise ValueError("Choose a constants context or mutation context")
        inherited_context: ModuleMutationContext | None = (
            context.mutation_context if context is not None else None
        )
        selected_context: ModuleMutationContext = (
            inherited_context or mutation_context or ModuleMutationContext()
        )
        self.mutation_context: ModuleMutationContext = selected_context
        active_context = selected_context
        self.used: set[str] = set()
        if context is not None:
            self.used.update(context.used)
        self.parents: dict[ast.AST, ast.AST] = {
            child: node
            for node in ast.walk(tree)
            for child in ast.iter_child_nodes(node)
        }
        counts = Counter(name for node in tree.body for name in module_bound_names(node))
        blocked: set[str] = set()
        dynamic = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Global):
                blocked.update(node.names)
            elif isinstance(node, ast.ImportFrom) and any(a.name == "*" for a in node.names):
                dynamic = True
            elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
                blocked.add(node.target.id)
            elif isinstance(node, ast.Attribute) and isinstance(node.ctx, (ast.Store, ast.Del)):
                blocked.add(node.attr)
            elif isinstance(node, (ast.MatchAs, ast.MatchStar)) and node.name:
                blocked.add(node.name)
            elif isinstance(node, ast.MatchMapping) and node.rest:
                blocked.add(node.rest)
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in {"globals", "locals", "vars", "exec", "eval"}:
                    dynamic = True
                if node.func.id in {"setattr", "delattr"}:
                    if len(node.args) > 1 and isinstance(node.args[1], ast.Constant) and isinstance(node.args[1].value, str):
                        blocked.add(node.args[1].value)
                    else:
                        dynamic = True
        active_context.absorb(blocked, dynamic=dynamic)
        dynamic = active_context.dynamic
        self.definitions: dict[str, dict[str, object]] = {}
        if dynamic:
            return
        for node in tree.body:
            value_node: ast.expr | None
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target: ast.expr = node.targets[0]
                value_node = node.value
            elif isinstance(node, ast.AnnAssign):
                target = node.target
                value_node = node.value
            else:
                continue
            if (
                value_node is None
                or not isinstance(target, ast.Name)
                or counts[target.id] != 1
                or target.id in active_context.names
            ):
                continue
            try:
                value = ast.literal_eval(value_node)
            except (ValueError, TypeError, SyntaxError):
                continue
            if type(value) not in {str, int, float, bool, type(None)}:
                continue
            if isinstance(value, float) and not math.isfinite(value):
                continue
            self.definitions[target.id] = {
                "kind": "source_local_constant_binding",
                "name": target.id,
                "value": repr(value),
                "path": path,
                "line": node.lineno,
            }

    @staticmethod
    def _local_names(scope: ast.AST) -> set[str]:
        # Overcollecting nested scopes may lose precision; it cannot make a
        # local or captured binding look like a module constant.
        names: set[str] = set()
        for node in ast.walk(scope):
            if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
                names.add(node.id)
            elif isinstance(node, ast.arg):
                names.add(node.arg)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                names.add(node.name)
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                names.update(node.names)
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                names.update(module_bound_names(node))
            elif isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and node.name:
                names.add(node.name)
            elif isinstance(node, ast.MatchMapping) and node.rest:
                names.add(node.rest)
        return names

    def available(self, function: ast.FunctionDef | ast.AsyncFunctionDef) -> dict[str, str]:
        """Exclude local and enclosing bindings before naming a module value."""
        hidden: set[str] = self._local_names(function)
        parent = self.parents.get(function)
        while parent is not None and not isinstance(parent, ast.Module):
            if isinstance(parent, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                hidden.update(self._local_names(parent))
            parent = self.parents.get(parent)
        if self.mutation_context.dynamic:
            return {}
        hidden.update(self.mutation_context.names)
        return {
            name: item["value"]
            for name, item in self.definitions.items()
            if name not in hidden and isinstance(item["value"], str)
        }

    def bind(
        self,
        function: ast.FunctionDef | ast.AsyncFunctionDef,
        values: SymbolicValues,
        *,
        expected: Iterable[str] = (),
    ) -> tuple[SymbolicValues, tuple[str, ...]]:
        """Add referenced constant values and the premises needed to use them."""
        names: set[str] = {
            node.id
            for node in ast.walk(function)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
        }
        names.update(expected)
        bindings = {
            name: value
            for name, value in self.available(function).items()
            if name in names
        }
        self.used.update(bindings)
        traces = tuple(
            "constant_binding:" + json.dumps(self.definitions[name], sort_keys=True)
            for name in sorted(bindings)
        )
        merged = dict(values.bindings)
        merged.update(bindings)
        return SymbolicValues(tuple(merged.items())), traces

    def validate(self, paths: Iterable[object]) -> list[object]:
        """Withdraw premises contradicted by writes in a followed helper."""
        checked: list[object] = []
        dynamic = self.mutation_context.dynamic
        mutated = self.mutation_context.names
        for path in paths:
            trace = getattr(path, "trace")
            unsupported = getattr(path, "unsupported")
            if (
                not isinstance(trace, tuple)
                or not all(isinstance(event, str) for event in trace)
                or not isinstance(unsupported, tuple)
                or not all(isinstance(reason, str) for reason in unsupported)
            ):
                raise TypeError("Analysis paths need string trace and unsupported tuples")
            names = {
                name
                for name in (
                    premise["name"]
                    for premise in constant_binding_assumptions([path])
                )
                if isinstance(name, str)
            }
            if names and (dynamic or names & mutated):
                typed_path = typing.cast("CallPath | ReturnPath", path)
                path = replace(
                    typed_path,
                    unsupported=typed_path.unsupported + ("module_constant_rebinding",),
                )
            checked.append(path)
        return checked


def constant_binding_assumptions(paths: Iterable[object]) -> list[dict[str, object]]:
    """Collect source premises retained through local and imported delegation."""
    events = {
        event.removeprefix("constant_binding:")
        for path in paths
        for event in getattr(path, "trace")
        if event.startswith("constant_binding:")
    }
    return [typing.cast(dict[str, object], json.loads(event)) for event in sorted(events)]
