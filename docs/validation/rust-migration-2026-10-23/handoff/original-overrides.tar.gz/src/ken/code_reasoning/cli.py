"""Public CLI for one source-scoped code contract investigation."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .code_discovery import CodeDiscovery
from .code_investigation import CodeInvestigation


def configure(parser: argparse.ArgumentParser) -> None:
    """Expose one readable contract and only its necessary controls."""
    parser.add_argument(
        "selector",
        help="Unique function name, Class.method, or path.py::function",
    )
    parser.add_argument(
        "contract",
        help="Example: os.fsync -> os.replace(_, path) or return save(user)",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--in",
        dest="search_path",
        metavar="DIR",
        help="Directory for short-name discovery (defaults to src/ when present)",
    )
    parser.add_argument("--when", action="append", default=[], metavar="EXPR=BOOL")
    parser.add_argument(
        "--effect-prior",
        action="append",
        default=[],
        metavar="NAME=P",
        help=(
            "Assumed chance of a callee effect or local public-method dispatch "
            "(e.g. Writer.publish=0.7)"
        ),
    )
    parser.add_argument("--cache-mb", type=int)
    parser.add_argument("--timeout-ms", type=int, default=15000)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--out", type=Path, help="Save the source-bound result JSON")


def configure_find(parser: argparse.ArgumentParser) -> None:
    """Expose candidate discovery as one contract and one source scope."""
    parser.add_argument(
        "contract",
        help="Example: os.replace or return save(user)",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--in",
        dest="search_path",
        metavar="PATH",
        help="Project directory or Python file (defaults to src/ when present)",
    )
    parser.add_argument("--max-candidates", type=int, default=100)
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--timeout-ms", type=int, default=15000)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--out", type=Path, help="Save the source-bound result JSON")


def dispatch(args: argparse.Namespace) -> int:
    """Check a contract and print or save its replayable result."""
    try:
        investigation = CodeInvestigation.from_selector(
            project_root=args.root,
            selector=args.selector,
            search_path=args.search_path,
        )
        result = investigation.check(
            args.contract,
            when=_pairs(args.when, boolean=True),
            effect_priors=_pairs(args.effect_prior, boolean=False),
            cache_mb=args.cache_mb,
            timeout_ms=args.timeout_ms,
            detail="full" if args.full else "answer",
        )
        _emit(result, args.out)
    except (ValueError, OSError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2
    return 0


def dispatch_find(args: argparse.Namespace) -> int:
    """Discover direct KQL2 candidates and check their source obligations."""
    try:
        result = CodeDiscovery(args.root).find(
            args.contract,
            search_path=args.search_path,
            max_candidates=args.max_candidates,
            limit=args.limit,
            timeout_ms=args.timeout_ms,
            detail="full" if args.full else "answer",
        )
        _emit(result, args.out)
    except (ValueError, OSError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2
    return 0


def _emit(result: dict, destination: Path | None) -> None:
    """Print or save one JSON receipt without changing its evidence."""
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if destination is None:
        print(payload, end="")
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(payload)
        print(f"Saved {destination}")


def _pairs(values: list[str], *, boolean: bool) -> dict[str, bool | float]:
    """Parse explicit assumptions while rejecting empty or duplicate names."""
    assumptions: dict[str, bool | float] = {}
    for raw in values:
        name, separator, value = raw.rpartition("=")
        if not separator or not name or not value or name in assumptions:
            raise ValueError("Expected distinct NAME=VALUE assumptions")
        if boolean:
            if value.lower() not in {"true", "false"}:
                raise ValueError("Branch preconditions must be true or false")
            assumptions[name] = value.lower() == "true"
        else:
            assumptions[name] = float(value)
    return assumptions
