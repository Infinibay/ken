"""Find functions worth investigating, then evaluate their code contracts."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from time import monotonic

from .call_contract import CallContract
from .call_paths import CallPaths
from .candidate_catalog import KqlCandidateCatalog
from .caller_expansion import DiscoveryCandidate, LocalCallerExpansion
from .imported_callers import ImportedCallerExpansion
from .return_contract import ReturnContract
from .return_paths import ReturnPaths


class CodeDiscovery:
    """Turn one KQL2 candidate search into source-backed code conclusions."""

    def __init__(self, project_root: Path):
        """Bind candidate discovery and path checks to one project."""
        self.catalog = KqlCandidateCatalog(project_root)
        self.callers = LocalCallerExpansion(project_root)
        self.imported_callers = ImportedCallerExpansion(project_root)

    def find(
        self,
        contract: str | CallContract | ReturnContract,
        *,
        search_path: str | None = None,
        max_candidates: int = 100,
        limit: int = 10,
        timeout_ms: int = 15000,
        detail: str = "answer",
    ) -> dict:
        """Rank direct and one-hop caller candidates by source obligations."""
        if not isinstance(max_candidates, int) or not 1 <= max_candidates <= 1000:
            raise ValueError("max_candidates must be between 1 and 1000")
        if not isinstance(limit, int) or limit < 1:
            raise ValueError("limit must be a positive integer")
        if not isinstance(timeout_ms, int) or timeout_ms < 1:
            raise ValueError("timeout_ms must be a positive integer")
        if detail not in {"answer", "full"}:
            raise ValueError("detail must be 'answer' or 'full'")
        if isinstance(contract, str):
            specification = (
                ReturnContract.parse(contract)
                if contract.strip().startswith("return ")
                else CallContract.parse(contract)
            )
        elif isinstance(contract, (CallContract, ReturnContract)):
            specification = contract
        else:
            raise TypeError("Expected a call or return contract")
        started = monotonic()
        batch = self.catalog.search(
            specification,
            search_path=search_path,
            max_candidates=max_candidates,
            timeout_ms=timeout_ms,
        )
        expansion = self.callers.expand(batch.candidates, limit=max_candidates)
        import_expansion = self.imported_callers.expand(
            batch.candidates,
            scope=batch.scope,
            limit=max_candidates,
            timeout_ms=max(1, int(timeout_ms - (monotonic() - started) * 1000)),
        )
        direct = tuple(DiscoveryCandidate.direct(seed) for seed in batch.candidates)
        direct_keys = {(item.source.path, item.source.symbol) for item in direct}
        local_expanded = tuple(
            item
            for item in expansion.candidates
            if (item.source.path, item.source.symbol) not in direct_keys
        )
        seen = direct_keys | {
            (item.source.path, item.source.symbol) for item in local_expanded
        }
        imported_expanded = tuple(
            item
            for item in import_expansion.candidates
            if (item.source.path, item.source.symbol) not in seen
        )
        expanded = (*local_expanded, *imported_expanded)
        matches = []
        unanalyzed = list(batch.omitted)
        for candidate in (*direct, *expanded):
            source = candidate.source
            try:
                if isinstance(specification, ReturnContract):
                    analysis = ReturnPaths(source, specification).analyze()
                    if detail != "full":
                        analysis = self._compact(ReturnPaths.summary(analysis))
                else:
                    target, receiver = specification.for_source(source)
                    analysis = CallPaths(
                        source,
                        target,
                        receiver=receiver,
                        arguments=specification.arguments,
                        after=specification.after,
                    ).analyze()
                    if detail != "full":
                        analysis = self._compact(CallPaths.summary(analysis))
            except (ValueError, OSError, SyntaxError) as exc:
                source.assert_current()
                unanalyzed.append(
                    {
                        "path": source.path,
                        "symbol": source.symbol,
                        "line": candidate.line,
                        "reason": str(exc),
                    }
                )
                continue
            match = {
                "selector": f"{source.path}::{source.symbol}",
                "source": source.data(),
                "candidate_line": candidate.line,
                "candidate_kind": candidate.kind,
                "analysis": analysis,
            }
            if candidate.call_sites:
                match["direct_call_locations"] = [
                    {"path": source.path, "line": line}
                    for line in candidate.call_sites
                ]
            if candidate.delegate_sites:
                match["delegate_call_locations"] = [
                    {"path": source.path, "line": line}
                    for line in candidate.delegate_sites
                ]
                match["via"] = list(candidate.via)
            matches.append(match)
        matches.sort(key=self._rank)
        counts = Counter(item["analysis"]["status"] for item in matches)
        result = {
            "schema": "ken-code-discovery/1",
            "contract": self._display(specification),
            "candidate_source": (
                "kql2_seeded_imported_callers"
                if imported_expanded
                else "kql2_seeded_local_callers"
                if local_expanded
                else "kql2_direct_relation"
            ),
            "candidate_relation": (
                (
                    "same_callable_return_flow"
                    if isinstance(specification, ReturnContract)
                    else "same_callable_call"
                )
                + ("+local_caller" if local_expanded else "")
                + ("+imported_caller" if imported_expanded else "")
            ),
            "scope": batch.scope,
            "coverage": batch.coverage,
            "expansion_coverage": expansion.coverage,
            "import_expansion_coverage": import_expansion.coverage,
            "contract_search_exhaustive": False,
            "direct_candidates_found": len(batch.candidates),
            "expanded_candidates_found": len(expanded),
            "imported_candidates_found": len(imported_expanded),
            "candidates_found": len(direct) + len(expanded),
            "analyzed": len(matches),
            "status_counts": dict(sorted(counts.items())),
            "matches": matches[:limit],
            "more_matches": max(0, len(matches) - limit),
            "unanalyzed": unanalyzed,
            "limits": [
                "Caller expansion follows one same-file or explicit-import hop from direct KQL2 seeds.",
                "An imported caller needs its direct seed inside the requested search scope.",
                "Deeper, dynamic-import, and indirect wrappers may remain undiscovered.",
                "A candidate match does not prove the full contract.",
                "Path conclusions cover modeled normal completion only.",
            ],
        }
        if detail == "full":
            result["query_source"] = batch.query
        return result

    @staticmethod
    def _rank(item: dict) -> tuple[int, str]:
        """Put witnessed obligations before unresolved and missing paths."""
        status = item["analysis"]["status"]
        order = (
            0 if status.startswith("all_paths_") else 1 if status == "unknown" else 2
        )
        return order, item["selector"]

    @staticmethod
    def _display(contract: CallContract | ReturnContract) -> str:
        """Preserve a compact, canonical account of the requested contract."""
        if isinstance(contract, ReturnContract):
            return "return " + CodeDiscovery._display(contract.call)
        target = contract.target
        if contract.arguments is not None:
            target += "(" + ", ".join(contract.arguments) + ")"
        return f"{contract.after} -> {target}" if contract.after else target

    @staticmethod
    def _compact(analysis: dict) -> dict:
        """Keep the answer, witness sites, and the first actionable blocker."""
        compact = {
            "status": analysis["status"],
            "path_count": analysis["path_count"],
            "analysis_complete": analysis["resolved_evidence"]["analysis_complete"],
        }
        for key in (
            "matched_locations",
            "conditional_matches",
            "ordered_locations",
            "conditional_ordered_locations",
            "out_of_order_locations",
            "producer_locations",
            "conditional_producers",
            "returned_locations",
            "conditional_returned_locations",
            "probability_all_paths_called",
            "probability_all_paths_return_value",
            "probability_bounds",
            "counterexample",
            "binding_assumptions",
            "method_candidates",
        ):
            if key in analysis and analysis[key] not in (None, [], {}):
                compact[key] = analysis[key]
        if analysis["status"] == "unknown":
            if analysis.get("unsupported"):
                compact["blockers"] = analysis["unsupported"][:5]
            elif analysis.get("next_checks"):
                compact["next_checks"] = analysis["next_checks"][:2]
            elif analysis.get("uncertain_calls"):
                compact["uncertain_calls"] = analysis["uncertain_calls"][:3]
        return compact
