"""Readable source contract for forwarding a call's produced value."""

from __future__ import annotations

from dataclasses import dataclass

from .call_contract import CallContract
from .code_source import PythonSymbol


@dataclass(frozen=True)
class ReturnContract:
    """Require every modeled normal return to forward one target call value."""

    call: CallContract

    @classmethod
    def parse(cls, text: str) -> ReturnContract:
        """Read ``return save(user)`` as value provenance, not just a call."""
        if not isinstance(text, str) or not text.strip().startswith("return "):
            raise ValueError("Expected a return contract such as return save(user)")
        call = CallContract.parse(text.strip().removeprefix("return ").strip())
        if call.after is not None:
            raise ValueError("A return contract cannot contain call ordering")
        return cls(call)

    def for_source(self, source: PythonSymbol) -> tuple[str, str | None]:
        """Bind a member target against the selected function parameters."""
        return self.call.for_source(source)
