"""Bindings and exits that remain relevant when a statement region is opaque."""

from __future__ import annotations

import ast

from .local_imports import module_bound_names


class StatementRegion(ast.NodeVisitor):
    """Collect possible writes and function exits without entering nested scopes."""

    def __init__(self, nodes):
        self.targets = []
        self.may_return = False
        self.may_break = False
        for node in nodes:
            self.visit(node)

    def visit_Name(self, node):
        if isinstance(node.ctx, (ast.Store, ast.Del)):
            self.targets.append(node)

    def visit_Attribute(self, node):
        if isinstance(node.ctx, (ast.Store, ast.Del)):
            self.targets.append(node)
        self.generic_visit(node)

    visit_Subscript = visit_Attribute

    def visit_FunctionDef(self, node):
        self.targets.append(ast.Name(id=node.name, ctx=ast.Store()))
        # Defaults/decorators are evaluated when the definition executes.
        for expression in [*node.args.defaults, *node.args.kw_defaults, *node.decorator_list]:
            if expression is not None:
                self.visit(expression)
        # Older Python annotation modes can evaluate these expressions too;
        # forgetting a possible binding is safe when evaluation is deferred.
        arguments = [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]
        for expression in [node.returns, *(argument.annotation for argument in arguments)]:
            if expression is not None:
                self.visit(expression)
        # A nested callable can rebind an enclosing variable when invoked in
        # this opaque region. Its returns still belong to its own scope.
        for child in ast.walk(node):
            if isinstance(child, (ast.Nonlocal, ast.Global)):
                self.targets.extend(ast.Name(id=name, ctx=ast.Store()) for name in child.names)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.targets.append(ast.Name(id=node.name, ctx=ast.Store()))
        # Class bodies execute now, unlike method bodies. Forgetting class-local
        # names too is conservative and covers explicit nonlocal assignments.
        self.generic_visit(node)

    def visit_Lambda(self, node):
        """A lambda's body has its own scope and cannot declare nonlocal writes."""
        for expression in [*node.args.defaults, *node.args.kw_defaults]:
            if expression is not None:
                self.visit(expression)

    def visit_Import(self, node):
        self.targets.extend(ast.Name(id=name, ctx=ast.Store()) for name in module_bound_names(node))

    visit_ImportFrom = visit_Import

    def visit_ExceptHandler(self, node):
        if node.name:
            self.targets.append(ast.Name(id=node.name, ctx=ast.Store()))
        self.generic_visit(node)

    def visit_Return(self, node):
        self.may_return = True
        self.generic_visit(node)

    def visit_Break(self, node):
        # A break in a nested loop can add an unnecessary alternative; it can
        # never justify dropping the outer loop's possible else-skipping path.
        self.may_break = True
