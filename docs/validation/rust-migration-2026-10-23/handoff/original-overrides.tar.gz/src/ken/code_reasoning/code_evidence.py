"""Source-scoped KQL2 observations for explicit code-claim models.

A match is a structural witness, not a behavioral proof. Probability models
belong to the claim evaluator, not to the observation or its KQL2 query.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path


@dataclass(frozen=True)
class CodeObservation:
    """Retain a KQL2 witness, uncertainty, and source provenance for a claim."""

    hypothesis: str
    state: str
    query: str
    path: str
    backend: str
    expected_symbol: str | None
    snapshot: object
    manifest_hash: str | None
    source_hash: str | None
    coverage: dict
    witnesses: tuple
    reason: str | None = None

    def __post_init__(self):
        """Reject unknown evidence states before a model uses this witness."""
        if self.state not in {"present", "absent", "unknown"}:
            raise ValueError("Unknown code observation state")

    def data(self):
        """Return source provenance without mixing in model assumptions."""
        return {
            "hypothesis": self.hypothesis,
            "state": self.state,
            "query_source": self.query,
            "query_sha256": sha256(self.query.encode()).hexdigest(),
            "path": self.path,
            "backend": self.backend,
            "expected_symbol": self.expected_symbol,
            "snapshot": self.snapshot,
            "manifest_hash": self.manifest_hash,
            "source_hash": self.source_hash,
            "coverage": dict(self.coverage),
            "witnesses": list(self.witnesses),
            "reason": self.reason,
        }

    def summary(self):
        """Show owner locations and coverage without exposing raw KQL rows."""
        locations = [
            {
                "path": cell.get("path"),
                "line": cell.get("line"),
                "kind": cell.get("kind"),
                "name": cell.get("name"),
            }
            for row in self.witnesses
            for cell in row
            if isinstance(cell, dict)
        ]
        return {
            "state": self.state,
            "reason": self.reason,
            "owner_locations": locations,
            "coverage_complete": (
                self.coverage.get("complete") is True
                and self.coverage.get("source_complete") is True
                and not self.coverage.get("unknown_candidates")
                and not self.coverage.get("results_truncated")
                and not self.coverage.get("skipped")
            ),
            "backend": self.backend,
        }


@dataclass(frozen=True)
class KqlProbe:
    """Run one KQL2 source pattern and retain positive/negative coverage."""

    query: str
    path: str
    hypothesis: str
    backend: str = "indexed"
    expected_symbol: str | None = None

    def __post_init__(self):
        """Require a source-scoped KQL2 query and claim identity."""
        if not self.query.strip() or not self.hypothesis or not self.path:
            raise ValueError("Probe requires a query, source path and hypothesis")
        if self.expected_symbol is not None and not self.expected_symbol:
            raise ValueError("Expected symbol cannot be empty")

    def run(self, root, *, cache_mb=None, timeout_ms=None):
        """Execute against live code; incomplete absence remains unknown."""
        try:
            from ken.kql2.service import search
        except ModuleNotFoundError as exc:
            if exc.name not in {"ken", "ken.kql2", "ken.kql2.service"}:
                raise
            return CodeObservation(
                hypothesis=self.hypothesis,
                state="unknown",
                query=self.query,
                path=self.path,
                backend=self.backend,
                expected_symbol=self.expected_symbol,
                snapshot=None,
                manifest_hash=None,
                source_hash=None,
                coverage={"complete": False, "source_complete": False},
                witnesses=(),
                reason="kql2_unavailable",
            )

        result = search(
            Path(root),
            self.query,
            path=self.path,
            backend=self.backend,
            cache_mb=cache_mb,
            timeout_ms=timeout_ms,
        )
        analysis = result.get("analysis") or {}
        manifest = analysis.get("manifest")
        source_hash = (
            next(
                (
                    item[1]
                    for item in manifest
                    if isinstance(item, (list, tuple))
                    and len(item) >= 2
                    and item[0] == self.path
                ),
                None,
            )
            if isinstance(manifest, list)
            else None
        )
        rows = result.get("rows") or []
        owners = [
            cell
            for row in rows
            for cell in row
            if isinstance(cell, dict) and cell.get("kind") == "CALLABLE"
        ]
        foreign_owner = any(
            owner.get("path") not in {None, self.path} for owner in owners
        )
        if self.expected_symbol is not None:
            rows = [
                row
                for row in rows
                if any(
                    isinstance(cell, dict)
                    and cell.get("kind") == "CALLABLE"
                    and cell.get("path") in {None, self.path}
                    and self.expected_symbol in {cell.get("name"), cell.get("local_id")}
                    for cell in row
                )
            ]
        complete = (
            result.get("complete") is True
            and result.get("coverage_complete") is True
            and manifest is not None
            and not result.get("results_truncated")
            and not result.get("unknown_candidates")
            and not analysis.get("skipped")
        )
        owner_missing = (
            self.expected_symbol is not None and bool(result.get("rows")) and not owners
        )
        target_ids = {
            cell.get("local_id")
            for row in rows
            for cell in row
            if isinstance(cell, dict) and cell.get("kind") == "CALLABLE"
        }
        ambiguous_target = self.expected_symbol is not None and (
            None in target_ids or len(target_ids) > 1
        )
        state = (
            "unknown"
            if ambiguous_target or foreign_owner or source_hash is None
            else "present"
            if rows
            else "absent"
            if complete and not owner_missing
            else "unknown"
        )
        if state != "unknown":
            reason = None
        elif ambiguous_target:
            reason = "ambiguous_target"
        elif foreign_owner:
            reason = "out_of_scope_owner"
        elif owner_missing:
            reason = "target_not_projected"
        elif not complete:
            reason = result.get("reason") or "incomplete_coverage"
        else:
            reason = "source_not_in_manifest"
        return CodeObservation(
            hypothesis=self.hypothesis,
            state=state,
            query=self.query,
            path=self.path,
            backend=self.backend,
            expected_symbol=self.expected_symbol,
            snapshot=analysis.get("snapshot"),
            manifest_hash=(
                sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
                if manifest is not None
                else None
            ),
            source_hash=source_hash,
            coverage={
                "complete": result.get("complete") is True,
                "source_complete": result.get("coverage_complete") is True,
                "unknown_candidates": result.get("unknown_candidates", 0),
                "results_truncated": bool(result.get("results_truncated")),
                "skipped": analysis.get("skipped") or [],
            },
            witnesses=tuple(rows[:3]),
            reason=reason,
        )
