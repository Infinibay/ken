"""Correlate KQL2 value-flow candidates with all-path return reasoning."""

from __future__ import annotations

from dataclasses import replace
from hashlib import sha256

from .candidate_query import CandidateQuery
from .code_evidence import KqlProbe
from .code_source import PythonSymbol
from .return_contract import ReturnContract
from .return_paths import ReturnPaths


class ReturnInvestigation:
    """Investigate whether one function forwards a target call's value."""

    def __init__(self, source: PythonSymbol):
        """Bind KQL2 and path evidence to the same versioned source."""
        self.source = source

    def check(
        self,
        contract: ReturnContract,
        *,
        when=None,
        effect_priors=None,
        cache_mb=None,
        timeout_ms=None,
        detail="answer",
        hypothesis=None,
    ):
        """Separate a some-return KQL2 witness from the all-path conclusion."""
        if detail not in {"answer", "full"}:
            raise ValueError("detail must be 'answer' or 'full'")
        self.source.assert_current()
        local_name = self.source.symbol.rsplit(".", 1)[-1]
        query = CandidateQuery.return_value(contract.call.target, symbol=local_name)
        question_id = (
            hypothesis
            or "return-investigation:"
            + sha256(
                repr(
                    (
                        self.source.path,
                        self.source.symbol,
                        self.source.source_sha256,
                        contract.call.target,
                        contract.call.arguments,
                        tuple(sorted((when or {}).items())),
                    )
                ).encode()
            ).hexdigest()[:24]
        )
        observation = KqlProbe(
            query,
            self.source.path,
            question_id,
            expected_symbol=local_name,
        ).run(self.source.project_root, cache_mb=cache_mb, timeout_ms=timeout_ms)
        if not self.source.basename_is_unique():
            observation = replace(
                observation, state="unknown", reason="ambiguous_target"
            )
        self.source.validate_observation(observation)
        analysis = ReturnPaths(self.source, contract, when=when).analyze(
            effect_priors=effect_priors
        )
        self.source.assert_current()
        candidate = observation.summary()
        candidate["relation"] = "same_callable_named_call_return_flow_only"
        candidate["absence_exhaustive"] = False
        result = {
            "schema": "ken-code-return-investigation/1",
            "source": self.source.data(),
            "candidate_return": candidate,
            "return_analysis": (
                analysis if detail == "full" else ReturnPaths.summary(analysis)
            ),
        }
        if detail == "full":
            result["candidate_return"] = observation.data() | {
                "relation": "same_callable_named_call_return_flow_only",
                "absence_exhaustive": False,
            }
        return result
