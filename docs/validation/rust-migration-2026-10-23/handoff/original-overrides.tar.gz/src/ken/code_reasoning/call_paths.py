"""Public all-path call contract over versioned Python source."""

from __future__ import annotations

import ast
import math

from .call_arguments import CallArguments
from .call_order import CallOrder
from .call_worlds import CallWorldModel
from .code_source import PythonSymbol
from .effect_site import EffectSite
from .guarded_evidence import GuardedEvidence
from .local_imports import LocalImportResolver
from .local_methods import local_method_candidates, private_binding_assumptions
from .module_constants import constant_binding_assumptions
from .next_evidence import NextEvidence
from .path_interpreter import PythonCallInterpreter


class CallPaths:
    """Bind a code question to a path interpreter and explicit code worlds."""

    def __init__(
        self,
        source: PythonSymbol,
        target: str,
        *,
        receiver: str | None = None,
        arguments=None,
        after: str | None = None,
        when=None,
        max_paths=64,
    ):
        """Validate a target call, optional receiver, and branch assumptions."""
        if not all(part.isidentifier() for part in target.split(".")):
            raise ValueError("Call target must be an identifier or dotted name")
        if receiver is not None and not all(
            part.isidentifier() for part in receiver.split(".")
        ):
            raise ValueError("Call receiver must be an identifier or member path")
        if receiver is not None and "." in target:
            raise ValueError("Receiver-specific targets use an undotted call name")
        if after is not None and (
            not all(part.isidentifier() for part in after.split(".")) or after == target
        ):
            raise ValueError("Call predecessor must be a different call name")
        if any(not isinstance(value, bool) for value in (when or {}).values()):
            raise ValueError("Branch preconditions must be booleans")
        if not isinstance(max_paths, int) or max_paths < 1:
            raise ValueError("max_paths must be a positive integer")
        self.source = source
        self.target = target
        self.receiver = receiver
        self.arguments = CallArguments(arguments) if arguments is not None else None
        self.after = after
        self.when = dict(when or {})
        self.max_paths = max_paths

    def analyze(self, *, effect_priors=None):
        """Report source-backed paths and optional all-path probability."""
        self.source.assert_current()
        tree = ast.parse((self.source.project_root / self.source.path).read_text())
        imports = LocalImportResolver(self.source.project_root)
        interpreter = PythonCallInterpreter(
            tree,
            self.target,
            self.receiver,
            self.when,
            self.max_paths,
            module_path=self.source.path,
            import_resolver=imports,
            arguments=self.arguments,
            after=self.after,
        )
        paths = interpreter.paths_for(self.source.symbol)
        if self.after is not None:
            paths = CallOrder(self.after, self.target).apply(paths)
        self.source.assert_current()
        imports.assert_current()
        worlds = CallWorldModel(paths, effect_priors)
        bounds, assumptions = worlds.probability_bounds()
        probability = (
            bounds[0]
            if bounds is not None
            and math.isclose(bounds[0], bounds[1], rel_tol=0.0, abs_tol=1e-12)
            else None
        )
        return {
            "schema": "ken-code-paths/1",
            "status": worlds.status(),
            "resolved_evidence": self.resolved_evidence(paths),
            "scope": "normal_completion_only",
            "source_path": self.source.path,
            "target": self.target,
            "receiver": self.receiver,
            "arguments": (
                list(self.arguments.expected) if self.arguments is not None else None
            ),
            "after": self.after,
            "when": dict(self.when),
            "dependencies": imports.dependencies(self.source.path),
            "paths": [
                {
                    "called": path.called,
                    "possible_callers": sorted(path.possible),
                    "possible_ordered_callers": sorted(path.upper_possible),
                    "possible_predecessors": sorted(path.possible_predecessors),
                    "guards": [
                        {"effect": effect, "selected": selected}
                        for effect, selected in path.guards
                    ],
                    "trace": list(path.trace),
                    "unsupported": list(path.unsupported),
                }
                for path in paths
            ],
            "unresolved_effects": list(worlds.effects),
            "binding_assumptions": private_binding_assumptions(paths) + constant_binding_assumptions(paths),
            "method_candidates": local_method_candidates(paths),
            "probability_all_paths_called": probability,
            "probability_bounds": (
                {"lower": bounds[0], "upper": bounds[1]} if bounds is not None else None
            ),
            "effect_priors": assumptions,
            "probability_model": (
                "independent_dispatch_and_call_site_assumptions"
                if any(key.startswith("dispatch:") for key in assumptions)
                else "independent_call_site_effects"
                if assumptions
                else None
            ),
            "unassumed_effects": [
                effect for effect in worlds.effects if effect not in assumptions
            ],
            "next_checks": NextEvidence(paths, worlds, self.source.path).suggest(),
            "limits": [
                "Only normal completion paths are modeled; exceptional exits are excluded.",
                "A call is structural evidence, not proof of its runtime effect.",
                "Literal module bindings assume no external mutation or reflection beyond followed source; visible writes invalidate them.",
                "Unknown-call priors are investigator assumptions, not learned probabilities.",
                "Declared priors are independent across distinct call and dispatch sites.",
                "Public-method body evidence is conditional on selecting that local implementation.",
                "A dispatch choice is stable per source call site in this model; runtime rebinding between invocations is outside scope.",
            ],
        }

    @staticmethod
    def summary(result):
        """Keep the decisive evidence while hiding routine full path traces."""
        target = result["target"]
        paths = result["paths"]
        locations = CallPaths._trace_locations(
            paths, f"call:{target}:", guarded=False
        )
        conditional = CallPaths._conditional_locations(paths, f"call:{target}:")
        summary = {
            "schema": result["schema"],
            "status": result["status"],
            "resolved_evidence": result["resolved_evidence"],
            "scope": result["scope"],
            "target": target,
            "receiver": result["receiver"],
            "arguments": result["arguments"],
            "after": result["after"],
            "when": result["when"],
            "dependencies": result["dependencies"],
            "path_count": len(paths),
            "matched_lines": [
                line for path, line in locations if path == result["source_path"]
            ],
            "matched_locations": [
                {"path": path, "line": line} for path, line in locations
            ],
            "conditional_matches": conditional,
            "probability_all_paths_called": result["probability_all_paths_called"],
            "effect_priors": result["effect_priors"],
            "probability_model": result["probability_model"],
        }
        if result["binding_assumptions"]:
            summary["binding_assumptions"] = result["binding_assumptions"]
        if result["method_candidates"]:
            summary["method_candidates"] = result["method_candidates"]
        if (
            result["probability_all_paths_called"] is None
            and result["probability_bounds"] is not None
        ):
            summary["probability_bounds"] = result["probability_bounds"]
        if result["arguments"] is not None:
            summary["argument_mismatches"] = [
                {"path": path, "line": line}
                for path, line in CallPaths._trace_locations(paths, "args_mismatch:")
            ]
        if result["after"] is not None:
            summary["ordered_locations"] = [
                {"path": path, "line": line}
                for path, line in CallPaths._trace_locations(
                    paths, "ordered:", guarded=False
                )
            ]
            summary["conditional_ordered_locations"] = (
                CallPaths._conditional_locations(paths, "ordered:")
            )
            summary["out_of_order_locations"] = [
                {"path": path, "line": line}
                for path, line in CallPaths._trace_locations(paths, "out_of_order:")
            ]
        if result["status"] == "missing_path":
            summary["counterexample"] = next(
                path["trace"]
                for path in paths
                if not path["called"] and not path["possible_callers"]
            )
        if result["status"] == "unknown":
            unsupported = sorted(
                {item for path in paths for item in path["unsupported"]}
            )
            summary["unsupported"] = unsupported[:5]
            if len(unsupported) > 5:
                summary["more_unsupported"] = len(unsupported) - 5
            if not unsupported:
                effects = result["unresolved_effects"]
                summary["unresolved_effects"] = effects[:5]
                if len(effects) > 5:
                    summary["more_unresolved_effects"] = len(effects) - 5
                uncertain = CallPaths._uncertain_calls(result)
                priority_lines = {
                    (item["path"], item["call_line"])
                    for item in result["method_candidates"]
                }
                uncertain.sort(
                    key=lambda item: (
                        (item["path"], item["line"]) not in priority_lines,
                        item["path"],
                        item["line"],
                    )
                )
                summary["uncertain_calls"] = uncertain[:4]
                if len(uncertain) > 4:
                    summary["more_uncertain_calls"] = len(uncertain) - 4
                if result["next_checks"]:
                    summary["next_checks"] = result["next_checks"]
                if result["after"] is not None:
                    possible_predecessors = sorted(
                        {
                            effect
                            for path in paths
                            for effect in path["possible_predecessors"]
                        }
                    )
                    internal_order = sorted(
                        {
                            effect
                            for path in paths
                            for effect in path["possible_ordered_callers"]
                            if effect not in path["possible_callers"]
                        }
                    )
                    if possible_predecessors or internal_order:
                        summary["order_uncertainty"] = {
                            "possible_predecessors": possible_predecessors,
                            "calls_requiring_internal_order": internal_order,
                        }
                if result["effect_priors"] and result["unassumed_effects"]:
                    summary["unassumed_effects"] = result["unassumed_effects"]
        return summary

    @staticmethod
    def resolved_evidence(paths):
        """Count path witnesses without treating unresolved effects as proof."""
        witnessed = sum(path.called for path in paths)
        complete = bool(paths) and not any(path.unsupported for path in paths)
        if witnessed < len(paths):
            status = "some_paths_unwitnessed"
        elif complete:
            status = "all_paths_witnessed"
        else:
            status = "incomplete"
        return {
            "status": status,
            "analysis_complete": complete,
            "witnessed_paths": witnessed,
            "unwitnessed_paths": len(paths) - witnessed,
        }

    @staticmethod
    def _trace_locations(paths, prefix, *, guarded=None):
        """Extract evidence locations, optionally excluding conditional paths."""
        return sorted(
            {
                (path, line)
                for path, line, conditions in CallPaths._trace_evidence(
                    paths, prefix
                ).records()
                if guarded is None or bool(conditions) == guarded
            }
        )

    @staticmethod
    def _conditional_locations(paths, prefix):
        """Name each witness together with the dispatch choices it requires."""
        return CallPaths._trace_evidence(paths, prefix).conditional()

    @staticmethod
    def _trace_evidence(paths, prefix):
        """Attach each call witness to choices already made at that trace step."""
        evidence = GuardedEvidence()
        for path in paths:
            conditions = []
            for event in path["trace"]:
                if event.startswith("dispatch_local:"):
                    effect = event.removeprefix("dispatch_local:").rsplit(":", 1)[0]
                    conditions.append((effect, True))
                elif event.startswith("dispatch_other:"):
                    effect = event.removeprefix("dispatch_other:").rsplit(":", 1)[0]
                    conditions.append((effect, False))
                if event.startswith(prefix):
                    location = event.removeprefix(prefix)
                    source, line = location.rsplit(":", 1)
                    evidence.add(source, int(line), conditions)
        return evidence

    @staticmethod
    def _uncertain_calls(result):
        """Locate only unresolved effects that can change this obligation."""
        relevant = set(result["unresolved_effects"]) | {
            effect
            for path in result["paths"]
            for effect in path["possible_predecessors"]
        }
        locations = set()
        for path in result["paths"]:
            for event in path["trace"]:
                if not event.startswith("unknown:"):
                    continue
                effect, line = event.removeprefix("unknown:").rsplit(":", 1)
                if effect not in relevant:
                    continue
                location = EffectSite.source_path(effect, result["source_path"])
                locations.add((location, int(line), effect))
        return [
            {"path": path, "line": line, "effect": effect}
            for path, line, effect in sorted(locations)
        ]
