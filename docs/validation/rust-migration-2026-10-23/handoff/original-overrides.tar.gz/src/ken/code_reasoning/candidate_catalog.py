"""Bind KQL2 direct candidates to exact, current Python source symbols."""

from __future__ import annotations

import ast
from collections import defaultdict
from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path

from .call_inventory import PythonCallInventory
from .candidate_query import CandidateQuery
from .call_contract import CallContract
from .code_source import PythonSymbol, matching_functions
from .return_contract import ReturnContract


@dataclass(frozen=True)
class SourceCandidate:
    """One KQL2 owner located in source bytes verified by the manifest."""

    source: PythonSymbol
    line: int
    call_sites: tuple[int, ...] = ()


@dataclass(frozen=True)
class CandidateBatch:
    """Direct candidates and the limits of the search that produced them."""

    candidates: tuple[SourceCandidate, ...]
    coverage: dict
    omitted: tuple[dict, ...]
    query: str
    scope: str


class KqlCandidateCatalog:
    """Find direct code relationships and resolve their Python owners safely."""

    def __init__(self, project_root: Path):
        """Keep all candidate locations inside one project boundary."""
        self.root = Path(project_root).resolve()

    def search(
        self,
        contract: CallContract | ReturnContract,
        *,
        search_path: str | None,
        max_candidates: int,
        timeout_ms: int,
    ) -> CandidateBatch:
        """Run one KQL2 query, then bind every returned owner to current code."""
        from ken.kql2.service import search

        scope = self._scope(search_path)
        query = CandidateQuery.for_contract(contract, include_call_site=True)
        target = (
            contract.call.target
            if isinstance(contract, ReturnContract)
            else contract.target
        )
        inventory = PythonCallInventory(self.root).scan(
            scope, target, timeout_ms=timeout_ms
        )
        if inventory.elapsed_ms >= timeout_ms:
            return CandidateBatch(
                (),
                {
                    "complete": False,
                    "source_complete": False,
                    "unknown_candidates": 0,
                    "results_truncated": False,
                    "skipped": list(inventory.skipped),
                    "reason": "timeout_ms",
                    "snapshot": None,
                    "query_sha256": sha256(query.encode()).hexdigest(),
                    "examined_files": inventory.examined_files,
                    "prefiltered_files": inventory.prefiltered_files,
                    "selected_files": len(inventory.source_paths),
                    "prefilter": "python_ast_call_name_and_dotted_root",
                },
                (),
                query,
                scope,
            )
        result = search(
            self.root,
            query,
            path=scope,
            backend="indexed",
            max_rows=max_candidates,
            timeout_ms=max(1, int(timeout_ms - inventory.elapsed_ms)),
            source_paths=list(inventory.source_paths),
        )
        analysis = result.get("analysis") or {}
        manifest = analysis.get("manifest")
        hashes = {
            item[0]: item[1]
            for item in manifest or []
            if isinstance(item, (tuple, list)) and len(item) >= 2
        }
        candidates_by_key = {}
        sites_by_key = defaultdict(set)
        omitted = []
        for row in result.get("rows") or []:
            owner = next(
                (
                    cell
                    for cell in row
                    if isinstance(cell, dict) and cell.get("kind") == "CALLABLE"
                ),
                None,
            )
            if owner is None:
                omitted.append({"reason": "owner_not_projected"})
                continue
            key = (owner.get("path"), owner.get("line"), owner.get("name"))
            if key not in candidates_by_key:
                candidate = self._bind(owner, hashes, scope)
                candidates_by_key[key] = candidate
                if not isinstance(candidate, SourceCandidate):
                    omitted.append(candidate)
            if isinstance(candidates_by_key[key], SourceCandidate):
                for cell in row:
                    if (
                        isinstance(cell, dict)
                        and cell.get("kind") == "CALL"
                        and cell.get("path") == owner.get("path")
                        and isinstance(cell.get("line"), int)
                    ):
                        sites_by_key[key].add(cell["line"])
        candidates = [
            replace(candidate, call_sites=tuple(sorted(sites_by_key[key])))
            for key, candidate in candidates_by_key.items()
            if isinstance(candidate, SourceCandidate)
        ]
        complete = (
            result.get("complete") is True
            and result.get("coverage_complete") is True
            and not result.get("results_truncated")
            and not result.get("unknown_candidates")
            and not analysis.get("skipped")
            and inventory.complete
            and manifest is not None
            and not omitted
        )
        return CandidateBatch(
            tuple(candidates),
            {
                "complete": complete,
                "source_complete": (
                    result.get("coverage_complete") is True and inventory.complete
                ),
                "unknown_candidates": result.get("unknown_candidates", 0),
                "results_truncated": bool(
                    result.get("results_truncated")
                    or result.get("reason") == "max_rows"
                ),
                "skipped": [*inventory.skipped, *(analysis.get("skipped") or [])],
                "reason": result.get("reason"),
                "snapshot": analysis.get("snapshot"),
                "query_sha256": sha256(query.encode()).hexdigest(),
                "examined_files": inventory.examined_files,
                "prefiltered_files": inventory.prefiltered_files,
                "selected_files": len(inventory.source_paths),
                "prefilter": "python_ast_call_name_and_dotted_root",
            },
            tuple(omitted),
            query,
            scope,
        )

    def _scope(self, search_path: str | None) -> str:
        """Default to src/ and reject missing or outside-project scopes."""
        default = "src" if (self.root / "src").is_dir() else "."
        scope = (self.root / (search_path or default)).resolve()
        try:
            relative = scope.relative_to(self.root).as_posix()
        except ValueError as exc:
            raise ValueError("Search path must stay inside the project") from exc
        if not scope.is_dir() and not (scope.is_file() and scope.suffix == ".py"):
            raise ValueError("Search path must be a project directory or Python file")
        return relative

    def _bind(self, owner: dict, hashes: dict, scope: str) -> SourceCandidate | dict:
        """Verify manifest bytes and locate the exact lexical function."""
        path, name, line = owner.get("path"), owner.get("name"), owner.get("line")
        label = {"path": path, "line": line, "name": name}
        if (
            owner.get("language") != "python"
            or not isinstance(path, str)
            or not path.endswith(".py")
            or not isinstance(name, str)
            or not name.isidentifier()
            or not isinstance(line, int)
        ):
            return label | {"reason": "not_a_python_function"}
        source_path = (self.root / path).resolve()
        scoped_path = (self.root / scope).resolve()
        try:
            source_path.relative_to(self.root)
            if scoped_path.is_dir():
                source_path.relative_to(scoped_path)
            elif source_path != scoped_path:
                raise ValueError("out of scope")
        except ValueError:
            return label | {"reason": "out_of_scope_owner"}
        if path not in hashes:
            return label | {"reason": "source_not_in_manifest"}
        try:
            content = source_path.read_bytes()
        except OSError:
            return label | {"reason": "source_unreadable"}
        if sha256(content).hexdigest() != hashes[path]:
            raise ValueError("KQL source snapshot differs from selected code")
        try:
            tree = ast.parse(content.decode("utf-8"), filename=path)
        except (SyntaxError, UnicodeError):
            return label | {"reason": "source_not_parseable"}
        matches = [
            qualified
            for qualified, node in matching_functions(tree, name)
            if line
            in {
                node.lineno,
                min(
                    (decorator.lineno for decorator in node.decorator_list),
                    default=node.lineno,
                ),
            }
        ]
        if len(matches) != 1:
            return label | {"reason": "ambiguous_source_symbol"}
        try:
            source = PythonSymbol.from_python(
                project_root=self.root, path=path, symbol=matches[0]
            )
        except (ValueError, OSError, SyntaxError, UnicodeError):
            return label | {"reason": "ambiguous_source_symbol"}
        if source.source_sha256 != hashes[path]:
            raise ValueError("KQL source snapshot differs from selected code")
        return SourceCandidate(source, line)
