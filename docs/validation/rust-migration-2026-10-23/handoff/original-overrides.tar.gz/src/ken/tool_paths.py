"""Resolve explicitly addressed source paths within an installed project."""

from pathlib import Path
import re


def source_paths(root: Path, tool_input, target: str | None, *, cwd: str | None = None) -> list[str]:
    """Resolve an action's paths using its working directory, including patches.

    This extracts declared paths, not arbitrary shell behavior. The workspace
    remains the boundary even when the command executes in a subdirectory.
    """
    root = root.resolve()
    directory = tool_input.get('workdir') if isinstance(tool_input, dict) else None
    base = root / (directory or cwd or '.')
    values = [target] if target else []
    text = (tool_input if isinstance(tool_input, str) else
            str(tool_input.get('patch', '')) if isinstance(tool_input, dict) else '')
    values.extend(re.findall(r'^\*\*\* (?:Update|Add|Delete) File: (.+)$', text, re.MULTILINE))
    paths = []
    for value in values:
        try:
            path = (base / value).resolve().relative_to(root).as_posix()
            if '.ken' not in Path(path).parts and '.git' not in Path(path).parts:
                paths.append(path)
        except (TypeError, ValueError, OSError):
            continue
    return list(dict.fromkeys(paths))
