"""Select declared memories for files an agent is about to work on.

This is a delivery policy, not a reasoner. It neither invents conclusions nor
infers applicability from a shared basename. Existing dependency assessment
owns freshness; the normal brief owns formatting and context deduplication.
"""

from pathlib import Path
import sqlite3

from ken.findings_graph import find_by_anchor
from .context import render_brief


def for_paths(
    conn: sqlite3.Connection,
    paths: list[str],
    *,
    root: Path,
    seen: dict[str, str] | None = None,
    max_chars: int = 2000,
) -> str:
    """Deliver anchored conclusions or review references, once per context view.

    Absolute and relative spellings of one file share the same lookup. Paths
    outside the workspace, directories and internal state are not candidates.
    Missing files remain eligible so a deleted dependency can be reported.
    """
    root = root.resolve()
    keys: set[str] = set()
    for value in paths:
        try:
            path = (root / value).resolve()
            relative = path.relative_to(root)
        except (ValueError, OSError):
            continue
        if path.is_dir() or any(part in {'.ken', '.git'} for part in relative.parts):
            continue
        keys.update((relative.as_posix(), str(path)))
    hits = {}
    for key in sorted(keys):
        for hit in find_by_anchor(conn, {'file': key}, exact_file=True):
            hits[hit['topic']] = hit
    topics = sorted(hits, key=lambda topic: (-hits[topic]['updated_at'], topic))
    return render_brief(conn, topics, root=root, seen=seen, max_chars=max_chars)
