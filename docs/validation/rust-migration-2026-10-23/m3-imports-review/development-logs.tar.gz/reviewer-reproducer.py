import json,sqlite3,tempfile,subprocess,sys
from pathlib import Path
import ken.indexer as original
probe=Path('/Users/andres/Projects/ken/.ken/rust-migration/m2-fastembed/target-final-ci/debug/examples/import_probe')
def check(name,raw):
 files=['main.ts','tsconfig.json','src/value.ts']; requests=[dict(module='@value',source_path='main.ts',language='typescript')]
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp); (root/'tsconfig.json').write_bytes(raw)
  conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row
  conn.executescript('CREATE TABLE ci_files(id INTEGER PRIMARY KEY,path TEXT,language TEXT); CREATE TABLE ci_imports(id INTEGER PRIMARY KEY,from_file_id INTEGER,to_module TEXT,to_file_id INTEGER,resolution TEXT);')
  for i,p in enumerate(files,1):conn.execute('INSERT INTO ci_files VALUES(?,?,?)',(i,p,'typescript'))
  conn.execute('INSERT INTO ci_imports(id,from_file_id,to_module) VALUES(1,1,?)',('@value',))
  try:
   original._resolve_internal_imports(conn,root)
   exp=dict(conn.execute('SELECT f.path AS target,i.resolution FROM ci_imports i LEFT JOIN ci_files f ON f.id=i.to_file_id').fetchone())
  except Exception as error:exp={'error':type(error).__name__,'message':str(error)}
  cases=[dict(id='inputs',files=files,imports=requests,source={'kind':'inputs','configs':{'tsconfig.json':raw.hex()}}),dict(id='project',files=files,imports=requests,source={'kind':'project','root':tmp})]
  actual=subprocess.run([probe],input=json.dumps({'cases':cases}).encode(),capture_output=True,timeout=10)
  print(name,json.dumps({'original':exp,'native_exit':actual.returncode,'native':actual.stdout.decode(),'stderr':actual.stderr.decode()}))
check('CR comments',b'// header\r{"compilerOptions":{"paths":{"@value":["src/value"]}}}')
check('surrogate base collapse',b'{"compilerOptions":{"baseUrl":"\\ud800/..","paths":{"@value":["src/value"]}}}')
check('surrogate target collapse',b'{"compilerOptions":{"paths":{"@value":["\\ud800/../src/value"]}}}')
check('deep JSON',b'{"compilerOptions":{"paths":{"@value":["src/value"]}},"unused":'+b'['*1100+b'0'+b']'*1100+b'}')
check('huge integer',b'{"compilerOptions":{"paths":{"@value":["src/value"]}},"unused":'+b'1'*5000+b'}')
