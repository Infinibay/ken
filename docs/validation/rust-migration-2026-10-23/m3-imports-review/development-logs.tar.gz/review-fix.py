from pathlib import Path
p=Path('crates/ken-core/src/imports/config.rs');s=p.read_text()
s=s.replace('use regex::Regex;', 'use ken_text::PythonText;\nuse regex::Regex;')
s=s.replace('Text(Option<String>),','Text(ConfigText),')
s=s.replace('value.as_deref()','value.scalar.as_deref()').replace('Self::Text(v) => v.as_ref().is_none_or(|s| !s.is_empty()),','Self::Text(v) => !v.points.is_empty(),').replace('Self::Text(value) => value.clone(),','Self::Text(value) => value.scalar.clone(),')
s=s.replace('let text = String::from_utf8_lossy(bytes);','let text = String::from_utf8_lossy(bytes).replace("\\r\\n", "\\n").replace(\'\\r\', "\\n");')
s=s.replace('fn string(&mut self) -> Option<Option<String>> {','fn string(&mut self) -> Option<ConfigText> {')
s=s.replace('''                // A non-scalar Python string cannot match a UTF8 inventory path,
                // but an unrelated config field must not invalidate other keys.
                return Some(serde_json::from_str(raw).ok());''','''                return ConfigText::parse(raw);''')
s=s.replace('let key = self.string()?;', 'let key = self.string()?.scalar;')
pos=s.index('impl ConfigValue {')
s=s[:pos]+'''/// Config paths retain non-scalar code points until lexical normalization.
#[derive(Clone, Debug)]
pub(super) struct ConfigText {
    scalar: Option<String>,
    pub points: PythonText,
}
impl ConfigText {
    fn parse(raw: &str) -> Option<Self> {
        let scalar: Option<String> = serde_json::from_str(raw).ok();
        let points = if let Some(value) = &scalar {
            PythonText::from(value.as_str())
        } else {
            let text: PythonText = serde_json::from_str(raw).ok()?;
            // Python's JSON decoder combines adjacent escaped surrogate pairs,
            // while PythonText's generic codec preserves individual code points.
            let mut points = Vec::new();
            let mut source = text.codepoints().iter().copied().peekable();
            while let Some(high) = source.next() {
                if (0xd800..=0xdbff).contains(&high)
                    && let Some(&low) = source.peek()
                    && (0xdc00..=0xdfff).contains(&low)
                {
                    source.next();
                    points.push(0x10000 + ((high - 0xd800) << 10) + low - 0xdc00);
                } else {
                    points.push(high);
                }
            }
            PythonText::from_codepoints(points)?
        };
        Some(Self { scalar, points })
    }
}
''' +s[pos:]
s=s.replace('''    pub fn truth(&self) -> bool {''','''    pub fn path_text(&self) -> Option<&PythonText> {
        if let Self::Text(value) = self { Some(&value.points) } else { None }
    }
    pub fn truth(&self) -> bool {''')
p.write_text(s)
p=Path('crates/ken-core/src/imports/aliases.rs');s=p.read_text()
s=s.replace('use std::collections', 'use ken_text::PythonText;\nuse std::collections')
s=s.replace('base: Option<String>,','base: PythonText,').replace('paths: Vec<(String, Vec<String>)>,','paths: Vec<(String, Vec<PythonText>)>,')
s=s.replace('''            let Some(base) = &config.base else {
                continue;
            };''','''            let base = &config.base;''')
s=s.replace('''                    let target = if pattern.ends_with('*') {
                        target.strip_suffix('*').unwrap_or(target).to_owned() + rest
                    } else {
                        target.clone()
                    };
                    if let Some(found) = paths::match_js_module(&norm_join(base, &target), files) {''','''                    let mut target = target.codepoints().to_vec();
                    if pattern.ends_with('*') {
                        if target.last() == Some(&u32::from('*')) { target.pop(); }
                        target.extend(rest.chars().map(u32::from));
                    }
                    let target = PythonText::from_codepoints(target).expect("existing code points");
                    if let Some(target) = norm_path(base, &target).to_utf8()
                        && let Some(found) = paths::match_js_module(&target, files) {''')
start=s.index('pub(super) fn norm_join(');end=s.index('fn clean_paths(',start)
s=s[:start]+'''pub(super) fn norm_join(base: &str, relative: &str) -> String {
    norm_path(&base.into(), &relative.into()).to_utf8().expect("scalar path inputs")
}
fn norm_path(base: &PythonText, relative: &PythonText) -> PythonText {
    let mut parts: Vec<Vec<u32>> = base.codepoints().split(|&p| p == 47)
        .filter(|p| !p.is_empty()).map(<[u32]>::to_vec).collect();
    let relative: Vec<u32> = relative.codepoints().iter().map(|&p| if p == 92 { 47 } else { p }).collect();
    for part in relative.split(|&p| p == 47) {
        match part {
            [] | [46] => {},
            [46,46] => { parts.pop(); },
            _ => parts.push(part.to_vec()),
        }
    }
    PythonText::from_codepoints(parts.join(&47)).expect("existing code points")
}
fn path(base: &str, value: &ConfigValue, file: &str) -> Result<PythonText, ImportError> {
    value.path_text().map(|v| norm_path(&base.into(), v)).ok_or_else(|| ImportError::Config {
        path: file.into(), reason: "baseUrl must support string path replacement".into(),
    })
}
''' +s[end:]
s=s.replace('-> Vec<(String, Vec<String>)>', '-> Vec<(String, Vec<PythonText>)>')
s=s.replace('''                        ConfigValue::Text(Some(value)) => vec![value.clone()],
                        ConfigValue::Text(None) => vec![],''','''                        ConfigValue::Text(value) => vec![value.points.clone()],''')
s=s.replace('''.filter_map(ConfigValue::text)
                            .map(str::to_owned)''','''.filter_map(ConfigValue::path_text)
                            .cloned()''')
s=s.replace('''&& let Some(extends) = data.get("extends").and_then(ConfigValue::text)
    {
        let mut parent = norm_join(directory, extends);''','''&& let Some(extends) = data.get("extends").and_then(ConfigValue::path_text)
        && let Some(mut parent) = norm_path(&directory.into(), extends).to_utf8()
    {''')
s=s.replace('Some(directory.into())','directory.into()')
p.write_text(s)
