# Review package: 03400e2b..HEAD

## Commits
ee32d6b1 test(imports): authenticate native project and explicit resolution
93bb0681 feat(imports): prepare resolution from indexed project configs
905ac99f feat(imports): complete native language resolution policies
6fc9ab9e feat(imports): resolve ordered JS and TS project aliases
3bf36d0e feat(imports): preserve structural module resolution
2ebd16e1 docs: plan native import resolution after reviewed parsers

## Files changed
 crates/ken-core/examples/import_probe.rs           |  113 ++
 crates/ken-core/src/imports/aliases.rs             |  245 +++
 crates/ken-core/src/imports/classification.rs      |  113 ++
 crates/ken-core/src/imports/config.rs              |  321 ++++
 crates/ken-core/src/imports/languages.rs           |  339 ++++
 crates/ken-core/src/imports/mod.rs                 |  121 ++
 crates/ken-core/src/imports/paths.rs               |  105 ++
 crates/ken-core/src/imports/project_inputs.rs      |   28 +
 crates/ken-core/src/lib.rs                         |    1 +
 .../tests/fixtures/import-alias-edges.json         |  545 ++++++
 .../tests/fixtures/import-alias-surrogates.json    |  121 ++
 .../tests/fixtures/import-language-edges.json      |  951 ++++++++++
 .../ken-core/tests/fixtures/import-reference.json  | 1979 ++++++++++++++++++++
 crates/ken-core/tests/import_project.rs            |  184 ++
 crates/ken-core/tests/import_resolution.rs         |  170 ++
 docs/rust-migration.md                             |    6 +
 .../plans/2026-10-23-rust-import-resolution.md     |  102 +
 .../2026-10-23-rust-import-resolution-design.md    |  117 ++
 .../m3-imports/FILES.json                          |   54 +
 .../m3-imports/INDEX.json                          |  499 +++++
 .../rust-migration-2026-10-23/m3-imports/LEDGER.md |   33 +
 .../rust-migration-2026-10-23/m3-imports/MINORS.md |    1 +
 .../rust-migration-2026-10-23/m3-imports/README.md |   29 +
 .../m3-imports/RULINGS.md                          |   11 +
 .../rust-migration-2026-10-23/m3-imports/VERIFY.py |   22 +
 .../m3-imports/development-logs.tar.gz             |  Bin 0 -> 27719 bytes
 .../m3-imports/linux-capture.tar.gz                |  Bin 0 -> 38002 bytes
 .../m3-imports/macos-capture.tar.gz                |  Bin 0 -> 64137 bytes
 .../m3-imports/sources.tar.gz                      |  Bin 0 -> 284727 bytes
 tests/rust_migration/test_import_evidence.py       |   56 +
 tests/rust_migration/test_import_matrix.py         |   41 +
 tests/rust_migration/test_import_reference.py      |   38 +
 tests/rust_migration/test_import_validate.py       |   44 +
 tools/rust_migration/import_evidence.py            |   91 +
 tools/rust_migration/import_reference.py           |  194 ++
 tools/rust_migration/import_validate.py            |   68 +
 tools/rust_migration/native_json.py                |   80 +
 37 files changed, 6822 insertions(+)

## Diff
diff --git a/crates/ken-core/examples/import_probe.rs b/crates/ken-core/examples/import_probe.rs
new file mode 100644
index 00000000..050beff6
--- /dev/null
+++ b/crates/ken-core/examples/import_probe.rs
@@ -0,0 +1,113 @@
+//! Strict input-only external consumer of native import resolution.
+use ken_core::imports::{ImportCatalog, ImportError, ImportRequest};
+use serde::Deserialize;
+use serde_json::json;
+use std::{
+    collections::{BTreeMap, BTreeSet},
+    io::{self, Read},
+    path::PathBuf,
+};
+#[derive(Deserialize)]
+#[serde(deny_unknown_fields)]
+struct Request {
+    cases: Vec<Case>,
+}
+#[derive(Deserialize)]
+#[serde(deny_unknown_fields)]
+struct Case {
+    id: String,
+    files: Vec<String>,
+    imports: Vec<ImportRequest>,
+    source: Source,
+}
+#[derive(Deserialize)]
+#[serde(tag = "kind", rename_all = "lowercase", deny_unknown_fields)]
+enum Source {
+    Inputs {
+        configs: Option<BTreeMap<String, String>>,
+    },
+    Project {
+        root: Option<PathBuf>,
+    },
+}
+fn main() -> Result<(), String> {
+    let mut bytes = Vec::new();
+    io::stdin()
+        .take(8 * 1024 * 1024 + 1)
+        .read_to_end(&mut bytes)
+        .map_err(|e| e.to_string())?;
+    if bytes.len() > 8 * 1024 * 1024 {
+        return Err("import request exceeds8MiB".into());
+    }
+    let request: Request = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
+    if request.cases.is_empty() || request.cases.len() > 4096 {
+        return Err("1..4096import cases required".into());
+    }
+    let mut identities = BTreeSet::new();
+    let mut rows = Vec::new();
+    let mut budget = 0;
+    for case in request.cases {
+        if case.id.is_empty() || !identities.insert(case.id.clone()) {
+            return Err("unique nonempty import case identities required".into());
+        }
+        let catalog = match case.source {
+            Source::Inputs { configs } => {
+                let configs = configs
+                    .map(|values| {
+                        values
+                            .into_iter()
+                            .map(|(name, hex)| {
+                                if !hex.len().is_multiple_of(2)
+                                    || !hex.bytes().all(|b| b.is_ascii_hexdigit())
+                                {
+                                    return Err(
+                                        "strict hexadecimal config bytes required".to_owned()
+                                    );
+                                }
+                                let bytes = (0..hex.len())
+                                    .step_by(2)
+                                    .map(|i| {
+                                        u8::from_str_radix(&hex[i..i + 2], 16)
+                                            .expect("validated ASCII hex")
+                                    })
+                                    .collect();
+                                Ok((name, bytes))
+                            })
+                            .collect::<Result<BTreeMap<_, _>, String>>()
+                    })
+                    .transpose()?;
+                ImportCatalog::from_inputs(case.files, configs)
+            }
+            Source::Project { root } => {
+                if root.as_ref().is_some_and(|r| !r.is_absolute()) {
+                    return Err("absolute project root required".into());
+                }
+                ImportCatalog::from_project(root.as_deref(), case.files)
+            }
+        };
+        let row = match catalog {
+            Ok(catalog) => {
+                let results = case
+                    .imports
+                    .iter()
+                    .map(|request| catalog.resolve(request))
+                    .collect::<Result<Vec<_>, _>>()
+                    .map_err(|e| e.to_string())?;
+                json!({"id":case.id,"results":results})
+            }
+            Err(ImportError::Config { path, reason }) => {
+                json!({"id":case.id,"error":{"kind":"invalid_config","path":path,"reason":reason}})
+            }
+        };
+        budget += serde_json::to_vec(&row).map_err(|e| e.to_string())?.len();
+        if budget > 16 * 1024 * 1024 - 1024 {
+            return Err("import response exceeds16MiB".into());
+        }
+        rows.push(row);
+    }
+    println!(
+        "{}",
+        json!({"format":"ken-import-observation/1","cases":rows})
+    );
+    Ok(())
+}
diff --git a/crates/ken-core/src/imports/aliases.rs b/crates/ken-core/src/imports/aliases.rs
new file mode 100644
index 00000000..32b63ad2
--- /dev/null
+++ b/crates/ken-core/src/imports/aliases.rs
@@ -0,0 +1,245 @@
+//! Ordered project aliases, inherited bases and workspace package names.
+use super::{
+    ImportError,
+    config::{self, ConfigValue},
+    paths,
+};
+use std::collections::{BTreeMap, BTreeSet};
+struct Config {
+    directory: String,
+    base: Option<String>,
+    paths: Vec<(String, Vec<String>)>,
+}
+#[derive(Default)]
+pub(super) struct AliasResolver {
+    configs: Vec<Config>,
+    packages: Vec<(String, String)>,
+}
+impl AliasResolver {
+    pub fn from_inputs(
+        files: &[String],
+        bytes: &BTreeMap<String, Vec<u8>>,
+    ) -> Result<Self, ImportError> {
+        let mut load = |file: &str| bytes.get(file).cloned();
+        Self::from_loader(files, &mut load)
+    }
+    pub fn from_loader(
+        files: &[String],
+        load: &mut dyn FnMut(&str) -> Option<Vec<u8>>,
+    ) -> Result<Self, ImportError> {
+        let mut resolver = Self::default();
+        for file in files {
+            let (directory, name) = file.rsplit_once('/').unwrap_or(("", file));
+            if matches!(name, "tsconfig.json" | "jsconfig.json") {
+                if let Some(config) = read_config(file, directory, load, 0)? {
+                    resolver.configs.push(config);
+                }
+            } else if name == "package.json"
+                && let Some(value) = load(file).and_then(|b| config::jsonc(&b))
+                && let Some(name) = value.get("name").and_then(ConfigValue::text)
+            {
+                if let Some(existing) = resolver.packages.iter_mut().find(|(key, _)| key == name) {
+                    existing.1 = directory.into();
+                } else {
+                    resolver.packages.push((name.into(), directory.into()));
+                }
+            }
+        }
+        resolver
+            .configs
+            .sort_by_key(|c| std::cmp::Reverse(c.directory.chars().count()));
+        Ok(resolver)
+    }
+    pub fn resolve(&self, module: &str, source: &str, files: &BTreeSet<String>) -> Option<String> {
+        let directory = source.rsplit_once('/').map_or("", |(d, _)| d);
+        for config in &self.configs {
+            if !contains(&config.directory, directory) {
+                continue;
+            }
+            let Some(base) = &config.base else {
+                continue;
+            };
+            for (pattern, targets) in &config.paths {
+                let rest = if let Some(prefix) = pattern.strip_suffix('*') {
+                    module.strip_prefix(prefix)
+                } else {
+                    (module == pattern).then_some("")
+                };
+                let Some(rest) = rest else {
+                    continue;
+                };
+                for target in targets {
+                    let target = if pattern.ends_with('*') {
+                        target.strip_suffix('*').unwrap_or(target).to_owned() + rest
+                    } else {
+                        target.clone()
+                    };
+                    if let Some(found) = paths::match_js_module(&norm_join(base, &target), files) {
+                        return Some(found);
+                    }
+                }
+            }
+        }
+        for (name, package) in &self.packages {
+            if module == name
+                || module
+                    .strip_prefix(name)
+                    .is_some_and(|s| s.starts_with('/'))
+            {
+                let sub = module[name.len()..].trim_start_matches('/');
+                let base = if sub.is_empty() {
+                    package.clone()
+                } else {
+                    norm_join(package, sub)
+                };
+                if let Some(found) = paths::match_js_module(&base, files) {
+                    return Some(found);
+                }
+            }
+        }
+        None
+    }
+    pub fn is_internal_shape(&self, module: &str, source: &str) -> bool {
+        let directory = source.rsplit_once('/').map_or("", |(d, _)| d);
+        self.configs
+            .iter()
+            .filter(|c| contains(&c.directory, directory))
+            .any(|c| {
+                c.paths.iter().any(|(pattern, _)| {
+                    if let Some(prefix) = pattern.strip_suffix('*') {
+                        module.starts_with(prefix)
+                    } else {
+                        module == pattern
+                    }
+                })
+            })
+            || self.packages.iter().any(|(name, _)| {
+                module == name
+                    || module
+                        .strip_prefix(name)
+                        .is_some_and(|s| s.starts_with('/'))
+            })
+    }
+}
+fn contains(base: &str, directory: &str) -> bool {
+    base.is_empty()
+        || base == directory
+        || directory
+            .strip_prefix(base)
+            .is_some_and(|s| s.starts_with('/'))
+}
+pub(super) fn norm_join(base: &str, relative: &str) -> String {
+    let mut parts: Vec<String> = base
+        .split('/')
+        .filter(|s| !s.is_empty())
+        .map(str::to_owned)
+        .collect();
+    for part in relative.replace('\\', "/").split('/') {
+        match part {
+            "" | "." => {}
+            ".." => {
+                parts.pop();
+            }
+            _ => parts.push(part.into()),
+        }
+    }
+    parts.join("/")
+}
+fn path(base: &str, value: &ConfigValue, file: &str) -> Result<Option<String>, ImportError> {
+    match value {
+        ConfigValue::Text(value) => Ok(value.as_ref().map(|v| norm_join(base, v))),
+        _ => Err(ImportError::Config {
+            path: file.into(),
+            reason: "baseUrl must support string path replacement".into(),
+        }),
+    }
+}
+fn clean_paths(value: Option<&ConfigValue>) -> Vec<(String, Vec<String>)> {
+    value
+        .and_then(ConfigValue::object)
+        .map_or_else(Vec::new, |values| {
+            values
+                .iter()
+                .filter_map(|(key, value)| {
+                    let key = key.clone()?;
+                    let targets = match value {
+                        ConfigValue::Text(Some(value)) => vec![value.clone()],
+                        ConfigValue::Text(None) => vec![],
+                        ConfigValue::Array(values) => values
+                            .iter()
+                            .filter_map(ConfigValue::text)
+                            .map(str::to_owned)
+                            .collect(),
+                        _ => return None,
+                    };
+                    Some((key, targets))
+                })
+                .collect()
+        })
+}
+fn read_config(
+    file: &str,
+    directory: &str,
+    load: &mut dyn FnMut(&str) -> Option<Vec<u8>>,
+    depth: usize,
+) -> Result<Option<Config>, ImportError> {
+    let Some(data) = load(file)
+        .and_then(|b| config::jsonc(&b))
+        .filter(|v| v.object().is_some())
+    else {
+        return Ok(None);
+    };
+    let options = data.get("compilerOptions").filter(|v| v.truth());
+    if options.is_some_and(|v| v.object().is_none()) {
+        return Err(ImportError::Config {
+            path: file.into(),
+            reason: "compilerOptions has no dictionary get method".into(),
+        });
+    }
+    let base = options
+        .and_then(|o| o.get("baseUrl"))
+        .filter(|v| !v.is_null());
+    let paths = options
+        .and_then(|o| o.get("paths"))
+        .filter(|v| !v.is_null());
+    if (base.is_none() || paths.is_none())
+        && depth < 3
+        && let Some(extends) = data.get("extends").and_then(ConfigValue::text)
+    {
+        let mut parent = norm_join(directory, extends);
+        if !parent.ends_with(".json") {
+            parent.push_str(".json");
+        }
+        let parent_dir = parent.rsplit_once('/').map_or("", |(d, _)| d);
+        if let Some(parent) = read_config(&parent, parent_dir, load, depth + 1)? {
+            let base = if let Some(base) = base {
+                path(directory, base, file)?
+            } else {
+                parent.base
+            };
+            let paths = if paths.is_some_and(ConfigValue::truth) {
+                clean_paths(paths)
+            } else {
+                parent.paths
+            };
+            return Ok(Some(Config {
+                directory: directory.into(),
+                base,
+                paths,
+            }));
+        }
+    }
+    if !paths.is_some_and(ConfigValue::truth) && base.is_none() {
+        return Ok(None);
+    }
+    let base = if let Some(base) = base.filter(|v| v.truth()) {
+        path(directory, base, file)?
+    } else {
+        Some(directory.into())
+    };
+    Ok(Some(Config {
+        directory: directory.into(),
+        base,
+        paths: clean_paths(paths),
+    }))
+}
diff --git a/crates/ken-core/src/imports/classification.rs b/crates/ken-core/src/imports/classification.rs
new file mode 100644
index 00000000..cfdd831b
--- /dev/null
+++ b/crates/ken-core/src/imports/classification.rs
@@ -0,0 +1,113 @@
+//! An unresolved edge retains original project-intent versus external meaning.
+use super::{
+    Resolution,
+    aliases::AliasResolver,
+    languages::{LanguageModules, directory},
+    paths,
+};
+use std::collections::BTreeSet;
+pub(super) fn classify(
+    module: &str,
+    language: Option<&str>,
+    source: &str,
+    aliases: &AliasResolver,
+    languages: &LanguageModules,
+    files: &BTreeSet<String>,
+) -> Resolution {
+    let m = paths::trim(
+        paths::trim(module)
+            .trim_matches('"')
+            .trim_matches('\'')
+            .trim_end_matches(';'),
+    );
+    let unresolved = match language {
+        Some("typescript" | "javascript") => {
+            m.starts_with("./") || m.starts_with("../") || aliases.is_internal_shape(m, source)
+        }
+        Some("rust") => matches!(
+            paths::trim(
+                m.split("::")
+                    .next()
+                    .unwrap_or("")
+                    .split('{')
+                    .next()
+                    .unwrap_or("")
+            ),
+            "crate" | "super" | "self"
+        ),
+        Some("go") => languages.go_modules.iter().any(|(_, prefix)| {
+            m == prefix || m.strip_prefix(prefix).is_some_and(|s| s.starts_with('/'))
+        }),
+        Some("python") => {
+            let slash = m.replace('.', "/");
+            m.starts_with('.')
+                || files.iter().any(|p| {
+                    *p == format!("{slash}.py")
+                        || p.ends_with(&format!("/{slash}.py"))
+                        || p.ends_with(&format!("/{slash}/__init__.py"))
+                })
+        }
+        Some("java") => {
+            !["java.", "javax.", "jakarta."]
+                .iter()
+                .any(|p| m.starts_with(p))
+                && files
+                    .iter()
+                    .any(|p| p.ends_with(&format!("/{}.java", m.replace('.', "/"))))
+        }
+        Some("kotlin") => {
+            if [
+                "kotlin.",
+                "kotlinx.",
+                "java.",
+                "javax.",
+                "jakarta.",
+                "android.",
+                "androidx.",
+            ]
+            .iter()
+            .any(|p| m.starts_with(p))
+            {
+                false
+            } else {
+                let trimmed = m.trim_end_matches('*').trim_end_matches('.');
+                let package = if m.contains('.') {
+                    trimmed.rsplit_once('.').map_or(trimmed, |(p, _)| p)
+                } else {
+                    m
+                };
+                let path = package.replace('.', "/");
+                files.iter().any(|p| {
+                    (p.ends_with(".kt") || p.ends_with(".kts"))
+                        && (directory(p) == path || directory(p).ends_with(&format!("/{path}")))
+                })
+            }
+        }
+        Some("php") => {
+            if module.contains('\\') || (!m.starts_with(['.', '/']) && !m.ends_with(".php")) {
+                let name = m.trim_start_matches('\\').replace('\\', "/");
+                let tail = name.rsplit('/').next().unwrap_or("");
+                files
+                    .iter()
+                    .any(|p| *p == format!("{tail}.php") || p.ends_with(&format!("/{tail}.php")))
+            } else {
+                m.starts_with(['.', '/']) || m.ends_with(".php")
+            }
+        }
+        Some("cpp") => {
+            let base = m.rsplit('/').next().unwrap_or("");
+            paths::trim(module).starts_with('"')
+                && files.iter().any(|p| {
+                    p.as_str() == m
+                        || p.ends_with(&format!("/{m}"))
+                        || p.ends_with(&format!("/{base}"))
+                })
+        }
+        _ => m.starts_with(['.', '/']),
+    };
+    if unresolved {
+        Resolution::Unresolved
+    } else {
+        Resolution::External
+    }
+}
diff --git a/crates/ken-core/src/imports/config.rs b/crates/ken-core/src/imports/config.rs
new file mode 100644
index 00000000..a8e930f4
--- /dev/null
+++ b/crates/ken-core/src/imports/config.rs
@@ -0,0 +1,321 @@
+//! Ordered config values retain Python JSON's numeric and string tolerance.
+use regex::Regex;
+use serde_json::value::RawValue;
+use std::sync::OnceLock;
+#[derive(Clone, Debug)]
+pub(super) enum ConfigValue {
+    Object(Vec<(Option<String>, ConfigValue)>),
+    Array(Vec<ConfigValue>),
+    Text(Option<String>),
+    Other { truth: bool, spelling: String },
+    Null,
+}
+impl ConfigValue {
+    pub fn get(&self, key: &str) -> Option<&Self> {
+        self.object()?
+            .iter()
+            .find(|(k, _)| k.as_deref() == Some(key))
+            .map(|(_, v)| v)
+    }
+    pub fn object(&self) -> Option<&[(Option<String>, Self)]> {
+        if let Self::Object(values) = self {
+            Some(values)
+        } else {
+            None
+        }
+    }
+    pub fn text(&self) -> Option<&str> {
+        if let Self::Text(value) = self {
+            value.as_deref()
+        } else {
+            None
+        }
+    }
+    pub fn truth(&self) -> bool {
+        match self {
+            Self::Object(v) => !v.is_empty(),
+            Self::Array(v) => !v.is_empty(),
+            Self::Text(v) => v.as_ref().is_none_or(|s| !s.is_empty()),
+            Self::Other { truth, .. } => *truth,
+            Self::Null => false,
+        }
+    }
+    pub fn is_null(&self) -> bool {
+        matches!(self, Self::Null)
+    }
+    pub fn python_string(&self) -> Option<String> {
+        match self {
+            Self::Text(value) => value.clone(),
+            Self::Null => Some("None".into()),
+            Self::Other { spelling, .. } => Some(spelling.clone()),
+            Self::Array(values) => Some(format!(
+                "[{}]",
+                values
+                    .iter()
+                    .map(Self::python_repr)
+                    .collect::<Option<Vec<_>>>()?
+                    .join(", ")
+            )),
+            Self::Object(values) => Some(format!(
+                "{{{}}}",
+                values
+                    .iter()
+                    .map(|(key, value)| Some(format!(
+                        "{}: {}",
+                        quote(key.as_deref()?),
+                        value.python_repr()?
+                    )))
+                    .collect::<Option<Vec<_>>>()?
+                    .join(", ")
+            )),
+        }
+    }
+    fn python_repr(&self) -> Option<String> {
+        if let Self::Text(value) = self {
+            Some(quote(value.as_deref()?))
+        } else {
+            self.python_string()
+        }
+    }
+}
+fn quote(value: &str) -> String {
+    let delimiter = if value.contains('\'') && !value.contains('"') {
+        '"'
+    } else {
+        '\''
+    };
+    let mut result = delimiter.to_string();
+    for c in value.chars() {
+        match c {
+            '\\' => result.push_str("\\\\"),
+            '\n' => result.push_str("\\n"),
+            '\r' => result.push_str("\\r"),
+            '\t' => result.push_str("\\t"),
+            _ if c == delimiter => {
+                result.push('\\');
+                result.push(c);
+            }
+            _ if c.is_control() && (c as u32) <= 0xff => {
+                result.push_str(&format!("\\x{:02x}", c as u32))
+            }
+            _ => result.push(c),
+        }
+    }
+    result.push(delimiter);
+    result
+}
+pub(super) fn jsonc(bytes: &[u8]) -> Option<ConfigValue> {
+    let text = String::from_utf8_lossy(bytes);
+    let source = text.as_bytes();
+    let mut output = Vec::new();
+    let mut i = 0;
+    let mut quoted = false;
+    let mut escaped = false;
+    while i < source.len() {
+        let c = source[i];
+        if quoted {
+            output.push(c);
+            if escaped {
+                escaped = false;
+            } else if c == b'\\' {
+                escaped = true;
+            } else if c == b'"' {
+                quoted = false;
+            }
+            i += 1;
+            continue;
+        }
+        if c == b'"' {
+            quoted = true;
+            output.push(c);
+            i += 1;
+            continue;
+        }
+        if source.get(i..i + 2) == Some(b"//") {
+            while i < source.len() && source[i] != b'\n' {
+                i += 1;
+            }
+        } else if source.get(i..i + 2) == Some(b"/*") {
+            i += 2;
+            while i + 1 < source.len() && source.get(i..i + 2) != Some(b"*/") {
+                i += 1;
+            }
+            i += 2;
+        } else {
+            output.push(c);
+            i += 1;
+        }
+    }
+    let stripped = String::from_utf8(output).ok()?;
+    static TRAILING: OnceLock<Regex> = OnceLock::new();
+    let cleaned = TRAILING
+        .get_or_init(|| Regex::new(r",([\s\x1c-\x1f]*[}\]])").expect("static JSONC expression"))
+        .replace_all(&stripped, "$1");
+    parse(&cleaned)
+}
+pub(super) fn parse(text: &str) -> Option<ConfigValue> {
+    let mut parser = Parser { text, position: 0 };
+    let value = parser.value(0)?;
+    parser.whitespace();
+    (parser.position == text.len()).then_some(value)
+}
+struct Parser<'a> {
+    text: &'a str,
+    position: usize,
+}
+impl Parser<'_> {
+    fn whitespace(&mut self) {
+        while self
+            .text
+            .as_bytes()
+            .get(self.position)
+            .is_some_and(|c| matches!(c, b' ' | b'\t' | b'\r' | b'\n'))
+        {
+            self.position += 1;
+        }
+    }
+    fn consume(&mut self, byte: u8) -> bool {
+        self.whitespace();
+        if self.text.as_bytes().get(self.position) != Some(&byte) {
+            return false;
+        }
+        self.position += 1;
+        true
+    }
+    fn string(&mut self) -> Option<Option<String>> {
+        self.whitespace();
+        let start = self.position;
+        if !self.consume(b'"') {
+            return None;
+        }
+        while let Some(&byte) = self.text.as_bytes().get(self.position) {
+            self.position += 1;
+            if byte == b'\\' {
+                self.position += 1;
+            } else if byte == b'"' {
+                let raw = &self.text[start..self.position];
+                serde_json::from_str::<Box<RawValue>>(raw).ok()?;
+                // A non-scalar Python string cannot match a UTF8 inventory path,
+                // but an unrelated config field must not invalidate other keys.
+                return Some(serde_json::from_str(raw).ok());
+            }
+        }
+        None
+    }
+    fn value(&mut self, depth: usize) -> Option<ConfigValue> {
+        if depth > 1000 {
+            return None;
+        }
+        self.whitespace();
+        match *self.text.as_bytes().get(self.position)? {
+            b'"' => return Some(ConfigValue::Text(self.string()?)),
+            b'{' => {
+                self.position += 1;
+                let mut values: Vec<(Option<String>, ConfigValue)> = Vec::new();
+                if self.consume(b'}') {
+                    return Some(ConfigValue::Object(values));
+                }
+                loop {
+                    let key = self.string()?;
+                    if !self.consume(b':') {
+                        return None;
+                    }
+                    let value = self.value(depth + 1)?;
+                    if let Some(existing) = key
+                        .as_ref()
+                        .and_then(|key| values.iter_mut().find(|(k, _)| k.as_ref() == Some(key)))
+                    {
+                        existing.1 = value;
+                    } else {
+                        values.push((key, value));
+                    }
+                    if self.consume(b'}') {
+                        break;
+                    }
+                    if !self.consume(b',') {
+                        return None;
+                    }
+                }
+                return Some(ConfigValue::Object(values));
+            }
+            b'[' => {
+                self.position += 1;
+                let mut values = Vec::new();
+                if self.consume(b']') {
+                    return Some(ConfigValue::Array(values));
+                }
+                loop {
+                    values.push(self.value(depth + 1)?);
+                    if self.consume(b']') {
+                        break;
+                    }
+                    if !self.consume(b',') {
+                        return None;
+                    }
+                }
+                return Some(ConfigValue::Array(values));
+            }
+            _ => {}
+        }
+        let start = self.position;
+        while self
+            .text
+            .as_bytes()
+            .get(self.position)
+            .is_some_and(|c| !matches!(c, b' ' | b'\t' | b'\r' | b'\n' | b',' | b']' | b'}'))
+        {
+            self.position += 1;
+        }
+        let raw = &self.text[start..self.position];
+        match raw {
+            "null" => Some(ConfigValue::Null),
+            "true" => Some(ConfigValue::Other {
+                truth: true,
+                spelling: "True".into(),
+            }),
+            "false" => Some(ConfigValue::Other {
+                truth: false,
+                spelling: "False".into(),
+            }),
+            "NaN" => Some(ConfigValue::Other {
+                truth: true,
+                spelling: "nan".into(),
+            }),
+            "Infinity" => Some(ConfigValue::Other {
+                truth: true,
+                spelling: "inf".into(),
+            }),
+            "-Infinity" => Some(ConfigValue::Other {
+                truth: true,
+                spelling: "-inf".into(),
+            }),
+            _ => {
+                serde_json::from_str::<Box<RawValue>>(raw).ok()?;
+                let number: f64 = raw.parse().ok()?;
+                Some(ConfigValue::Other {
+                    truth: number != 0.0,
+                    spelling: if raw.contains(['.', 'e', 'E']) {
+                        float_spelling(number)
+                    } else if number == 0.0 {
+                        "0".into()
+                    } else {
+                        raw.into()
+                    },
+                })
+            }
+        }
+    }
+}
+fn float_spelling(number: f64) -> String {
+    let text = format!("{number:?}");
+    if let Some((base, exponent)) = text.split_once('e') {
+        let value: i32 = exponent.parse().expect("native float exponent");
+        format!(
+            "{base}e{}{number:02}",
+            if value < 0 { '-' } else { '+' },
+            number = value.unsigned_abs()
+        )
+    } else {
+        text
+    }
+}
diff --git a/crates/ken-core/src/imports/languages.rs b/crates/ken-core/src/imports/languages.rs
new file mode 100644
index 00000000..b37dd4d7
--- /dev/null
+++ b/crates/ken-core/src/imports/languages.rs
@@ -0,0 +1,339 @@
+//! Language module lookup owns each ecosystem's actual inventory/config rules.
+use super::{ImportError, config, paths};
+use std::collections::{BTreeMap, BTreeSet};
+pub(super) struct LanguageModules {
+    java: Vec<String>,
+    kotlin: Vec<String>,
+    cargo: Vec<String>,
+    pub go_modules: Vec<(String, String)>,
+    go_files: BTreeMap<String, Vec<String>>,
+    php: Vec<(String, String)>,
+}
+impl LanguageModules {
+    pub fn from_inputs(
+        files: &[String],
+        configs: Option<&BTreeMap<String, Vec<u8>>>,
+    ) -> Result<Self, ImportError> {
+        let mut cargo: Vec<_> = files
+            .iter()
+            .filter(|p| p.ends_with("Cargo.toml"))
+            .map(|p| directory(p).to_owned())
+            .collect();
+        cargo.sort_by_key(|d| std::cmp::Reverse(d.chars().count()));
+        let mut go_files: BTreeMap<String, Vec<String>> = BTreeMap::new();
+        for path in files.iter().filter(|p| p.ends_with(".go")) {
+            go_files
+                .entry(directory(path).into())
+                .or_default()
+                .push(path.clone());
+        }
+        let mut go_modules: Vec<(String, String)> = Vec::new();
+        let mut php = Vec::new();
+        if let Some(configs) = configs {
+            for file in files {
+                if file.ends_with("go.mod")
+                    && let Some(bytes) = configs.get(file)
+                {
+                    let text = String::from_utf8_lossy(bytes);
+                    for line in python_lines(&text).map(paths::trim) {
+                        if let Some(module) = line.strip_prefix("module ") {
+                            go_modules.push((directory(file).into(), paths::trim(module).into()));
+                            break;
+                        }
+                    }
+                }
+                if file.ends_with("composer.json")
+                    && let Some(bytes) = configs.get(file)
+                {
+                    let Some(data) = std::str::from_utf8(bytes).ok().and_then(config::parse) else {
+                        continue;
+                    };
+                    if data.object().is_none() {
+                        return Err(invalid(file, "composer data has no dictionary get method"));
+                    }
+                    for section in ["autoload", "autoload-dev"] {
+                        let Some(section) = data.get(section).filter(|v| v.truth()) else {
+                            continue;
+                        };
+                        if section.object().is_none() {
+                            return Err(invalid(
+                                file,
+                                "autoload section has no dictionary get method",
+                            ));
+                        }
+                        let Some(mapping) = section.get("psr-4").filter(|v| v.truth()) else {
+                            continue;
+                        };
+                        let Some(mapping) = mapping.object() else {
+                            return Err(invalid(
+                                file,
+                                "PSR4 mapping has no dictionary items method",
+                            ));
+                        };
+                        for (prefix, dirs) in mapping {
+                            let Some(prefix) = prefix else {
+                                continue;
+                            };
+                            let values = if let config::ConfigValue::Array(values) = dirs {
+                                values.as_slice()
+                            } else {
+                                std::slice::from_ref(dirs)
+                            };
+                            for value in values {
+                                if let Some(value) = value.python_string() {
+                                    let base = directory(file);
+                                    let full = if base.is_empty() {
+                                        value
+                                    } else {
+                                        format!("{base}/{value}")
+                                    };
+                                    php.push((prefix.clone(), full.trim_matches('/').into()));
+                                }
+                            }
+                        }
+                    }
+                }
+            }
+        }
+        go_modules.sort_by_key(|(dir, _)| std::cmp::Reverse(dir.chars().count()));
+        php.sort_by_key(|(prefix, _)| std::cmp::Reverse(prefix.chars().count()));
+        Ok(Self {
+            java: files
+                .iter()
+                .filter(|p| p.ends_with(".java"))
+                .cloned()
+                .collect(),
+            kotlin: files
+                .iter()
+                .filter(|p| p.ends_with(".kt") || p.ends_with(".kts"))
+                .cloned()
+                .collect(),
+            cargo,
+            go_modules,
+            go_files,
+            php,
+        })
+    }
+    pub fn resolve(
+        &self,
+        module: &str,
+        source: &str,
+        language: Option<&str>,
+        files: &BTreeSet<String>,
+    ) -> Option<String> {
+        match language {
+            Some("java") => java(module, &self.java),
+            Some("rust") => rust(module, source, files, &self.cargo),
+            Some("go") => self.go(module, source),
+            Some("ruby") => ruby(module, source, files),
+            Some("cpp") => cpp(module, source, files),
+            Some("kotlin") => kotlin(module, &self.kotlin),
+            Some("php") => php(module, &self.php, files),
+            _ => None,
+        }
+    }
+    fn go(&self, module: &str, source: &str) -> Option<String> {
+        let module = paths::trim(module).trim_matches('"');
+        let source_dir = directory(source);
+        for (dir, prefix) in &self.go_modules {
+            if !contains(dir, source_dir) {
+                continue;
+            }
+            if module == prefix
+                || module
+                    .strip_prefix(prefix)
+                    .is_some_and(|s| s.starts_with('/'))
+            {
+                let relative = module[prefix.len()..].trim_matches('/');
+                let package = if relative.is_empty() {
+                    dir.clone()
+                } else {
+                    format!("{dir}/{relative}").trim_matches('/').to_owned()
+                };
+                return self
+                    .go_files
+                    .get(&package)
+                    .and_then(|files| files.iter().filter(|p| !p.ends_with("_test.go")).min())
+                    .cloned();
+            }
+        }
+        None
+    }
+}
+fn invalid(path: &str, reason: &str) -> ImportError {
+    ImportError::Config {
+        path: path.into(),
+        reason: reason.into(),
+    }
+}
+pub(super) fn directory(path: &str) -> &str {
+    path.rsplit_once('/').map_or("", |(d, _)| d)
+}
+fn contains(base: &str, directory: &str) -> bool {
+    base.is_empty()
+        || base == directory
+        || directory
+            .strip_prefix(base)
+            .is_some_and(|s| s.starts_with('/'))
+}
+fn java(module: &str, files: &[String]) -> Option<String> {
+    let module = paths::trim(paths::trim(module).trim_matches(';'));
+    if module.is_empty() || module.ends_with('*') {
+        return None;
+    }
+    for candidate in [module, module.rsplit_once('.').map_or(module, |(m, _)| m)] {
+        let suffix = candidate.replace('.', "/") + ".java";
+        let matches: Vec<_> = files
+            .iter()
+            .filter(|p| *p == &suffix || p.ends_with(&format!("/{suffix}")))
+            .collect();
+        if matches.len() == 1 {
+            return Some(matches[0].clone());
+        }
+    }
+    None
+}
+fn rust(module: &str, source: &str, files: &BTreeSet<String>, cargo: &[String]) -> Option<String> {
+    let module = paths::trim(module.split('{').next().unwrap_or("")).trim_matches(':');
+    if module.is_empty() {
+        return None;
+    }
+    let mut parts: Vec<_> = module.split("::").filter(|s| !s.is_empty()).collect();
+    if parts.last() == Some(&"*") {
+        parts.pop();
+        if !parts.is_empty() && parts.iter().all(|p| matches!(*p, "super" | "self")) {
+            return files.contains(source).then(|| source.into());
+        }
+    }
+    let root = cargo
+        .iter()
+        .find(|d| contains(d, directory(source)))
+        .map(|d| format!("{d}/src").trim_start_matches('/').to_owned());
+    let (base, segments) = match parts.first().copied().unwrap_or("") {
+        "crate" => (root, &parts[1..]),
+        "self" => (Some(directory(source).into()), &parts[1..]),
+        "super" => {
+            let mut base = directory(source);
+            let mut count = 0;
+            while parts.get(count) == Some(&"super") {
+                base = directory(base);
+                count += 1;
+            }
+            (Some(base.into()), &parts[count..])
+        }
+        _ => (root, parts.as_slice()),
+    };
+    let base = base?;
+    for count in (1..=segments.len()).rev() {
+        let stem = format!("{base}/{}", segments[..count].join("/"))
+            .trim_matches('/')
+            .to_owned();
+        for candidate in [format!("{stem}.rs"), format!("{stem}/mod.rs")] {
+            if files.contains(&candidate) {
+                return Some(candidate);
+            }
+        }
+    }
+    None
+}
+fn ruby(module: &str, source: &str, files: &BTreeSet<String>) -> Option<String> {
+    let module = paths::trim(module).trim_matches(['\'', '"']);
+    if !module.starts_with("./") && !module.starts_with("../") {
+        return None;
+    }
+    let joined = paths::join_relative(source, module);
+    [joined.clone(), format!("{joined}.rb")]
+        .into_iter()
+        .find(|p| files.contains(p))
+}
+fn cpp(module: &str, source: &str, files: &BTreeSet<String>) -> Option<String> {
+    if !paths::trim(module).starts_with('"') {
+        return None;
+    }
+    let module = paths::trim(module).trim_matches('"');
+    if module.is_empty() {
+        return None;
+    }
+    if module.starts_with("./") || module.starts_with("../") {
+        let joined = paths::join_relative(source, module);
+        return files.contains(&joined).then_some(joined);
+    }
+    let matches: Vec<_> = files
+        .iter()
+        .filter(|p| p.as_str() == module || p.ends_with(&format!("/{module}")))
+        .collect();
+    if matches.len() == 1 {
+        return Some(matches[0].clone());
+    }
+    if matches.len() > 1 {
+        let top = source.split('/').next();
+        let matches: Vec<_> = matches
+            .into_iter()
+            .filter(|p| p.split('/').next() == top)
+            .collect();
+        if matches.len() == 1 {
+            return Some(matches[0].clone());
+        }
+    }
+    None
+}
+fn kotlin(module: &str, files: &[String]) -> Option<String> {
+    let module = paths::trim(paths::trim(module).trim_matches(';'));
+    if module.is_empty() || module.ends_with('*') {
+        return None;
+    }
+    let package = module.rsplit_once('.').map_or(module, |(p, _)| p);
+    if package.is_empty() {
+        return None;
+    }
+    let package = package.replace('.', "/");
+    let matches: Vec<_> = files
+        .iter()
+        .filter(|p| directory(p) == package || directory(p).ends_with(&format!("/{package}")))
+        .collect();
+    (matches.len() == 1).then(|| matches[0].clone())
+}
+fn php(module: &str, mappings: &[(String, String)], files: &BTreeSet<String>) -> Option<String> {
+    let module = paths::trim(module)
+        .trim_matches(';')
+        .trim_start_matches('\\');
+    if module.is_empty() {
+        return None;
+    }
+    for (prefix, base) in mappings {
+        if let Some(rest) = module.strip_prefix(prefix.trim_start_matches('\\')) {
+            let rest = rest.trim_matches('\\').replace('\\', "/");
+            let candidate = format!("{base}/{rest}.php").trim_matches('/').to_owned();
+            if files.contains(&candidate) {
+                return Some(candidate);
+            }
+        }
+    }
+    let normalized = module.replace('\\', "/");
+    let tail = normalized.rsplit('/').next().unwrap_or("");
+    let matches: Vec<_> = files
+        .iter()
+        .filter(|p| p.ends_with(&format!("/{tail}.php")) || **p == format!("{tail}.php"))
+        .collect();
+    (matches.len() == 1).then(|| matches[0].clone())
+}
+fn python_lines(text: &str) -> impl Iterator<Item = &str> {
+    let mut parts = Vec::new();
+    let mut start = 0;
+    for (index, value) in text.match_indices([
+        '\n', '\r', '\x0b', '\x0c', '\x1c', '\x1d', '\x1e', '\u{85}', '\u{2028}', '\u{2029}',
+    ]) {
+        if index < start {
+            continue;
+        }
+        parts.push(&text[start..index]);
+        start = index + value.len();
+        if value == "\r" && text.as_bytes().get(start) == Some(&b'\n') {
+            start += 1;
+        }
+    }
+    if start < text.len() {
+        parts.push(&text[start..]);
+    }
+    parts.into_iter()
+}
diff --git a/crates/ken-core/src/imports/mod.rs b/crates/ken-core/src/imports/mod.rs
new file mode 100644
index 00000000..7ee610cb
--- /dev/null
+++ b/crates/ken-core/src/imports/mod.rs
@@ -0,0 +1,121 @@
+//! Resolve indexed import edges from explicit ordered project inputs.
+mod aliases;
+mod classification;
+mod config;
+mod languages;
+mod paths;
+mod project_inputs;
+use serde::{Deserialize, Serialize};
+use std::collections::{BTreeMap, BTreeSet};
+use thiserror::Error;
+
+#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
+#[serde(deny_unknown_fields)]
+pub struct ImportRequest {
+    pub module: String,
+    pub source_path: String,
+    pub language: Option<String>,
+}
+#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
+#[serde(rename_all = "lowercase")]
+pub enum Resolution {
+    Internal,
+    Unresolved,
+    External,
+}
+#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
+pub struct ImportResolution {
+    pub target: Option<String>,
+    pub resolution: Resolution,
+}
+#[derive(Debug, Error)]
+pub enum ImportError {
+    #[error("invalid import config {path}: {reason}")]
+    Config { path: String, reason: String },
+}
+
+pub struct ImportCatalog {
+    files: BTreeSet<String>,
+    python_suffixes: BTreeMap<String, Vec<String>>,
+    aliases: aliases::AliasResolver,
+    languages: languages::LanguageModules,
+}
+impl ImportCatalog {
+    pub fn from_inputs(
+        files: Vec<String>,
+        configs: Option<BTreeMap<String, Vec<u8>>>,
+    ) -> Result<Self, ImportError> {
+        let aliases = if let Some(configs) = &configs {
+            aliases::AliasResolver::from_inputs(&files, configs)?
+        } else {
+            aliases::AliasResolver::default()
+        };
+        Self::prepared(files, configs.as_ref(), aliases)
+    }
+    pub fn from_project(
+        root: Option<&std::path::Path>,
+        files: Vec<String>,
+    ) -> Result<Self, ImportError> {
+        let Some(root) = root else {
+            return Self::from_inputs(files, None);
+        };
+        let inputs = project_inputs::ProjectImportInputs::read(root, &files)?;
+        Self::prepared(files, Some(&inputs.bytes), inputs.aliases)
+    }
+    fn prepared(
+        files: Vec<String>,
+        configs: Option<&BTreeMap<String, Vec<u8>>>,
+        aliases: aliases::AliasResolver,
+    ) -> Result<Self, ImportError> {
+        let python_suffixes = paths::python_suffixes(&files);
+        let languages = languages::LanguageModules::from_inputs(&files, configs)?;
+        Ok(Self {
+            files: files.into_iter().collect(),
+            python_suffixes,
+            aliases,
+            languages,
+        })
+    }
+    /// The original language-independent structural phase; ambiguity is absence.
+    pub fn structural_target(&self, module: &str, source: Option<&str>) -> Option<String> {
+        paths::structural_target(module, source, &self.files, &self.python_suffixes)
+    }
+    pub fn resolve(&self, request: &ImportRequest) -> Result<ImportResolution, ImportError> {
+        if let Some(target) = self.structural_target(&request.module, Some(&request.source_path)) {
+            return Ok(ImportResolution {
+                target: Some(target),
+                resolution: Resolution::Internal,
+            });
+        }
+        let mut target = None;
+        if matches!(
+            request.language.as_deref(),
+            Some("typescript" | "javascript")
+        ) {
+            target = self
+                .aliases
+                .resolve(&request.module, &request.source_path, &self.files);
+        }
+        if target.is_none() {
+            target = self.languages.resolve(
+                &request.module,
+                &request.source_path,
+                request.language.as_deref(),
+                &self.files,
+            );
+        }
+        let resolution = if target.is_some() {
+            Resolution::Internal
+        } else {
+            classification::classify(
+                &request.module,
+                request.language.as_deref(),
+                &request.source_path,
+                &self.aliases,
+                &self.languages,
+                &self.files,
+            )
+        };
+        Ok(ImportResolution { target, resolution })
+    }
+}
diff --git a/crates/ken-core/src/imports/paths.rs b/crates/ken-core/src/imports/paths.rs
new file mode 100644
index 00000000..502c7b7c
--- /dev/null
+++ b/crates/ken-core/src/imports/paths.rs
@@ -0,0 +1,105 @@
+//! Original lexical path joining, module suffix priority and ambiguity rules.
+use std::collections::{BTreeMap, BTreeSet};
+
+const JS_EXTENSIONS: [&str; 7] = [".ts", ".tsx", ".d.ts", ".js", ".jsx", ".mjs", ".cjs"];
+pub(super) fn trim(value: &str) -> &str {
+    value.trim_matches(|c: char| c.is_whitespace() || matches!(c, '\x1c'..='\x1f'))
+}
+pub(super) fn python_suffixes(files: &[String]) -> BTreeMap<String, Vec<String>> {
+    let mut index: BTreeMap<String, Vec<String>> = BTreeMap::new();
+    for path in files.iter().filter(|p| p.ends_with(".py")) {
+        let parts: Vec<_> = path.split('/').collect();
+        for i in 1..parts.len() {
+            index
+                .entry(format!("/{}", parts[i..].join("/")))
+                .or_default()
+                .push(path.clone());
+        }
+    }
+    index
+}
+pub(super) fn join_relative(source: &str, module: &str) -> String {
+    let mut parts: Vec<_> = source.split('/').collect();
+    parts.pop();
+    for segment in module.split('/') {
+        match segment {
+            "" | "." => {}
+            ".." => {
+                parts.pop();
+            }
+            _ => parts.push(segment),
+        }
+    }
+    parts.join("/")
+}
+pub(super) fn match_js_module(joined: &str, files: &BTreeSet<String>) -> Option<String> {
+    if joined.is_empty() {
+        return None;
+    }
+    if files.contains(joined) {
+        return Some(joined.into());
+    }
+    let stem = [".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"]
+        .into_iter()
+        .find_map(|ext| joined.strip_suffix(ext))
+        .unwrap_or(joined);
+    for suffix in JS_EXTENSIONS {
+        let candidate = format!("{stem}{suffix}");
+        if files.contains(&candidate) {
+            return Some(candidate);
+        }
+    }
+    for suffix in JS_EXTENSIONS {
+        let candidate = format!("{stem}/index{suffix}");
+        if files.contains(&candidate) {
+            return Some(candidate);
+        }
+    }
+    None
+}
+pub(super) fn structural_target(
+    module: &str,
+    source: Option<&str>,
+    files: &BTreeSet<String>,
+    suffixes: &BTreeMap<String, Vec<String>>,
+) -> Option<String> {
+    let module = trim(module).trim_matches(['\'', '"']);
+    if module.is_empty() {
+        return None;
+    }
+    if let Some(source) = source.filter(|_| module.starts_with("./") || module.starts_with("../")) {
+        return match_js_module(&join_relative(source, module), files);
+    }
+    let module = module.trim_start_matches('.');
+    let slash = module.replace('.', "/");
+    let mut candidates: BTreeSet<_> = [
+        ".py",
+        "/__init__.py",
+        ".ts",
+        ".tsx",
+        ".js",
+        ".jsx",
+        ".go",
+        ".java",
+        ".rs",
+        ".dart",
+    ]
+    .into_iter()
+    .map(|ext| format!("{slash}{ext}"))
+    .collect();
+    if module.contains('/') {
+        candidates.extend([
+            module.to_owned(),
+            format!("{module}.py"),
+            format!("{module}.ts"),
+            format!("{module}.js"),
+        ]);
+    }
+    let mut matches: BTreeSet<_> = candidates.intersection(files).cloned().collect();
+    if let Some(paths) = suffixes.get(&format!("/{slash}.py")) {
+        matches.extend(paths.iter().cloned());
+    }
+    (matches.len() == 1)
+        .then(|| matches.into_iter().next())
+        .flatten()
+}
diff --git a/crates/ken-core/src/imports/project_inputs.rs b/crates/ken-core/src/imports/project_inputs.rs
new file mode 100644
index 00000000..70707744
--- /dev/null
+++ b/crates/ken-core/src/imports/project_inputs.rs
@@ -0,0 +1,28 @@
+//! Read actual config bytes; alias dependencies remain the alias owner's rule.
+use super::{ImportError, aliases::AliasResolver};
+use std::{collections::BTreeMap, fs, path::Path};
+pub(super) struct ProjectImportInputs {
+    pub bytes: BTreeMap<String, Vec<u8>>,
+    pub aliases: AliasResolver,
+}
+impl ProjectImportInputs {
+    pub fn read(root: &Path, files: &[String]) -> Result<Self, ImportError> {
+        let mut bytes = BTreeMap::new();
+        let aliases = {
+            let mut load = |name: &str| {
+                let value = fs::read(root.join(name)).ok()?;
+                bytes.insert(name.to_owned(), value.clone());
+                Some(value)
+            };
+            AliasResolver::from_loader(files, &mut load)?
+        };
+        for name in files {
+            if (name.ends_with("go.mod") || name.ends_with("composer.json"))
+                && let Ok(value) = fs::read(root.join(name))
+            {
+                bytes.insert(name.clone(), value);
+            }
+        }
+        Ok(Self { bytes, aliases })
+    }
+}
diff --git a/crates/ken-core/src/lib.rs b/crates/ken-core/src/lib.rs
index 36b1e4bc..a7e35bfd 100644
--- a/crates/ken-core/src/lib.rs
+++ b/crates/ken-core/src/lib.rs
@@ -1,8 +1,9 @@
 //! Native project inspection, independent of the Python runtime.
 pub mod health;
+pub mod imports;
 pub mod project;
 mod source_directory;
 pub mod source_filter;
 mod source_patterns;
 pub mod source_walk;
 pub mod status;
diff --git a/crates/ken-core/tests/fixtures/import-alias-edges.json b/crates/ken-core/tests/fixtures/import-alias-edges.json
new file mode 100644
index 00000000..ac424bad
--- /dev/null
+++ b/crates/ken-core/tests/fixtures/import-alias-edges.json
@@ -0,0 +1,545 @@
+{
+  "format": "ken-import-supplements/1",
+  "cases": [
+    {
+      "id": "0dd3d0ce046a80506e2d59030740c5e48d980434681308a6934f9d05d3b4c3a6",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "one/app/value.ts",
+          "two/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22402a223a205b226f6e652f2a225d2c2022406170702f2a223a205b2274776f2f2a225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@app/value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one/app/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "f57cf1072e317fc49aab616d0ff49334c99a414b0a22b9a464cbd6fdca38135c",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "one/app/value.ts",
+          "two/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22406170702f2a223a205b2274776f2f2a225d2c2022402a223a205b226f6e652f2a225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@app/value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "two/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1912d0c6065a8b01cdec1eab5af5aad5e43ddc928ace89fb97fe366cea6c8f1d",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "one/package.json",
+          "two/package.json",
+          "one/sub.ts",
+          "two/index.ts"
+        ],
+        "configs": {
+          "one/package.json": "7b226e616d65223a224073636f70652f706b67227d",
+          "two/package.json": "7b226e616d65223a224073636f70652f706b672f737562227d"
+        },
+        "imports": [
+          {
+            "module": "@scope/pkg/sub",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one/sub.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "a22f5a0df13ed28e756d6350b946477ef5cc2838aa190ab3fbdac5d31c1ce593",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "two/package.json",
+          "one/package.json",
+          "one/sub.ts",
+          "two/index.ts"
+        ],
+        "configs": {
+          "two/package.json": "7b226e616d65223a224073636f70652f706b672f737562227d",
+          "one/package.json": "7b226e616d65223a224073636f70652f706b67227d"
+        },
+        "imports": [
+          {
+            "module": "@scope/pkg/sub",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "two/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "01ef125e21dd18f873718ff6ac8eacab9839d7fc05ac7bf79f1b3e556dbe6a14",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "jsconfig.json",
+          "one.ts",
+          "two.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d",
+          "jsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "e0d905dc83fc01e1e8f54d801b77860e9dfd97c349e18167ee15d605191d931e",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "jsconfig.json",
+          "tsconfig.json",
+          "one.ts",
+          "two.ts"
+        ],
+        "configs": {
+          "jsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d",
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "two.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "d90582779e63593d96c313e066ee809b8716eb32517a6f476efaea636bbaadfb",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "one/package.json",
+          "two/package.json",
+          "one/index.ts",
+          "two/index.ts"
+        ],
+        "configs": {
+          "one/package.json": "7b226e616d65223a2273616d65227d",
+          "two/package.json": "7b226e616d65223a2273616d65227d"
+        },
+        "imports": [
+          {
+            "module": "same",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "two/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "51f8fa1c81ea5dab89d79babb9c5b152f8fa814a9e37860e968577d72bee17c1",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "config/lib/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22657874656e6473223a222e2f636f6e6669672f62617365227d",
+          "config/base.json": "7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a222e2f6c6962222c227061746873223a7b224076616c7565223a5b2276616c7565225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "config/lib/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "9df51d1e32bdeb113822223178066eae1fa2efbb0ee486b20fb03e946a810a7d",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "one.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b226f6e65225d7d7d2c22756e75736564223a225c7564383030227d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "dbae8d801400fbc3a1476d02d88d672eb5a12a7f046663052be2d6c6e670699c",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "one.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b2240612c7d223a205b226f6e65225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@a}",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one.ts",
+          "resolution": "internal"
+        }
+      ]
+    }
+  ],
+  "calls": 10,
+  "discovered": [],
+  "test_states": [],
+  "original_test_exit": 0,
+  "runtime": {
+    "system": "Darwin",
+    "machine": "arm64",
+    "python": "3.12.9"
+  },
+  "owners": {
+    "src/ken/indexer.py": "430dab7bec2d643a17a1cf3a616434b3c4efd0ffe07ea93a279146950377cbd4",
+    "src/ken/jsresolve.py": "228919f225dffc74d193d6e24cab7fe093aed4ec7c8d507e722b3079169efd0a",
+    "tests/conftest.py": "e350ce30ebaf2ee1d2861e1e737c96957478b498a9fcaa8a59f04a5e91933986",
+    "tests/test_indexer.py": "17badc54c148fbfec50db43e35dd1fd0ab8c0914cba8e2bc1a1fd64711e88121"
+  },
+  "script": "\nimport functools,hashlib,json,pathlib,platform,sqlite3,sys,tempfile\nimport pytest\nrequest=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root']).resolve()\nimport tree_sitter_language_pack as pack\npack.configure({'cache_dir':request['grammar_cache']})\nimport ken.indexer as indexer\nimport ken.jsresolve as jsresolve\nfor module in (indexer,jsresolve):\n if not pathlib.Path(module.__file__).resolve().is_relative_to(root):raise ValueError('wrong original import module root')\nactual_resolve=indexer._resolve_internal_imports;actual_load=jsresolve._load_jsonc\nobserved={};active_test=None;active_configs=None;discovered=[];states=[];calls=0\n\ndef load(project,rel):\n if active_configs is not None:\n  try:active_configs[rel]=(project/rel).read_bytes().hex()\n  except OSError:pass\n return actual_load(project,rel)\njsresolve._load_jsonc=load\n\n@functools.wraps(actual_resolve)\ndef resolve(conn,project_root=None):\n global calls,active_configs\n imports=conn.execute('SELECT i.id,i.to_module,f.path AS src,f.language AS lang FROM ci_imports i JOIN ci_files f ON f.id=i.from_file_id WHERE i.to_file_id IS NULL').fetchall()\n if not imports:return actual_resolve(conn,project_root)\n calls+=1\n files=[r['path']for r in conn.execute('SELECT id,path FROM ci_files')]\n configs=None if project_root is None else {}\n if configs is not None:\n  for path in files:\n   if path.endswith(('go.mod','composer.json')):\n    try:configs[path]=(project_root/path).read_bytes().hex()\n    except OSError:pass\n inputs=[dict(module=r['to_module'],source_path=r['src'],language=r['lang'])for r in imports]\n structural=[indexer._resolve_import_target(r['module'],files,source_path=r['source_path'])for r in inputs]\n old=active_configs;active_configs=configs\n error=None\n try:actual_resolve(conn,project_root)\n except Exception as failure:error=dict(type=type(failure).__name__,message=str(failure))\n finally:active_configs=old\n definition=dict(files=files,configs=configs,imports=inputs)\n identity=hashlib.sha256(json.dumps(definition,sort_keys=True,ensure_ascii=True).encode()).hexdigest()\n result=dict(id=identity,input=definition,structural_targets=structural,tests=[active_test]if active_test else[],calls=1)\n if error is not None:result['error']=error\n else:\n  values={r['id']:dict(target=r['target'],resolution=r['resolution'])for r in conn.execute('SELECT i.id,f.path AS target,i.resolution FROM ci_imports i LEFT JOIN ci_files f ON f.id=i.to_file_id')}\n  result['results']=[values[r['id']]for r in imports]\n if identity in observed:\n  existing=observed[identity]\n  if {k:v for k,v in result.items()if k not in ('tests','calls')}!={k:v for k,v in existing.items()if k not in ('tests','calls')}:raise ValueError('nondeterministic original resolution')\n  existing['calls']+=1\n  if active_test and active_test not in existing['tests']:existing['tests'].append(active_test)\n else:observed[identity]=result\n if error is not None:raise RuntimeError('observed original resolution error: '+str(error))\nindexer._resolve_internal_imports=resolve\n\nclass Plugin:\n def pytest_collection_finish(self,session):discovered.extend(item.nodeid for item in session.items)\n def pytest_runtest_setup(self,item):\n  global active_test\n  active_test=item.nodeid\n def pytest_runtest_logreport(self,report):\n  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))\nexit_code=0\nactive_test=None\nfor definition in request['supplements']:\n with tempfile.TemporaryDirectory(prefix='ken-original-import-')as directory:\n  project=pathlib.Path(directory)\n  for path,raw in (definition['configs']or{}).items():\n   target=project/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytes.fromhex(raw))\n  conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row\n  conn.executescript('CREATE TABLE ci_files(id INTEGER PRIMARY KEY,path TEXT,language TEXT); CREATE TABLE ci_imports(id INTEGER PRIMARY KEY,from_file_id INTEGER,to_module TEXT,to_file_id INTEGER,resolution TEXT);')\n  languages={r['source_path']:r['language']for r in definition['imports']}\n  for i,path in enumerate(definition['files'],1):conn.execute('INSERT INTO ci_files VALUES(?,?,?)',(i,path,languages.get(path)))\n  ids={r['path']:r['id']for r in conn.execute('SELECT id,path FROM ci_files')}\n  for i,row in enumerate(definition['imports'],1):conn.execute('INSERT INTO ci_imports(id,from_file_id,to_module)VALUES(?,?,?)',(i,ids[row['source_path']],row['module']))\n  try:resolve(conn,None if definition['configs']is None else project)\n  except RuntimeError:pass\n  conn.close()\nresult=dict(format='ken-import-reference/1',cases=list(observed.values()),calls=calls,discovered=discovered,test_states=states,original_test_exit=exit_code,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version()))\npathlib.Path(request['result']).write_text(json.dumps(result,ensure_ascii=True)+'\\n')\nsys.exit(exit_code)\n",
+  "execution": {
+    "exit": 0,
+    "stdout": "",
+    "stderr": "",
+    "observations": "{\"format\": \"ken-import-reference/1\", \"cases\": [{\"id\": \"0dd3d0ce046a80506e2d59030740c5e48d980434681308a6934f9d05d3b4c3a6\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"one/app/value.ts\", \"two/value.ts\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22402a223a205b226f6e652f2a225d2c2022406170702f2a223a205b2274776f2f2a225d7d7d7d\"}, \"imports\": [{\"module\": \"@app/value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one/app/value.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"f57cf1072e317fc49aab616d0ff49334c99a414b0a22b9a464cbd6fdca38135c\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"one/app/value.ts\", \"two/value.ts\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22406170702f2a223a205b2274776f2f2a225d2c2022402a223a205b226f6e652f2a225d7d7d7d\"}, \"imports\": [{\"module\": \"@app/value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"two/value.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"1912d0c6065a8b01cdec1eab5af5aad5e43ddc928ace89fb97fe366cea6c8f1d\", \"input\": {\"files\": [\"src/main.ts\", \"one/package.json\", \"two/package.json\", \"one/sub.ts\", \"two/index.ts\"], \"configs\": {\"one/package.json\": \"7b226e616d65223a224073636f70652f706b67227d\", \"two/package.json\": \"7b226e616d65223a224073636f70652f706b672f737562227d\"}, \"imports\": [{\"module\": \"@scope/pkg/sub\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one/sub.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"a22f5a0df13ed28e756d6350b946477ef5cc2838aa190ab3fbdac5d31c1ce593\", \"input\": {\"files\": [\"src/main.ts\", \"two/package.json\", \"one/package.json\", \"one/sub.ts\", \"two/index.ts\"], \"configs\": {\"two/package.json\": \"7b226e616d65223a224073636f70652f706b672f737562227d\", \"one/package.json\": \"7b226e616d65223a224073636f70652f706b67227d\"}, \"imports\": [{\"module\": \"@scope/pkg/sub\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"two/index.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"01ef125e21dd18f873718ff6ac8eacab9839d7fc05ac7bf79f1b3e556dbe6a14\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"jsconfig.json\", \"one.ts\", \"two.ts\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d\", \"jsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"e0d905dc83fc01e1e8f54d801b77860e9dfd97c349e18167ee15d605191d931e\", \"input\": {\"files\": [\"src/main.ts\", \"jsconfig.json\", \"tsconfig.json\", \"one.ts\", \"two.ts\"], \"configs\": {\"jsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d\", \"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"two.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"d90582779e63593d96c313e066ee809b8716eb32517a6f476efaea636bbaadfb\", \"input\": {\"files\": [\"src/main.ts\", \"one/package.json\", \"two/package.json\", \"one/index.ts\", \"two/index.ts\"], \"configs\": {\"one/package.json\": \"7b226e616d65223a2273616d65227d\", \"two/package.json\": \"7b226e616d65223a2273616d65227d\"}, \"imports\": [{\"module\": \"same\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"two/index.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"51f8fa1c81ea5dab89d79babb9c5b152f8fa814a9e37860e968577d72bee17c1\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"config/lib/value.ts\"], \"configs\": {\"tsconfig.json\": \"7b22657874656e6473223a222e2f636f6e6669672f62617365227d\", \"config/base.json\": \"7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a222e2f6c6962222c227061746873223a7b224076616c7565223a5b2276616c7565225d7d7d7d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"config/lib/value.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"9df51d1e32bdeb113822223178066eae1fa2efbb0ee486b20fb03e946a810a7d\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"one.ts\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b226f6e65225d7d7d2c22756e75736564223a225c7564383030227d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"dbae8d801400fbc3a1476d02d88d672eb5a12a7f046663052be2d6c6e670699c\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\", \"one.ts\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b2240612c7d223a205b226f6e65225d7d7d7d\"}, \"imports\": [{\"module\": \"@a}\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one.ts\", \"resolution\": \"internal\"}]}], \"calls\": 10, \"discovered\": [], \"test_states\": [], \"original_test_exit\": 0, \"runtime\": {\"system\": \"Darwin\", \"machine\": \"arm64\", \"python\": \"3.12.9\"}}\n"
+  },
+  "definitions": [
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "one/app/value.ts",
+        "two/value.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22402a223a205b226f6e652f2a225d2c2022406170702f2a223a205b2274776f2f2a225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@app/value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "one/app/value.ts",
+        "two/value.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b22406170702f2a223a205b2274776f2f2a225d2c2022402a223a205b226f6e652f2a225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@app/value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "one/package.json",
+        "two/package.json",
+        "one/sub.ts",
+        "two/index.ts"
+      ],
+      "configs": {
+        "one/package.json": "7b226e616d65223a224073636f70652f706b67227d",
+        "two/package.json": "7b226e616d65223a224073636f70652f706b672f737562227d"
+      },
+      "imports": [
+        {
+          "module": "@scope/pkg/sub",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "two/package.json",
+        "one/package.json",
+        "one/sub.ts",
+        "two/index.ts"
+      ],
+      "configs": {
+        "one/package.json": "7b226e616d65223a224073636f70652f706b67227d",
+        "two/package.json": "7b226e616d65223a224073636f70652f706b672f737562227d"
+      },
+      "imports": [
+        {
+          "module": "@scope/pkg/sub",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "jsconfig.json",
+        "one.ts",
+        "two.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d",
+        "jsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "jsconfig.json",
+        "tsconfig.json",
+        "one.ts",
+        "two.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b226f6e65225d7d7d7d",
+        "jsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b224076616c7565223a205b2274776f225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "one/package.json",
+        "two/package.json",
+        "one/index.ts",
+        "two/index.ts"
+      ],
+      "configs": {
+        "one/package.json": "7b226e616d65223a2273616d65227d",
+        "two/package.json": "7b226e616d65223a2273616d65227d"
+      },
+      "imports": [
+        {
+          "module": "same",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "config/lib/value.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22657874656e6473223a222e2f636f6e6669672f62617365227d",
+        "config/base.json": "7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a222e2f6c6962222c227061746873223a7b224076616c7565223a5b2276616c7565225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "one.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b226f6e65225d7d7d2c22756e75736564223a225c7564383030227d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json",
+        "one.ts"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a207b227061746873223a207b2240612c7d223a205b226f6e65225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@a}",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    }
+  ]
+}
diff --git a/crates/ken-core/tests/fixtures/import-alias-surrogates.json b/crates/ken-core/tests/fixtures/import-alias-surrogates.json
new file mode 100644
index 00000000..0e2cc16c
--- /dev/null
+++ b/crates/ken-core/tests/fixtures/import-alias-surrogates.json
@@ -0,0 +1,121 @@
+{
+  "format": "ken-import-supplements/1",
+  "cases": [
+    {
+      "id": "28807e5223357963c74a2dc0aad7120d3640e36a7ce6718d6de6b151527c49f1",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a225c7564383030227d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "90dd2c7ddeb1ddd72a41468c906d41f571cf9c6fbac2957d4aa8da57ae2209ec",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a225c7564383030222c227061746873223a7b224076616c7565223a5b226f6e65225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    }
+  ],
+  "calls": 2,
+  "discovered": [],
+  "test_states": [],
+  "original_test_exit": 0,
+  "runtime": {
+    "system": "Darwin",
+    "machine": "arm64",
+    "python": "3.12.9"
+  },
+  "owners": {
+    "src/ken/indexer.py": "430dab7bec2d643a17a1cf3a616434b3c4efd0ffe07ea93a279146950377cbd4",
+    "src/ken/jsresolve.py": "228919f225dffc74d193d6e24cab7fe093aed4ec7c8d507e722b3079169efd0a",
+    "tests/conftest.py": "e350ce30ebaf2ee1d2861e1e737c96957478b498a9fcaa8a59f04a5e91933986",
+    "tests/test_indexer.py": "17badc54c148fbfec50db43e35dd1fd0ab8c0914cba8e2bc1a1fd64711e88121"
+  },
+  "script": "\nimport functools,hashlib,json,pathlib,platform,sqlite3,sys,tempfile\nimport pytest\nrequest=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root']).resolve()\nimport tree_sitter_language_pack as pack\npack.configure({'cache_dir':request['grammar_cache']})\nimport ken.indexer as indexer\nimport ken.jsresolve as jsresolve\nfor module in (indexer,jsresolve):\n if not pathlib.Path(module.__file__).resolve().is_relative_to(root):raise ValueError('wrong original import module root')\nactual_resolve=indexer._resolve_internal_imports;actual_load=jsresolve._load_jsonc\nobserved={};active_test=None;active_configs=None;discovered=[];states=[];calls=0\n\ndef load(project,rel):\n if active_configs is not None:\n  try:active_configs[rel]=(project/rel).read_bytes().hex()\n  except OSError:pass\n return actual_load(project,rel)\njsresolve._load_jsonc=load\n\n@functools.wraps(actual_resolve)\ndef resolve(conn,project_root=None):\n global calls,active_configs\n imports=conn.execute('SELECT i.id,i.to_module,f.path AS src,f.language AS lang FROM ci_imports i JOIN ci_files f ON f.id=i.from_file_id WHERE i.to_file_id IS NULL').fetchall()\n if not imports:return actual_resolve(conn,project_root)\n calls+=1\n files=[r['path']for r in conn.execute('SELECT id,path FROM ci_files')]\n configs=None if project_root is None else {}\n if configs is not None:\n  for path in files:\n   if path.endswith(('go.mod','composer.json')):\n    try:configs[path]=(project_root/path).read_bytes().hex()\n    except OSError:pass\n inputs=[dict(module=r['to_module'],source_path=r['src'],language=r['lang'])for r in imports]\n structural=[indexer._resolve_import_target(r['module'],files,source_path=r['source_path'])for r in inputs]\n old=active_configs;active_configs=configs\n error=None\n try:actual_resolve(conn,project_root)\n except Exception as failure:error=dict(type=type(failure).__name__,message=str(failure))\n finally:active_configs=old\n definition=dict(files=files,configs=configs,imports=inputs)\n identity=hashlib.sha256(json.dumps(definition,sort_keys=True,ensure_ascii=True).encode()).hexdigest()\n result=dict(id=identity,input=definition,structural_targets=structural,tests=[active_test]if active_test else[],calls=1)\n if error is not None:result['error']=error\n else:\n  values={r['id']:dict(target=r['target'],resolution=r['resolution'])for r in conn.execute('SELECT i.id,f.path AS target,i.resolution FROM ci_imports i LEFT JOIN ci_files f ON f.id=i.to_file_id')}\n  result['results']=[values[r['id']]for r in imports]\n if identity in observed:\n  existing=observed[identity]\n  if {k:v for k,v in result.items()if k not in ('tests','calls')}!={k:v for k,v in existing.items()if k not in ('tests','calls')}:raise ValueError('nondeterministic original resolution')\n  existing['calls']+=1\n  if active_test and active_test not in existing['tests']:existing['tests'].append(active_test)\n else:observed[identity]=result\n if error is not None:raise RuntimeError('observed original resolution error: '+str(error))\nindexer._resolve_internal_imports=resolve\n\nclass Plugin:\n def pytest_collection_finish(self,session):discovered.extend(item.nodeid for item in session.items)\n def pytest_runtest_setup(self,item):\n  global active_test\n  active_test=item.nodeid\n def pytest_runtest_logreport(self,report):\n  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))\nexit_code=0\nactive_test=None\nfor definition in request['supplements']:\n with tempfile.TemporaryDirectory(prefix='ken-original-import-')as directory:\n  project=pathlib.Path(directory)\n  for path,raw in (definition['configs']or{}).items():\n   target=project/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytes.fromhex(raw))\n  conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row\n  conn.executescript('CREATE TABLE ci_files(id INTEGER PRIMARY KEY,path TEXT,language TEXT); CREATE TABLE ci_imports(id INTEGER PRIMARY KEY,from_file_id INTEGER,to_module TEXT,to_file_id INTEGER,resolution TEXT);')\n  languages={r['source_path']:r['language']for r in definition['imports']}\n  for i,path in enumerate(definition['files'],1):conn.execute('INSERT INTO ci_files VALUES(?,?,?)',(i,path,languages.get(path)))\n  ids={r['path']:r['id']for r in conn.execute('SELECT id,path FROM ci_files')}\n  for i,row in enumerate(definition['imports'],1):conn.execute('INSERT INTO ci_imports(id,from_file_id,to_module)VALUES(?,?,?)',(i,ids[row['source_path']],row['module']))\n  try:resolve(conn,None if definition['configs']is None else project)\n  except RuntimeError:pass\n  conn.close()\nresult=dict(format='ken-import-reference/1',cases=list(observed.values()),calls=calls,discovered=discovered,test_states=states,original_test_exit=exit_code,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version()))\npathlib.Path(request['result']).write_text(json.dumps(result,ensure_ascii=True)+'\\n')\nsys.exit(exit_code)\n",
+  "execution": {
+    "exit": 0,
+    "stdout": "",
+    "stderr": "",
+    "observations": "{\"format\": \"ken-import-reference/1\", \"cases\": [{\"id\": \"28807e5223357963c74a2dc0aad7120d3640e36a7ce6718d6de6b151527c49f1\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a225c7564383030227d7d7d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}, {\"id\": \"90dd2c7ddeb1ddd72a41468c906d41f571cf9c6fbac2957d4aa8da57ae2209ec\", \"input\": {\"files\": [\"src/main.ts\", \"tsconfig.json\"], \"configs\": {\"tsconfig.json\": \"7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a225c7564383030222c227061746873223a7b224076616c7565223a5b226f6e65225d7d7d7d\"}, \"imports\": [{\"module\": \"@value\", \"source_path\": \"src/main.ts\", \"language\": \"typescript\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}], \"calls\": 2, \"discovered\": [], \"test_states\": [], \"original_test_exit\": 0, \"runtime\": {\"system\": \"Darwin\", \"machine\": \"arm64\", \"python\": \"3.12.9\"}}\n"
+  },
+  "definitions": [
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a225c7564383030227d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.ts",
+        "tsconfig.json"
+      ],
+      "configs": {
+        "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a225c7564383030222c227061746873223a7b224076616c7565223a5b226f6e65225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "@value",
+          "source_path": "src/main.ts",
+          "language": "typescript"
+        }
+      ]
+    }
+  ]
+}
diff --git a/crates/ken-core/tests/fixtures/import-language-edges.json b/crates/ken-core/tests/fixtures/import-language-edges.json
new file mode 100644
index 00000000..670619b0
--- /dev/null
+++ b/crates/ken-core/tests/fixtures/import-language-edges.json
@@ -0,0 +1,951 @@
+{
+  "format": "ken-import-supplements/1",
+  "cases": [
+    {
+      "id": "c0de0c095850676f652f1db075caf335ef690e21360a5b2dcf62d3b3e7e09109",
+      "input": {
+        "files": [
+          "src/a/main.rs",
+          "src/a/util.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "self::util::Value",
+            "source_path": "src/a/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/a/util.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "0d1cdca5e12d36a4e574e834527651da82cae613e64d9df1ba5f816b7f782f3c",
+      "input": {
+        "files": [
+          "src/a/b/main.rs",
+          "src/util.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "super::super::util::Value",
+            "source_path": "src/a/b/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/util.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "7480c6162c393a5f57f3cb5b0894d0c8be06323c65f0d71e66efbb95d7078461",
+      "input": {
+        "files": [
+          "src/main.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "self::*",
+            "source_path": "src/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/main.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "d9bb77a7d54362bc2038ff34c82be24595c01ded57f9a1318e83c7502c0a562e",
+      "input": {
+        "files": [
+          "src/main.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "crate::missing",
+            "source_path": "src/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "70beb417e51d6857f427bc6d9e53c974de1c6b97deb7d3c0057b2fd1f50b252b",
+      "input": {
+        "files": [
+          "pkg/src/main.rs",
+          "Cargo.toml",
+          "pkg/Cargo.toml",
+          "src/util.rs",
+          "pkg/src/util/mod.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "crate::util::{Foo,Bar}",
+            "source_path": "pkg/src/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "pkg/src/util/mod.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "aaa6763b12ede650e0ec5cd41416966f3ceab5e34a5f59525f88233595abc80e",
+      "input": {
+        "files": [
+          "sub/main.go",
+          "go.mod",
+          "sub/go.mod",
+          "lib/value.go"
+        ],
+        "configs": {
+          "go.mod": "6d6f64756c65206578616d706c650a",
+          "sub/go.mod": "6d6f64756c65206578616d706c650a"
+        },
+        "imports": [
+          {
+            "module": "example/lib",
+            "source_path": "sub/main.go",
+            "language": "go"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "ebcc4c016ed684ad2fc8e8cc65d0c37db48bdb9605d4d7f6380390c2c46c379e",
+      "input": {
+        "files": [
+          "main.go",
+          "go.mod",
+          "lib/a_test.go",
+          "lib/z.go",
+          "lib/b.go"
+        ],
+        "configs": {
+          "go.mod": "6d6f64756c65206578616d706c650a"
+        },
+        "imports": [
+          {
+            "module": "example/lib",
+            "source_path": "main.go",
+            "language": "go"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "lib/b.go",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "65082ff2a90a4671adb1951e6d5f3d116c05cef746bc9fa4d0e9ece9a4e8dfc9",
+      "input": {
+        "files": [
+          "main.java",
+          "src/pkg/A.java"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.*",
+            "source_path": "main.java",
+            "language": "java"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "d7974e2bfe7dfced04a7e728908c0c7b2993107c5f4a92e5faa0e9617deea4da",
+      "input": {
+        "files": [
+          "main.kt",
+          "src/pkg/A.kt"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.*",
+            "source_path": "main.kt",
+            "language": "kotlin"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "00c94cc2a8b5eee630fd156316bb399c04d0d3a10053e236a6af9189c450d1a4",
+      "input": {
+        "files": [
+          "main.kt",
+          "src/foo/bar/A.kt"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "foo.bar.*",
+            "source_path": "main.kt",
+            "language": "kotlin"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "2f957a8278683156bfa6c4c7d30241a575631881affcf552574250ba13e2f0f7",
+      "input": {
+        "files": [
+          "src/main.rb",
+          "src/util.ts",
+          "src/util.rb"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./util",
+            "source_path": "src/main.rb",
+            "language": "ruby"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/util.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/util.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "ee5255cf06288c65552983870a8a1ad635a33c1d232cb21d42820b1d8b8f5c0b",
+      "input": {
+        "files": [
+          "src/main.rb",
+          "src/util.rb"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "util",
+            "source_path": "src/main.rb",
+            "language": "ruby"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "d3011e12ec0cc1aa46d3b588b069a4fd1700a9ed9a2b44f2e4a6c5174e27091e",
+      "input": {
+        "files": [
+          "src/main.cpp",
+          "one/shared.hpp",
+          "two/shared.hpp"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "\"shared.hpp\"",
+            "source_path": "src/main.cpp",
+            "language": "cpp"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "65d1b52c4ad2c946308b4a958bc6980c3120eb14eee9462cffd1d5f08a0da484",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "3/Value.php",
+          "other/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a337d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "3/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "ca31505cf9e2ba7a7db6dc74fdd3d590f52717cf163893038e64acfbe9fb511a",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "3.0/Value.php",
+          "other/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a3365307d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "3.0/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "d4dad55b1aeb72febf749894f41a0a43ce1ee9ee5bd99524bc5bc99adf37f0ac",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "True/Value.php",
+          "other/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a747275657d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "True/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "82990277827f255ee15e6720be3aa7e88f4fed24950595144bc249442bd0744f",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "None/Value.php",
+          "other/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a6e756c6c7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "None/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "8f29b29438019cec8927a7353602f434999d0becb978e45932ec787b8ee2b78b",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "one/Value.php",
+          "two/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a5b226f6e65222c2274776f225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "5ece992793fe605f7b6c3b3544ce68052aebd00d2ffa0e2a5ab284fe1db1a53e",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "one/Value.php",
+          "two/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a226f6e65227d7d2c226175746f6c6f61642d646576223a7b227073722d34223a7b224170705c5c223a2274776f227d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "f54fa12afe44e9142f74879b5cfc5affefe853b0b6e4ef748bd566b0357e090d",
+      "input": {
+        "files": [
+          "main.php",
+          "Value.py",
+          "composer.json",
+          "lib/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b22223a226c6962227d7d7d"
+        },
+        "imports": [
+          {
+            "module": "Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        "Value.py"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "Value.py",
+          "resolution": "internal"
+        }
+      ]
+    }
+  ],
+  "calls": 20,
+  "discovered": [],
+  "test_states": [],
+  "original_test_exit": 0,
+  "runtime": {
+    "system": "Darwin",
+    "machine": "arm64",
+    "python": "3.12.9"
+  },
+  "owners": {
+    "src/ken/indexer.py": "430dab7bec2d643a17a1cf3a616434b3c4efd0ffe07ea93a279146950377cbd4",
+    "src/ken/jsresolve.py": "228919f225dffc74d193d6e24cab7fe093aed4ec7c8d507e722b3079169efd0a",
+    "tests/conftest.py": "e350ce30ebaf2ee1d2861e1e737c96957478b498a9fcaa8a59f04a5e91933986",
+    "tests/test_indexer.py": "17badc54c148fbfec50db43e35dd1fd0ab8c0914cba8e2bc1a1fd64711e88121"
+  },
+  "script": "\nimport functools,hashlib,json,pathlib,platform,sqlite3,sys,tempfile\nimport pytest\nrequest=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root']).resolve()\nimport tree_sitter_language_pack as pack\npack.configure({'cache_dir':request['grammar_cache']})\nimport ken.indexer as indexer\nimport ken.jsresolve as jsresolve\nfor module in (indexer,jsresolve):\n if not pathlib.Path(module.__file__).resolve().is_relative_to(root):raise ValueError('wrong original import module root')\nactual_resolve=indexer._resolve_internal_imports;actual_load=jsresolve._load_jsonc\nobserved={};active_test=None;active_configs=None;discovered=[];states=[];calls=0\n\ndef load(project,rel):\n if active_configs is not None:\n  try:active_configs[rel]=(project/rel).read_bytes().hex()\n  except OSError:pass\n return actual_load(project,rel)\njsresolve._load_jsonc=load\n\n@functools.wraps(actual_resolve)\ndef resolve(conn,project_root=None):\n global calls,active_configs\n imports=conn.execute('SELECT i.id,i.to_module,f.path AS src,f.language AS lang FROM ci_imports i JOIN ci_files f ON f.id=i.from_file_id WHERE i.to_file_id IS NULL').fetchall()\n if not imports:return actual_resolve(conn,project_root)\n calls+=1\n files=[r['path']for r in conn.execute('SELECT id,path FROM ci_files')]\n configs=None if project_root is None else {}\n if configs is not None:\n  for path in files:\n   if path.endswith(('go.mod','composer.json')):\n    try:configs[path]=(project_root/path).read_bytes().hex()\n    except OSError:pass\n inputs=[dict(module=r['to_module'],source_path=r['src'],language=r['lang'])for r in imports]\n structural=[indexer._resolve_import_target(r['module'],files,source_path=r['source_path'])for r in inputs]\n old=active_configs;active_configs=configs\n error=None\n try:actual_resolve(conn,project_root)\n except Exception as failure:error=dict(type=type(failure).__name__,message=str(failure))\n finally:active_configs=old\n definition=dict(files=files,configs=configs,imports=inputs)\n identity=hashlib.sha256(json.dumps(definition,sort_keys=True,ensure_ascii=True).encode()).hexdigest()\n result=dict(id=identity,input=definition,structural_targets=structural,tests=[active_test]if active_test else[],calls=1)\n if error is not None:result['error']=error\n else:\n  values={r['id']:dict(target=r['target'],resolution=r['resolution'])for r in conn.execute('SELECT i.id,f.path AS target,i.resolution FROM ci_imports i LEFT JOIN ci_files f ON f.id=i.to_file_id')}\n  result['results']=[values[r['id']]for r in imports]\n if identity in observed:\n  existing=observed[identity]\n  if {k:v for k,v in result.items()if k not in ('tests','calls')}!={k:v for k,v in existing.items()if k not in ('tests','calls')}:raise ValueError('nondeterministic original resolution')\n  existing['calls']+=1\n  if active_test and active_test not in existing['tests']:existing['tests'].append(active_test)\n else:observed[identity]=result\n if error is not None:raise RuntimeError('observed original resolution error: '+str(error))\nindexer._resolve_internal_imports=resolve\n\nclass Plugin:\n def pytest_collection_finish(self,session):discovered.extend(item.nodeid for item in session.items)\n def pytest_runtest_setup(self,item):\n  global active_test\n  active_test=item.nodeid\n def pytest_runtest_logreport(self,report):\n  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))\nexit_code=0\nactive_test=None\nfor definition in request['supplements']:\n with tempfile.TemporaryDirectory(prefix='ken-original-import-')as directory:\n  project=pathlib.Path(directory)\n  for path,raw in (definition['configs']or{}).items():\n   target=project/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytes.fromhex(raw))\n  conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row\n  conn.executescript('CREATE TABLE ci_files(id INTEGER PRIMARY KEY,path TEXT,language TEXT); CREATE TABLE ci_imports(id INTEGER PRIMARY KEY,from_file_id INTEGER,to_module TEXT,to_file_id INTEGER,resolution TEXT);')\n  languages={r['source_path']:r['language']for r in definition['imports']}\n  for i,path in enumerate(definition['files'],1):conn.execute('INSERT INTO ci_files VALUES(?,?,?)',(i,path,languages.get(path)))\n  ids={r['path']:r['id']for r in conn.execute('SELECT id,path FROM ci_files')}\n  for i,row in enumerate(definition['imports'],1):conn.execute('INSERT INTO ci_imports(id,from_file_id,to_module)VALUES(?,?,?)',(i,ids[row['source_path']],row['module']))\n  try:resolve(conn,None if definition['configs']is None else project)\n  except RuntimeError:pass\n  conn.close()\nresult=dict(format='ken-import-reference/1',cases=list(observed.values()),calls=calls,discovered=discovered,test_states=states,original_test_exit=exit_code,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version()))\npathlib.Path(request['result']).write_text(json.dumps(result,ensure_ascii=True)+'\\n')\nsys.exit(exit_code)\n",
+  "execution": {
+    "exit": 0,
+    "stdout": "",
+    "stderr": "",
+    "observations": "{\"format\": \"ken-import-reference/1\", \"cases\": [{\"id\": \"c0de0c095850676f652f1db075caf335ef690e21360a5b2dcf62d3b3e7e09109\", \"input\": {\"files\": [\"src/a/main.rs\", \"src/a/util.rs\"], \"configs\": {}, \"imports\": [{\"module\": \"self::util::Value\", \"source_path\": \"src/a/main.rs\", \"language\": \"rust\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"src/a/util.rs\", \"resolution\": \"internal\"}]}, {\"id\": \"0d1cdca5e12d36a4e574e834527651da82cae613e64d9df1ba5f816b7f782f3c\", \"input\": {\"files\": [\"src/a/b/main.rs\", \"src/util.rs\"], \"configs\": {}, \"imports\": [{\"module\": \"super::super::util::Value\", \"source_path\": \"src/a/b/main.rs\", \"language\": \"rust\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"src/util.rs\", \"resolution\": \"internal\"}]}, {\"id\": \"7480c6162c393a5f57f3cb5b0894d0c8be06323c65f0d71e66efbb95d7078461\", \"input\": {\"files\": [\"src/main.rs\"], \"configs\": {}, \"imports\": [{\"module\": \"self::*\", \"source_path\": \"src/main.rs\", \"language\": \"rust\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"src/main.rs\", \"resolution\": \"internal\"}]}, {\"id\": \"d9bb77a7d54362bc2038ff34c82be24595c01ded57f9a1318e83c7502c0a562e\", \"input\": {\"files\": [\"src/main.rs\"], \"configs\": {}, \"imports\": [{\"module\": \"crate::missing\", \"source_path\": \"src/main.rs\", \"language\": \"rust\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}, {\"id\": \"70beb417e51d6857f427bc6d9e53c974de1c6b97deb7d3c0057b2fd1f50b252b\", \"input\": {\"files\": [\"pkg/src/main.rs\", \"Cargo.toml\", \"pkg/Cargo.toml\", \"src/util.rs\", \"pkg/src/util/mod.rs\"], \"configs\": {}, \"imports\": [{\"module\": \"crate::util::{Foo,Bar}\", \"source_path\": \"pkg/src/main.rs\", \"language\": \"rust\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"pkg/src/util/mod.rs\", \"resolution\": \"internal\"}]}, {\"id\": \"aaa6763b12ede650e0ec5cd41416966f3ceab5e34a5f59525f88233595abc80e\", \"input\": {\"files\": [\"sub/main.go\", \"go.mod\", \"sub/go.mod\", \"lib/value.go\"], \"configs\": {\"go.mod\": \"6d6f64756c65206578616d706c650a\", \"sub/go.mod\": \"6d6f64756c65206578616d706c650a\"}, \"imports\": [{\"module\": \"example/lib\", \"source_path\": \"sub/main.go\", \"language\": \"go\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}, {\"id\": \"ebcc4c016ed684ad2fc8e8cc65d0c37db48bdb9605d4d7f6380390c2c46c379e\", \"input\": {\"files\": [\"main.go\", \"go.mod\", \"lib/a_test.go\", \"lib/z.go\", \"lib/b.go\"], \"configs\": {\"go.mod\": \"6d6f64756c65206578616d706c650a\"}, \"imports\": [{\"module\": \"example/lib\", \"source_path\": \"main.go\", \"language\": \"go\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"lib/b.go\", \"resolution\": \"internal\"}]}, {\"id\": \"65082ff2a90a4671adb1951e6d5f3d116c05cef746bc9fa4d0e9ece9a4e8dfc9\", \"input\": {\"files\": [\"main.java\", \"src/pkg/A.java\"], \"configs\": {}, \"imports\": [{\"module\": \"pkg.*\", \"source_path\": \"main.java\", \"language\": \"java\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"external\"}]}, {\"id\": \"d7974e2bfe7dfced04a7e728908c0c7b2993107c5f4a92e5faa0e9617deea4da\", \"input\": {\"files\": [\"main.kt\", \"src/pkg/A.kt\"], \"configs\": {}, \"imports\": [{\"module\": \"pkg.*\", \"source_path\": \"main.kt\", \"language\": \"kotlin\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}, {\"id\": \"00c94cc2a8b5eee630fd156316bb399c04d0d3a10053e236a6af9189c450d1a4\", \"input\": {\"files\": [\"main.kt\", \"src/foo/bar/A.kt\"], \"configs\": {}, \"imports\": [{\"module\": \"foo.bar.*\", \"source_path\": \"main.kt\", \"language\": \"kotlin\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"external\"}]}, {\"id\": \"2f957a8278683156bfa6c4c7d30241a575631881affcf552574250ba13e2f0f7\", \"input\": {\"files\": [\"src/main.rb\", \"src/util.ts\", \"src/util.rb\"], \"configs\": {}, \"imports\": [{\"module\": \"./util\", \"source_path\": \"src/main.rb\", \"language\": \"ruby\"}]}, \"structural_targets\": [\"src/util.ts\"], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"src/util.ts\", \"resolution\": \"internal\"}]}, {\"id\": \"ee5255cf06288c65552983870a8a1ad635a33c1d232cb21d42820b1d8b8f5c0b\", \"input\": {\"files\": [\"src/main.rb\", \"src/util.rb\"], \"configs\": {}, \"imports\": [{\"module\": \"util\", \"source_path\": \"src/main.rb\", \"language\": \"ruby\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"external\"}]}, {\"id\": \"d3011e12ec0cc1aa46d3b588b069a4fd1700a9ed9a2b44f2e4a6c5174e27091e\", \"input\": {\"files\": [\"src/main.cpp\", \"one/shared.hpp\", \"two/shared.hpp\"], \"configs\": {}, \"imports\": [{\"module\": \"\\\"shared.hpp\\\"\", \"source_path\": \"src/main.cpp\", \"language\": \"cpp\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": null, \"resolution\": \"unresolved\"}]}, {\"id\": \"65d1b52c4ad2c946308b4a958bc6980c3120eb14eee9462cffd1d5f08a0da484\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"3/Value.php\", \"other/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a337d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"3/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"ca31505cf9e2ba7a7db6dc74fdd3d590f52717cf163893038e64acfbe9fb511a\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"3.0/Value.php\", \"other/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a3365307d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"3.0/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"d4dad55b1aeb72febf749894f41a0a43ce1ee9ee5bd99524bc5bc99adf37f0ac\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"True/Value.php\", \"other/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a747275657d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"True/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"82990277827f255ee15e6720be3aa7e88f4fed24950595144bc249442bd0744f\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"None/Value.php\", \"other/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a6e756c6c7d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"None/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"8f29b29438019cec8927a7353602f434999d0becb978e45932ec787b8ee2b78b\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"one/Value.php\", \"two/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a5b226f6e65222c2274776f225d7d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"5ece992793fe605f7b6c3b3544ce68052aebd00d2ffa0e2a5ab284fe1db1a53e\", \"input\": {\"files\": [\"main.php\", \"composer.json\", \"one/Value.php\", \"two/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a226f6e65227d7d2c226175746f6c6f61642d646576223a7b227073722d34223a7b224170705c5c223a2274776f227d7d7d\"}, \"imports\": [{\"module\": \"App\\\\Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [null], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"one/Value.php\", \"resolution\": \"internal\"}]}, {\"id\": \"f54fa12afe44e9142f74879b5cfc5affefe853b0b6e4ef748bd566b0357e090d\", \"input\": {\"files\": [\"main.php\", \"Value.py\", \"composer.json\", \"lib/Value.php\"], \"configs\": {\"composer.json\": \"7b226175746f6c6f6164223a7b227073722d34223a7b22223a226c6962227d7d7d\"}, \"imports\": [{\"module\": \"Value\", \"source_path\": \"main.php\", \"language\": \"php\"}]}, \"structural_targets\": [\"Value.py\"], \"tests\": [], \"calls\": 1, \"results\": [{\"target\": \"Value.py\", \"resolution\": \"internal\"}]}], \"calls\": 20, \"discovered\": [], \"test_states\": [], \"original_test_exit\": 0, \"runtime\": {\"system\": \"Darwin\", \"machine\": \"arm64\", \"python\": \"3.12.9\"}}\n"
+  },
+  "definitions": [
+    {
+      "files": [
+        "src/a/main.rs",
+        "src/a/util.rs"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "self::util::Value",
+          "source_path": "src/a/main.rs",
+          "language": "rust"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/a/b/main.rs",
+        "src/util.rs"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "super::super::util::Value",
+          "source_path": "src/a/b/main.rs",
+          "language": "rust"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.rs"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "self::*",
+          "source_path": "src/main.rs",
+          "language": "rust"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.rs"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "crate::missing",
+          "source_path": "src/main.rs",
+          "language": "rust"
+        }
+      ]
+    },
+    {
+      "files": [
+        "pkg/src/main.rs",
+        "Cargo.toml",
+        "pkg/Cargo.toml",
+        "src/util.rs",
+        "pkg/src/util/mod.rs"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "crate::util::{Foo,Bar}",
+          "source_path": "pkg/src/main.rs",
+          "language": "rust"
+        }
+      ]
+    },
+    {
+      "files": [
+        "sub/main.go",
+        "go.mod",
+        "sub/go.mod",
+        "lib/value.go"
+      ],
+      "configs": {
+        "go.mod": "6d6f64756c65206578616d706c650a",
+        "sub/go.mod": "6d6f64756c65206578616d706c650a"
+      },
+      "imports": [
+        {
+          "module": "example/lib",
+          "source_path": "sub/main.go",
+          "language": "go"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.go",
+        "go.mod",
+        "lib/a_test.go",
+        "lib/z.go",
+        "lib/b.go"
+      ],
+      "configs": {
+        "go.mod": "6d6f64756c65206578616d706c650a"
+      },
+      "imports": [
+        {
+          "module": "example/lib",
+          "source_path": "main.go",
+          "language": "go"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.java",
+        "src/pkg/A.java"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "pkg.*",
+          "source_path": "main.java",
+          "language": "java"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.kt",
+        "src/pkg/A.kt"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "pkg.*",
+          "source_path": "main.kt",
+          "language": "kotlin"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.kt",
+        "src/foo/bar/A.kt"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "foo.bar.*",
+          "source_path": "main.kt",
+          "language": "kotlin"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.rb",
+        "src/util.ts",
+        "src/util.rb"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "./util",
+          "source_path": "src/main.rb",
+          "language": "ruby"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.rb",
+        "src/util.rb"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "util",
+          "source_path": "src/main.rb",
+          "language": "ruby"
+        }
+      ]
+    },
+    {
+      "files": [
+        "src/main.cpp",
+        "one/shared.hpp",
+        "two/shared.hpp"
+      ],
+      "configs": {},
+      "imports": [
+        {
+          "module": "\"shared.hpp\"",
+          "source_path": "src/main.cpp",
+          "language": "cpp"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "3/Value.php",
+        "other/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a337d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "3.0/Value.php",
+        "other/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a3365307d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "True/Value.php",
+        "other/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a747275657d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "None/Value.php",
+        "other/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a6e756c6c7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "one/Value.php",
+        "two/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a5b226f6e65222c2274776f225d7d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "composer.json",
+        "one/Value.php",
+        "two/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a226f6e65227d7d2c226175746f6c6f61642d646576223a7b227073722d34223a7b224170705c5c223a2274776f227d7d7d"
+      },
+      "imports": [
+        {
+          "module": "App\\Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    },
+    {
+      "files": [
+        "main.php",
+        "Value.py",
+        "composer.json",
+        "lib/Value.php"
+      ],
+      "configs": {
+        "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b22223a226c6962227d7d7d"
+      },
+      "imports": [
+        {
+          "module": "Value",
+          "source_path": "main.php",
+          "language": "php"
+        }
+      ]
+    }
+  ]
+}
diff --git a/crates/ken-core/tests/fixtures/import-reference.json b/crates/ken-core/tests/fixtures/import-reference.json
new file mode 100644
index 00000000..acece3e0
--- /dev/null
+++ b/crates/ken-core/tests/fixtures/import-reference.json
@@ -0,0 +1,1979 @@
+{
+  "format": "ken-import-reference/1",
+  "cases": [
+    {
+      "id": "7a74137b70ecf46be4b692d8f0896c5b940841bc94e49166d4a54a512e558b92",
+      "input": {
+        "files": [
+          "mod.py"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "os",
+            "source_path": "mod.py",
+            "language": "python"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_persists_symbols_and_imports"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "f31c6052ed6c5e0878bdceaa02a6e47c2eaa8db19ec6feaa24a5137f0cdca9d1",
+      "input": {
+        "files": [
+          "main.py",
+          "pkg/util.py"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.util",
+            "source_path": "main.py",
+            "language": "python"
+          }
+        ]
+      },
+      "structural_targets": [
+        "pkg/util.py"
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_internal_python_import"
+      ],
+      "calls": 2,
+      "results": [
+        {
+          "target": "pkg/util.py",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "e3d4ef66cd9cd674c611edc942de746cefe48f17334f1d3a48a95000ad76277e",
+      "input": {
+        "files": [
+          "src/app.ts",
+          "src/lib.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./lib",
+            "source_path": "src/app.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/lib.ts"
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_ts_relative_import"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/lib.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "5f2205f63cc64bef6622def0ba01b1b2e0be24944b33e25d1ea58c4b24d2ac42",
+      "input": {
+        "files": [
+          "src/cache.ts",
+          "src/use.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./cache.js",
+            "source_path": "src/use.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/cache.ts"
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_ts_esm_js_extension"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/cache.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "e3ca2e0d996659d1206bf1498a954e9020c83901f339b1582aa291044f9b410c",
+      "input": {
+        "files": [
+          "src/app.ts",
+          "src/comp/index.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./comp",
+            "source_path": "src/app.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/comp/index.ts"
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_relative_index_file"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/comp/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "4d1b243347fd1b9f78e99b75184f211b12128e39bb182001dbcdf43220907cad",
+      "input": {
+        "files": [
+          "app/src/main.ts",
+          "app/src/utils/debug.ts",
+          "app/tsconfig.json"
+        ],
+        "configs": {
+          "app/tsconfig.json": "7b0a20202f2f206a736f6e6320636f6d6d656e740a202022636f6d70696c65724f7074696f6e73223a207b0a20202020226261736555726c223a20222e222c0a20202020227061746873223a207b2022402f2a223a205b227372632f2a225d207d2c0a20207d0a7d0a"
+        },
+        "imports": [
+          {
+            "module": "@/utils/debug",
+            "source_path": "app/src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_tsconfig_path_alias"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "app/src/utils/debug.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "65dc8987f0692bff8c5a4a030ea6b2ee3a6233edb4c618a52aa21db073941054",
+      "input": {
+        "files": [
+          "app/src/use.ts",
+          "packages/shared/package.json",
+          "packages/shared/src/index.ts"
+        ],
+        "configs": {
+          "packages/shared/package.json": "7b226e616d65223a20224061636d652f736861726564227d0a"
+        },
+        "imports": [
+          {
+            "module": "@acme/shared/src/index",
+            "source_path": "app/src/use.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_workspace_package"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "packages/shared/src/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1f1ac87afbca87e08bf038b8e1a85f4cc7da29692ece4b4697173cac9da8e144",
+      "input": {
+        "files": [
+          "src/main/java/com/acme/App.java",
+          "src/main/java/com/acme/Helper.java"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "com.acme.Helper",
+            "source_path": "src/main/java/com/acme/App.java",
+            "language": "java"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_java_package_import"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/main/java/com/acme/Helper.java",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "3ad8a3d37b3cfed88fe5832947ff1583b28ddb7cc1a210e094f2beb441c9c956",
+      "input": {
+        "files": [
+          "Cargo.toml",
+          "src/lib.rs",
+          "src/machine.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "crate::machine::Machine",
+            "source_path": "src/lib.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_rust_crate_path"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/machine.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "26336a14f3f9dc38d451672522de971ed072a9c91a4b480972e41394c87bff2b",
+      "input": {
+        "files": [
+          "Cargo.toml",
+          "src/commands/mod.rs",
+          "src/lib.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "crate::commands",
+            "source_path": "src/lib.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_rust_mod_dir"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/commands/mod.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1faadcca78857feedfba019309e3c4cddbe715cff883081af00cf36a0bc45f72",
+      "input": {
+        "files": [
+          "go.mod",
+          "internal/store/store.go",
+          "main.go"
+        ],
+        "configs": {
+          "go.mod": "6d6f64756c65206769746875622e636f6d2f61636d652f70726f6a0a0a676f20312e32310a"
+        },
+        "imports": [
+          {
+            "module": "github.com/acme/proj/internal/store",
+            "source_path": "main.go",
+            "language": "go"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_index_files_resolves_go_module_path"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "internal/store/store.go",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "a420ca216af9a42ca2f1cff75f1ef92f4ea87eed43cd1b8136fc8918c68b2324",
+      "input": {
+        "files": [
+          "app.rb",
+          "lib/util.rb"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./lib/util",
+            "source_path": "app.rb",
+            "language": "ruby"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_resolves_ruby_require_relative"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "lib/util.rb",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "12d4050f525e9b10b5bc11732ee667d873aff4549ef3784b5cb92a32592ace58",
+      "input": {
+        "files": [
+          "inc/helper.hpp",
+          "main.cpp"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "\"inc/helper.hpp\"",
+            "source_path": "main.cpp",
+            "language": "cpp"
+          },
+          {
+            "module": "vector",
+            "source_path": "main.cpp",
+            "language": "cpp"
+          }
+        ]
+      },
+      "structural_targets": [
+        "inc/helper.hpp",
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_resolves_cpp_quoted_include"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "inc/helper.hpp",
+          "resolution": "internal"
+        },
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "034c62100d87111ff85ae2f331322d948632a5b6a77c6f474f9648b23e2d8394",
+      "input": {
+        "files": [
+          "com/app.kt",
+          "com/foo/models.kt"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "com.foo.Baz",
+            "source_path": "com/app.kt",
+            "language": "kotlin"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_resolves_kotlin_package_import"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "com/foo/models.kt",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1521cda655564e30a6e57c7e5bd427d74ab63fc60eda322e62366a54421da398",
+      "input": {
+        "files": [
+          "src/Models/User.php",
+          "src/Service.php"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "App\\Models\\User",
+            "source_path": "src/Service.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_resolves_php_psr4_import"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/Models/User.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "679cd6377d2971ed2f977ef4c968cca6f5f308de0c08babc8aa7eef016567220",
+      "input": {
+        "files": [
+          "src/calc.rs",
+          "src/lib.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "super::*",
+            "source_path": "src/calc.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [
+        "tests/test_indexer.py::test_resolves_rust_super_glob_to_own_file"
+      ],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/calc.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "031f7ef224cdc9ceeb9ba9df68b6d1179b17acdb880514370dfd2e1f98ce0682",
+      "input": {
+        "files": [
+          "main.py",
+          "a/util.py",
+          "b/util.py"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "util",
+            "source_path": "main.py",
+            "language": "python"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "b4e870e7c01e817545d38fd93cc567889f878ebf9b39c3696080ff43321fb6f0",
+      "input": {
+        "files": [
+          "main.py",
+          "a/caf\u00e9.py"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "\u001ccaf\u00e9\u001f",
+            "source_path": "main.py",
+            "language": "python"
+          }
+        ]
+      },
+      "structural_targets": [
+        "a/caf\u00e9.py"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "a/caf\u00e9.py",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "f7af834a51f9764c87c534c42ee95aed2f824f0dfacab91059a3a3c21bfbd09b",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value.js",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "356633f0ff11d53809b9a075351edcecafcd5f3a0b9b66f35a4b8505a0f076d4",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.ts",
+          "src/value.js"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value.js",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.js"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.js",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "9f6b5cb36cca27a08c7c9999a7d49ad1e45e4f9fff0654323a09c14344c4f5e1",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1e5e355f5928cb5d47df5ad8b1ea8a356e0a0d7833a1d8c92386257dd09cea65",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "9b5547db8b789de8302f558abb23005f5824d1869546a03a7e2ff300552a16f0",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.tsx"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.tsx"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.tsx",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "fbf3521b9532b8480de0ed5902fd50d97c9ad8efa997f4b22774333abee8868c",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.tsx"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.tsx"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.tsx",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "f53f289e389ac4fa3747fc71a63e763c53d1c6eee590ce0b8250521481cababc",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.d.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.d.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.d.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "2e92f7116e7cf48943cb42838cb29a861d1a341ebba05086268ba22f8f511384",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.d.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.d.ts"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.d.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "597ff91908855de3226656742bbd77da74a807395c7751ba23e6e6c46441beb8",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.js"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.js"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.js",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "62cd90d8672ab3f54a4d3558711295de811c9c1ccff3e2ec224973cb411a7a0c",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.js"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.js"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.js",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "ffe032a37848dbb734f0e8f792c597a6fda946d608dbe621252ed70b9fd1dfb5",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.jsx"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.jsx"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.jsx",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "523c6ce0a38676a125ba369d38fd4c2f5d8dc01454a6821c0ea67ce7ab74ccaf",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.jsx"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.jsx"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.jsx",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "a29f52ad1cfd567e6226781297bf9358f834cbc9895958a9ad34ef56e1bd12cf",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.mjs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.mjs"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.mjs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "7a68eccd32d1ac7c552cb33093695dba00309ba3965952ca9330143d253dab4e",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.mjs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.mjs"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.mjs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "eafd8a63fe46f4dfbc63d265c36deee791e6b4ee1d1fe374a619a229a71c10d4",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value.cjs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value.cjs"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.cjs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "cef12cdf7604442b31fd73c20f406bc479cedc2cc2e47ffa50079e0cf4ce8c45",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "src/value/index.cjs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "src/value/index.cjs"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value/index.cjs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "c12f80e229aa25659d90a3ffbae1b3ef270f3b08a4d4f411edeb0985514421e0",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "asset.json"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "../../asset.json",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        "asset.json"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "asset.json",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "df494afe8ffa3951808ffb2ed16094b2b9ab7c73458e11d77a9c1936a66eaf9a",
+      "input": {
+        "files": [
+          "main"
+        ],
+        "configs": null,
+        "imports": [
+          {
+            "module": ".missing",
+            "source_path": "main",
+            "language": null
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "d38bbe37907b6248eba0f547b9c31e2b195e127c18bdab6389d2db409dbe5ff9",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "pkg/value.ts",
+          "src/value.ts"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "@app/value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "511a5bf099fc29163ff460d0c8e6c14de1d7a4ae37df70dc7393971752ca94a9",
+      "input": {
+        "files": [
+          "child/main.ts",
+          "tsconfig.json",
+          "child/tsconfig.json",
+          "shared/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b227368617265642f76616c7565225d7d7d7d",
+          "child/tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b226d697373696e67225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "child/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "shared/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "0eac1116a57441e1a1aecccf11b3340f5315697ed3f140a7508713d4c7a3173e",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "shared/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22657874656e6473223a222e2f62617365227d",
+          "base.json": "2f2f20696e6865726974656420636f6e6669670a7b22636f6d70696c65724f7074696f6e73223a7b226261736555726c223a222e222c227061746873223a7b224076616c7565223a5b227368617265642f76616c7565222c5d2c7d2c7d2c7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "shared/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "8b88b4420991348b87f4171a4acb976d8a9b1cbe902ca1270f5edb085a4aace0",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22657874656e6473223a222e2f7473636f6e666967222c22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b22406d697373696e67223a5b226e6f6e65225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@missing",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "1a841674b527e7ebed01aa1e580f04d3a650480e88698513fb6f71d14f02e5ee",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "src/value.ts",
+          "pkg/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b22706b672f76616c7565225d2c224076616c7565223a5b227372632f76616c7565225d7d7d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "999a2d86425a0b6d289dfda3739b27ff15fe65e015b437f8470f72c4e2f417e3",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "src/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b227372632f76616c7565225d7d7d2c22756e75736564223a31653939397d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "720f20f435b6adccf36b36d22ac26b5f2392adcfc2ef0938c8d816ea14d27e5d",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json",
+          "src/value.ts"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a7b227061746873223a7b224076616c7565223a5b227372632f76616c7565225d7d7d2c22756e75736564223a4e614e7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/value.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "d614d4d314ff3c65f19e02be695e114af050a8849be74c2f69d9881b50196cc1",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a5b315d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "error": {
+        "type": "AttributeError",
+        "message": "'list' object has no attribute 'get'"
+      }
+    },
+    {
+      "id": "59c45ebb6a7858b0c3ed093e6a8e76b3bba7d0aa385f679b44ca11fe58ac5010",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b22636f6d70696c65724f7074696f6e73223a5b5d7d"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "feb17b809c720394af579f14b35920ad5185657a92eb81171e7c6b0f3d6ae083",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "tsconfig.json"
+        ],
+        "configs": {
+          "tsconfig.json": "7b2062726f6b656e206a736f6e"
+        },
+        "imports": [
+          {
+            "module": "@value",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "9520c04df97b5a783086f14c38546e8321b1279e7782126acf1d67ac6b02033e",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "pkg/package.json",
+          "pkg/index.ts"
+        ],
+        "configs": {
+          "pkg/package.json": "7b226e616d65223a224073636f70652f706b67227d"
+        },
+        "imports": [
+          {
+            "module": "@scope/pkg",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "pkg/index.ts",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "6a8a38da73ed18567bc70e9297875dc94bdd1992b0b0f05d70909e9610a76d15",
+      "input": {
+        "files": [
+          "src/main.ts",
+          "pkg/package.json",
+          "pkg/index.ts"
+        ],
+        "configs": null,
+        "imports": [
+          {
+            "module": "@scope/pkg",
+            "source_path": "src/main.ts",
+            "language": "typescript"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "external"
+        }
+      ]
+    },
+    {
+      "id": "ecf2b53cf754638ccc4aa025e1796401cb5d16bf865b17b1e5933bc6fc933cc2",
+      "input": {
+        "files": [
+          "crate/src/main.rs",
+          "crate/Cargo.toml",
+          "crate/src/config.rs"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "crate::config::Value",
+            "source_path": "crate/src/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "crate/src/config.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "d24ad93fd6f67f4e796f13f1d312179eb772dc1709e5034f881109c23d07883d",
+      "input": {
+        "files": [
+          "src/main.rs",
+          "Cargo.toml"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "super::*",
+            "source_path": "src/main.rs",
+            "language": "rust"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/main.rs",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "2396f83ca619923a645796d91d32665a176630f4c475ba82deb687bcc10ef7fb",
+      "input": {
+        "files": [
+          "main.go",
+          "go.mod",
+          "internal/a_test.go",
+          "internal/z.go",
+          "internal/b.go"
+        ],
+        "configs": {
+          "go.mod": "6d6f64756c65206578616d706c652e746573742f6170700a"
+        },
+        "imports": [
+          {
+            "module": "example.test/app/internal",
+            "source_path": "main.go",
+            "language": "go"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "internal/b.go",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "7e5a286678f9c3d5e7273e3d253bec43b80e2b753c65a52378a9ab1d897a4227",
+      "input": {
+        "files": [
+          "src/main.rb",
+          "src/util.rb"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "./util",
+            "source_path": "src/main.rb",
+            "language": "ruby"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/util.rb",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "c42ab12a90f82c97b22966c2dd1e3b56f4de61331786707e2bb54a91a3841b9a",
+      "input": {
+        "files": [
+          "main.java",
+          "one/pkg/Value.java",
+          "two/pkg/Value.java"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.Value",
+            "source_path": "main.java",
+            "language": "java"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "b8c23c066d7d6b7d561aca3e6b0efebbfa6f268f648d2183ad0270c7b16ee79b",
+      "input": {
+        "files": [
+          "main.java",
+          "src/pkg/Value.java"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.Value.member",
+            "source_path": "main.java",
+            "language": "java"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "src/pkg/Value.java",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "1786870916a371b0c9e28ffee223de19f3baeb53cb96139f80de486c0e42d65b",
+      "input": {
+        "files": [
+          "one/main.cpp",
+          "one/shared.hpp",
+          "two/shared.hpp"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "\"shared.hpp\"",
+            "source_path": "one/main.cpp",
+            "language": "cpp"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "one/shared.hpp",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "f4d2e7511b675ced8363b0a7ac657aa0d97145bfc580e4718840e04ff88c215b",
+      "input": {
+        "files": [
+          "main.cpp",
+          "vector.py"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "vector",
+            "source_path": "main.cpp",
+            "language": "cpp"
+          }
+        ]
+      },
+      "structural_targets": [
+        "vector.py"
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "vector.py",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "20cee5177e62a9288b507fe9e2ef1f2cf4b577d89a20795fc684d147888481f3",
+      "input": {
+        "files": [
+          "main.kt",
+          "src/pkg/A.kt",
+          "src/pkg/B.kt"
+        ],
+        "configs": {},
+        "imports": [
+          {
+            "module": "pkg.Value",
+            "source_path": "main.kt",
+            "language": "kotlin"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": null,
+          "resolution": "unresolved"
+        }
+      ]
+    },
+    {
+      "id": "dacae383088196680c4b0c0dff4d2f74ecd8a67bf96adac30cd55289de004cc7",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json",
+          "lib/Value.php"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a7b227073722d34223a7b224170705c5c223a226c69622f227d7d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "results": [
+        {
+          "target": "lib/Value.php",
+          "resolution": "internal"
+        }
+      ]
+    },
+    {
+      "id": "fcb840a209d9a406f17a87d1d3fee51d71fd72f56b9da997d28e827d98e38fed",
+      "input": {
+        "files": [
+          "main.php",
+          "composer.json"
+        ],
+        "configs": {
+          "composer.json": "7b226175746f6c6f6164223a5b315d7d"
+        },
+        "imports": [
+          {
+            "module": "App\\Value",
+            "source_path": "main.php",
+            "language": "php"
+          }
+        ]
+      },
+      "structural_targets": [
+        null
+      ],
+      "tests": [],
+      "calls": 1,
+      "error": {
+        "type": "AttributeError",
+        "message": "'list' object has no attribute 'get'"
+      }
+    }
+  ],
+  "calls": 60,
+  "discovered": [
+    "tests/test_indexer.py::test_hash_is_deterministic",
+    "tests/test_indexer.py::test_index_files_skips_too_large",
+    "tests/test_indexer.py::test_index_files_persists_symbols_and_imports",
+    "tests/test_indexer.py::test_index_files_resolves_internal_python_import",
+    "tests/test_indexer.py::test_index_files_resolves_ts_relative_import",
+    "tests/test_indexer.py::test_index_files_resolves_ts_esm_js_extension",
+    "tests/test_indexer.py::test_index_files_resolves_relative_index_file",
+    "tests/test_indexer.py::test_index_files_resolves_tsconfig_path_alias",
+    "tests/test_indexer.py::test_index_files_resolves_workspace_package",
+    "tests/test_indexer.py::test_index_files_resolves_java_package_import",
+    "tests/test_indexer.py::test_index_files_resolves_rust_crate_path",
+    "tests/test_indexer.py::test_index_files_resolves_rust_mod_dir",
+    "tests/test_indexer.py::test_index_files_resolves_go_module_path",
+    "tests/test_indexer.py::test_index_files_skips_unchanged_on_rerun",
+    "tests/test_indexer.py::test_is_unchanged_requires_embedding_when_asked",
+    "tests/test_indexer.py::test_index_files_with_embedder_populates_embedding",
+    "tests/test_indexer.py::test_index_files_with_embedder_populates_plain_text_intent",
+    "tests/test_indexer.py::test_index_files_persists_docstring_intent_sources",
+    "tests/test_indexer.py::test_delete_file_cascades_to_symbols",
+    "tests/test_indexer.py::test_delete_file_returns_false_when_missing",
+    "tests/test_indexer.py::test_delete_path_removes_indexed_subtree",
+    "tests/test_indexer.py::test_resolves_ruby_require_relative",
+    "tests/test_indexer.py::test_resolves_cpp_quoted_include",
+    "tests/test_indexer.py::test_resolves_kotlin_package_import",
+    "tests/test_indexer.py::test_resolves_php_psr4_import",
+    "tests/test_indexer.py::test_resolves_rust_super_glob_to_own_file",
+    "tests/test_indexer.py::test_chunk_size_does_not_change_a_vector",
+    "tests/test_indexer.py::test_worker_count_gates_on_size_and_env",
+    "tests/test_indexer.py::test_parse_falls_back_to_serial_when_the_pool_breaks",
+    "tests/test_indexer.py::test_progress_is_reported_in_walk_order",
+    "tests/test_indexer.py::test_legacy_rust_index_is_reparsed_when_new_trait_owners_are_available",
+    "tests/test_indexer.py::test_cpp_header_language_reaches_serial_parser_and_database",
+    "tests/test_indexer.py::test_cpp_header_reindexes_unchanged_source_after_parser_upgrade"
+  ],
+  "test_states": [
+    {
+      "nodeid": "tests/test_indexer.py::test_hash_is_deterministic",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_skips_too_large",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_persists_symbols_and_imports",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_internal_python_import",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_ts_relative_import",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_ts_esm_js_extension",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_relative_index_file",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_tsconfig_path_alias",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_workspace_package",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_java_package_import",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_rust_crate_path",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_rust_mod_dir",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_resolves_go_module_path",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_skips_unchanged_on_rerun",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_is_unchanged_requires_embedding_when_asked",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_with_embedder_populates_embedding",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_with_embedder_populates_plain_text_intent",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_index_files_persists_docstring_intent_sources",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_delete_file_cascades_to_symbols",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_delete_file_returns_false_when_missing",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_delete_path_removes_indexed_subtree",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_resolves_ruby_require_relative",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_resolves_cpp_quoted_include",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_resolves_kotlin_package_import",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_resolves_php_psr4_import",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_resolves_rust_super_glob_to_own_file",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_chunk_size_does_not_change_a_vector",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_worker_count_gates_on_size_and_env",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_parse_falls_back_to_serial_when_the_pool_breaks",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_progress_is_reported_in_walk_order",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_legacy_rust_index_is_reparsed_when_new_trait_owners_are_available",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_cpp_header_language_reaches_serial_parser_and_database",
+      "when": "call",
+      "outcome": "passed"
+    },
+    {
+      "nodeid": "tests/test_indexer.py::test_cpp_header_reindexes_unchanged_source_after_parser_upgrade",
+      "when": "call",
+      "outcome": "passed"
+    }
+  ],
+  "original_test_exit": 0,
+  "runtime": {
+    "system": "Darwin",
+    "machine": "arm64",
+    "python": "3.12.9"
+  },
+  "owners": {
+    "src/ken/indexer.py": "430dab7bec2d643a17a1cf3a616434b3c4efd0ffe07ea93a279146950377cbd4",
+    "src/ken/jsresolve.py": "228919f225dffc74d193d6e24cab7fe093aed4ec7c8d507e722b3079169efd0a",
+    "tests/conftest.py": "e350ce30ebaf2ee1d2861e1e737c96957478b498a9fcaa8a59f04a5e91933986",
+    "tests/test_indexer.py": "17badc54c148fbfec50db43e35dd1fd0ab8c0914cba8e2bc1a1fd64711e88121"
+  },
+  "script_sha256": "402cb354fc55489afd3b9386e7981ebfd6e5f45d6e104c399908d29d32a27c49",
+  "supplements_sha256": "90c1f165e92522f50c6a6a878899d1ff1dfaf3c9c14709d021d0832b13b18506",
+  "cases_sha256": "dcff83f7cf16241c9cff12af4b7f8dc960983d073d0bb3156fb7582f7d2f7671",
+  "test_execution": {
+    "exit": 0,
+    "python": "/Users/andres/Projects/ken/.venv/bin/python",
+    "cwd": "/Users/andres/Projects/ken/.ken/rust-migration/m2-optional/reference-final-t9",
+    "stdout_sha256": "f94c6c1d339436e4b15545cc8b6dbd973c2a2e35b44255841d6b22c5739be072",
+    "stderr_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
+    "observations_sha256": "fb3d580bdaac7b3bbcdbc21abe8614de311b4a557a3637c75d69a25912adf0a4",
+    "timeout_s": 120
+  }
+}
diff --git a/crates/ken-core/tests/import_project.rs b/crates/ken-core/tests/import_project.rs
new file mode 100644
index 00000000..8ebaaca2
--- /dev/null
+++ b/crates/ken-core/tests/import_project.rs
@@ -0,0 +1,184 @@
+//! Real config acquisition must preserve the independently observed edge results.
+use ken_core::imports::{ImportCatalog, ImportError, ImportRequest, Resolution};
+use serde_json::Value;
+use std::fs;
+
+#[test]
+fn project_acquisition_matches_all_original_inputs_and_config_failures() {
+    for corpus in [
+        include_str!("fixtures/import-reference.json"),
+        include_str!("fixtures/import-alias-edges.json"),
+        include_str!("fixtures/import-alias-surrogates.json"),
+        include_str!("fixtures/import-language-edges.json"),
+    ] {
+        let reference: Value = serde_json::from_str(corpus).unwrap();
+        for row in reference["cases"].as_array().unwrap() {
+            let root = tempfile::tempdir().unwrap();
+            if let Some(configs) = row["input"]["configs"].as_object() {
+                for (name, value) in configs {
+                    let path = root.path().join(name);
+                    fs::create_dir_all(path.parent().unwrap()).unwrap();
+                    let hex = value.as_str().unwrap();
+                    let bytes: Vec<_> = (0..hex.len())
+                        .step_by(2)
+                        .map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap())
+                        .collect();
+                    fs::write(path, bytes).unwrap();
+                }
+            }
+            let files = serde_json::from_value(row["input"]["files"].clone()).unwrap();
+            let catalog = ImportCatalog::from_project(
+                (!row["input"]["configs"].is_null()).then_some(root.path()),
+                files,
+            );
+            if row.get("error").is_some() {
+                assert!(matches!(catalog, Err(ImportError::Config { .. })));
+                continue;
+            }
+            let catalog = catalog.unwrap();
+            let requests: Vec<ImportRequest> =
+                serde_json::from_value(row["input"]["imports"].clone()).unwrap();
+            for (request, expected) in requests.iter().zip(row["results"].as_array().unwrap()) {
+                assert_eq!(
+                    serde_json::to_value(catalog.resolve(request).unwrap()).unwrap(),
+                    *expected,
+                    "case={} request={request:?}",
+                    row["id"]
+                );
+            }
+        }
+    }
+}
+fn request(module: &str, language: &str) -> ImportRequest {
+    ImportRequest {
+        module: module.into(),
+        source_path: "main.ts".into(),
+        language: Some(language.into()),
+    }
+}
+
+#[test]
+fn inherited_unindexed_config_is_reloaded_but_unindexed_package_is_ignored() {
+    let root = tempfile::tempdir().unwrap();
+    fs::write(root.path().join("tsconfig.json"), r#"{"extends":"./base"}"#).unwrap();
+    fs::write(
+        root.path().join("base.json"),
+        r#"{"compilerOptions":{"paths":{"@value":["one"]}}}"#,
+    )
+    .unwrap();
+    fs::write(root.path().join("package.json"), r#"{"name":"@hidden"}"#).unwrap();
+    let files = vec![
+        "main.ts".into(),
+        "tsconfig.json".into(),
+        "one.ts".into(),
+        "two.ts".into(),
+        "index.ts".into(),
+    ];
+    let first = ImportCatalog::from_project(Some(root.path()), files.clone()).unwrap();
+    assert_eq!(
+        first
+            .resolve(&request("@value", "typescript"))
+            .unwrap()
+            .target
+            .as_deref(),
+        Some("one.ts")
+    );
+    assert_eq!(
+        first
+            .resolve(&request("@hidden", "typescript"))
+            .unwrap()
+            .resolution,
+        Resolution::External
+    );
+    fs::write(
+        root.path().join("base.json"),
+        r#"{"compilerOptions":{"paths":{"@value":["two"]}}}"#,
+    )
+    .unwrap();
+    let second = ImportCatalog::from_project(Some(root.path()), files).unwrap();
+    assert_eq!(
+        second
+            .resolve(&request("@value", "typescript"))
+            .unwrap()
+            .target
+            .as_deref(),
+        Some("two.ts")
+    );
+    assert_eq!(
+        first
+            .resolve(&request("@value", "typescript"))
+            .unwrap()
+            .target
+            .as_deref(),
+        Some("one.ts")
+    );
+}
+
+#[test]
+fn jsonc_replaces_invalid_utf8_while_composer_strict_decoding_ignores_it() {
+    let root = tempfile::tempdir().unwrap();
+    fs::write(
+        root.path().join("tsconfig.json"),
+        b"{\"compilerOptions\":{\"paths\":{\"@value\":[\"one\"]}},\"unused\":\"\xff\"}",
+    )
+    .unwrap();
+    fs::write(
+        root.path().join("composer.json"),
+        b"{\"autoload\":{\"psr-4\":{\"App\\\\\":\"one\"}},\"unused\":\"\xff\"}",
+    )
+    .unwrap();
+    let files = vec![
+        "main.ts".into(),
+        "tsconfig.json".into(),
+        "composer.json".into(),
+        "one.ts".into(),
+        "one/Value.php".into(),
+        "two/Value.php".into(),
+    ];
+    let catalog = ImportCatalog::from_project(Some(root.path()), files).unwrap();
+    assert_eq!(
+        catalog
+            .resolve(&request("@value", "typescript"))
+            .unwrap()
+            .target
+            .as_deref(),
+        Some("one.ts")
+    );
+    let php = catalog.resolve(&request("App\\Value", "php")).unwrap();
+    assert_eq!(php.target, None);
+    assert_eq!(php.resolution, Resolution::Unresolved);
+}
+
+#[test]
+fn absent_root_missing_files_and_unreadable_directory_configs_are_tolerated() {
+    let root = tempfile::tempdir().unwrap();
+    fs::create_dir(root.path().join("tsconfig.json")).unwrap();
+    let files = vec![
+        "main.ts".into(),
+        "tsconfig.json".into(),
+        "missing/package.json".into(),
+        "utility.py".into(),
+    ];
+    for project in [
+        Some(root.path()),
+        Some(root.path().join("missing-root").as_path()),
+        None,
+    ] {
+        let catalog = ImportCatalog::from_project(project, files.clone()).unwrap();
+        assert_eq!(
+            catalog
+                .resolve(&request("utility", "python"))
+                .unwrap()
+                .target
+                .as_deref(),
+            Some("utility.py")
+        );
+        assert_eq!(
+            catalog
+                .resolve(&request("@missing", "typescript"))
+                .unwrap()
+                .resolution,
+            Resolution::External
+        );
+    }
+}
diff --git a/crates/ken-core/tests/import_resolution.rs b/crates/ken-core/tests/import_resolution.rs
new file mode 100644
index 00000000..dd5e18e0
--- /dev/null
+++ b/crates/ken-core/tests/import_resolution.rs
@@ -0,0 +1,170 @@
+//! Caller-level original structural-target comparisons, including ambiguities.
+use ken_core::imports::{ImportCatalog, ImportError, ImportRequest};
+use serde_json::Value;
+
+#[test]
+fn original_structural_phase_preserves_every_target_and_missing_result() {
+    let reference: Value =
+        serde_json::from_str(include_str!("fixtures/import-reference.json")).unwrap();
+    let mut queries = 0;
+    for row in reference["cases"].as_array().unwrap() {
+        let files = serde_json::from_value(row["input"]["files"].clone()).unwrap();
+        let catalog = ImportCatalog::from_inputs(files, None).unwrap();
+        for (request, expected) in row["input"]["imports"]
+            .as_array()
+            .unwrap()
+            .iter()
+            .zip(row["structural_targets"].as_array().unwrap())
+        {
+            let target = catalog.structural_target(
+                request["module"].as_str().unwrap(),
+                request["source_path"].as_str(),
+            );
+            assert_eq!(
+                serde_json::to_value(target).unwrap(),
+                *expected,
+                "case={} request={request}",
+                row["id"]
+            );
+            queries += 1;
+        }
+    }
+    assert!(queries >= 50, "lost original request inventory");
+}
+
+#[test]
+fn structural_phase_supports_absent_source_and_quote_whitespace_rules() {
+    let catalog =
+        ImportCatalog::from_inputs(vec!["src/café.py".into(), "asset.json".into()], None).unwrap();
+    assert_eq!(
+        catalog.structural_target("\u{1c}'café'\u{1f}", None),
+        Some("src/café.py".into())
+    );
+    assert_eq!(
+        catalog.structural_target("./asset.json", Some("main.ts")),
+        Some("asset.json".into())
+    );
+    assert_eq!(catalog.structural_target("   ", None), None);
+    let ambiguous =
+        ImportCatalog::from_inputs(vec!["a/item.py".into(), "b/item.py".into()], None).unwrap();
+    assert_eq!(ambiguous.structural_target("item", None), None);
+}
+
+#[test]
+fn original_javascript_aliases_preserve_targets_classification_and_config_failures() {
+    compare_javascript(include_str!("fixtures/import-reference.json"), 25);
+}
+#[test]
+fn original_alias_workspace_order_duplicates_and_inherited_bases_match() {
+    compare_javascript(include_str!("fixtures/import-alias-edges.json"), 10);
+}
+#[test]
+fn original_non_scalar_alias_targets_keep_internal_shape() {
+    compare_javascript(include_str!("fixtures/import-alias-surrogates.json"), 2);
+}
+
+#[test]
+fn all_original_languages_preserve_full_resolution_and_failure_boundaries() {
+    let mut compared = 0;
+    for corpus in [
+        include_str!("fixtures/import-reference.json"),
+        include_str!("fixtures/import-alias-edges.json"),
+        include_str!("fixtures/import-alias-surrogates.json"),
+        include_str!("fixtures/import-language-edges.json"),
+    ] {
+        let reference: Value = serde_json::from_str(corpus).unwrap();
+        for row in reference["cases"].as_array().unwrap() {
+            let files = serde_json::from_value(row["input"]["files"].clone()).unwrap();
+            let configs = row["input"]["configs"].as_object().map(|cfg| {
+                cfg.iter()
+                    .map(|(name, value)| {
+                        let hex = value.as_str().unwrap();
+                        (
+                            name.clone(),
+                            (0..hex.len())
+                                .step_by(2)
+                                .map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap())
+                                .collect(),
+                        )
+                    })
+                    .collect()
+            });
+            let requests: Vec<ImportRequest> =
+                serde_json::from_value(row["input"]["imports"].clone()).unwrap();
+            compared += requests.len();
+            let catalog = ImportCatalog::from_inputs(files, configs);
+            if row.get("error").is_some() {
+                assert!(
+                    matches!(catalog, Err(ImportError::Config { .. })),
+                    "original config failure lost: {}",
+                    row["id"]
+                );
+                continue;
+            }
+            let catalog = catalog.unwrap();
+            for (request, expected) in requests.iter().zip(row["results"].as_array().unwrap()) {
+                let actual = catalog.resolve(request).unwrap();
+                assert_eq!(
+                    serde_json::to_value(actual).unwrap(),
+                    *expected,
+                    "case={} request={request:?}",
+                    row["id"]
+                );
+            }
+        }
+    }
+    assert!(compared >= 92, "lost original resolution requests");
+}
+fn compare_javascript(corpus: &str, minimum: usize) {
+    let reference: Value = serde_json::from_str(corpus).unwrap();
+    let mut queries = 0;
+    for row in reference["cases"].as_array().unwrap() {
+        let requests: Vec<ImportRequest> =
+            serde_json::from_value(row["input"]["imports"].clone()).unwrap();
+        if !requests
+            .iter()
+            .any(|r| matches!(r.language.as_deref(), Some("typescript" | "javascript")))
+        {
+            continue;
+        }
+        let files = serde_json::from_value(row["input"]["files"].clone()).unwrap();
+        let configs = row["input"]["configs"].as_object().map(|cfg| {
+            cfg.iter()
+                .map(|(name, value)| {
+                    let hex = value.as_str().unwrap();
+                    let bytes = (0..hex.len())
+                        .step_by(2)
+                        .map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap())
+                        .collect();
+                    (name.clone(), bytes)
+                })
+                .collect()
+        });
+        let catalog = ImportCatalog::from_inputs(files, configs);
+        if row.get("error").is_some() {
+            assert!(
+                matches!(catalog, Err(ImportError::Config { .. })),
+                "original wrong config shape must fail"
+            );
+            continue;
+        }
+        let catalog = catalog.unwrap();
+        for (request, expected) in requests.iter().zip(row["results"].as_array().unwrap()) {
+            if !matches!(
+                request.language.as_deref(),
+                Some("typescript" | "javascript")
+            ) {
+                continue;
+            }
+            let actual = catalog.resolve(request).unwrap();
+            assert_eq!(
+                serde_json::to_value(actual).unwrap(),
+                *expected,
+                "case={} request={request:?}",
+                row["id"]
+            );
+            queries += 1;
+        }
+    }
+    assert!(queries >= minimum, "lost JS/TS case inventory");
+}
diff --git a/docs/rust-migration.md b/docs/rust-migration.md
index 85d1c04a..1f4b21da 100644
--- a/docs/rust-migration.md
+++ b/docs/rust-migration.md
@@ -29,20 +29,26 @@ M3a añade `SourceFilter` y `ProjectSources` para exclusiones y recorrido confin
 La [revisión y reparación](validation/rust-migration-2026-10-23/m3-source-review/README.md)
 cierra sus seis hallazgos con34pruebas Rust y24pruebas de herramientas por
 plataforma. Se comparan702decisiones y134recorridos originales, preservando
 patrones Unicode, prioridades, orden y scopes. Los directorios pendientes se
 abren mediante un descriptor confinado. M3a está aceptado. M3b implementa los19analizadores con20gramáticas y44extensiones;
 [su revisión y reparación](validation/rust-migration-2026-10-23/m3-parsers-review/README.md)
 cierra dos diferencias con249entradas por plataforma,33pruebas Rust y38pruebas de
 herramientas. M3b está aceptado tras una única revisión y pasada de reparación. Modelo común, resolución de imports e indexación incremental siguen
 pendientes en M3, al igual que M4–M8. Los originales permanecen intactos.
 
+M3c añade resolución nativa de imports y lectura de configuraciones reales.
+[Su matriz](validation/rust-migration-2026-10-23/m3-imports/README.md) compara91datasets
+en dos modos por plataforma:182casos/184solicitudes,44pruebas raíz Rust y33pruebas
+de herramientas. La revisión final de M3c está en curso. Modelo común e indexación
+incremental siguen pendientes; la aplicación instalada conserva Python.
+
 Los recibos históricos describen sus propias fuentes. Para reproducir el bloque
 de fuentes después de cambios posteriores, el agregador usa la copia pequeña de
 `native-sources` incluida en el recibo; no atribuye una ejecución vieja al código
 nuevo ni obliga a repetir inferencia sin cambios.
 
 ## Referencia y pruebas
 
 M0 conserva una copia del worktree original, incluyendo fuentes untracked,
 en `.ken/rust-migration/m0-m1/reference`. Sus manifiestos detectan alteraciones.
 Los 1.066 hashes iniciales corresponden al worktree con cambios previos;
diff --git a/docs/superpowers/plans/2026-10-23-rust-import-resolution.md b/docs/superpowers/plans/2026-10-23-rust-import-resolution.md
new file mode 100644
index 00000000..86bef101
--- /dev/null
+++ b/docs/superpowers/plans/2026-10-23-rust-import-resolution.md
@@ -0,0 +1,102 @@
+# Native Import Resolution Implementation Plan
+
+> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task with native inline execution.
+
+**Goal:** Resolve native parsed imports with exact original target/classification and config precedence.
+
+**Architecture:** ImportCatalog owns ordered indexed paths and delegates to ModulePath, AliasResolver and language policies. Config acquisition produces byte inputs; the pure resolver never reads filesystem or SQLite. Incremental writes consume the resulting edges in a later plan.
+
+**Tech Stack:** Rust1.95, existing ken-core serde/serde_json/regex, Python validation only.
+
+**Spec:** `docs/superpowers/specs/2026-10-23-rust-import-resolution-design.md`
+
+## Global Constraints
+
+- Begin implementation after M3b final review and verified repair; preserve original1066files/user dirt.
+- Native inline implementation, no confirmation pauses, one fresh whole-plan final reviewer.
+- Exact request/result/config ordering, language priorities and original error boundaries.
+- No third-party upgrades or global serde_json feature changes; no production writer/CLI promotion.
+- Actual Macarm64/Linuxaarch64 acceptance, unchanged model/parser/source histories reused.
+- SDK preparation may use Python; native import consumers never use Python/processes/network.
+
+## Review Focus
+
+1. Two aliases or workspace prefixes can match; preserve original ordered first success and stable duplicate-key positions. Task2 tests exact targets.
+2. A generic structural match can precede a language rule; do not apply preferred language semantics out of order. Task3 tests collisions.
+3. Malformed config shape differs from missing/invalid JSON; preserve actual original failure versus tolerance. Tasks1,2,4 observe and test both.
+4. Nearest config/module with no target may or may not fall through according to its owner; Task2/3 tests missing-target ancestor/nested cases.
+5. A native proof must retain every target/classification and every original error, including no-root and Unicode inputs. Task5 rejects resealed omissions and false summaries.
+
+---
+
+### Task 1: Independent original resolution reference and structural targets
+
+**Files:** Create `tools/rust_migration/import_reference.py`, `tests/rust_migration/test_import_reference.py`, `crates/ken-core/src/imports/{mod.rs,paths.rs}`, `crates/ken-core/tests/import_resolution.rs`, `crates/ken-core/tests/fixtures/import-reference.json`; export imports from lib.rs.
+
+**Interfaces:** Original capture records ordered files, config bytes, pending module/source/language requests and observed final target/resolution. Public ImportRequest{module:String,source_path:String,language:Option<String>}, ImportResolution{target:Option<String>,resolution:Resolution}, Resolution::{Internal,Unresolved,External}, ImportError. Internal structural_target(module:&str,source:Option<&str>,files:&[String],suffixes:&BTreeMap<String,Vec<String>>)->Option<String>. `ImportCatalog::from_inputs(files:Vec<String>,configs:Option<BTreeMap<String,Vec<u8>>>)->Result<Self,ImportError>` constructs native catalogs; specialized resolve remains explicitly pending until Tasks2/3.
+
+- [ ] Capture actual original tests/test_indexer.py resolution calls with owners and124parser/model histories reused. Record all test IDs/states, real raw requests/output and supplemental direct original ambiguity/no-root/Unicode cases; reference tests reject changed owners, missing cases and stale captures.
+- [ ] Add Rust public-usage tests for generic dotted/suffix uniqueness, relative joins, exact/non-code path priority, all seven extension/index fallbacks and ESM rewrite. Run affected test: expect missing imports module/API RED.
+- [ ] Implement data contracts, path normalization, JS matcher and precomputed Python suffix lookup; preserve bytes/whitespace/ambiguity rules from original. No DB access or generic guessed external success for pending languages.
+- [ ] Run structural subset, focused capture tests, ken-core existing tests and fmt/clippy on both native systems. Expect complete captured structural results and original1066guard GREEN.
+- [ ] Commit scoped changes as `feat(imports): preserve structural module resolution`.
+
+### Task 2: Ordered config and JS/TS aliases
+
+**Files:** Create `crates/ken-core/src/imports/{config.rs,aliases.rs}`; extend imports tests/reference fixtures.
+
+**Interfaces:** ConfigValue owns ordered object values, UTF8 replacement/strict parsing policies and original JSONC cleanup. AliasResolver::from_inputs(files:&[String],configs:&BTreeMap<String,Vec<u8>>)->Result<Self,ImportError>; resolve(module:&str,source:&str)->Option<String>; is_internal_shape(module:&str,source:&str)->bool. Reads only supplied bytes and indexed config paths.
+
+- [ ] Add original full-target tests for ordered overlapping aliases/workspaces, duplicate keys, nearest config ties and fallthrough, depth<3 extends cycles, parent baseUrl inheritance, malformed/invalid JSON and wrong shapes.
+- [ ] Run JS/TS subset expecting explicit pending/missing aliases RED.
+- [ ] Implement ordered JSON via serde visitor and string-aware original JSONC cleanup. Preserve first-position/last-value duplicate semantics, paths insertion order and stable nearest-first configs/packages.
+- [ ] Run all current imports tests, focused tooling, existing ken-core regressions and fmt/clippy on both systems. Expect exact original target/classification/error boundaries and unchanged model dependencies.
+- [ ] Commit as `feat(imports): resolve ordered JS and TS project aliases`.
+
+### Task 3: Language module rules and unresolved classification
+
+**Files:** Create `crates/ken-core/src/imports/{languages.rs,classification.rs}`; extend mod.rs/tests.
+
+**Interfaces:** `ImportCatalog::resolve(&self,request:&ImportRequest)->Result<ImportResolution,ImportError>` becomes complete. Language policies consume catalog inventory/config-derived Go/PSR4 data; targets are existing paths only. Generic structural match always precedes specialized lookup.
+
+- [ ] Add complete original edge tests for Java static/wildcard, Rust crate/self/super/glob/module precedence, nested Go modules and representative non-test files, Ruby relative loads, quoted C++ subtree ambiguity, Kotlin unique package files, PHP ordered PSR4/unique tail and all language-specific unresolved/external shapes. Include deliberate generic-vs-specialized collisions.
+- [ ] Run affected language/classification tests: expect pending branches RED.
+- [ ] Implement language decisions in their owners, stable ordering and exact original early-return/fallthrough rules. Remove all pending resolve branches; unknown languages retain original generic resolution/classification.
+- [ ] Run complete native import corpus, original-owner guard, affected tooling, ken-core regressions and fmt/clippy on both systems; expect complete ordered results/errors GREEN.
+- [ ] Commit as `feat(imports): complete native language resolution policies`.
+
+### Task 4: Real project config acquisition
+
+**Files:** Create `crates/ken-core/src/imports/project_inputs.rs`; extend imports public API and tests.
+
+**Interfaces:** `ImportCatalog::from_project(root:Option<&Path>,files:Vec<String>)->Result<Self,ImportError>` reads indexed root config paths plus their actually referenced extends parents, with original UTF8/error tolerance, then delegates pure construction. None means no project configs. The filesystem adapter never chooses import targets.
+
+- [ ] Write real temporary-project tests for indexed/unindexed configs, missing/unreadable files, JSONC UTF8 replacement versus PHP strict decoding, wrong shapes, optional root and config changes between separately constructed catalogs.
+- [ ] Run new public caller tests: expect missing from_project RED.
+- [ ] Implement config acquisition and contextual errors; keep resolution/persistence outside this owner.
+- [ ] Run imports suite and relevant existing ken-core tests on Mac/Linux, fmt/clippy and1066guard. Expect same results as explicit-input catalogs and no hidden cache/fallback.
+- [ ] Commit as `feat(imports): prepare resolution from indexed project configs`.
+
+### Task 5: Native differential acceptance and review
+
+**Files:** Create `crates/ken-core/examples/import_probe.rs`, `tools/rust_migration/{import_validate.py,import_evidence.py}`, `tests/rust_migration/{test_import_validate.py,test_import_evidence.py}`, `docs/validation/rust-migration-2026-10-23/m3-imports/`; update migration progress docs.
+
+**Interfaces:** Strict bounded input-only probe accepts ordered file/config bytes and import requests, returns complete ordered ImportResolution or contextual errors. Native acquisition mode reads actual temporary project config files. Authentication pins the final closed M3b FILES manifest at execution time, validates immutable predecessor bytes and snapshots every consumed source/config/test input.
+
+- [ ] Add RED comparator/protocol/receipt tests for missing/duplicate/reordered inputs, changed target/resolution, config order or bytes, lost original failures, injected expectations, missing platforms and resealed false passing gates.
+- [ ] Implement native probe, isolated copied-binary process driver and semantic receipt replay. Record actual stdout/stderr/exit, sentinelPATH/loader evidence and Linux exec/connect audit; no expected values accepted by native requests.
+- [ ] Run full affected native/tooling gates and one complete differential per actual platform, with actual config acquisition fixtures. Reuse unchanged earlier parser/source/model histories; verify1066originals intact.
+- [ ] Replay authenticated evidence independently; expect all resealed mutations rejected and M3c-only acceptance. Compress raw histories, retain small source snapshots and exact gate inventories.
+- [ ] Commit evidence, run one fresh whole-plan review and one TDD Important/Critical repair pass, archive complete ledger/rulings/minors/review before deleting own completed workspace. Continue common model and incremental indexing without confirmation pauses.
+
+## Self-review
+
+The catalog and ordered config boundary are fixed before specialized consumers;
+all five Review Focus inputs have explicit task tests. No task conflates native
+resolution with SQLite writes or claims global migration completion. Canonical
+common-AST normalization remains its own producer/consumer boundary after import
+resolution and before M3 indexing acceptance. The final M3b predecessor identity
+is resolved only after that plan's required review repair closes, avoiding a pin
+to provisional evidence. Existing no-confirmation/native authorization applies.
+
+Closed M3b predecessor: `docs/validation/rust-migration-2026-10-23/m3-parsers-review`; FILES.json SHA256 `c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8`, repaired commit03400e2b. Its immutable proof is reused; no124parser-suite/model recapture.
diff --git a/docs/superpowers/specs/2026-10-23-rust-import-resolution-design.md b/docs/superpowers/specs/2026-10-23-rust-import-resolution-design.md
new file mode 100644
index 00000000..670f12ea
--- /dev/null
+++ b/docs/superpowers/specs/2026-10-23-rust-import-resolution-design.md
@@ -0,0 +1,117 @@
+# Native import resolution — M3c
+
+This subsystem continues the approved whole-migration contract after M3b's final
+review and verified repair pass. The user authorized native inline execution,
+continuous stages without confirmation, preserved originals and reuse of unchanged
+validated evidence. This design does not promote production writers or commands.
+
+## Purpose and boundary
+
+Map each pending parsed import to its original indexed-file target, or classify it
+as `unresolved` or `external`, with identical precedence. This turns M3b's native
+ParsedImport into useful index edges without translating the 1610-line indexer as
+one component. Original owners are `indexer.py:1014–1544` and `jsresolve.py`;
+SQLite updates/backfill remain owned by the later incremental-indexing service.
+
+The working example is:
+
+```rust
+let catalog = ImportCatalog::from_inputs(files, Some(config_bytes))?;
+let edge = catalog.resolve(&ImportRequest {
+    module: "@app/store".into(), source_path: "src/main.ts".into(),
+    language: Some("typescript".into()),
+})?;
+assert_eq!(edge.target.as_deref(), Some("src/store.ts"));
+assert_eq!(edge.resolution, Resolution::Internal);
+```
+
+`files: Vec<String>` preserves original SQLite row order. `config_bytes` is an
+ordered-file-addressed map of exact bytes for indexed tsconfig/jsconfig/package,
+go.mod and composer inputs, or None when the original has no project root.
+The config map includes referenced extends parents even when those parent files are not indexed. Preparation errors remain explicit when malformed config shapes crash the original;
+missing/unreadable/invalid-JSON configs retain the original tolerant behavior.
+No heuristic invents a target for an ambiguous import.
+
+## Concepts and ownership
+
+- `ImportCatalog` owns the indexed path inventory, precomputed Python suffix
+  index, nearest Cargo dirs, Go package representatives and language delegations.
+- `ModulePath` helpers own original lexical relative joining and JS extension/index
+  priority, including `.js` imports selecting an existing `.ts` source.
+- `AliasResolver` owns ordered JS/TS config inheritance, nearest config matching,
+  workspace-package priority and internal-shape recognition.
+- `OrderedJson` preserves Python dictionary insertion order and duplicate-key
+  last-value/first-position semantics when reading config objects. It is local to
+  config resolution, using existing serde without globally enabling preserve_order.
+- Language-specific resolution owns Rust crate/self/super/glob rules, Java/Kotlin
+  package matching, Go go.mod packages, Ruby relative loads, C++ quoted includes
+  and PHP PSR-4 mappings. Classification belongs beside its language decision.
+- `ProjectImportInputs` reads actual indexed config files before pure resolution;
+  the pure engine has no filesystem, database, parser, network or process access.
+
+Use a focused public `ken-core::imports` module. Existing project/source owners
+remain unchanged. Public types derive serde/Clone/Debug/PartialEq; Resolution uses
+lowercase `internal`, `unresolved`, `external`. ImportResolution contains
+`target: Option<String>` and `resolution: Resolution`. ImportRequest contains
+module/source_path/optional language. ImportError identifies invalid config shape
+and contextual file; errors never become successful external classifications.
+
+## Approaches and chosen tradeoff
+
+The chosen implementation separates pure resolution from config acquisition,
+then connects its result to the index writer in the next index stage. It exposes
+inputs and ordering for independent differential tests and keeps database work in
+its owner. Porting all indexer code together couples parser/model/vector/storage
+failures. Retaining Python resolution violates native execution. Neither advances
+the approved migration with a testable native capability.
+
+No new crate or third-party version is required: ken-core already has serde,
+serde_json, regex and standard collections. Local ordered deserialization avoids
+changing serde_json features for already accepted model consumers.
+
+## Exact behavior to preserve
+
+Resolution order is generic structural target, JS/TS aliases/workspaces, Java,
+Rust, Go, Ruby, C++, Kotlin and PHP according to the importing language. Generic
+resolution intentionally runs for all languages before specialized rules.
+
+Relative `./`/`../` first uses the importing directory and JS module matcher.
+Exact indexed paths precede extension rewrites; suffix order is `.ts`, `.tsx`,
+`.d.ts`, `.js`, `.jsx`, `.mjs`, `.cjs`, then corresponding `/index` candidates.
+Python dotted fallback uses unique suffix membership; duplicates stay ambiguous.
+Lexical joins clamp parent traversal at the inventory root, as the original does.
+
+JS configs are nearest-first with stable ties, inherited extends depth <3,
+original JSONC comment/trailing-comma behavior, baseUrl relative to its declaring
+config and ordered paths/package entries. A nearer unsuccessful alias may fall
+through to an ancestor. These observed rules take precedence over comments that
+imply a different policy. Unresolved classification matches original shapes.
+
+Go selects the first matching nearest module and lexically-first non-test file;
+Rust preserves original file-vs-module/glob behavior; quoted C++ matches unique
+suffix then unique importing top-level subtree; PHP prefix ordering is stable by
+length and keeps autoload before autoload-dev; Kotlin requires one containing
+package file. Preserve wildcard, missing, malformed, Unicode and unknown-language
+results without improving language semantics during the migration.
+
+## Verification and acceptance
+
+Capture pending requests, ordered inventory, actual indexed config bytes and final
+original target/classification through real original indexer tests. Record owner
+hashes, test inventory/states and raw captures. Add direct independent original
+cases for ambiguity, no-root catalogs, precedence ties, extends/cycles, malformed
+config shapes, duplicate JSON keys, Unicode and missing targets. Preserve failures.
+Do not repeat model inference or the original parser suite.
+
+Native tests compare complete ordered edge results, not just matching counts.
+Native macOS arm64/Linux aarch64 probes run outside checkout with copied binary,
+empty PATH, loader audit, Linux exec/connect trace and real config-acquisition
+fixtures. Authenticated receipts reject lost/duplicate cases, altered config/source
+bytes, missing platforms, fabricated passing gates and swallowed original errors.
+Original1066hashes must remain intact. Final review follows the single whole-plan
+review plus one Important/Critical TDD repair pass; no confirmation pause.
+
+Acceptance is M3c only. Common AST normalization, incremental writes, full M3,
+M4–M8 and application cutover remain pending until their own real gates pass.
+
+Closed M3b predecessor: `docs/validation/rust-migration-2026-10-23/m3-parsers-review`; FILES.json SHA256 `c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8`, repaired commit03400e2b. Its immutable proof is reused; no124parser-suite/model recapture.
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/FILES.json b/docs/validation/rust-migration-2026-10-23/m3-imports/FILES.json
new file mode 100644
index 00000000..2bd2aa72
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/FILES.json
@@ -0,0 +1,54 @@
+{
+  "files": [
+    {
+      "path": "INDEX.json",
+      "bytes": 19775,
+      "sha256": "d96f0156802e2ce41c9549d59a6da2445fa60b3505ba0f43187ec4de70ba90f0"
+    },
+    {
+      "path": "LEDGER.md",
+      "bytes": 8499,
+      "sha256": "92b51d9bad6a0bb9c00b182a39a276741f39eace7fb71bf5f3265d7c5f75a48b"
+    },
+    {
+      "path": "MINORS.md",
+      "bytes": 15,
+      "sha256": "d9ea6a437b0f2c688143648b8f88b2147c5c0487b7892fe108c604dd8e4f68bd"
+    },
+    {
+      "path": "README.md",
+      "bytes": 1745,
+      "sha256": "33578c40ca3e4431c226cdde8965604b15de75db56f3171e71721a1e06aa6dd2"
+    },
+    {
+      "path": "RULINGS.md",
+      "bytes": 2594,
+      "sha256": "e64f67811d84a35b8df40115f91d1715832653c9755387b3c87ffcff1e61e8cd"
+    },
+    {
+      "path": "VERIFY.py",
+      "bytes": 1467,
+      "sha256": "f8304f50241917209b2f6596c35be5827fadc55d14f60a83b5d77c74287798cc"
+    },
+    {
+      "path": "development-logs.tar.gz",
+      "bytes": 27719,
+      "sha256": "5babf3d5c75a59ae21a7891e36a0d58e669cff591d4922ea25d946287522979d"
+    },
+    {
+      "path": "linux-capture.tar.gz",
+      "bytes": 38002,
+      "sha256": "352b9c27290a34d2b83ecaad51df607db5136c1e1413c356162a7d0db6689671"
+    },
+    {
+      "path": "macos-capture.tar.gz",
+      "bytes": 64137,
+      "sha256": "21cca28e16bbb123865c38cf3f72a83557ab915df34e1c2e1e0c9a10c452dc19"
+    },
+    {
+      "path": "sources.tar.gz",
+      "bytes": 284727,
+      "sha256": "e3b25b8996562bd816ff3e47f3baa9b962ee24229a3f150c16e2b670f199544c"
+    }
+  ]
+}
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/INDEX.json b/docs/validation/rust-migration-2026-10-23/m3-imports/INDEX.json
new file mode 100644
index 00000000..7d5d9e4a
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/INDEX.json
@@ -0,0 +1,499 @@
+{
+  "format": "ken-import-matrix/1",
+  "sources": {
+    "Cargo.toml": {
+      "bytes": 2019,
+      "sha256": "3e9ab664c63933ef61125d6dc7254e0c53d164559c7cb0303fe95d6aaa66dd12"
+    },
+    "Cargo.lock": {
+      "bytes": 58000,
+      "sha256": "2ee55934a3214dd0be3f2e587a4ec4982d1fed3277740c90d201dcaa7873e68c"
+    },
+    "rust-toolchain.toml": {
+      "bytes": 86,
+      "sha256": "7d21c66a15f41bad66b82ed06a289f5dc8a6e3751951d2696bbf20ce296f2b0f"
+    },
+    "crates/ken-core/Cargo.toml": {
+      "bytes": 452,
+      "sha256": "2d116c0914aeff41a044816ddecd891eac13d9c69349ca21ac1f6fe38a7e81a0"
+    },
+    "crates/ken-core/examples/import_probe.rs": {
+      "bytes": 4138,
+      "sha256": "b9a4aa6f7cd1a1e51f8a345f3c94e02008bc82c0c75acf65eb08eaf4ed4bcde2"
+    },
+    "crates/ken-core/examples/source_probe.rs": {
+      "bytes": 3348,
+      "sha256": "7ff81197d3d7d4182decadf044477606795376830c2430c845fe39621b6260ad"
+    },
+    "crates/ken-core/licenses/pathspec-MPL-2.0.txt": {
+      "bytes": 16725,
+      "sha256": "1f256ecad192880510e84ad60474eab7589218784b9a50bc7ceee34c2b91f1d5"
+    },
+    "crates/ken-core/src/health.rs": {
+      "bytes": 2050,
+      "sha256": "5e35b9c1a2134d4f99c0aac9fdf60fdcbc1a93ac07b013cd33fd0e451722ca12"
+    },
+    "crates/ken-core/src/imports/aliases.rs": {
+      "bytes": 8572,
+      "sha256": "e83b8fab595b75b5f62917f410d66ba17a0ac13a444a358b371f87d5f1b15041"
+    },
+    "crates/ken-core/src/imports/classification.rs": {
+      "bytes": 3855,
+      "sha256": "1ae85ba3795831e41a22b042e44855c4b456afc52385db5d579b620f3aa87b9b"
+    },
+    "crates/ken-core/src/imports/config.rs": {
+      "bytes": 10310,
+      "sha256": "e40d2f84a97872bae28dd45ca0d2bfba870e7004f545eff49df68dcdca2db52b"
+    },
+    "crates/ken-core/src/imports/languages.rs": {
+      "bytes": 12867,
+      "sha256": "c5f932c151328dbf222990d335fa3d8387eafa50be0b6361e7d4ad6fa5f92e52"
+    },
+    "crates/ken-core/src/imports/mod.rs": {
+      "bytes": 4003,
+      "sha256": "cf0dd16442d97e4e63688f376ca6962f22a4be9284b51667d98f113cee1623b1"
+    },
+    "crates/ken-core/src/imports/paths.rs": {
+      "bytes": 3290,
+      "sha256": "8b792ea6f55e8fcf94a176f0a083c2689275c07f7d6d12268d667465d67fcaaa"
+    },
+    "crates/ken-core/src/imports/project_inputs.rs": {
+      "bytes": 1042,
+      "sha256": "5aca07f98b8359e92ca534c694f7f3b425116b234f6e206668dadc3a6a261845"
+    },
+    "crates/ken-core/src/lib.rs": {
+      "bytes": 219,
+      "sha256": "b142229ec87d794b2ebfdfcb37820d0f3ecb16c9124ed942a61636b914d4db17"
+    },
+    "crates/ken-core/src/project.rs": {
+      "bytes": 8620,
+      "sha256": "b669c8dc857efeae55ad5f1bb595c4f6ea9db259a2f5f09b30e3958d1f38d727"
+    },
+    "crates/ken-core/src/source_directory.rs": {
+      "bytes": 2793,
+      "sha256": "6fab845774ec482621add6012c42e84c3164df19b258bcfd08424acb8acf0b2f"
+    },
+    "crates/ken-core/src/source_filter.rs": {
+      "bytes": 4319,
+      "sha256": "246ec7fe47008e08e8524653be18a8db0ed74ceff0237458a1497b65ff5648e0"
+    },
+    "crates/ken-core/src/source_patterns.rs": {
+      "bytes": 7364,
+      "sha256": "ffaa01551eca63d0048a15e49309264b604afcef9789594c154d90f400bf50cd"
+    },
+    "crates/ken-core/src/source_walk.rs": {
+      "bytes": 7188,
+      "sha256": "58b29e459aeab35ef4ae80a1712aac52a8f8c3415e188253706ff03221e5d9dd"
+    },
+    "crates/ken-core/src/status/model.rs": {
+      "bytes": 1731,
+      "sha256": "18eab502970f8bd769fca80ed5b3e0c357878de3cbcc5706ed97302d40a01d40"
+    },
+    "crates/ken-core/src/status/reader.rs": {
+      "bytes": 5058,
+      "sha256": "0cbc804d30e438bbf70ec3447eca17a9276aa1a90ade118f4b052f51cfb8e990"
+    },
+    "crates/ken-core/src/status/rules.rs": {
+      "bytes": 3308,
+      "sha256": "c0afe23ddf53d722519b672fd5b8912fbfebef1f676417c4bf5afce5edf93308"
+    },
+    "crates/ken-core/src/status.rs": {
+      "bytes": 1131,
+      "sha256": "489d271eeb971a1b28b68b856b47b75bb3678e375591338a1693ab8417566485"
+    },
+    "crates/ken-core/tests/fixtures/import-alias-edges.json": {
+      "bytes": 25740,
+      "sha256": "a5585c1f272b6f230a33848aa5175a48312374590d52ab14a49b0d5897b0e08a"
+    },
+    "crates/ken-core/tests/fixtures/import-alias-surrogates.json": {
+      "bytes": 9420,
+      "sha256": "bf231ebddb59458f4ce8393782d78635dc16a9eb669277f3a1734a5b056c6a6e"
+    },
+    "crates/ken-core/tests/fixtures/import-language-edges.json": {
+      "bytes": 35342,
+      "sha256": "3ae9b612a41e96411653d3577afadaf8dbe8489f328da12c6ba63631f2a41ab0"
+    },
+    "crates/ken-core/tests/fixtures/import-reference.json": {
+      "bytes": 48932,
+      "sha256": "3a75348978be412abbb6d7b4abc49785acb8d186ee33ac3246c767cc52b4e936"
+    },
+    "crates/ken-core/tests/fixtures/source-discovery/reference-review.json": {
+      "bytes": 165229,
+      "sha256": "ae684857de1b6bfd15ec713e445544506412cf0c6467631dad00e4295afd7cb6"
+    },
+    "crates/ken-core/tests/fixtures/source-discovery/reference.json": {
+      "bytes": 104312,
+      "sha256": "b8d7c4e79a532e02f38cc84e7484592ceaaa59984c7042052411073ea2f62ccc"
+    },
+    "crates/ken-core/tests/health.rs": {
+      "bytes": 7886,
+      "sha256": "12dbab109dcddf5058c56d8e6e361d4297e27c45c57577addb2cf02284aaffe6"
+    },
+    "crates/ken-core/tests/import_project.rs": {
+      "bytes": 6209,
+      "sha256": "8c64ad0f6b564ed046507fbd4aed3222d010fee22c2d7ee0dcaf17ce93a78a86"
+    },
+    "crates/ken-core/tests/import_resolution.rs": {
+      "bytes": 6724,
+      "sha256": "c27017c4e74fb35f5d26fec7ec252f1cd7c9ce5ad20d0bbf5379695cc79d1ba0"
+    },
+    "crates/ken-core/tests/project.rs": {
+      "bytes": 6228,
+      "sha256": "28fe05b5f6d0e027ae55c4b17d7a9337d819ef745c7b3afd3e0611cd2419a652"
+    },
+    "crates/ken-core/tests/source_filter.rs": {
+      "bytes": 6481,
+      "sha256": "a1fe30b210fc25a0edd042a2de33575fd90612c3ab6f147234d1c9f2e5ab1fba"
+    },
+    "crates/ken-core/tests/source_walk.rs": {
+      "bytes": 9987,
+      "sha256": "bd6afbb1fdc6ae3ec4930b6f089f453e8da16639f30dcdb5dd1eb092c352a050"
+    },
+    "crates/ken-core/tests/status.rs": {
+      "bytes": 10072,
+      "sha256": "c5464929f4e4a251047faee1f63d7be341ae78f97cf75e40d4506b64b903876f"
+    }
+  },
+  "tooling": {
+    "tools/__init__.py": {
+      "bytes": 80,
+      "sha256": "cc672f1041e449e9b702bb93a3bbcdc9383641556543ef3be576fa0a95e71047"
+    },
+    "tools/rust_migration/measure.py": {
+      "bytes": 4552,
+      "sha256": "0ffb80a1648467cd00cb45400b3c815b6cca0d5760a47ccb2309fcf85450e4d2"
+    },
+    "tools/rust_migration/storage_compare.py": {
+      "bytes": 11148,
+      "sha256": "8f8baa860d35236e227fa3176b5bad1aff670c9b0cc29a2feb3ccaaec246aab4"
+    },
+    "tools/rust_migration/parser_reference.py": {
+      "bytes": 12621,
+      "sha256": "00fbc24a7d18bb2c88449f6e77563526a831fe7c4b4124d6eb376fd82bf9c2e2"
+    },
+    "tools/rust_migration/import_validate.py": {
+      "bytes": 4381,
+      "sha256": "48828f7110e91b89946ca049a086036c014a689d733b1bfc7d289b9085033563"
+    },
+    "tools/rust_migration/policy_evidence.py": {
+      "bytes": 8303,
+      "sha256": "91632eb4d04323b7c95c74d2b17b6f8aeeeccba2b74cabc313f70ff3fd2c6571"
+    },
+    "tools/rust_migration/model_reference.py": {
+      "bytes": 8957,
+      "sha256": "56b63cb387a431188ef713660e67bc19f5ad964448aef17ea772a1466d85de58"
+    },
+    "tools/rust_migration/receipts.py": {
+      "bytes": 4788,
+      "sha256": "4280b58613e563bd20d0d7e0311928fca08747f4a39611a05123e8960cf0fb4d"
+    },
+    "tools/rust_migration/context_compare.py": {
+      "bytes": 12247,
+      "sha256": "c79f4a4db8e89db39f7289917305f596b76174f248e73a3c29ab5af454be68c3"
+    },
+    "tools/rust_migration/source_validate.py": {
+      "bytes": 9003,
+      "sha256": "d972011b403909d6dbef5403dab8f2c89798011d54f86bf0b31f1f25333bd898"
+    },
+    "tools/rust_migration/table_compare.py": {
+      "bytes": 9106,
+      "sha256": "8c76825717c1297246aa9d70735b280e903700ca5458bbee6b0d04d2164bb2f6"
+    },
+    "tools/rust_migration/translation_build.py": {
+      "bytes": 14992,
+      "sha256": "da7724c9f34f71eebf109c81ec21325747f017c75e637f995d1311a0863b21fe"
+    },
+    "tools/rust_migration/model_validate.py": {
+      "bytes": 17597,
+      "sha256": "ab4bfb85df0ff842bd785142e31c9fbbbf05d7e1043bf2ab9921b422f824fb1e"
+    },
+    "tools/rust_migration/fastembed_evidence.py": {
+      "bytes": 13071,
+      "sha256": "127df1f0b403b6a049b9a68d2fd5f0d663cab9f24546baade377119239e1315b"
+    },
+    "tools/rust_migration/translation_reference.py": {
+      "bytes": 9303,
+      "sha256": "fc5706535d48c5a8d53c425d43bedcaaaec39b8d2a15cec3320644e026d57e2c"
+    },
+    "tools/rust_migration/integration_compare.py": {
+      "bytes": 3367,
+      "sha256": "b2b401485b6eee7809992ebe6ce255563a230b81e65b7f14ed5f47b20276d4bc"
+    },
+    "tools/rust_migration/fastembed_ownership.py": {
+      "bytes": 12036,
+      "sha256": "65503f469595730e165b259d2a42d1dcc5cd0cd4b2d0031360eec08618108f20"
+    },
+    "tools/rust_migration/table_reference.py": {
+      "bytes": 7243,
+      "sha256": "e059ad45e1ae8612501f65847ccd9faf4caa6525d50f058a732b367ca35065bd"
+    },
+    "tools/rust_migration/fastembed_validate.py": {
+      "bytes": 13542,
+      "sha256": "1f3b31cc98beeb2b67650ef93807394dc4220f88321e6b809a10456f47c9a066"
+    },
+    "tools/rust_migration/source_evidence.py": {
+      "bytes": 9387,
+      "sha256": "46033e2566a072a96b0af3f88c4a1fca4e3222452ce7ea3e6877fddbe1856501"
+    },
+    "tools/rust_migration/integration_capture.py": {
+      "bytes": 7215,
+      "sha256": "e1a7ab5625a946d3580ca2011c9406b79589b754d0c98e9d63d0459268ee1849"
+    },
+    "tools/rust_migration/source_reference.py": {
+      "bytes": 8114,
+      "sha256": "c5137cb4b8af0b028807bfa99a54b76036d7402a1379baf94e3849c010ff515d"
+    },
+    "tools/rust_migration/fastembed_catalog.py": {
+      "bytes": 3797,
+      "sha256": "978facf54488ca13af21e70bc62225c9e9276be5732a3b735dfec40dd6d7ca61"
+    },
+    "tools/rust_migration/policy_compare.py": {
+      "bytes": 11297,
+      "sha256": "dbb43260a806be82e6bea187dc0ada76bd264313e113d109cd346b7807d54b6a"
+    },
+    "tools/rust_migration/storage_reference_child.py": {
+      "bytes": 14232,
+      "sha256": "8502c57da0317d6e08abfbd221f4cd5f328944254e09bb723d182ddd32959c49"
+    },
+    "tools/rust_migration/integration_process.py": {
+      "bytes": 398,
+      "sha256": "95186012bf42a40b2646e460a28fd2866a5ed0ee67c3f5ee224f2150febb2c91"
+    },
+    "tools/rust_migration/transformer_reference.py": {
+      "bytes": 19647,
+      "sha256": "a21cfe9481dcf0812d50ee1ccb18546c9d3bc1380012953195c892dfc2052196"
+    },
+    "tools/rust_migration/translation_compare.py": {
+      "bytes": 16407,
+      "sha256": "51f4222da2281bf23858df1682d1100204a830654e38801a8ec544e65da68a85"
+    },
+    "tools/rust_migration/__init__.py": {
+      "bytes": 74,
+      "sha256": "dc1e069b6b8053078e6b87958f7b61434fad0a26be01ce854c1d6e25926b7224"
+    },
+    "tools/rust_migration/storage_recovery_child.py": {
+      "bytes": 3813,
+      "sha256": "f554b37c01145a12448abf5491b9e2a3d169d68b83384b7b103c71889ad8f3e7"
+    },
+    "tools/rust_migration/integration_reference.py": {
+      "bytes": 7475,
+      "sha256": "697f0a8c0f2d6c52c860ff55883f9d83726d51aac49d17dabc7ebe6020025901"
+    },
+    "tools/rust_migration/import_reference.py": {
+      "bytes": 14008,
+      "sha256": "98c8a2e053012a99d6c516db492c44021faefbd9956762143cabafcb22841f6f"
+    },
+    "tools/rust_migration/model_compare.py": {
+      "bytes": 11890,
+      "sha256": "411447128758f71b7fdfd7cf348c4b5bdf390bea4d8321ff3581674a0836c13f"
+    },
+    "tools/rust_migration/policy_validate.py": {
+      "bytes": 12193,
+      "sha256": "fdd3ac0cc55c6fb2e59b8e6b2e2220b8c750f531b6dab00cbd906c9478affdcd"
+    },
+    "tools/rust_migration/ettin_reference.py": {
+      "bytes": 9049,
+      "sha256": "8922f83f2bfa2870827d9bf17e6352a17d377533974d41491a37002ce27c0c3d"
+    },
+    "tools/rust_migration/import_evidence.py": {
+      "bytes": 8443,
+      "sha256": "421fdd9f88a0d9b88af13ae6fb267dd94159873b395b34e1fa166c61d1493dd2"
+    },
+    "tools/rust_migration/integration_roles.py": {
+      "bytes": 10580,
+      "sha256": "930e821854514f538aa9f92b9c9d089495dc3a61eb01f2f5a52d2657314719d2"
+    },
+    "tools/rust_migration/storage_recovery.py": {
+      "bytes": 12926,
+      "sha256": "b9936ed48dba949f8116f6baaa7dddfce6c9e55a91a6779a137841d32454722b"
+    },
+    "tools/rust_migration/translation_fixtures.py": {
+      "bytes": 2621,
+      "sha256": "e014f47f2ef1771fe8aa19e77947a5db047b1cb3ad33fa1a7c048caa44d27c05"
+    },
+    "tools/rust_migration/integration_replay.py": {
+      "bytes": 16530,
+      "sha256": "98b144039e0ac79c20fcf7a104eef2809de83c2fa45e5da052d18696ecec69b7"
+    },
+    "tools/rust_migration/fastembed_reference.py": {
+      "bytes": 20650,
+      "sha256": "c844e16dc9d76c11cb30c6068de9625d0e7ec3fe6c309ef893b48b8017b29730"
+    },
+    "tools/rust_migration/ettin_validate.py": {
+      "bytes": 11635,
+      "sha256": "f99904a8fd1edcf43d2bcd8b12c583ace1118eba5b1277934b506821f90b0c11"
+    },
+    "tools/rust_migration/transformer_capture_judge.py": {
+      "bytes": 12140,
+      "sha256": "970a8c6d437f3169e0b5b1b8cf53c2197c08955ac181a12f99c70fa7c3cdb639"
+    },
+    "tools/rust_migration/validate.py": {
+      "bytes": 16891,
+      "sha256": "fb0548ade14f66c4c35ef58fa229febb769d09841135ded64b7cba9eecc9a51f"
+    },
+    "tools/rust_migration/parser_evidence.py": {
+      "bytes": 12972,
+      "sha256": "6a72d7735636ac2779e9d538c10fd8d5e36cde9062bcfa016a9ec044911138d0"
+    },
+    "tools/rust_migration/grammar_prepare.py": {
+      "bytes": 5582,
+      "sha256": "f2d84b8950610967b40a5eea38ce72eb5dcf76bd95a108c2db5590f4a499666b"
+    },
+    "tools/rust_migration/transformer_prepare.py": {
+      "bytes": 10086,
+      "sha256": "12e632618ef2e980d3a48e42e1b8af07d343b2aa3cc34f01d276153366b0d023"
+    },
+    "tools/rust_migration/context_fixtures.py": {
+      "bytes": 8262,
+      "sha256": "e19549dd9b20986d787718ea3c32d95ba0e1fa3f58db2faf27af92a8f27bbb27"
+    },
+    "tools/rust_migration/transformer_evidence.py": {
+      "bytes": 10832,
+      "sha256": "f5494d035340c0fe8d3beded260b6d9f54d55e3734effee79937edaaf7d54f9a"
+    },
+    "tools/rust_migration/transformer_compare.py": {
+      "bytes": 10449,
+      "sha256": "b91cf5de5b7fe8fa411b2cad78ff82e46f20ba0777ee0fded5a3741391cc0d38"
+    },
+    "tools/rust_migration/policy_reference.py": {
+      "bytes": 8761,
+      "sha256": "66684bbaa2d522141f1d3fef4bd1bb58b4b45bf0d1d53d0371819ef1b67b01b4"
+    },
+    "tools/rust_migration/fastembed_reference_child.py": {
+      "bytes": 6713,
+      "sha256": "35396d72619b149eff28ded5b8c1f46ec802471fca5a501d4d9af9a684d8d051"
+    },
+    "tools/rust_migration/integration_validate.py": {
+      "bytes": 14461,
+      "sha256": "72615ba984d350ebd05e80a128d254f3291b1b64c65749d20c2bf3c140ef1469"
+    },
+    "tools/rust_migration/translation_unicode.py": {
+      "bytes": 6616,
+      "sha256": "73f219750c4a9d7abc0418801de3452c6a62fd255faa28aebbe40475c960f77a"
+    },
+    "tools/rust_migration/storage_evidence.py": {
+      "bytes": 4153,
+      "sha256": "fb0c6f342c86b7f781bcbc4041e48ab30d4a04cae497e02468db292fd8294a0c"
+    },
+    "tools/rust_migration/reference.py": {
+      "bytes": 5539,
+      "sha256": "3380a0cc6fcd0124207d63754b0b065676a67855dfd6df45a4f8a7633a78a219"
+    },
+    "tools/rust_migration/fastembed_compare.py": {
+      "bytes": 18274,
+      "sha256": "26298f05630b81de055cfbc3933b4007b15ad0622a7048ba491a4ceeade27b52"
+    },
+    "tools/rust_migration/native_json.py": {
+      "bytes": 6489,
+      "sha256": "300208e9dbf5c7c1a41c6896a0b8f13b51f5b2d5f1aea08dc60133ac0e6ce949"
+    },
+    "tools/rust_migration/table_fixtures.py": {
+      "bytes": 3822,
+      "sha256": "98c835d95bebea06d1da416798f1f4390e628635f0d775599d223016ddd3677d"
+    },
+    "tools/rust_migration/fastembed_sources.py": {
+      "bytes": 5870,
+      "sha256": "0ef3aeed831d7438d13b925a35e03d0dbd5475e0631d202205c79b4faf318ea8"
+    },
+    "tools/rust_migration/table_validate.py": {
+      "bytes": 8354,
+      "sha256": "3f1c620b74d9c54509c0f6c8b7c795e839861e29ecfd503abc6c36c612dc8d78"
+    },
+    "tools/rust_migration/transformer_process.py": {
+      "bytes": 6824,
+      "sha256": "f8bd0a2053be6c70fc3a95ed348b8524e1194b4f49d708a1a16b43d39cd2a13f"
+    },
+    "tools/rust_migration/storage_validate.py": {
+      "bytes": 14279,
+      "sha256": "59806a810c4298064fd688966c14c70e506060d45b3b8af3debc64a61398c054"
+    },
+    "tools/rust_migration/context_reference.py": {
+      "bytes": 10064,
+      "sha256": "4d3b0e4ddcba14d5790b2632358b9b04984c812a9bb7350194ddd2795fa37b5c"
+    },
+    "tools/rust_migration/transformer_sources.py": {
+      "bytes": 3826,
+      "sha256": "8111f58ce8a35e6bc0ec6db4527ffeb15602fe640419a3a0e89f3ccd535f497f"
+    },
+    "tools/rust_migration/context_validate.py": {
+      "bytes": 10861,
+      "sha256": "deba39ee07ad21512fa252348dadd176808880341457d5cf4505766cce8aaf52"
+    },
+    "tools/rust_migration/compare.py": {
+      "bytes": 9999,
+      "sha256": "6dab072d0845e823878fe33d5d11beb7439933e8513c2cd306d1bfc51fe14778"
+    },
+    "tools/rust_migration/storage_reference.py": {
+      "bytes": 6514,
+      "sha256": "9b3094147813a470a6265676d230a5f52f765c83ca4a5e0d801099ffeb69e0ff"
+    },
+    "tools/rust_migration/fastembed_process.py": {
+      "bytes": 10007,
+      "sha256": "7f7a8b09760903cfe80a7f1db38593ba81bb7955be3c59f8e8998ba596b5e79e"
+    },
+    "tools/rust_migration/transformer_validate.py": {
+      "bytes": 9968,
+      "sha256": "fca3431505a352bc306b855b1bf845153d64360ea9e2a524ca3e14db8ac79486"
+    },
+    "tools/rust_migration/preparation.py": {
+      "bytes": 9837,
+      "sha256": "2961392ca86803839724608070d349bd4de8416807d4df2d2196cac2e4e261c8"
+    },
+    "tools/rust_migration/ettin_compare.py": {
+      "bytes": 15945,
+      "sha256": "a81d3c4ac156d9891413aa7623417a5bcb9cc5d642970e0a3a4575c31eec9853"
+    },
+    "tools/rust_migration/fixtures.py": {
+      "bytes": 12730,
+      "sha256": "9b2bdbeefb81d8924d9d2650f9f1789a6ae09a6901128220b6c946b195316158"
+    },
+    "tools/rust_migration/ettin_fixtures.py": {
+      "bytes": 8546,
+      "sha256": "9d755cdd2400ccd30874dab1429d9e6cb0e946d88ddef8c6f41d005f09a01786"
+    },
+    "tools/rust_migration/translation_validate.py": {
+      "bytes": 13752,
+      "sha256": "2882f6858e3a6dd1224e6d26bd9ff620bb7183815de448e960e3566d111d498e"
+    },
+    "tools/rust_migration/parser_validate.py": {
+      "bytes": 6846,
+      "sha256": "ef5f0d15a9d5c180fc6c76de5d70319a68620d96ebd5ed79504fa88c92ae4e07"
+    },
+    "tools/rust_migration/inventory.py": {
+      "bytes": 7966,
+      "sha256": "34c1e8514fa3b29f263a88cf9b5644beee5380215cbc00e88cdd36494cce47bd"
+    },
+    "tools/rust_migration/transformer_execution.py": {
+      "bytes": 10238,
+      "sha256": "3c213d2a3609f7774e3cb170ac707e542759bf2ba8c26c5ebad82b5f924c769e"
+    },
+    "tests/rust_migration/test_import_matrix.py": {
+      "bytes": 2982,
+      "sha256": "81506cb7a92f4fd3fd1a91661b0373edc68548baa0ea4ba1bb626c5764b56471"
+    },
+    "tests/rust_migration/test_import_reference.py": {
+      "bytes": 2063,
+      "sha256": "25805e6d0bda4212bc250c6c9c0b75bdfbf0a4e34b0a010f32308827c42c05b8"
+    },
+    "tests/rust_migration/test_import_validate.py": {
+      "bytes": 2235,
+      "sha256": "92036bf96b59ab0c750568f63cb163537a9e3b82f5f8776fc846c2aa0445dfe6"
+    },
+    "tests/rust_migration/test_import_evidence.py": {
+      "bytes": 3376,
+      "sha256": "38da989730ee6a078b78a61ccccb1994c6a59536c15d219f46dee98809228ed7"
+    }
+  },
+  "platforms": {
+    "macos": {
+      "native_sha256": "6bcc29ef05979fbf61499826b79649324146671cc580b606ed8800fe84a268fb"
+    },
+    "linux": {
+      "native_sha256": "81d364f07d20b7ad12f8f2d17bc6822816291e533a35ddfd338cf400f7eefb84"
+    }
+  },
+  "predecessor": {
+    "path": "docs/validation/rust-migration-2026-10-23/m3-parsers-review",
+    "sha256": "c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8"
+  }
+}
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/LEDGER.md b/docs/validation/rust-migration-2026-10-23/m3-imports/LEDGER.md
new file mode 100644
index 00000000..c438815d
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/LEDGER.md
@@ -0,0 +1,33 @@
+# SDD ledger — plan: docs/superpowers/plans/2026-10-23-rust-import-resolution.md
+
+Authorization: wholemigration, nativeinline, no confirmations, original1066/userdirt preserved, reuse unchanged validated work.
+Closed M3b:03400e2b,33Rust/38tooling perplatform,249inputs/215syntaxshapes,2Important TDDfixed/noMinor. Finalreceipt FILES SHA c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8. Bothplatform reference.json caches preserved outside completedWS; removed104788089ownedtemporary/cachebytesMac plus obsoleteLinuxworkspace/transports. CurrentSDK/models/compileddependencies kept. ~140GiBfree.
+Pre-flight1→2: catalog/data/pathcontracts precede orderedconfig/aliasconsumer.1/2→3: languagepolicies consume stable inventory andconfig data.1/2/3→4: projectreader only prepares bytes for purecatalog.1–4→5: acceptance requires complete resolution/errors and actualprojectconfig acquisition. No sharedinterface conflict found; current M3b histories remain immutable.
+Task1: Ruling: expose ImportCatalog::structural_target(&self,module:&str,source:Option<&str>)->Option<String> as the original structural-phase boundary for meaningful caller-level tests; resolve remains explicitly pending for specialized policies until Tasks2/3. Costifwrong: an extra narrow API, no hidden languageguess/fallback.
+First ken_find attempted semantic owner lookup and returned tool error; read actualindexer/jsresolve/model sources directly. SourceIR normalization depends on structuralIR and is planned separately before fullM3acceptance; not claimed completed by imports.
+
+Task1 referenceRED missingcapturemodule;3toolingtests GREEN eachplatform.33original indexer tests passed onceperplatform,60resolutioncalls/59uniqueinputs/60queries,including2actualAttributeError configshape failures. Full input/config/results and structural-targets equal independently acrossMac/Linux; parser124suite/models were not rerun.
+Task1 nativeRED missingimportsAPI; implemented ImportCatalog/path policy.2new publiccases compare all60original structural targets includingNone,7extension/indexfallbacks,exactpath/ESMpriority,Unicode/quotes/controlwhitespace andambiguoussuffixes. Full37/37ken-core tests eachplatform,clippy/fmt/1066guardGREEN. Specializedconfig/language policies still explicitPending. Count audit initially expected36 but observed37: acceptance uses actual complete37case logs, without repeating passingtests.
+Task 1: complete (tests: saved3tooling/37Rust perplatform,exactoriginalcaseequality and1066guard;commit follows;Task2may proceed.)
+
+Task2 actualJS/TS RED pendingconfiguration. Ordered aliases,nearestconfig/fallthrough,parentbase/extends<3,workspacepackagepriority andstableduplicatepositions implemented.12newdirectoriginal priority/Unicodecases independently matchLinux/Mac in addition to59maincases; no original33suite rerun. Separateoriginalcaptures retainrequests/rawobservations/script andprovenance.
+Task2: Ruling: Pythonjson acceptsNaN/Infinity andoverflowingnumbers inignoredfields, plusnon-scalarstrings. Defaultserde_json valuevisitor wouldinvalidate aconfig thatoriginalstilluses. ConfigValue owns orderedobjects andPythontruthiness with nativeJSONCcleanup; RawValue validates individualstring/numbertokens. A smallorderedparser handles these actualcapturedcases, withno newcrate/features or globalserde_jsonchange. This replaces theplannedserdevisitor. Costifwrong: configcouldlosealiases; fulloriginalsincludeNaN/1e999,duplicates,Unicode,invalidJSON andwrongshapes.
+Task2 actualnon-scalar target case exposed external vsoriginalunresolved: directText(None) targetwasdroppingalias key. REDsaved, preservekeywithemptytargetvector; bothoriginbase/targetcases andnativeclassificationGREEN. NonUTF8representabletargetcannotmatchUTF8inventory butoriginalinternalshape survives.
+Task2 pureJSONparser/aliases firstapply_patch failed atomiccontextmatch; no partialfiles or originalchanges. Reapplied againstactualmod.rs; clippy clean withoutsuppressions.
+Task 2: complete (verification:40Rust eachplatform,3unchangedcapturetooltests cachedGREEN eachplatform,12neworiginalcaseequality,clippy/fmt/1066guardGREEN. Commit follows;Task3may proceed.)
+
+Task3 actualRED pendinglanguagepolicy. Implemented nativeJava/Rust/Go/Ruby/C++/Kotlin/PHP targets andallunresolved/external shapes, genericpassbeforelanguagepolicy. NoPending variants or branches remain. LanguageModules owns sharedpreparedinventory/configdata; classification owns originalintentlabels.20newindependentoriginal cases matchMac/Linux, includingnestedCargo,Goearlyreturn,glob/wildcardquirks,Ruby/C++/PHPgenericcollisions andPSR4array/primitive dirs.
+Task3: Ruling: originalPSR4 coerces directories withPythonstr, including3,3e0,True,None. ConfigValue retains typedtruth andPythonspelling, preserving originalnumeric/boolean/null paths instead ofrejecting or inventingdefaultdirs. Captured4primitivecases withambiguousclassfallback forceactualPSR4targetuse; orderedautoload/autoload-dev andarraytargets also verified. Costifwrong: PHPwrongedge; allactualfulltargets compared.
+Task 3: complete (verification:41Rust eachplatform,91originalcases/92queries total,including2originalconfigerrors;20neworiginals equal,prior3toolingtests reusable unchanged,clippy/fmt/1066guardGREEN. Commit follows;Task4may proceed.)
+
+Task4 RED missingfrom_project;4newactualfilesystem cases GREENMac/Linux,full45Rust eachplatform. All91originaldatasets nowalso exercised throughactualconfigfiles,plusreload snapshots,unindexedpackage exclusion,unindexedextendsparent discovery,JSONCUTF8replacement/PHPstrictdecoding,andmissingroot/files/directory-readerror tolerance. No process/network/database access introduced. Clippy firstrejectednestedif; collapsed conditionwithout suppression, allgatesGREEN.
+Task4: Ruling: indexedrootconfigs can referenceunindexedextendsparents; priorphrase onlyindexedpaths wasincomplete. AliasResolver nowtakesprivate byte-loader callback, used byMap andprojectreader. Parentchoice/depth/shape rule stays inoneowner, no duplicateddependencywalker. Filesystemadapter onlyreadsbytes anddelegates; Catalog prepareslanguage metadataafteraliases asoriginal. Costifwrong: missedparentaliases/unexpectedreads; actualoriginalunindexedparent fixture andall91project-mode cases verify it. Spec/plan amended.
+Task4: Ruling: portableunreadable-config testusesa directoryatconfigpath (actualOSError onbothMacuser/Linuxroot), sincechmod0 isreadableforLinuxroot. Missing/unreadableinputs preserveoriginaltolerance. Costifwrong: OSpermissionedge notdirectlyexercised; nativefs::read OSError paths sharethesameownedtolerance.
+Task 4: complete (verification:45Rust eachplatform,clippy/fmt/1066guardGREEN,3unchangedcapturetests reused;commit follows;Task5may proceed.)
+
+Task5 countaudit: earlier37/40/41/45Rust totals summed every test-result line, including one nativechild helper execution. Complete root inventories are36/39/40/44 respectively. Finalacceptance uses existing rust_gate_errors to validate exactdiscovery/execution and childnesting, then44rootcases; the childexecution remains inrawlogs. No tests lost/ignored and no native rerun solely forcorrecting this reportingerror.
+Task5 nativeJSONprotocol/evidence REDmissingAPIs then30/30newtooling cases GREENMac/Linux. Final45execution(44root+1child)/33tooling gates GREENeachplatform and182outside-checkout nativecases/184requests captured withinput-only protocol,actual configtrees,emptyPATH,loaderaudit andLinuxexec/connecttrace. Original33suite/main59captures andprior models/parser proofs reused; newdirect32edgeinputs retained separately.
+Task5: Ruling: sources/tooling andplatformrawhistories are compressedintoarchives, reducing productartifactcount toabout10files instead ofhundreds ofduplicate scratchfiles. VERIFY authenticatesexactarchive memberbytes before importing snapshotreplay; no currentcode/modelinference rerun forhistoricalproofs. Costifwrong: historicalreplaycouldloseprovenance; exactsourceMap/manifest,raworiginal andcase/test checks guardit.
+
+Task5 authenticatedmatrixVERIFY --current GREEN:44rootRust/33tooling eachplatform;91originalinputs in2actualnative modes,182cases/184requests.8resealedmatrixtests GREEN, including source/platform/request/config/stdout/original/gate tampering. NoPython/native subprocess/network fallback; originalconfigfailures retained.
+Task 5: complete (verification: rawboth-platformgates,actualnative captures,independentcompressedreplay and8resealedmatrix cases GREEN;freshwholeplanreview follows before advancing.)
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/MINORS.md b/docs/validation/rust-migration-2026-10-23/m3-imports/MINORS.md
new file mode 100644
index 00000000..edeefbff
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/MINORS.md
@@ -0,0 +1 @@
+None recorded.
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/README.md b/docs/validation/rust-migration-2026-10-23/m3-imports/README.md
new file mode 100644
index 00000000..bebb297f
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/README.md
@@ -0,0 +1,29 @@
+# Native import resolution — M3c
+
+ImportCatalog now resolves generic paths, JS/TS aliases/workspaces and the
+original Java, Rust, Go, Ruby, C++, Kotlin and PHP policies. It preserves
+ambiguous targets, ordered priorities, internal-gap versus external labels and
+original configuration failures. Project config acquisition delegates parent
+selection to the alias owner and performs no database writes.
+
+Each actual macOS arm64/Linux aarch64 platform runs44Rust root and33affected tooling
+cases. An external copied executable processes91original datasets in both explicit
+input and actual project-file modes:182cases/184requests, including four expected
+configuration failures. All targets/classifications and case order are compared.
+The original33indexer-test captures and earlier model/parser histories are reused;
+only new direct edge inputs were additionally captured. No inference rerun.
+
+`sources.tar.gz` contains exact native/tooling snapshots; platform archives contain
+raw original/native requests, observations, loader/exec/connect audit and test gates.
+`FILES.json` seals the compressed receipt; semantic replay rejects resealed changes
+and missing cases, modes, sources, configs, tests or platforms. The bootstrap
+checks every archived source byte before importing its replay implementation.
+
+```sh
+PYTHONPATH=. .venv/bin/python docs/validation/rust-migration-2026-10-23/m3-imports/VERIFY.py --current
+```
+
+Run from the repository root. Omit `--current` after subsequent native edits to
+replay this historical snapshot. The final whole-plan review remains pending.
+Only M3c is accepted by this matrix: common model and incremental indexing remain
+M3 work; M4–M8 and installed application cutover remain pending. Originals intact.
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/RULINGS.md b/docs/validation/rust-migration-2026-10-23/m3-imports/RULINGS.md
new file mode 100644
index 00000000..9b5633fe
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/RULINGS.md
@@ -0,0 +1,11 @@
+Task1: Ruling: expose ImportCatalog::structural_target(&self,module:&str,source:Option<&str>)->Option<String> as the original structural-phase boundary for meaningful caller-level tests; resolve remains explicitly pending for specialized policies until Tasks2/3. Costifwrong: an extra narrow API, no hidden languageguess/fallback.
+
+Task2: Ruling: Pythonjson acceptsNaN/Infinity andoverflowingnumbers inignoredfields, plusnon-scalarstrings. Defaultserde_json valuevisitor wouldinvalidate aconfig thatoriginalstilluses. ConfigValue owns orderedobjects andPythontruthiness with nativeJSONCcleanup; RawValue validates individualstring/numbertokens. A smallorderedparser handles these actualcapturedcases, withno newcrate/features or globalserde_jsonchange. This replaces theplannedserdevisitor. Costifwrong: configcouldlosealiases; fulloriginalsincludeNaN/1e999,duplicates,Unicode,invalidJSON andwrongshapes.
+
+Task3: Ruling: originalPSR4 coerces directories withPythonstr, including3,3e0,True,None. ConfigValue retains typedtruth andPythonspelling, preserving originalnumeric/boolean/null paths instead ofrejecting or inventingdefaultdirs. Captured4primitivecases withambiguousclassfallback forceactualPSR4targetuse; orderedautoload/autoload-dev andarraytargets also verified. Costifwrong: PHPwrongedge; allactualfulltargets compared.
+
+Task4: Ruling: indexedrootconfigs can referenceunindexedextendsparents; priorphrase onlyindexedpaths wasincomplete. AliasResolver nowtakesprivate byte-loader callback, used byMap andprojectreader. Parentchoice/depth/shape rule stays inoneowner, no duplicateddependencywalker. Filesystemadapter onlyreadsbytes anddelegates; Catalog prepareslanguage metadataafteraliases asoriginal. Costifwrong: missedparentaliases/unexpectedreads; actualoriginalunindexedparent fixture andall91project-mode cases verify it. Spec/plan amended.
+
+Task4: Ruling: portableunreadable-config testusesa directoryatconfigpath (actualOSError onbothMacuser/Linuxroot), sincechmod0 isreadableforLinuxroot. Missing/unreadableinputs preserveoriginaltolerance. Costifwrong: OSpermissionedge notdirectlyexercised; nativefs::read OSError paths sharethesameownedtolerance.
+
+Task5: Ruling: sources/tooling andplatformrawhistories are compressedintoarchives, reducing productartifactcount toabout10files instead ofhundreds ofduplicate scratchfiles. VERIFY authenticatesexactarchive memberbytes before importing snapshotreplay; no currentcode/modelinference rerun forhistoricalproofs. Costifwrong: historicalreplaycouldloseprovenance; exactsourceMap/manifest,raworiginal andcase/test checks guardit.
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/VERIFY.py b/docs/validation/rust-migration-2026-10-23/m3-imports/VERIFY.py
new file mode 100644
index 00000000..9affca6b
--- /dev/null
+++ b/docs/validation/rust-migration-2026-10-23/m3-imports/VERIFY.py
@@ -0,0 +1,22 @@
+"""Authenticate archived source bytes before importing their replay implementation."""
+from pathlib import Path
+import hashlib,json,sys,tarfile,tempfile
+sys.dont_write_bytecode=True
+proof=Path(__file__).resolve().parent
+index=json.loads((proof/'INDEX.json').read_bytes())
+expected={**{'native-sources/'+p:v for p,v in index['sources'].items()},**{'validation-sources/'+p:v for p,v in index['tooling'].items()}}
+with tempfile.TemporaryDirectory(prefix='ken-import-snapshot-')as temporary:
+    snapshot=Path(temporary)
+    with tarfile.open(proof/'sources.tar.gz')as archive:
+        members=archive.getmembers()
+        assert len(members)==len(expected)and{m.name for m in members}==set(expected),'source archive membership differs'
+        for member in members:
+            assert member.isfile()and not Path(member.name).is_absolute()and'..'not in Path(member.name).parts,'unsafe source archive member'
+            raw=archive.extractfile(member).read()
+            assert expected[member.name]==dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),'source archive bytes differ'
+        archive.extractall(snapshot,filter='data')
+    sys.path.insert(0,str(snapshot/'validation-sources'))
+    from tools.rust_migration.import_evidence import aggregate_import_matrix
+    result=aggregate_import_matrix(proof,Path.cwd(),snapshot=snapshot,current='--current'in sys.argv)
+    print(json.dumps(result,indent=2))
+    raise SystemExit(0 if result['passed'] else 1)
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/development-logs.tar.gz b/docs/validation/rust-migration-2026-10-23/m3-imports/development-logs.tar.gz
new file mode 100644
index 00000000..796ee3a7
Binary files /dev/null and b/docs/validation/rust-migration-2026-10-23/m3-imports/development-logs.tar.gz differ
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/linux-capture.tar.gz b/docs/validation/rust-migration-2026-10-23/m3-imports/linux-capture.tar.gz
new file mode 100644
index 00000000..0c95fad8
Binary files /dev/null and b/docs/validation/rust-migration-2026-10-23/m3-imports/linux-capture.tar.gz differ
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/macos-capture.tar.gz b/docs/validation/rust-migration-2026-10-23/m3-imports/macos-capture.tar.gz
new file mode 100644
index 00000000..c86752ce
Binary files /dev/null and b/docs/validation/rust-migration-2026-10-23/m3-imports/macos-capture.tar.gz differ
diff --git a/docs/validation/rust-migration-2026-10-23/m3-imports/sources.tar.gz b/docs/validation/rust-migration-2026-10-23/m3-imports/sources.tar.gz
new file mode 100644
index 00000000..ab169e81
Binary files /dev/null and b/docs/validation/rust-migration-2026-10-23/m3-imports/sources.tar.gz differ
diff --git a/tests/rust_migration/test_import_evidence.py b/tests/rust_migration/test_import_evidence.py
new file mode 100644
index 00000000..c6876b87
--- /dev/null
+++ b/tests/rust_migration/test_import_evidence.py
@@ -0,0 +1,56 @@
+"""Actual native process evidence and strict input-only protocol boundaries."""
+from copy import deepcopy
+import json,os,shutil,subprocess
+from pathlib import Path
+import pytest
+from tools.rust_migration.import_validate import import_cases,run_import_capture
+from tools.rust_migration.import_evidence import verify_import_capture
+from tools.rust_migration.native_json import NativeJsonCapture
+REPO=Path(__file__).resolve().parents[2]
+
+@pytest.fixture(scope='module')
+def capture(tmp_path_factory):
+    out=tmp_path_factory.mktemp('import-evidence')/'capture';cases=import_cases(REPO)
+    run_import_capture(REPO,Path(os.environ['KEN_IMPORT_PROBE']),cases,out)
+    return out,cases
+
+def test_actual_both_mode_capture_and_native_audit(capture):
+    out,cases=capture;assert verify_import_capture(out,cases)==[]
+
+@pytest.mark.parametrize('mutation',['stdout','request','resource','source','binary','exit','loader','cwd','summary'])
+def test_resealed_native_execution_cannot_hide_changed_proof(capture,tmp_path,mutation):
+    original,cases=capture;out=tmp_path/'capture';shutil.copytree(original,out)
+    if mutation=='loader':(out/'stderr.log').write_text('libpython.so')
+    else:
+        file={'stdout':'stdout.json','request':'inputs.json','resource':'BUILD.json','source':'BUILD.json','binary':'BUILD.json'}.get(mutation,'execution.json')
+        path=out/file;value=json.loads(path.read_bytes())
+        if mutation=='stdout':value['cases'].pop()
+        elif mutation=='request':value['cases'][0]['expected']={}
+        elif mutation=='resource':value['resources'][0]['sha256']='0'*64
+        elif mutation=='source':value['sources']['Cargo.lock']['sha256']='0'*64
+        elif mutation=='binary':value['native_sha256']='0'*64
+        elif mutation=='exit':value['exit']=1
+        elif mutation=='cwd':value['cwd']=str(REPO)
+        else:value['passed']=True
+        path.write_text(json.dumps(value))
+    assert verify_import_capture(out,cases)
+
+@pytest.mark.parametrize('mutation',['top','case','import','source','hex','unicode_hex','duplicate','relative_root','kind'])
+def test_native_protocol_rejects_untrusted_shape_and_encoding(mutation):
+    row=dict(id='case',files=['main.ts'],imports=[dict(module='value',source_path='main.ts',language='typescript')],source=dict(kind='inputs',configs=None))
+    request=dict(cases=[row])
+    if mutation=='top':request['expected']={}
+    elif mutation=='case':row['expected']={}
+    elif mutation=='import':row['imports'][0]['expected']={}
+    elif mutation=='source':row['source']['expected']={}
+    elif mutation in ('hex','unicode_hex'):row['source']['configs']={'tsconfig.json':'0g'if mutation=='hex'else'\u00e9'}
+    elif mutation=='duplicate':request['cases'].append(deepcopy(row))
+    elif mutation=='relative_root':row['source']=dict(kind='project',root='relative')
+    else:row['source']['kind']='other'
+    result=subprocess.run([os.environ['KEN_IMPORT_PROBE']],input=json.dumps(request).encode(),capture_output=True,timeout=10)
+    assert result.returncode!=0 and result.stdout==b''
+
+def test_capture_rejects_interpreter_script_before_launch(tmp_path):
+    script=tmp_path/'probe';script.write_text('#!/usr/bin/python3\nprint(1)\n');script.chmod(0o755)
+    with pytest.raises(ValueError,match='native executable'):
+        with NativeJsonCapture(script,tmp_path/'capture',repo=REPO,prefix='ken-import-process-'):pass
diff --git a/tests/rust_migration/test_import_matrix.py b/tests/rust_migration/test_import_matrix.py
new file mode 100644
index 00000000..6cf9fdf6
--- /dev/null
+++ b/tests/rust_migration/test_import_matrix.py
@@ -0,0 +1,41 @@
+"""Re-sealing altered compressed receipts cannot make missing evidence pass."""
+import json,shutil,tarfile
+from pathlib import Path
+import pytest
+from tools.rust_migration.import_evidence import aggregate_import_matrix
+from tools.rust_migration.native_json import identity
+REPO=Path(__file__).resolve().parents[2]
+PROOF=REPO/'docs/validation/rust-migration-2026-10-23/m3-imports'
+def seal(folder):
+    rows=[dict(path=str(p.relative_to(folder)),**identity(p))for p in sorted(folder.iterdir())if p.is_file()and p.name!='FILES.json']
+    (folder/'FILES.json').write_text(json.dumps(dict(files=rows),indent=2)+'\n')
+def replay(proof,tmp_path,current=False):
+    source=tmp_path/'source';source.mkdir()
+    with tarfile.open(proof/'sources.tar.gz')as archive:archive.extractall(source,filter='data')
+    return aggregate_import_matrix(proof,REPO,snapshot=source,current=current)
+def test_actual_matrix_accepts_only_import_resolution(tmp_path):
+    result=replay(PROOF,tmp_path,current=True);assert result['passed'],result
+    assert result['M3c_accepted']and not result['M3_accepted']and not result['migration_complete']
+
+@pytest.mark.parametrize('mutation',['platform','source','request','resource','stdout','original','gate'])
+def test_resealed_compressed_evidence_rejects_tampering(tmp_path,mutation):
+    out=tmp_path/'proof';shutil.copytree(PROOF,out);index=json.loads((out/'INDEX.json').read_bytes())
+    if mutation=='platform':index['platforms'].pop('linux')
+    elif mutation=='source':index['sources']['Cargo.lock']['sha256']='0'*64
+    else:
+        capture=tmp_path/'capture';capture.mkdir()
+        with tarfile.open(out/'linux-capture.tar.gz')as archive:archive.extractall(capture,filter='data')
+        if mutation=='gate':(capture/'gates/rust-tests.log').write_text('test result: ok. 45 passed; 0 failed; 0 ignored;\n')
+        elif mutation=='original':
+            path=capture/'original/original-observations.json';value=json.loads(path.read_bytes());value['cases'].pop();path.write_text(json.dumps(value))
+        elif mutation=='resource':
+            path=capture/'native/BUILD.json';value=json.loads(path.read_bytes());value['resources'][0]['sha256']='0'*64;path.write_text(json.dumps(value))
+        else:
+            path=capture/'native'/('inputs.json'if mutation=='request'else'stdout.json');value=json.loads(path.read_bytes())
+            if mutation=='request':value['cases'][0]['expected']={}
+            else:value['cases'].pop()
+            path.write_text(json.dumps(value));receipt=capture/'native/execution.json';execution=json.loads(receipt.read_bytes());execution['request_sha256'if mutation=='request'else'stdout_sha256']=identity(path)['sha256'];receipt.write_text(json.dumps(execution))
+        with tarfile.open(out/'linux-capture.tar.gz','w:gz')as archive:
+            for path in capture.iterdir():archive.add(path,arcname=path.name)
+    (out/'INDEX.json').write_text(json.dumps(index));seal(out)
+    assert not replay(out,tmp_path)['passed']
diff --git a/tests/rust_migration/test_import_reference.py b/tests/rust_migration/test_import_reference.py
new file mode 100644
index 00000000..8b9afadb
--- /dev/null
+++ b/tests/rust_migration/test_import_reference.py
@@ -0,0 +1,38 @@
+"""Resolution references come from real original callers and retain complete inputs."""
+from dataclasses import replace
+import json, os, sys
+from pathlib import Path
+import pytest
+from tools.rust_migration.reference import Reference
+from tools.rust_migration.import_reference import capture_import_reference, import_owner_hashes, validate_import_reference
+
+REPO=Path(__file__).resolve().parents[2]
+def reference():
+    return replace(Reference.load(Path(os.environ.get('KEN_RUST_REFERENCE',REPO/'.ken/rust-migration/m2-optional/reference-final-t9'))),python=Path(sys.executable).absolute())
+
+def test_import_owner_drift_rejected_before_original_execution(tmp_path):
+    old=reference();root=tmp_path/'original';root.mkdir()
+    for name in import_owner_hashes(REPO):
+        target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((old.root/name).read_bytes())
+    (root/'src/ken/jsresolve.py').write_text('# altered original')
+    with pytest.raises(ValueError,match='original import owner changed'):
+        capture_import_reference(replace(old,root=root),tmp_path/'out',repo=REPO)
+
+@pytest.fixture(scope='module')
+def captured(tmp_path_factory):
+    out=Path(os.environ.get('KEN_IMPORT_REFERENCE_OUT',tmp_path_factory.mktemp('imports')/'capture'))
+    return out,capture_import_reference(reference(),out,repo=REPO)
+
+def test_real_indexer_callers_and_missing_target_cases_are_captured_once(captured):
+    out,value=captured
+    assert validate_import_reference(value)==[]
+    assert len(value['discovered'])>=30
+    assert any(r['tests']for r in value['cases'])
+    assert any(None in r['structural_targets']for r in value['cases'])
+    assert any(r['input']['configs']is not None for r in value['cases'])
+    assert capture_import_reference(replace(reference(),python=Path('/missing/python')),out,repo=REPO)==value
+
+def test_lost_reordered_or_modified_reference_case_is_rejected(captured):
+    out,_=captured;value=json.loads((out/'reference.json').read_bytes())
+    value['cases'].pop()
+    assert validate_import_reference(value)
diff --git a/tests/rust_migration/test_import_validate.py b/tests/rust_migration/test_import_validate.py
new file mode 100644
index 00000000..de524e52
--- /dev/null
+++ b/tests/rust_migration/test_import_validate.py
@@ -0,0 +1,44 @@
+"""Import acceptance retains every complete edge in input and project modes."""
+from copy import deepcopy
+from pathlib import Path
+import pytest
+from tools.rust_migration.import_validate import import_cases, compare_import_observations, source_identity
+REPO=Path(__file__).resolve().parents[2]
+
+@pytest.fixture
+def cases():return import_cases(REPO)
+
+def observed(cases):
+    rows=[]
+    for row in cases:
+        for mode in ('inputs','project'):
+            if 'error'in row:
+                error=dict(kind='invalid_config',path=next(iter(row['input']['configs'])),reason='invalid config shape')
+                rows.append(dict(id=mode+':'+row['id'],error=error))
+            else:rows.append(dict(id=mode+':'+row['id'],results=deepcopy(row['results'])))
+    return dict(format='ken-import-observation/1',cases=rows)
+
+def test_complete_original_inventory_and_both_native_modes(cases):
+    assert len(cases)==91 and sum(len(c['input']['imports'])for c in cases)==92
+    assert len([c for c in cases if'error'in c])==2
+    assert compare_import_observations(cases,observed(cases))==[]
+
+@pytest.mark.parametrize('mutation',['missing','duplicate','reorder','target','classification','error','success','format'])
+def test_changed_or_lost_edges_and_failures_are_rejected(cases,mutation):
+    actual=observed(cases);rows=actual['cases']
+    if mutation=='missing':rows.pop()
+    elif mutation=='duplicate':rows[-1]=deepcopy(rows[0])
+    elif mutation=='reorder':rows[0],rows[1]=rows[1],rows[0]
+    elif mutation in ('target','classification'):
+        result=next(r['results'][0]for r in rows if r.get('results'))
+        result['target'if mutation=='target'else'resolution']='changed'
+    elif mutation=='error':next(r for r in rows if'error'in r)['error']['kind']='other'
+    elif mutation=='success':
+        row=next(r for r in rows if'error'in r);row.pop('error');row['results']=[]
+    else:actual['format']='other'
+    assert compare_import_observations(cases,actual)
+
+def test_source_identity_includes_input_assets_and_actual_filesystem_owner():
+    sources=source_identity(REPO)
+    assert 'crates/ken-core/tests/fixtures/import-alias-surrogates.json'in sources
+    assert 'crates/ken-core/src/imports/project_inputs.rs'in sources
diff --git a/tools/rust_migration/import_evidence.py b/tools/rust_migration/import_evidence.py
new file mode 100644
index 00000000..d9b485e5
--- /dev/null
+++ b/tools/rust_migration/import_evidence.py
@@ -0,0 +1,91 @@
+"""Authenticate actual import observations without trusting passing summaries."""
+from __future__ import annotations
+from pathlib import Path
+from .native_json import load,verify_native_json
+from .import_validate import requests,compare_import_observations
+
+def verify_import_capture(out:Path,cases:list[dict],sources:dict|None=None,native_sha256:str|None=None)->list[str]:
+    try:
+        def require(value,message):
+            if not value:raise ValueError(message)
+        errors=verify_native_json(out,'ken-import-process-');require(not errors,'; '.join(errors))
+        build=load(out/'BUILD.json');execution=load(out/'execution.json')
+        require(build['format']=='ken-import-build/1'and build['sources']==load(out/'SOURCES.json'),'native import source inputs differ')
+        if sources is not None:require(build['sources']==sources,'native import source snapshot differs')
+        require(build['native_sha256']==execution['native_sha256'],'native import binary differs')
+        if native_sha256 is not None:require(build['native_sha256']==native_sha256,'pinned native import binary differs')
+        expected,resources=requests(cases,Path(execution['cwd']))
+        require(load(out/'inputs.json')==expected,'actual native import request differs/contains expectations')
+        require(build['resources']==resources,'actual native project config identities differ')
+        expected_owned={r['path']:{k:r[k]for k in ('bytes','sha256')}for r in resources}
+        expected_owned['native-probe']=execution['owned_before']['native-probe']
+        require(execution['owned_before']==expected_owned,'actual project config bytes/inventory differ')
+        errors=compare_import_observations(cases,load(out/'stdout.json'));require(not errors,'; '.join(errors))
+        return []
+    except(OSError,ValueError,KeyError,TypeError,IndexError)as error:return[str(error)]
+
+
+def aggregate_import_matrix(directory:Path,repo:Path,*,snapshot:Path,current:bool=False)->dict:
+    """Accept import resolution only; compressed source snapshots remain replayable."""
+    import json,re,tarfile,tempfile
+    from .integration_validate import _manifest_errors,rust_gate_errors
+    from .import_reference import SCRIPT,validate_import_reference,import_owner_hashes
+    from .import_validate import import_cases,source_identity,FIXTURES
+    from .native_json import identity
+    from .receipts import junit_states
+    from .reference import verify_reference
+    result=dict(passed=False,M3c_accepted=False,M3_accepted=False,migration_complete=False,errors=[])
+    try:
+        def require(value,message):
+            if not value:raise ValueError(message)
+        errors=_manifest_errors(directory);require(not errors,'; '.join(errors))
+        index=load(directory/'INDEX.json')
+        require(index['format']=='ken-import-matrix/1','wrong import matrix protocol')
+        require(index['sources']==source_identity(snapshot/'native-sources'),'native import source snapshot differs')
+        if current:require(index['sources']==source_identity(repo),'current import sources differ')
+        for name,expected in index['tooling'].items():
+            require(not Path(name).is_absolute()and'..'not in Path(name).parts and identity(snapshot/'validation-sources'/name)==expected,'validation source differs')
+        predecessor=dict(path='docs/validation/rust-migration-2026-10-23/m3-parsers-review',sha256='c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8')
+        require(index['predecessor']==predecessor,'closed parser predecessor differs')
+        require(identity(repo/predecessor['path']/'FILES.json')['sha256']==predecessor['sha256']and not _manifest_errors(repo/predecessor['path']),'parser receipt changed')
+        require(not verify_reference(repo,repo/'docs/validation/rust-migration-2026-10-18/baseline.json'),'original1066files changed')
+        require(set(index['platforms'])=={'macos','linux'},'both actual platforms required')
+        cases=import_cases(snapshot/'native-sources');require(len(cases)==91 and len({c['id']for c in cases})==91 and sum(len(c['input']['imports'])for c in cases)==92,'complete import inventory required')
+        fixtures=snapshot/'native-sources/crates/ken-core/tests/fixtures'
+        supplements={name:load(fixtures/(name+'.json'))for name in FIXTURES[1:]}
+        direct_script='\n'.join('exit_code=0'if line.startswith('exit_code=pytest.main(')else line for line in SCRIPT.splitlines())+'\n'
+        for name,value in supplements.items():
+            require(value['format']=='ken-import-supplements/1'and value['script']==direct_script and value['owners']==import_owner_hashes(repo),'supplement script/owners differ')
+            require(value['execution']['exit']==0 and json.loads(value['execution']['observations'])['cases']==value['cases'],'raw supplement original differs')
+        original_cases=None
+        for system,platform in index['platforms'].items():
+            with tempfile.TemporaryDirectory(prefix='ken-import-replay-')as temporary:
+                raw=Path(temporary)
+                with tarfile.open(directory/(system+'-capture.tar.gz'))as archive:archive.extractall(raw,filter='data')
+                original=load(raw/'original/reference.json')
+                require(not validate_import_reference(original)and original['owners']==import_owner_hashes(repo),'invalid original import reference')
+                runtime=original['runtime'];expected=('Darwin','arm64')if system=='macos'else('Linux','aarch64')
+                require((runtime['system'],runtime['machine'],runtime['python'])==(*expected,'3.12.9'),'original platform differs')
+                if original_cases is None:original_cases=original['cases']
+                require(original['cases']==original_cases==load(fixtures/'import-reference.json')['cases'],'original platform cases differ')
+                for file,key in [('stdout.log','stdout_sha256'),('stderr.log','stderr_sha256'),('original-observations.json','observations_sha256')]:require(identity(raw/'original'/file)['sha256']==original['test_execution'][key],'raw original process bytes differ')
+                observed=load(raw/'original/original-observations.json')
+                require(all(original[k]==v for k,v in observed.items()),'raw original observations differ')
+                require(len(junit_states(raw/'original/original-tests.xml'))==33 and set(junit_states(raw/'original/original-tests.xml').values())=={'passed'},'actual original indexer suite differs')
+                for name,value in supplements.items():
+                    extra=load(raw/'supplements'/(name+'.json'))
+                    require(extra['cases']==value['cases']and(extra['runtime']['system'],extra['runtime']['machine'])==expected and extra['runtime']['python']=='3.12.9','independent original supplements differ')
+                errors=verify_import_capture(raw/'native',cases,index['sources'],platform['native_sha256']);require(not errors,'; '.join(errors))
+                execution=load(raw/'native/execution.json')
+                require(execution['system']==system and execution['machine']==expected[1],'native platform differs')
+                gates=raw/'gates'
+                require(not rust_gate_errors((gates/'rust-list.log').read_text(),(gates/'rust-tests.log').read_text()),'complete native tests differ')
+                require(len(re.findall(r'^([^\n]+): test$',(gates/'rust-list.log').read_text(),re.M))==44,'complete44native root cases required')
+                states=junit_states(gates/'python.xml')
+                discovered={path[:-3].replace('/','.')+'::'+name for path,name in re.findall(r'^(tests/rust_migration/test_import_(?:reference|validate|evidence)\.py)::(.+)$',(gates/'python-list.log').read_text(),re.M)}
+                require(len(discovered)==33 and set(states)==discovered and set(states.values())=={'passed'},'complete33affected tooling cases required')
+                clippy=(gates/'clippy.log').read_text();require('Finished `dev` profile'in clippy and'error:'not in clippy and'warning:'not in clippy,'clippy failed/missing')
+                require((gates/'fmt.log').read_bytes()==b'','format failed')
+        result.update(passed=True,M3c_accepted=True,per_platform=dict(Rust=44,Python=33,original_inputs=91,native_cases=182,import_requests=184))
+    except(OSError,ValueError,KeyError,TypeError,IndexError,tarfile.TarError)as error:result['errors'].append(str(error))
+    return result
diff --git a/tools/rust_migration/import_reference.py b/tools/rust_migration/import_reference.py
new file mode 100644
index 00000000..432dbc7a
--- /dev/null
+++ b/tools/rust_migration/import_reference.py
@@ -0,0 +1,194 @@
+"""Observe original import SQL callers and pure structural decisions independently."""
+from __future__ import annotations
+import hashlib, json, os, subprocess
+from pathlib import Path
+from .reference import Reference, reference_env
+
+
+def supplements() -> list[dict]:
+    cases=[]
+    def add(files, module, *, source='src/main.ts', language='typescript', configs=None, root=True):
+        files=[source,*[p for p in files if p!=source]]
+        cases.append(dict(files=files,configs=({k:v.encode().hex() for k,v in (configs or {}).items()} if root else None),
+                          imports=[dict(module=module,source_path=source,language=language)]))
+    add(['pkg/util.py'],'pkg.util',source='main.py',language='python')
+    add(['a/util.py','b/util.py'],'util',source='main.py',language='python')
+    add(['a/caf\u00e9.py'],'\x1ccaf\u00e9\x1f',source='main.py',language='python')
+    add(['src/value.ts'],'./value.js')
+    add(['src/value.ts','src/value.js'],'./value.js')
+    for extension in ('.ts','.tsx','.d.ts','.js','.jsx','.mjs','.cjs'):
+        add(['src/value'+extension],'./value')
+        add(['src/value/index'+extension],'./value')
+    add(['asset.json'],'../../asset.json')
+    add([],'.missing',source='main',language=None,root=False)
+    add(['pkg/value.ts','src/value.ts'],'@app/value',configs={'tsconfig.json':'{"compilerOptions":{"baseUrl":".","paths":{"@app/*":["missing/*","src/*"]}}}'})
+    add(['tsconfig.json','child/tsconfig.json','shared/value.ts'],'@value',source='child/main.ts',configs={
+        'tsconfig.json':'{"compilerOptions":{"paths":{"@value":["shared/value"]}}}',
+        'child/tsconfig.json':'{"compilerOptions":{"paths":{"@value":["missing"]}}}'})
+    add(['tsconfig.json','shared/value.ts'],'@value',configs={
+        'tsconfig.json':'{"extends":"./base"}',
+        'base.json':'// inherited config\n{"compilerOptions":{"baseUrl":".","paths":{"@value":["shared/value",],},},}'})
+    add(['tsconfig.json'],'@missing',configs={'tsconfig.json':'{"extends":"./tsconfig","compilerOptions":{"paths":{"@missing":["none"]}}}'})
+    add(['tsconfig.json','src/value.ts','pkg/value.ts'],'@value',configs={'tsconfig.json':'{"compilerOptions":{"paths":{"@value":["pkg/value"],"@value":["src/value"]}}}'})
+    add(['tsconfig.json','src/value.ts'],'@value',configs={'tsconfig.json':'{"compilerOptions":{"paths":{"@value":["src/value"]}},"unused":1e999}'})
+    add(['tsconfig.json','src/value.ts'],'@value',configs={'tsconfig.json':'{"compilerOptions":{"paths":{"@value":["src/value"]}},"unused":NaN}'})
+    add(['tsconfig.json'],'@value',configs={'tsconfig.json':'{"compilerOptions":[1]}'})
+    add(['tsconfig.json'],'@value',configs={'tsconfig.json':'{"compilerOptions":[]}'})
+    add(['tsconfig.json'],'@value',configs={'tsconfig.json':'{ broken json'})
+    add(['pkg/package.json','pkg/index.ts'],'@scope/pkg',configs={'pkg/package.json':'{"name":"@scope/pkg"}'})
+    add(['pkg/package.json','pkg/index.ts'],'@scope/pkg',configs={'pkg/package.json':'{"name":"@scope/pkg"}'},root=False)
+    add(['crate/Cargo.toml','crate/src/config.rs'],'crate::config::Value',source='crate/src/main.rs',language='rust')
+    add(['Cargo.toml'],'super::*',source='src/main.rs',language='rust')
+    add(['go.mod','internal/a_test.go','internal/z.go','internal/b.go'],'example.test/app/internal',source='main.go',language='go',configs={'go.mod':'module example.test/app\n'})
+    add(['src/util.rb'],'./util',source='src/main.rb',language='ruby')
+    add(['one/pkg/Value.java','two/pkg/Value.java'],'pkg.Value',source='main.java',language='java')
+    add(['src/pkg/Value.java'],'pkg.Value.member',source='main.java',language='java')
+    add(['one/shared.hpp','two/shared.hpp'],'"shared.hpp"',source='one/main.cpp',language='cpp')
+    add(['vector.py'],'vector',source='main.cpp',language='cpp')
+    add(['src/pkg/A.kt','src/pkg/B.kt'],'pkg.Value',source='main.kt',language='kotlin')
+    add(['composer.json','lib/Value.php'],'App\\Value',source='main.php',language='php',configs={'composer.json':'{"autoload":{"psr-4":{"App\\\\":"lib/"}}}'})
+    add(['composer.json'],'App\\Value',source='main.php',language='php',configs={'composer.json':'{"autoload":[1]}'})
+    return cases
+
+
+SCRIPT=r'''
+import functools,hashlib,json,pathlib,platform,sqlite3,sys,tempfile
+import pytest
+request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root']).resolve()
+import tree_sitter_language_pack as pack
+pack.configure({'cache_dir':request['grammar_cache']})
+import ken.indexer as indexer
+import ken.jsresolve as jsresolve
+for module in (indexer,jsresolve):
+ if not pathlib.Path(module.__file__).resolve().is_relative_to(root):raise ValueError('wrong original import module root')
+actual_resolve=indexer._resolve_internal_imports;actual_load=jsresolve._load_jsonc
+observed={};active_test=None;active_configs=None;discovered=[];states=[];calls=0
+
+def load(project,rel):
+ if active_configs is not None:
+  try:active_configs[rel]=(project/rel).read_bytes().hex()
+  except OSError:pass
+ return actual_load(project,rel)
+jsresolve._load_jsonc=load
+
+@functools.wraps(actual_resolve)
+def resolve(conn,project_root=None):
+ global calls,active_configs
+ imports=conn.execute('SELECT i.id,i.to_module,f.path AS src,f.language AS lang FROM ci_imports i JOIN ci_files f ON f.id=i.from_file_id WHERE i.to_file_id IS NULL').fetchall()
+ if not imports:return actual_resolve(conn,project_root)
+ calls+=1
+ files=[r['path']for r in conn.execute('SELECT id,path FROM ci_files')]
+ configs=None if project_root is None else {}
+ if configs is not None:
+  for path in files:
+   if path.endswith(('go.mod','composer.json')):
+    try:configs[path]=(project_root/path).read_bytes().hex()
+    except OSError:pass
+ inputs=[dict(module=r['to_module'],source_path=r['src'],language=r['lang'])for r in imports]
+ structural=[indexer._resolve_import_target(r['module'],files,source_path=r['source_path'])for r in inputs]
+ old=active_configs;active_configs=configs
+ error=None
+ try:actual_resolve(conn,project_root)
+ except Exception as failure:error=dict(type=type(failure).__name__,message=str(failure))
+ finally:active_configs=old
+ definition=dict(files=files,configs=configs,imports=inputs)
+ identity=hashlib.sha256(json.dumps(definition,sort_keys=True,ensure_ascii=True).encode()).hexdigest()
+ result=dict(id=identity,input=definition,structural_targets=structural,tests=[active_test]if active_test else[],calls=1)
+ if error is not None:result['error']=error
+ else:
+  values={r['id']:dict(target=r['target'],resolution=r['resolution'])for r in conn.execute('SELECT i.id,f.path AS target,i.resolution FROM ci_imports i LEFT JOIN ci_files f ON f.id=i.to_file_id')}
+  result['results']=[values[r['id']]for r in imports]
+ if identity in observed:
+  existing=observed[identity]
+  if {k:v for k,v in result.items()if k not in ('tests','calls')}!={k:v for k,v in existing.items()if k not in ('tests','calls')}:raise ValueError('nondeterministic original resolution')
+  existing['calls']+=1
+  if active_test and active_test not in existing['tests']:existing['tests'].append(active_test)
+ else:observed[identity]=result
+ if error is not None:raise RuntimeError('observed original resolution error: '+str(error))
+indexer._resolve_internal_imports=resolve
+
+class Plugin:
+ def pytest_collection_finish(self,session):discovered.extend(item.nodeid for item in session.items)
+ def pytest_runtest_setup(self,item):
+  global active_test
+  active_test=item.nodeid
+ def pytest_runtest_logreport(self,report):
+  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
+exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q','tests/test_indexer.py','--junitxml='+request['junit']],plugins=[Plugin()])
+active_test=None
+for definition in request['supplements']:
+ with tempfile.TemporaryDirectory(prefix='ken-original-import-')as directory:
+  project=pathlib.Path(directory)
+  for path,raw in (definition['configs']or{}).items():
+   target=project/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytes.fromhex(raw))
+  conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row
+  conn.executescript('CREATE TABLE ci_files(id INTEGER PRIMARY KEY,path TEXT,language TEXT); CREATE TABLE ci_imports(id INTEGER PRIMARY KEY,from_file_id INTEGER,to_module TEXT,to_file_id INTEGER,resolution TEXT);')
+  languages={r['source_path']:r['language']for r in definition['imports']}
+  for i,path in enumerate(definition['files'],1):conn.execute('INSERT INTO ci_files VALUES(?,?,?)',(i,path,languages.get(path)))
+  ids={r['path']:r['id']for r in conn.execute('SELECT id,path FROM ci_files')}
+  for i,row in enumerate(definition['imports'],1):conn.execute('INSERT INTO ci_imports(id,from_file_id,to_module)VALUES(?,?,?)',(i,ids[row['source_path']],row['module']))
+  try:resolve(conn,None if definition['configs']is None else project)
+  except RuntimeError:pass
+  conn.close()
+result=dict(format='ken-import-reference/1',cases=list(observed.values()),calls=calls,discovered=discovered,test_states=states,original_test_exit=exit_code,runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version()))
+pathlib.Path(request['result']).write_text(json.dumps(result,ensure_ascii=True)+'\n')
+sys.exit(exit_code)
+'''
+
+
+def import_owner_hashes(repo:Path)->dict[str,str]:
+    baseline=json.loads((repo/'docs/validation/rust-migration-2026-10-18/baseline.json').read_bytes())
+    selected={'src/ken/indexer.py','src/ken/jsresolve.py','tests/test_indexer.py','tests/conftest.py'}
+    return {r['path']:r['sha256']for r in baseline['files']if r['path']in selected}
+
+def cases_digest(cases:list)->str:
+    return hashlib.sha256(json.dumps(cases,sort_keys=True,ensure_ascii=True).encode()).hexdigest()
+
+def validate_import_reference(value:dict)->list[str]:
+    try:
+        def require(condition,message):
+            if not condition:raise ValueError(message)
+        require(value['format']=='ken-import-reference/1','wrong original import protocol')
+        require(value['script_sha256']==hashlib.sha256(SCRIPT.encode()).hexdigest(),'original import script differs')
+        require(value['supplements_sha256']==cases_digest(supplements()),'supplement inputs differ')
+        cases=value['cases'];ids=[]
+        require(bool(cases)and value['cases_sha256']==cases_digest(cases),'original import cases changed/missing')
+        for row in cases:
+            identity=hashlib.sha256(json.dumps(row['input'],sort_keys=True,ensure_ascii=True).encode()).hexdigest()
+            require(row['id']==identity,'original import identity differs');ids.append(identity)
+            count=len(row['input']['imports'])
+            require(count>0 and len(row['structural_targets'])==count,'lost structural inputs')
+            require(('error'in row)!=('results'in row),'result/error boundary differs')
+            if 'results'in row:
+                require(len(row['results'])==count and all(r['resolution']in ('internal','unresolved','external')for r in row['results']),'incomplete import results')
+        require(len(ids)==len(set(ids))and sum(c['calls']for c in cases)==value['calls'],'original inventory differs')
+        require(value['original_test_exit']==0 and value['test_execution']['exit']==0,'actual original indexer tests failed')
+        discovered=value['discovered'];states=value['test_states']
+        require(len(discovered)>=30 and len(set(discovered))==len(discovered),'original indexer discovery differs')
+        require({r['nodeid']for r in states}==set(discovered)and all(r['when']=='call'and r['outcome']=='passed'for r in states),'original indexer test states differ')
+        return []
+    except (ValueError,KeyError,TypeError)as error:return[str(error)]
+
+def capture_import_reference(reference:Reference,out:Path,*,repo:Path)->dict:
+    owners=import_owner_hashes(repo)
+    for name,expected in owners.items():
+        if not(reference.root/name).is_file()or hashlib.sha256((reference.root/name).read_bytes()).hexdigest()!=expected:raise ValueError('original import owner changed: '+name)
+    if(out/'reference.json').exists():
+        value=json.loads((out/'reference.json').read_bytes())
+        if value['owners']!=owners or validate_import_reference(value):raise ValueError('stale original import reference')
+        return value
+    import tree_sitter_language_pack as pack
+    cache=Path(os.environ.get('KEN_IMPORT_ORIGINAL_GRAMMARS',pack.cache_dir())).resolve()
+    out.mkdir(parents=True,exist_ok=True);out=out.resolve()
+    request=dict(root=str(reference.root),grammar_cache=str(cache),junit=str(out/'original-tests.xml'),result=str(out/'original-observations.json'),supplements=supplements())
+    (out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
+    execution=subprocess.run([str(reference.python),'-c',SCRIPT,str(out/'request.json')],cwd=reference.root,env=reference_env(reference,out/'environment'),capture_output=True,timeout=120,check=False)
+    (out/'stdout.log').write_bytes(execution.stdout);(out/'stderr.log').write_bytes(execution.stderr)
+    if execution.returncode:raise ValueError('original indexer resolution capture failed: '+execution.stdout[-3000:].decode(errors='replace')+'\n'+execution.stderr[-1500:].decode(errors='replace'))
+    raw=(out/'original-observations.json').read_bytes()
+    value=json.loads(raw)
+    value.update(owners=owners,script_sha256=hashlib.sha256(SCRIPT.encode()).hexdigest(),supplements_sha256=cases_digest(supplements()),cases_sha256=cases_digest(value['cases']),test_execution=dict(exit=execution.returncode,python=str(reference.python),cwd=str(reference.root),stdout_sha256=hashlib.sha256(execution.stdout).hexdigest(),stderr_sha256=hashlib.sha256(execution.stderr).hexdigest(),observations_sha256=hashlib.sha256(raw).hexdigest(),timeout_s=120))
+    errors=validate_import_reference(value)
+    if errors:raise ValueError(errors)
+    (out/'reference.json').write_text(json.dumps(value,indent=2)+'\n')
+    return value
diff --git a/tools/rust_migration/import_validate.py b/tools/rust_migration/import_validate.py
new file mode 100644
index 00000000..c971f717
--- /dev/null
+++ b/tools/rust_migration/import_validate.py
@@ -0,0 +1,68 @@
+"""Complete original import comparison and actual two-mode native acquisition."""
+from __future__ import annotations
+import hashlib,json
+from pathlib import Path
+from .native_json import NativeJsonCapture,identity,load
+FIXTURES=('import-reference','import-alias-edges','import-alias-surrogates','import-language-edges')
+
+def source_identity(repo:Path)->dict:
+    files=[repo/p for p in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')]
+    files+=sorted(p for p in(repo/'crates/ken-core').rglob('*')if p.is_file())
+    return {str(p.relative_to(repo)):identity(p)for p in files}
+
+def import_cases(repo:Path)->list[dict]:
+    cases=[]
+    for name in FIXTURES:
+        for row in load(repo/'crates/ken-core/tests/fixtures'/(name+'.json'))['cases']:
+            cases.append(dict(id=name+':'+row['id'],input=row['input'],**{k:row[k]for k in ('error','results')if k in row}))
+    return cases
+
+def compare_import_observations(cases:list[dict],actual:dict)->list[str]:
+    try:
+        def require(value,message):
+            if not value:raise ValueError(message)
+        require(set(actual)=={'format','cases'}and actual['format']=='ken-import-observation/1','wrong import observation protocol')
+        expected=[(mode+':'+case['id'],case)for case in cases for mode in ('inputs','project')]
+        require(len(actual['cases'])==len(expected),'missing/duplicate native import cases')
+        for row,(name,case)in zip(actual['cases'],expected,strict=True):
+            require(row['id']==name,'native import identity/order differs')
+            if'error'in case:
+                error=row.get('error',{})
+                require(set(row)=={'id','error'}and case['error']['type']=='AttributeError'and set(error)=={'kind','path','reason'}and error['kind']=='invalid_config'and error['path']in case['input']['configs']and type(error['reason'])is str and bool(error['reason']),'original config failure differs/swallowed')
+            else:require(set(row)=={'id','results'}and row['results']==case['results'],'complete ordered import targets/classifications differ: '+name)
+        return []
+    except(ValueError,KeyError,TypeError)as error:return[str(error)]
+
+def requests(cases:list[dict],root:Path)->tuple[dict,list[dict]]:
+    rows=[];resources=[]
+    for index,case in enumerate(cases):
+        data=case['input'];rows.append(dict(id='inputs:'+case['id'],files=data['files'],imports=data['imports'],source=dict(kind='inputs',configs=data['configs'])))
+        project=None
+        if data['configs']is not None:
+            project=root/'projects'/f'{index:04d}'
+            for name,hex in data['configs'].items():
+                path=Path(name)
+                if path.is_absolute()or'..'in path.parts:raise ValueError('safe relative original config identity required')
+                raw=bytes.fromhex(hex)
+                resources.append(dict(path=str((project/path).relative_to(root)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
+        rows.append(dict(id='project:'+case['id'],files=data['files'],imports=data['imports'],source=dict(kind='project',root=str(project)if project is not None else None)))
+    return dict(cases=rows),sorted(resources,key=lambda r:r['path'])
+
+def run_import_capture(repo:Path,probe:Path,cases:list[dict],out:Path)->dict:
+    before=source_identity(repo)
+    with NativeJsonCapture(probe,out,repo=repo,prefix='ken-import-process-')as process:
+        request,resources=requests(cases,process.root)
+        for index,case in enumerate(cases):
+            if case['input']['configs']is None:continue
+            project=process.root/'projects'/f'{index:04d}';project.mkdir(parents=True)
+            for name,hex in case['input']['configs'].items():
+                path=project/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(bytes.fromhex(hex))
+        (out/'SOURCES.json').write_text(json.dumps(before,indent=2)+'\n')
+        actual=process.run(request)
+        build=dict(format='ken-import-build/1',sources=before,native_sha256=process.binary['sha256'],resources=resources)
+        (out/'BUILD.json').write_text(json.dumps(build,indent=2)+'\n')
+        if source_identity(repo)!=before:raise ValueError('native import sources changed during execution')
+    from .import_evidence import verify_import_capture
+    errors=verify_import_capture(out,cases)
+    if errors:raise ValueError(errors)
+    return build
diff --git a/tools/rust_migration/native_json.py b/tools/rust_migration/native_json.py
new file mode 100644
index 00000000..a858b1a4
--- /dev/null
+++ b/tools/rust_migration/native_json.py
@@ -0,0 +1,80 @@
+"""One bounded native JSON process with reusable outside-checkout execution audit."""
+from __future__ import annotations
+import hashlib,json,os,platform,re,shutil,signal,subprocess,tempfile
+from pathlib import Path
+from .fastembed_process import _distinct,_nonfinite
+
+LIMIT=16*1024*1024
+def identity(path:Path)->dict:
+    with path.open('rb')as stream:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
+def load(path:Path):
+    with path.open('rb')as stream:raw=stream.read(LIMIT+1)
+    if len(raw)>LIMIT:raise ValueError('native JSON exceeds16MiB')
+    return json.loads(raw,object_pairs_hook=_distinct,parse_constant=_nonfinite)
+def tree(root:Path)->dict:
+    return {str(p.relative_to(root)):identity(p)for p in sorted(root.rglob('*'))if p.is_file()}
+
+class NativeJsonCapture:
+    def __init__(self,probe:Path,out:Path,*,repo:Path,prefix:str):
+        self.probe,self.out,self.repo,self.prefix=probe.resolve(),out.resolve(),repo.resolve(),prefix
+    def __enter__(self):
+        with self.probe.open('rb')as stream:magic=stream.read(4)
+        if magic not in (b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe')or not os.access(self.probe,os.X_OK):raise ValueError('native executable required; interpreter scripts rejected')
+        self.out.mkdir(parents=True,exist_ok=False)
+        self.temporary=tempfile.TemporaryDirectory(prefix=self.prefix);self.root=Path(self.temporary.name).resolve()
+        try:
+            if self.root.is_relative_to(self.repo):raise ValueError('native process must run outside checkout')
+            self.native=self.root/'native-probe';shutil.copy2(self.probe,self.native)
+            self.binary=identity(self.probe)
+            (self.root/'empty-path').mkdir();(self.root/'home').mkdir()
+            return self
+        except BaseException:self.temporary.cleanup();raise
+    def run(self,request:dict)->dict:
+        raw=(json.dumps(request,ensure_ascii=True,allow_nan=False)+'\n').encode()
+        if len(raw)>8*1024*1024:raise ValueError('native request exceeds8MiB')
+        (self.out/'inputs.json').write_bytes(raw);before=tree(self.root)
+        env=dict(PATH=str(self.root/'empty-path'),HOME=str(self.root/'home'),LANG='C.UTF-8',LC_ALL='C.UTF-8')
+        system='macos'if platform.system()=='Darwin'else'linux'
+        command=[str(self.native)]
+        if system=='linux':
+            tracer=shutil.which('strace')
+            if not tracer:raise ValueError('actual Linux exec/connect audit required')
+            command=[tracer,'--seccomp-bpf','-f','-e','trace=execve,execveat,connect','-o',str(self.out/'exec.trace'),*command];env['LD_DEBUG']='libs'
+        else:env['DYLD_PRINT_LIBRARIES']='1'
+        with(self.out/'stdout.json').open('wb')as stdout,(self.out/'stderr.log').open('wb')as stderr:
+            process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,cwd=self.root,env=env,start_new_session=True)
+            try:process.communicate(raw,timeout=60)
+            except BaseException:
+                try:os.killpg(process.pid,signal.SIGKILL)
+                except ProcessLookupError:pass
+                process.wait();raise
+        receipt=dict(format='ken-native-json-execution/1',command=command,cwd=str(self.root),env=env,system=system,machine=platform.machine(),exit=process.returncode,timeout_s=60,native_sha256=self.binary['sha256'],request_sha256=identity(self.out/'inputs.json')['sha256'],stdout_sha256=identity(self.out/'stdout.json')['sha256'],stderr_sha256=identity(self.out/'stderr.log')['sha256'],owned_before=before,owned_after=tree(self.root))
+        (self.out/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
+        if identity(self.probe)!=self.binary or identity(self.native)!=self.binary:raise ValueError('native executable changed during execution')
+        errors=verify_native_json(self.out,self.prefix)
+        if errors:raise ValueError(errors)
+        return load(self.out/'stdout.json')
+    def __exit__(self,*args):self.temporary.cleanup()
+
+def verify_native_json(out:Path,prefix:str)->list[str]:
+    try:
+        def require(value,message):
+            if not value:raise ValueError(message)
+        receipt=load(out/'execution.json');root=Path(receipt['cwd']);command=receipt['command'];env=receipt['env']
+        require(set(receipt)=={'format','command','cwd','env','system','machine','exit','timeout_s','native_sha256','request_sha256','stdout_sha256','stderr_sha256','owned_before','owned_after'},'unexpected execution fields/fabricated passing summary')
+        require(receipt['format']=='ken-native-json-execution/1'and receipt['exit']==0 and receipt['timeout_s']==60,'native exit/timeout/protocol differs')
+        require(root.is_absolute()and root.name.startswith(prefix)and command[-1]==str(root/'native-probe'),'native executable not copied outside checkout')
+        require(env['PATH']==str(root/'empty-path')and env['HOME']==str(root/'home'),'native isolated environment differs')
+        require(receipt['owned_before']==receipt['owned_after']and receipt['owned_before']['native-probe']['sha256']==receipt['native_sha256'],'native wrote/changed owned files')
+        for name,key in [('inputs.json','request_sha256'),('stdout.json','stdout_sha256'),('stderr.log','stderr_sha256')]:require(identity(out/name)['sha256']==receipt[key],'raw native execution bytes differ')
+        loader=(out/'stderr.log').read_bytes()
+        require(len(loader)<=LIMIT and b'libpython'not in loader and b'libtorch_python'not in loader,'forbidden native linkage/oversized loader log')
+        if receipt['system']=='linux':
+            require(len(command)==8 and Path(command[0]).name=='strace'and command[1:5]==['--seccomp-bpf','-f','-e','trace=execve,execveat,connect'],'actual exec/connect audit command differs')
+            trace=(out/'exec.trace').read_text()
+            require(len(re.findall(r'\bexecve(?:at)?\(',trace))==1 and command[-1]in trace and not re.search(r'\bconnect\(',trace),'unexpected native subprocess/network')
+            require(env['LD_DEBUG']=='libs'and b'calling init:'in loader,'actual Linux loader audit missing')
+        else:require(receipt['system']=='macos'and command==[str(root/'native-probe')]and env['DYLD_PRINT_LIBRARIES']=='1'and b'dyld['in loader,'actual macOS loader audit missing')
+        load(out/'inputs.json');load(out/'stdout.json')
+        return []
+    except(OSError,ValueError,KeyError,TypeError,IndexError)as error:return[str(error)]
