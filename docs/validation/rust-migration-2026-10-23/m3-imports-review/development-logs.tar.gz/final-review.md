# Fresh whole-plan review — imports
Reviewer: /root/m3_imports_final_review; gpt-6-astra high; final package fromee32d6b.
Strengths: separated acquisition/alias/language/classification ownership; ordered config and generic-first parity; full public-caller/error/filesystem comparisons. Fresh VERIFY --current and8matrix mutations passed. Acceptance limited toM3c.
Critical: none.
Important1: config.rs108/135, originalPath.read_text universal newline translation occurs beforeJSONCstrip. `// header\r{"compilerOptions":{"paths":{"@value":["src/value"]}}}` originally resolves src/value.ts; native external inbothmodes.
Important2: config.rs198/aliases.rs150/167, dropping non-scalar strings before path normalization loses valid paths. `baseUrl:"\ud800/.."` or target`"\ud800/../src/value"` originally resolvesinternal; native unresolved. Inherited bases must retain points too.
Minor: JSON parser native1000depthcap rejects an original1100nested unused array; native accepts5000digit unusedinteger where original4300digitlimit ignoresconfig. Explicit limitation recorded.
Declined: production writer/CLI/empty-pending orchestration; commonAST/M3–M8; prior model/parser internals beyond predecessor; exhaustive permission/symlinkmatrix. Executor rulings covereach.
Evidence: /private/tmp/ken-m3-review-experiment.py, original SQLite caller andexistingcopied nativeprobe bothmodes; no original suite ormodel rerun. No source/index/HEAD writes.
Verdict: ready withtwoImportantfixes. OneTDDrepairpass, no rereview.
