from pathlib import Path
import os
namespace={}
source=Path('.superpowers/sdd/2026-10-23-rust-import-resolution/task-2-original-surrogates.py').read_text()
start=source.index('rows=[]\nadd(')
end=source.index("script='\\n'.join", start)
replacement=r'''rows=[]
def add_review(config,extra=None,files=None):
 configs={'tsconfig.json':config};configs.update(extra or {})
 add(files or ['tsconfig.json','src/value.ts'],'@value',configs,source='main.ts')
for newline in ('\r','\r\n','\n'):
 add_review('// header'+newline+'{"compilerOptions":{"paths":{"@value":["src/value"]}}}')
for point in ('\\ud800','\\udfff','\\ud800\\udfff'):
 add_review('{"compilerOptions":{"baseUrl":"'+point+'/..","paths":{"@value":["src/value"]}}}')
 add_review('{"compilerOptions":{"paths":{"@value":["'+point+'/../src/value"]}}}')
 add_review('{"compilerOptions":{"baseUrl":"'+point+'","paths":{"@value":["../src/value"]}}}')
add_review('{"extends":"\\ud800/../base"}',{'base.json':'{"compilerOptions":{"paths":{"@value":["src/value"]}}}'})
add_review('{"extends":"config/base"}',{'config/base.json':'{"compilerOptions":{"baseUrl":"\\ud800","paths":{"@value":["../../src/value"]}}}'})
add_review('{"extends":"config/base","compilerOptions":{"baseUrl":"\\ud800"}}',{'config/base.json':'{"compilerOptions":{"paths":{"@value":["../src/value"]}}}'})
add_review('{"compilerOptions":{"paths":{"@value":["\\ud83d\\ude00/value"]}}}',files=['tsconfig.json','😀/value.ts'])
'''
source=source[:start]+replacement+source[end:]
source=source.replace("out=ws/'task-2-original-surrogate'", "out=ws/('review-original-'+('macos' if sys.platform=='darwin' else 'linux'))")
os.environ.setdefault('KEN_IMPORT_EXTRA_DEST','crates/ken-core/tests/fixtures/import-review-regressions.json')
exec(compile(source,__file__,'exec'),namespace)
