
import dataclasses,hashlib,json,os,pathlib,platform,shutil,sys,tempfile
import numpy as np
import pytest
import tree_sitter_language_pack as pack
request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(request['root']);pack.configure({'cache_dir':request['grammar_cache']})
import ken.indexer as ix
import ken.embedder as embedder
from ken.db import connect,init_schema
from ken.retrieval import indexing,representations
from ken.retrieval.profile import RetrievalProfile
from ken.retrieval.passages import PassagePolicy,lexical_token_count
from ken.retrieval.storage import load_passage_map
from ken.vectors import VectorStore
for m in (ix,embedder,indexing,representations):
 if not pathlib.Path(m.__file__).resolve().is_relative_to(root.resolve()):raise ValueError('wrong original module')
discovered=[];states=[]
class Plugin:
 def pytest_collection_finish(self,session):discovered.extend(i.nodeid for i in session.items)
 def pytest_runtest_logreport(self,report):
  if report.when=='call'or report.failed or report.skipped:states.append(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome))
exit_code=pytest.main(['-o','addopts=','--rootdir='+str(root),'-q',*request['suite'],'--junitxml='+request['junit']],plugins=[Plugin()])
ix.time.time=lambda:1700000000.0
embedder.active_model=lambda:'provided-deterministic'
original_open=ix._open_stores
class Encoder:
 dim=3
 def __init__(self,root,conn):self.root=root;self.conn=conn;self.calls=[];self.loads=0;self.characters=False;self.fail_encode=False;self.fail_load=False;self.nan_behavior=False;self.race=None;self.mapped=False;self.fallback=False
 def load(self,spec):
  self.loads+=1
  if self.fail_load:raise RuntimeError('encoder load unavailable')
  return self
 def token_count(self,text):return len(text)if self.characters else lexical_token_count(text)
 def embed_passages(self,texts):
  self.calls.append(list(texts))
  if self.fail_encode:raise RuntimeError('encoding unavailable')
  out=[]
  for text in texts:
   if self.nan_behavior and'\nSource:\n'in text:out.append(np.array([np.nan,1.,0.],dtype=np.float32));continue
   b=text.encode();v=np.array([sum(b)%31+1,len(b)%23+1,sum((i+1)*n for i,n in enumerate(b))%19+1],dtype=np.float32);out.append(v/np.linalg.norm(v))
  race=self.race;self.race=None
  if race:
   if race['kind']=='source':write(self.root,race['path'],race['source_hex'])
   else:self.conn.execute("UPDATE meta SET value=? WHERE key='retrieval_profile_fingerprint'",(race['fingerprint'],))
  return out
 def open(self,conn,root,encoder):
  if not self.mapped:return None
  stores=original_open(conn,root,encoder)
  if encoder is not None and stores is None:self.fallback=True
  return stores
def write(root,path,source):
 target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bytes.fromhex(source));os.utime(target,ns=(1234567890000000000,1234567890000000000))
def failure(error):return dict(type=type(error).__name__,message=str(error))
def snapshot(conn,project):
 tables={}
 for table,order in [('ci_files','id'),('ci_symbols','id'),('ci_imports','id'),('ci_intent_sources','id'),('ci_name_tokens','kind,token,row_id'),('ci_passages','id'),('ci_passage_terms','passage_id,field,term'),('ci_passage_lengths','passage_id,field'),('ci_retrieval_files','file_id'),('ci_retrieval_embeddings','id'),('ci_passage_vectors','passage_id,view'),('ci_vec_alloc','space'),('ci_vec_free','space,slot'),('meta','key')]:tables[table]=[[{'blob_hex':v.hex()}if isinstance(v,bytes)else v for v in r]for r in conn.execute('SELECT * FROM '+table+' ORDER BY '+order)]
 legacy={}
 for space in ('ci_files','ci_symbols','ci_intent_sources'):
  out=[]
  for row in conn.execute('SELECT id,vec_slot,embedding FROM '+space+' ORDER BY id'):
   if row[1]is not None:
    try:
     store=VectorStore(project,space,dim=3,model='provided-deterministic')
     try:value=dict(vector=store.read([int(row[1])])[0].tolist())
     finally:store.close()
    except Exception as error:value=dict(error=str(error))
   elif row[2]is not None:value=dict(vector=np.frombuffer(row[2],dtype=np.float32).tolist())
   else:value=dict(vector=None)
   out.append(dict(id=row[0],slot=row[1],value=value))
  legacy[space]=out
 try:loaded=dict(passages=[[pid,dataclasses.asdict(p)]for pid,p in load_passage_map(conn).items()])
 except Exception as error:loaded=dict(error=failure(error))
 return dict(tables=tables,legacy_vectors=legacy,loaded=loaded)
cases=[]
for definition in request['definitions']:
 private=pathlib.Path(tempfile.mkdtemp(dir=request['scratch']));project=private/'IndexProject';project.mkdir();(project/'.ken').mkdir();conn=connect(project/'.ken/ken.db');init_schema(conn);encoder=Encoder(project,conn);ix._open_stores=encoder.open;indexing.load_encoder=representations.load_encoder=encoder.load;steps=[]
 for op in definition['operations']:
  events=[]
  try:
   kind=op['op']
   if kind=='write':write(project,op['path'],op['source_hex']);result=dict(written=True)
   elif kind=='remove':
    target=project/op['path'];shutil.rmtree(target)if target.is_dir()else target.unlink();result=dict(removed=True)
   elif kind=='delete':result=dict(deleted=ix.delete_path(conn,op['path'])if op.get('subtree')else ix.delete_file(conn,op['path']))
   elif kind=='invalidate':
    if op.get('parser_version')is not None:conn.execute('UPDATE ci_files SET parser_version=?',(op['parser_version'],))
    if op.get('name_token_version')is not None:conn.execute("INSERT INTO meta(key,value)VALUES('name_token_version',?)ON CONFLICT(key)DO UPDATE SET value=excluded.value",(op['name_token_version'],))
    if op.get('extractor_version')is not None:conn.execute('UPDATE ci_retrieval_files SET extractor_version=?',(op['extractor_version'],))
    if op.get('clear_tokens'):conn.execute('DELETE FROM ci_name_tokens')
    result=dict(invalidated=True)
   elif kind=='block_vectors':
    target=project/'.ken/vectors';saved=project/'.ken/vectors.saved'
    if op['blocked']:
     if target.exists():target.rename(saved)
     target.write_bytes(b'not a directory')
    else:
     target.unlink()
     if saved.exists():saved.rename(target)
    result=dict(blocked=op['blocked'])
   elif kind=='index':
    encoder.calls=[];encoder.loads=0;encoder.characters=op.get('characters',False);encoder.fail_encode=op.get('fail_encode',False);encoder.fail_load=op.get('fail_load',False);encoder.nan_behavior=op.get('nan_behavior',False);encoder.race=op.get('race');encoder.mapped=op.get('mapped',False);encoder.fallback=False;os.environ['KEN_INDEX_WORKERS']=str(op.get('workers',0))
    profile=RetrievalProfile.from_dict(op['profile'])if op.get('profile')is not None else None;policy=PassagePolicy(**op['policy'])if op.get('policy')is not None else None
    stats=ix.index_files(conn,project,[pathlib.Path(p)for p in op['paths']],max_file_bytes=op.get('max_file_bytes',1024*1024),on_progress=lambda p,s:events.append([p,s]),embedder=encoder if op.get('embed')else None,retrieval_profile=profile,retrieval_policy=policy)
    if op.get('prepare'):representations.index_embeddings(conn,profile)
    result=dict(stats=dataclasses.asdict(stats),events=events,encoder_calls=encoder.calls,encoder_loads=encoder.loads,storage_fallback=encoder.fallback)
   else:raise ValueError('unknown operation')
   step=dict(result=result)
  except Exception as error:step=dict(error=failure(error),events=events,encoder_calls=encoder.calls,encoder_loads=encoder.loads)
  step['snapshot']=snapshot(conn,project);steps.append(step)
 cases.append(dict(id=definition['id'],steps=steps));conn.close();shutil.rmtree(private)
value=dict(format='ken-index-scenario-reference/1',cases=cases,definitions=request['definitions'],runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version(),numpy=np.__version__),discovered=discovered,test_states=states,original_test_exit=exit_code,normalizations=['result.stats.elapsed_s','warnings diagnostic text'],physical_slot_contract='M2 rollback-safe allocator; audit ownership and bounded high-water separately')
pathlib.Path(request['result']).write_text(json.dumps(value,ensure_ascii=True)+'\n');sys.exit(exit_code)
