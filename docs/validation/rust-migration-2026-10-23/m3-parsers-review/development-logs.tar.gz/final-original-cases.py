import dataclasses,hashlib,json
from pathlib import Path
import tree_sitter_language_pack as pack
pack.configure({'cache_dir':'/Users/andres/Library/Caches/tree-sitter-language-pack/v1.8.1/libs'})
from ken.parsers.rust import parse_rust_file
from ken.parsers.python import parse_python_file
rows=[]
inputs=[('rust',b'#[doc = "\xff"]\nfn f() {}\n'),('rust',b'#[doc = "\xff"]\nmod m { fn f() {} }\n')]
for literal in [r'"Useful documentation \ud800 end"',r'"Useful documentation \udfff end"',r'"Useful documentation \U0000D800 end"',r'"\ud800\udc00"',r'"\udc00\ud800"',r'"a\n\ud800\ttext"',r'r"\ud800"',r'"\U0001f980"']:
 inputs.append(('python',('def f():\n    '+literal+'\n    pass\n').encode()))
for language,source in inputs:
 request=dict(language=language,hint='review.'+('rs'if language=='rust'else'py'),source_hex=source.hex())
 row=dict(input=request)
 try:
  parsed=dataclasses.asdict((parse_rust_file if language=='rust'else parse_python_file)(source,request['hint']))
  row['parsed_json']=json.dumps(parsed,ensure_ascii=True)
  row['documentation_codepoints']=[ord(c)for c in parsed['scopes'][0]['documentation']]if parsed['scopes'][0]['documentation']is not None else None
 except Exception as error:row['error']=dict(type=type(error).__name__,message=str(error))
 rows.append(row)
print(json.dumps(dict(cases=rows)))
