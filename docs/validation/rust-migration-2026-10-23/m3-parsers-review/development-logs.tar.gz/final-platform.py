from pathlib import Path
import os,sys,json,shutil,subprocess
from tools.rust_migration.parser_validate import parser_cases,run_parser_capture
repo=Path.cwd(); system=sys.argv[1]; ws=repo/'.superpowers/sdd/2026-10-23-rust-parsers'; out=ws/('final-'+system); out.mkdir(exist_ok=True)
wrapper=repo/'.ken/rust-migration/m2-optional/review-repair'/('prepared-macos-env' if system=='macos' else 'prepared-linux-env')
if system=='linux': wrapper=Path('/app/.ken/rust-migration/m2-optional/review-repair/prepared-linux-env')
probe=Path(os.environ['KEN_PARSER_PROBE']); manifest=Path(os.environ['KEN_GRAMMAR_MANIFEST']); gates=out/'gates';gates.mkdir(exist_ok=True)
targets=['tests/rust_migration/test_parser_reference.py','tests/rust_migration/test_grammar_prepare.py','tests/rust_migration/test_parser_validate.py','tests/rust_migration/test_parser_evidence.py']
commands=[('rust-list.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-syntax','--','--list']),('rust-tests.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-syntax']),('python-list.log',[sys.executable,'-m','pytest','-o','addopts=','--collect-only','-q',*targets]),('python.log',[sys.executable,'-m','pytest','-o','addopts=','-q',*targets,'--junitxml='+str(gates/'python.xml')]),('clippy.log',[str(wrapper),'cargo','clippy','--locked','--offline','-p','ken-syntax','--all-targets','--','-D','warnings']),('fmt.log',[str(wrapper),'cargo','fmt','--all','--','--check'])]
for name,command in commands:
 with (gates/name).open('wb') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
 if result.returncode: raise SystemExit(name+' failed: '+(gates/name).read_text()[-3000:])
run_parser_capture(repo,probe,manifest,parser_cases(repo),out/'native')
original=ws/('task-1-reference-'+system); dest=out/'original';dest.mkdir(exist_ok=True)
for name in ('reference.json','original-observations.json','original-tests.xml','request.json','stdout.log','stderr.log'): shutil.copy2(original/name,dest/name)
print(system, '33 Rust +38 tooling cases and249 native inputs passed')
