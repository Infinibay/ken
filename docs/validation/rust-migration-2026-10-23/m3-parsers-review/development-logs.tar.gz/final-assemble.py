from pathlib import Path
import json,shutil,tarfile
from tools.rust_migration.parser_validate import source_identity,identity
repo=Path.cwd(); ws=repo/'.superpowers/sdd/2026-10-23-rust-parsers'; proof=repo/'docs/validation/rust-migration-2026-10-23/m3-parsers-review';proof.mkdir(parents=True,exist_ok=True)
sources=source_identity(repo)
for name in sources:
 target=proof/'native-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
tooling={}
for pattern in ('tools/**/*.py','tests/rust_migration/test_parser_*.py','tests/rust_migration/test_grammar_prepare.py'):
 for p in repo.glob(pattern):
  name=str(p.relative_to(repo));tooling[name]=identity(p);target=proof/'validation-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
platforms={}
for system in ('macos','linux'):
 root=ws/('final-'+system)
 shutil.copytree(root/'gates',proof/'gates'/system,dirs_exist_ok=True)
 with tarfile.open(proof/f'{system}-capture.tar.gz','w:gz') as archive:
  for name in ('native','original'):archive.add(root/name,arcname=name)
 receipt=json.loads((root/'native/execution.json').read_bytes())
 platforms[system]={'native_sha256':receipt['native_sha256']}
for p in [ws/'task-2-unicode-delta.py',repo/'.ken/rust-migration/m3-parsers/research/runtime-core-exact.json']:
 target=proof/'research'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
index=dict(format='ken-parser-review-repair/1',sources=sources,tooling=tooling,platforms=platforms,predecessor=dict(path='docs/validation/rust-migration-2026-10-23/m3-parsers',sha256='263308848530d463d8c807d15d79dbedd586b25eb10fb6968ae3fa24aa7d4edd'))
(proof/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
(proof/'LEDGER.md').write_bytes((ws/'progress.md').read_bytes())
with tarfile.open(proof/'development-logs.tar.gz','w:gz') as archive:
 for p in sorted(ws.iterdir()):
  if p.is_file() and (p.suffix in ('.log','.py','.md') or p.name=='plan-path'):archive.add(p,arcname=p.name)
for filename,token in [('RULINGS.md','Ruling:'),('MINORS.md','minor (deferred)')]:
 lines=[s for s in (ws/'progress.md').read_text().splitlines() if token in s]
 (proof/filename).write_text('\n\n'.join(lines) + '\n' if lines else 'None recorded.\n')
rows=[dict(path=str(p.relative_to(proof)),**identity(p))for p in sorted(proof.rglob('*'))if p.is_file() and p.name!='FILES.json']
(proof/'FILES.json').write_text(json.dumps(dict(files=rows),indent=2)+'\n')
print('Assembled',len(rows),'artifacts')
