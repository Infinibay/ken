from pathlib import Path
import json,subprocess
ws=Path('.superpowers/sdd/2026-10-23-rust-parsers')
script=(ws/'final-original-cases.py').read_text().replace('/Users/andres/Library/Caches/tree-sitter-language-pack/v1.8.1/libs',str(Path('.ken/rust-migration/m3-parsers/sdk-linux').resolve()))
checks='''
import sys,platform
owners={}
for name,module in list(sys.modules.items()):
 if name=='ken.parsers' or name.startswith('ken.parsers.'):
  path=Path(module.__file__)
  owners['src/ken/parsers/'+path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
expected={r['path']:r['sha256']for r in json.loads(Path('docs/validation/rust-migration-2026-10-18/baseline.json').read_bytes())['files']if r['path'].startswith('src/ken/parsers/')}
assert owners==expected,(owners.keys(),expected.keys())
print(json.dumps(dict(cases=rows,owners=owners,runtime=dict(system=platform.system(),machine=platform.machine()))))
'''
script=script.replace('print(json.dumps(dict(cases=rows)))',checks)
execution=subprocess.run(['/app/.venv/bin/python','-c',script],capture_output=True,text=True,check=False)
if execution.returncode:raise SystemExit(execution.stderr)
observed=json.loads(execution.stdout)
assert observed['cases']==json.loads(Path('crates/ken-syntax/tests/fixtures/review-cases.json').read_bytes())['cases']
(ws/'final-original-linux.json').write_text(json.dumps(dict(script=script,execution=dict(exit=execution.returncode,stdout=execution.stdout,stderr=execution.stderr)),indent=2)+'\n')
print('Linux original module origins/hash identities verified')
