"""Extend the complete native-model gates with the independent NPZ profile."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform

from .model_validate import FINGERPRINT_KEYS, REQUIRED_GATES, _model_fingerprints, validate_models
from .reference import Reference
from .table_compare import GOLDEN, compare
from .table_reference import table_cases
from .validate import _sha, _write,bind_native_release
from .preparation import PreparedNativeFastEmbed,fastembed_environment,PreparedNativeStorage,storage_environment
from .preparation import PreparedNativeContext,PreparedNativeEttin,PreparedNativeTranslation

TABLE_KEYS = FINGERPRINT_KEYS | {'table_artifact', 'table_oracle'}
TABLE_GATES = (*REQUIRED_GATES, 'table_release', 'table_parity')


def bind_table_probe(repo: Path, native: Path) -> dict:
    """Bind an explicitly selected executable to the just-built release bytes."""
    return bind_native_release(repo,native,'table_probe')


def _binding_matches(binding: dict, parity: dict) -> bool:
    digest = binding.get('built_sha256')
    return (binding.get('ran') is True and binding.get('passed') is True
        and isinstance(digest, str) and len(digest) == 64
        and all(c in '0123456789abcdef' for c in digest)
        and digest == binding.get('supplied_sha256') == parity.get('native_sha256'))


def table_fingerprints(repo:Path,reference:Reference|None,artifact:Path)->dict:
    cases=repo/'docs/validation/rust-migration-2026-10-18/m2-static/cases.json'
    return _model_fingerprints(repo,reference,cases)|{'table_artifact':_sha(artifact),'table_oracle':_sha(GOLDEN)}


def table_receipt_errors(row:dict,expected_ids:list[str])->list[str]:
    errors=[];name=row.get('platform');gates=row.get('gates',{})
    if row.get('scope')!='table-local' or row.get('passed') is not True or row.get('execution_error') or row.get('M2_accepted') is not False:
        errors.append(f'failed table receipt: {name}')
    if any(not isinstance(gates.get(g),dict) or gates[g].get('ran') is not True
           or gates[g].get('passed') is not True for g in TABLE_GATES):errors.append(f'incomplete full gates: {name}')
    identities=row.get('fingerprints',{})
    if set(identities)!=TABLE_KEYS or any(not isinstance(v,str) or len(v)!=64
            or any(c not in '0123456789abcdef' for c in v) for v in identities.values()):errors.append(f'incomplete identities: {name}')
    if not str(row.get('rustc','')).startswith('rustc 1.95.0 '):errors.append(f'wrong toolchain: {name}')
    if row.get('case_ids')!=expected_ids:errors.append(f'wrong cases: {name}')
    parity=row.get('table_parity',{})
    if not _binding_matches(row.get('table_release',{}),parity):errors.append(f'table executable is not bound to fresh release: {name}')
    if (parity.get('passed') is not True or parity.get('outside_checkout') is not True
            or parity.get('native_children')!=[] or parity.get('dependency_audit',{}).get('passed') is not True):
        errors.append(f'missing native table proof: {name}')
    if name=='Linux' and parity.get('exec_attempts')!=1:errors.append('Linux requires exactly1exec')
    return errors


def aggregate_tables(directory: Path, *, expected_ids: list[str] | None = None) -> dict:
    rows, errors = [], []
    expected_ids = [c['id'] for c in table_cases()] if expected_ids is None else expected_ids
    for path in sorted(directory.rglob('summary.json')):
        try:
            value = json.loads(path.read_text())
            if isinstance(value, dict) and value.get('scope') == 'table-local': rows.append(value)
        except (OSError, ValueError): errors.append(f'unreadable receipt: {path}')
    if sorted(row.get('platform', '') for row in rows) != ['Darwin', 'Linux']:
        errors.append('exactly one Linux and one macOS table receipt required')
    signatures = []
    for row in rows:
        errors.extend(table_receipt_errors(row,expected_ids))
        signatures.append((row.get('fingerprints',{}),row.get('rustc')))
    if signatures and any(s != signatures[0] for s in signatures): errors.append('platform source/input/toolchain drift')
    passed = not errors and len(rows) == 2
    return {'scope': 'table-matrix', 'passed': passed, 'errors': errors,
            'platforms': [r.get('platform') for r in rows], 'Table_accepted': passed, 'M2_accepted': False}


def validate_tables(repo: Path, reference: Reference, model_probe: Path, snapshot: Path,
                    native: Path, artifact: Path, out: Path, baseline_dir: Path,
                    original_manifest: Path,*,context:PreparedNativeContext|None=None,ettin:PreparedNativeEttin|None=None,translation:PreparedNativeTranslation|None=None,policy_probe:Path|None=None,storage:PreparedNativeStorage|None=None,fastembed:PreparedNativeFastEmbed|None=None) -> int:
    out = out.resolve(); out.mkdir(parents=True, exist_ok=True)
    result = {'scope': 'table-local', 'platform': platform.system(), 'architecture': platform.machine(),
              'passed': False, 'M2_accepted': False, 'gates': {}}
    _write(out / 'summary.json', result)
    try:
        def fingerprints():return table_fingerprints(repo,reference,artifact)
        before = fingerprints()
        result['fingerprints'] = before
        validate_models(repo, reference, model_probe, snapshot, out / 'base', baseline_dir,
                        original_manifest, table_probe=native,context=context,ettin=ettin,translation=translation,policy_probe=policy_probe,storage=storage,fastembed=fastembed)
        base = json.loads((out / 'base/summary.json').read_text())
        result.update(gates=base.get('gates', {}), rustc=base.get('rustc'))
        if base.get('execution_error'): result['execution_error'] = base['execution_error']
        binding = (bind_table_probe(repo, native) if result['gates'].get('release', {}).get('passed') is True
                   else {'ran': False, 'passed': False, 'error': 'fresh release build did not pass'})
        result['table_release'] = binding
        result['gates']['table_release'] = binding
        if binding['passed']:
            parity = compare(reference, native, artifact, out / 'table-parity')
            result.update(table_parity=parity, case_ids=parity.get('case_ids', []))
            result['gates']['table_parity'] = {'ran': True, 'passed': parity['passed'] and
                _binding_matches(binding, parity) and result['case_ids'] == [c['id'] for c in table_cases()]}
        if before != fingerprints(): result['execution_error'] = 'source/input drift during validation'
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        result['execution_error'] = f'{type(error).__name__}: {error}'
    result['errors'] = (['execution_error'] if result.get('execution_error') else []) + [g for g in TABLE_GATES
        if result['gates'].get(g, {}).get('ran') is not True or result['gates'][g].get('passed') is not True]
    result['passed'] = not result['errors']; result['Table_local_accepted'] = result['passed']
    _write(out / 'summary.json', result)
    return int(not result['passed'])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope', choices=['local', 'matrix'], default='local')
    parser.add_argument('--platform-receipts', type=Path)
    for name in ('reference', 'model-probe', 'snapshot', 'native', 'artifact', 'baseline-dir', 'original-manifest'):
        parser.add_argument('--'+name, type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.scope == 'matrix':
        if not args.platform_receipts: parser.error('matrix requires platform-receipts')
        result = aggregate_tables(args.platform_receipts); _write(args.out / 'summary.json', result)
        return int(not result['passed'])
    if not all(getattr(args, n) for n in ('reference', 'model_probe', 'snapshot', 'native', 'artifact', 'baseline_dir', 'original_manifest')):
        parser.error('local requires all reference/model/artifact/baseline arguments')
    return validate_tables(Path.cwd(), Reference.load(args.reference), args.model_probe, args.snapshot,
                           args.native, args.artifact, args.out, args.baseline_dir, args.original_manifest)


if __name__ == '__main__':
    raise SystemExit(main())
