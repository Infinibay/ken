from dataclasses import replace
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys
from tools.rust_migration.program_reference import SCRIPT,program_owner_hashes
from tools.rust_migration.reference import Reference,reference_env
repo=Path.cwd();system='macos'if sys.platform=='darwin'else'linux';ws=repo/'.superpowers/sdd/2026-10-23-rust-program-model';out=ws/('review-original-'+system);out.mkdir(exist_ok=True)
base=dict(path='test.py',language='python',version='1.88.0',entities={'e':dict(id='e',kind='CLASS',name='T',path='test.py',line=1,end_line=1,attrs=dict(start_byte=1,end_byte=9,native_kind='class_definition'))},operations=[dict(id='root',kind='UNKNOWN',native_kind='module',parent=None,role='',start=0,end=10,line=1,owner='owner',attrs={}),dict(id='child',kind='UNKNOWN',native_kind='class_definition',parent='root',role='',start=1,end=9,line=1,owner='owner',attrs={})],facts=[],capabilities=[],diagnostics=[])
inputs=[]
for callable in (False,True):
 for value in (None,False,0,[],{},True,'','int',1,3.0,['int'],{'kind':'int'},0.0,' '):
  graph=copy.deepcopy(base);entity=graph['entities']['e']
  if callable:
   entity.update(kind='CALLABLE',name='f');entity['attrs']['native_kind']=graph['operations'][1]['native_kind']='function_definition'
  entity['attrs']['native_return_type'if callable else'native_type']=value;inputs.append(graph)
script=SCRIPT[:SCRIPT.index('class Plugin:')]+'''
for data in request['inputs']:
 try:observed_normalize(IR.from_dict(data))
 except Exception:pass
result=dict(format='ken-program-review-reference/1',programs=list(programs.values()),runtime=dict(system=platform.system(),machine=platform.machine(),python=platform.python_version()))
pathlib.Path(request['result']).write_text(json.dumps(result,ensure_ascii=True)+'\\n')
'''
reference=replace(Reference.load(Path(os.environ.get('KEN_RUST_REFERENCE',repo/'.ken/rust-migration/m2-optional/reference-final-t9'))),python=Path(sys.executable).absolute())
request=dict(root=str(reference.root),grammar_cache=str(repo/('.ken/rust-migration/m3-parsers/sdk-'+system)),result=str(out/'original-observations.json'),inputs=inputs)
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
result=subprocess.run([str(reference.python),'-c',script,str(out/'request.json')],cwd=reference.root,env=reference_env(reference,out/'environment'),capture_output=True,check=True,timeout=30)
(out/'stdout.log').write_bytes(result.stdout);(out/'stderr.log').write_bytes(result.stderr);raw=(out/'original-observations.json').read_bytes();value=json.loads(raw)
value.update(script=script,owners=program_owner_hashes(repo),definitions=inputs,execution=dict(exit=result.returncode,stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),observations_sha256=hashlib.sha256(raw).hexdigest()))
Path(os.environ.get('KEN_PROGRAM_REVIEW_DEST',repo/'crates/ken-program/tests/fixtures/program-review.json')).write_text(json.dumps(value,indent=2)+'\n')
print(system,len(value['programs']),'actual original annotation regressions;',sum('error'in r for r in value['programs']),'failures;lookups',sum(len(r.get('lookups',[]))for r in value['programs']))
