from pathlib import Path
import json,tarfile
from tools.rust_migration.program_validate import source_identity
from tools.rust_migration.native_json import identity
repo=Path.cwd();ws=repo/'.superpowers/sdd/2026-10-23-rust-program-model';proof=repo/'docs/validation/rust-migration-2026-10-23/m3-program-review';proof.mkdir(parents=True,exist_ok=True)
sources=source_identity(repo);tooling={}
for pattern in ('tools/**/*.py','tests/rust_migration/test_program_*.py'):
 for path in repo.glob(pattern):tooling[str(path.relative_to(repo))]=identity(path)
with tarfile.open(proof/'sources.tar.gz','w:gz')as archive:
 for prefix,records in [('native-sources',sources),('validation-sources',tooling)]:
  for name in sorted(records):archive.add(repo/name,arcname=prefix+'/'+name,recursive=False)
platforms={}
for system in ('macos','linux'):
 capture=ws/('review-'+system)
 with tarfile.open(proof/(system+'-capture.tar.gz'),'w:gz')as archive:
  for name in ('native','original','review','gates'):archive.add(capture/name,arcname=name)
 platforms[system]=dict(native_sha256=json.loads((capture/'native/BUILD.json').read_bytes())['native_sha256'])
index=dict(format='ken-program-review-repair/1',sources=sources,tooling=tooling,platforms=platforms,predecessor=dict(path='docs/validation/rust-migration-2026-10-23/m3-imports-review',sha256='3779ac933aacc766c9372b8e623c4314bd5b65a31bb65735177ba2fa7aa6db6f'))
index['repair_of']=dict(path='docs/validation/rust-migration-2026-10-23/m3-program',sha256=identity(repo/'docs/validation/rust-migration-2026-10-23/m3-program/FILES.json')['sha256'])
(proof/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n');(proof/'LEDGER.md').write_bytes((ws/'progress.md').read_bytes())
for filename,token in [('RULINGS.md','Ruling:'),('MINORS.md','minor (deferred)')]:
 lines=[line for line in(ws/'progress.md').read_text().splitlines()if token in line];(proof/filename).write_text('\n\n'.join(lines)+'\n'if lines else'None recorded.\n')
with tarfile.open(proof/'development-logs.tar.gz','w:gz')as archive:
 for path in sorted(ws.iterdir()):
  if path.is_file()and path.suffix in('.py','.md','.log','.txt','.json'):archive.add(path,arcname=path.name)
rows=[dict(path=p.name,**identity(p))for p in sorted(proof.iterdir())if p.is_file()and p.name!='FILES.json'];(proof/'FILES.json').write_text(json.dumps(dict(files=rows),indent=2)+'\n')
print('Compressed proof artifacts:',len(rows))
