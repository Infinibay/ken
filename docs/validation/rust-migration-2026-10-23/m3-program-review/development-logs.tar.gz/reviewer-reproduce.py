"""Fresh reviewer probes; run from the repository root, with frozen PYTHONPATH.

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.ken/rust-migration/m2-optional/reference-final-t9/src .venv/bin/python /private/tmp/ken-m3d-final-review-18ea2020/reproduce.py
Add --types to reproduce the separately completed 3,060-case annotation comparison.
This script does not write to the checkout or recapture any original suite.
"""
import copy
import dataclasses
import json
import random
import subprocess
import sys

from ken.common_ast.normalize import normalize
from ken.structural.model import Entity, IR, Operation
from ken.structural.type_refs import parse_type

PROBE = '.ken/rust-migration/m2-fastembed/target-final-ci/debug/examples/program_probe'

def native(requests):
    result = subprocess.run([PROBE], input=json.dumps({'cases': requests}), capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)['cases']

if '--types' in sys.argv:
    random.seed(4)
    values = ['int', 'User', 'u32', 'π', 'A\u0301', 'None', 'unknown', '', 'const', 'volatile']
    for _ in range(500):
        a = random.choice(values)
        b = random.choice(values[:60])
        space = random.choice([' ', '\t', '\n', '\x1c', '\u00a0'])
        values.append(random.choice([f'Vec<{a}>', f'{a}[{b}]', f'{a} | {b}', f'({a},{b})', f'const{space}{a}', f'{a}*{space}volatile', f"&'a{space}mut{space}{a}", f'map[{a}]{b}', f'[{a}; {b}]', f'{a}?']))
    requests = [{'id': str(i), 'kind': 'type', 'annotation': s, 'language': lang} for i, (s, lang) in enumerate((s, lang) for s in values for lang in ['cpp', 'go', 'rust', 'python', 'csharp', 'typescript'])]
    mismatches = []
    for request, row in zip(requests, native(requests)):
        original = json.loads(json.dumps(dataclasses.asdict(parse_type(request['annotation'], request['language']))))
        if original != row['descriptor']:
            mismatches.append((request, original, row['descriptor']))
    print('compared', len(requests), 'mismatches', len(mismatches))
    for row in mismatches:
        print(json.dumps(row, ensure_ascii=True))
else:
    base = IR('test.py', 'python', entities={'e': Entity('e', 'CLASS', 'T', 'test.py', 1, 1, {'start_byte': 1, 'end_byte': 9, 'native_kind': 'class_definition'})}, operations=[Operation('root', 'UNKNOWN', 'module', None, '', 0, 10, 1, 'owner', {}), Operation('child', 'UNKNOWN', 'class_definition', 'root', '', 1, 9, 1, 'owner', {})])
    requests = []
    originals = {}
    for value in [None, False, 0, '', [], {}, True, 'int']:
        base.entities['e'].attrs['native_type'] = value
        key = repr(value)
        try:
            originals[key] = normalize(base).to_dict()
        except Exception as error:
            originals[key] = str(type(error)) + ': ' + str(error)
        requests.append({'id': key, 'kind': 'normalize', 'ir': copy.deepcopy(base.to_dict()), 'lookups': []})
    for row in native(requests):
        original = originals[row['id']]
        print(row['id'], 'PY', [(n['kind'], n['type_kind']) for n in original['nodes']] if isinstance(original, dict) else original, 'RS', [(n['kind'], n['type_kind']) for n in row['program']['nodes']] if 'program' in row else row)
