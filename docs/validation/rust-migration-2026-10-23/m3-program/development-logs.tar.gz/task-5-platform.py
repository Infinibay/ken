from pathlib import Path
import json,os,shutil,subprocess,sys
from tools.rust_migration.program_validate import program_cases,run_program_capture
repo=Path.cwd();system=sys.argv[1];ws=repo/'.superpowers/sdd/2026-10-23-rust-program-model';out=ws/('task-5-'+system);out.mkdir(exist_ok=True);gates=out/'gates';gates.mkdir(exist_ok=True)
wrapper=repo/'.ken/rust-migration/m2-optional/review-repair/prepared-macos-env'if system=='macos'else Path('/app/.ken/rust-migration/m2-optional/review-repair/prepared-linux-env')
targets=['tests/rust_migration/test_program_'+name+'.py'for name in ('reference','validate','evidence')]
commands=[('build.log',[str(wrapper),'cargo','build','--locked','--offline','-p','ken-program','--example','program_probe']),('rust-list.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-program','--','--list']),('rust-tests.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-program']),('python-list.log',[sys.executable,'-m','pytest','-o','addopts=','--collect-only','-q',*targets]),('python.log',[sys.executable,'-m','pytest','-o','addopts=','-q',*targets,'--junitxml='+str(gates/'python.xml')]),('clippy.log',[str(wrapper),'cargo','clippy','--locked','--offline','-p','ken-program','--all-targets','--','-D','warnings']),('fmt.log',[str(wrapper),'cargo','fmt','--all','--','--check'])]
for name,command in commands:
 with(gates/name).open('wb')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
 if result.returncode:raise SystemExit(name+' failed: '+(gates/name).read_text()[-3000:])
run_program_capture(repo,Path(os.environ['KEN_PROGRAM_PROBE']),program_cases(repo),out/'native')
original=out/'original';original.mkdir(exist_ok=True);cache=Path(os.environ['KEN_PROGRAM_REFERENCE_OUT'])
for name in ('reference.json','original-observations.json','original-tests.xml','request.json','stdout.log','stderr.log'):shutil.copy2(cache/name,original/name)
print(system,'7Rust/28tooling;320nativecases incl90programs,204types,26codecs,1240lookups;originals reused')
