### Task 2: Annotation syntax descriptors

**Interfaces:** parse_type(annotation:&str,language:&str)->TypeRef; split_types(&str,separator:char)->Vec<String>; recursive descriptor fields kind/native/arguments/bits/signed/extent/rank/qualifiers.

- [ ] Add type tests comparing all captured original descriptors, including qualifiers/pointers, arrays/ranks/extents, generics/unions, malformed delimiters, Unicode word boundaries, whitespace and depth/length limits. Expected missing API RED.
- [ ] Implement syntax policy in types.rs using authoritative static mappings; preserve fallback nominal/opaque distinctions. Generate pinned Unicode word ranges only if actual classification requires it, with original provenance and license record.
- [ ] Run full ken-program tests plus affected tooling on both platforms. Expected complete TypeRef equality and prior model gates green.
- [ ] Commit `feat(program): normalize annotation type syntax`.

