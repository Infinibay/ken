### Task 5: Isolated native acceptance, compact proof and final review

**Interfaces:** program_probe accepts bounded input-only IR, codec payloads, type/lookup requests and returns full observed results/errors; never accepts injected expectations. Reuse native_json process capture and existing receipt/gate validators; do not create another process harness.

- [ ] Add failing comparator/protocol/receipt tests for source/input/output changes, missing/duplicate/reordered cases, swallowed errors, altered unknowns, missing platforms and resealed false gate summaries. Expected missing APIs RED.
- [ ] Implement native probe and comparison/capture/replay, pin closed M3c FILES, record exact source snapshot and real discovered/executed test inventories. Actual copied native process, empty PATH/loader/Linux exec/connect audit.
- [ ] Run affected native/tooling gates and complete differential on both platforms, reusing cached original captures and all earlier proofs. Expected full semantics/errors exact and1066guard intact.
- [ ] Compress source/raw histories and independently replay authentic proof; exercise resealed mutations. Expected M3d-only acceptance, M3/M8 false. Commit `test(program): authenticate native common model parity`.
- [ ] Dispatch one fresh whole-plan reviewer, ledger regraded findings and declined scopes. One Important/Critical RED→GREEN repair pass plus green affected suites, no rereview. Archive review/ledger/rulings/minors before removing only this completed workspace; continue incremental indexing without confirmation.

## Self-review

One functional domain boundary, five testable tasks. IR ordering and shared
model schemas precede every consumer; type syntax precedes normalization/binding;
Environment is authoritative for both public lookup and reference construction.
Pre-binding comparisons are explicitly intermediate and final acceptance requires
full programs and original failures. Source lowering is neither duplicated nor
quietly counted complete; it will reuse StructuralIr inM5a. Existing continuous
native authorization settles workflow choices without another approval step.
