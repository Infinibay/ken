### Task 1: Ordered IR, common model codec and independent original capture

**Interfaces:** StructuralIr::from_json(&str)->Result<Self,ProgramError> preserves ordered entities/raw attrs and checks1.88.0. Program::{from_json(&str),to_json(),validate()} uses common-ast/1; public Node/Scope/Symbol/Reference/Link retain every original field/default. body_ranges(&Program)->Vec<BodyRange> has owner/relation/root/subtree_end and final_node().

- [ ] Add failing tooling capture test for actual original common-AST/type suites and cached reuse; expected missing module. Capture full IR/program/type outputs and real test discovery/states/raw process provenance from frozen owners; original reference root verified.
- [ ] Run actual original tests once per platform, with actual SDK cache and supplements for codecs/forest/order/Unicode. Cache immutable observations for later tasks; no parsers/models suite rerun. Expected all selected tests passed, exact independently captured cases.
- [ ] Add native model tests comparing every original codec/body-range success/error, defaults and full roundtrip. Expected missing ken-program RED.
- [ ] Implement ordered IR/model/codec/body-range boundaries, contextual ProgramError; no normalization stubs presented complete. Expected all model tests pass, native fmt/clippy and1066guard.
- [ ] Commit `feat(program): preserve ordered IR and common AST codec`.

