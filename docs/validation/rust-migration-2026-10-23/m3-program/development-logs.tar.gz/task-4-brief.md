### Task 4: Declaration policy, import bindings and lexical references

**Interfaces:** normalize(&StructuralIr)->Result<Program,ProgramError> calls the syntax builder, binding owner and final validate. Environment::new(&Program); resolve(name:&str,scope:usize,point:i64)->Result<Resolution,ProgramError>; Resolution retains symbol/status/availability/reason. No duplicate reference-resolution policy inside the normalizer.

- [ ] Add complete original-program and actual lookup tests for all captured cases. Explicitly pin hoisting/TDZ, Rust shadowing, Python directives/defaults/class/comprehension, Ruby blocks, parameter receivers, all import forms, dynamic deletion/eval and member dispatch. Expected missing final binding/lookup or mismatched full results RED.
- [ ] Implement focused declaration/import helpers and shared Environment policy. Preserve ordered declaration winners, flag sorting and all source/native/effective parameter positions. Keep unknowns conservative.
- [ ] Run full ken-program tests/affected tooling Mac/Linux, fmt/clippy/1066guard. Expected complete original Program, bodies and lookup equality including errors, no partial successful forest.
- [ ] Commit `feat(program): bind declarations and resolve lexical references`.

