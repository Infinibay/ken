from pathlib import Path
import json
repo=Path.cwd();base=repo/'.ken/rust-migration/m3-program'
values=[json.loads((base/('reference-'+system)/'reference.json').read_bytes())for system in ('macos','linux')]
first,second=values
for group in ('types','codecs','vocabulary','discovered','test_states'):assert first[group]==second[group],group
rows={}
for value in values:
 for row in value['programs']:
  if row['id']in rows:assert rows[row['id']]==row
  else:rows[row['id']]=row
# Real producer records carry Tree-sitter node addresses in attrs.block_scope.
# Keep both exact inputs; their complete normalized outputs are identical.
for a,b in zip(first['programs'],second['programs'],strict=True):
 assert all(a[k]==b[k]for k in a if k not in ('id','input'))
 if a['input']!=b['input']:
  aa=json.loads(json.dumps(a['input']));bb=json.loads(json.dumps(b['input']))
  for graph in (aa,bb):
   for entity in graph['entities'].values():
    if 'block_scope'in entity['attrs']:entity['attrs']['block_scope']='<compared only; actual fixture retains bytes>'
  assert aa==bb
out=repo/'crates/ken-program/tests/fixtures'
metadata=dict(original_corpus_sha256=[v['corpus_sha256']for v in values],owners=first['owners'])
for name,data in [('program-reference',dict(programs=list(rows.values()),codecs=first['codecs'])),('type-reference',dict(types=first['types'])),('vocabulary',dict(vocabulary=first['vocabulary']))]:
 (out/(name+'.json')).write_text(json.dumps({**data,**metadata},ensure_ascii=True,separators=(',',':'))+'\n')
print('Full original union:',len(rows),'program inputs; 204types; 26codecs; 135original tests eachplatform')
