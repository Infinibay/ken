### Task 3: Ordered tree, scopes, kinds and argument normalization

**Interfaces:** normalize_syntax(&StructuralIr)->Result<Program,ProgramError> is an explicit intermediate builder used by normalize; produces exact nodes/scopes/links/diagnostics before lexical binding. Its output is not claimed final until Task4. Static kind vocabulary generated from original owner may be stored in an authenticated asset.

- [ ] Add tests comparing full original pre-binding tree/scopes/links plus invalid forests, duplicate ids/ordered equal spans, root/unknown/Unicode/default/comprehension and argument cases. Expected missing normalize_syntax RED.
- [ ] Implement kinds.rs and normalize.rs, deterministic rooted traversal with cycle/duplicate handling, subtree intervals, scoped names, flags, literal/type descriptors, argument source/effective positions and sorted unique canonical links.
- [ ] Run complete model/types/tree suite Mac/Linux, fmt/clippy/1066guard. Expected all pre-binding fields exact; malformed forests explicitly fail.
- [ ] Commit `feat(program): normalize ordered syntax and lexical scopes`.

