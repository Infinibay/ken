from pathlib import Path
import json,os,shutil,subprocess,sys
from tools.rust_migration.import_validate import import_cases,run_import_capture,FIXTURES
repo=Path.cwd();system=sys.argv[1];ws=repo/'.superpowers/sdd/2026-10-23-rust-import-resolution';out=ws/('task-5-'+system);out.mkdir(exist_ok=True)
wrapper=repo/'.ken/rust-migration/m2-optional/review-repair/prepared-macos-env'if system=='macos'else Path('/app/.ken/rust-migration/m2-optional/review-repair/prepared-linux-env')
gates=out/'gates';gates.mkdir(exist_ok=True)
targets=['tests/rust_migration/test_import_reference.py','tests/rust_migration/test_import_validate.py','tests/rust_migration/test_import_evidence.py']
commands=[('rust-list.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-core','--','--list']),('rust-tests.log',[str(wrapper),'cargo','test','--locked','--offline','-p','ken-core']),('python-list.log',[sys.executable,'-m','pytest','-o','addopts=','--collect-only','-q',*targets]),('python.log',[sys.executable,'-m','pytest','-o','addopts=','-q',*targets,'--junitxml='+str(gates/'python.xml')]),('clippy.log',[str(wrapper),'cargo','clippy','--locked','--offline','-p','ken-core','--all-targets','--','-D','warnings']),('fmt.log',[str(wrapper),'cargo','fmt','--all','--','--check'])]
for name,command in commands:
 with(gates/name).open('wb')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
 if result.returncode:raise SystemExit(name+' failed: '+(gates/name).read_text()[-2500:])
run_import_capture(repo,Path(os.environ['KEN_IMPORT_PROBE']),import_cases(repo),out/'native')
reference=repo/'.ken/rust-migration/m3-imports'/('reference-'+system);original=out/'original';original.mkdir(exist_ok=True)
for name in ('reference.json','original-observations.json','original-tests.xml','request.json','stdout.log','stderr.log'):shutil.copy2(reference/name,original/name)
supp=out/'supplements';supp.mkdir(exist_ok=True)
for name in FIXTURES[1:]:
 if system=='macos':
  value=json.loads((repo/'crates/ken-core/tests/fixtures'/(name+'.json')).read_bytes());raw=value['execution']['observations']
 elif name=='import-alias-edges':raw=(ws/'task-2-original-extra/original-observations.json').read_text()
 else:
  value=json.loads((ws/(name+'-linux.json')).read_bytes());raw=value['execution']['observations']
 (supp/(name+'.json')).write_text(raw)
print(system,'45Rust/33tooling;91originalinputs in2native modes;no original-suite/model rerun')
