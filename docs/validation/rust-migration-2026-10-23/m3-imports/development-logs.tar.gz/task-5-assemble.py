from pathlib import Path
import json,shutil,tarfile
from tools.rust_migration.import_validate import source_identity
from tools.rust_migration.native_json import identity
repo=Path.cwd();ws=repo/'.superpowers/sdd/2026-10-23-rust-import-resolution';proof=repo/'docs/validation/rust-migration-2026-10-23/m3-imports';proof.mkdir(parents=True,exist_ok=True)
sources=source_identity(repo);tooling={}
for pattern in ('tools/**/*.py','tests/rust_migration/test_import_*.py'):
 for path in repo.glob(pattern):tooling[str(path.relative_to(repo))]=identity(path)
with tarfile.open(proof/'sources.tar.gz','w:gz')as archive:
 for prefix,records in [('native-sources',sources),('validation-sources',tooling)]:
  for name in sorted(records):archive.add(repo/name,arcname=prefix+'/'+name,recursive=False)
platforms={}
for system in ('macos','linux'):
 capture=ws/('task-5-'+system)
 with tarfile.open(proof/(system+'-capture.tar.gz'),'w:gz')as archive:
  for name in ('native','original','supplements','gates'):archive.add(capture/name,arcname=name)
 platforms[system]=dict(native_sha256=json.loads((capture/'native/BUILD.json').read_bytes())['native_sha256'])
index=dict(format='ken-import-matrix/1',sources=sources,tooling=tooling,platforms=platforms,predecessor=dict(path='docs/validation/rust-migration-2026-10-23/m3-parsers-review',sha256='c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8'))
(proof/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
(proof/'LEDGER.md').write_bytes((ws/'progress.md').read_bytes())
for filename,token in [('RULINGS.md','Ruling:'),('MINORS.md','minor (deferred)')]:
 lines=[line for line in(ws/'progress.md').read_text().splitlines()if token in line];(proof/filename).write_text('\n\n'.join(lines)+'\n'if lines else'None recorded.\n')
with tarfile.open(proof/'development-logs.tar.gz','w:gz')as archive:
 for path in sorted(ws.iterdir()):
  if path.is_file()and path.suffix in ('.py','.md','.log'):archive.add(path,arcname=path.name)
rows=[dict(path=str(p.relative_to(proof)),**identity(p))for p in sorted(proof.iterdir())if p.is_file()and p.name!='FILES.json']
(proof/'FILES.json').write_text(json.dumps(dict(files=rows),indent=2)+'\n')
print('Compressed receipt artifacts:',len(rows))
