### Task 3: Language module rules and unresolved classification

**Files:** Create `crates/ken-core/src/imports/{languages.rs,classification.rs}`; extend mod.rs/tests.

**Interfaces:** `ImportCatalog::resolve(&self,request:&ImportRequest)->Result<ImportResolution,ImportError>` becomes complete. Language policies consume catalog inventory/config-derived Go/PSR4 data; targets are existing paths only. Generic structural match always precedes specialized lookup.

- [ ] Add complete original edge tests for Java static/wildcard, Rust crate/self/super/glob/module precedence, nested Go modules and representative non-test files, Ruby relative loads, quoted C++ subtree ambiguity, Kotlin unique package files, PHP ordered PSR4/unique tail and all language-specific unresolved/external shapes. Include deliberate generic-vs-specialized collisions.
- [ ] Run affected language/classification tests: expect pending branches RED.
- [ ] Implement language decisions in their owners, stable ordering and exact original early-return/fallthrough rules. Remove all pending resolve branches; unknown languages retain original generic resolution/classification.
- [ ] Run complete native import corpus, original-owner guard, affected tooling, ken-core regressions and fmt/clippy on both systems; expect complete ordered results/errors GREEN.
- [ ] Commit as `feat(imports): complete native language resolution policies`.

