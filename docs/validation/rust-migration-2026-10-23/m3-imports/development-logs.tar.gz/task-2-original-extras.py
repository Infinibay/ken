from dataclasses import replace
from pathlib import Path
import hashlib,json,subprocess,sys,os
from tools.rust_migration.import_reference import SCRIPT,import_owner_hashes
from tools.rust_migration.reference import Reference,reference_env
repo=Path.cwd();ws=repo/'.superpowers/sdd/2026-10-23-rust-import-resolution';out=ws/'task-2-original-extra';out.mkdir(exist_ok=True)
reference=replace(Reference.load(Path(os.environ.get('KEN_RUST_REFERENCE',repo/'.ken/rust-migration/m2-optional/reference-final-t9'))),python=Path(sys.executable).absolute())
rows=[]
def add(files,module,configs,source='src/main.ts'):
 rows.append(dict(files=[source,*files],configs={k:v.encode().hex()for k,v in configs.items()},imports=[dict(module=module,source_path=source,language='typescript')]))
def cfg(paths):return json.dumps(dict(compilerOptions=dict(paths=paths)))
for reverse in (False,True):
 pairs=[('@*',['one/*']),('@app/*',['two/*'])]
 if reverse:pairs.reverse()
 add(['tsconfig.json','one/app/value.ts','two/value.ts'],'@app/value',{'tsconfig.json':cfg(dict(pairs))})
for reverse in (False,True):
 files=['one/package.json','two/package.json','one/sub.ts','two/index.ts']
 if reverse:files[:2]=reversed(files[:2])
 add(files,'@scope/pkg/sub',{'one/package.json':'{"name":"@scope/pkg"}','two/package.json':'{"name":"@scope/pkg/sub"}'})
for reverse in (False,True):
 files=['tsconfig.json','jsconfig.json','one.ts','two.ts']
 if reverse:files[:2]=reversed(files[:2])
 add(files,'@value',{'tsconfig.json':cfg({'@value':['one']}),'jsconfig.json':cfg({'@value':['two']})})
add(['one/package.json','two/package.json','one/index.ts','two/index.ts'],'same',{'one/package.json':'{"name":"same"}','two/package.json':'{"name":"same"}'})
add(['tsconfig.json','config/lib/value.ts'],'@value',{'tsconfig.json':'{"extends":"./config/base"}','config/base.json':'{"compilerOptions":{"baseUrl":"./lib","paths":{"@value":["value"]}}}'})
add(['tsconfig.json','one.ts'],'@value',{'tsconfig.json':'{"compilerOptions":{"paths":{"@value":["one"]}},"unused":"\\ud800"}'})
add(['tsconfig.json','one.ts'],'@a}',{'tsconfig.json':cfg({'@a,}':['one']})})
script='\n'.join('exit_code=0'if line.startswith('exit_code=pytest.main(')else line for line in SCRIPT.splitlines())+'\n'
request=dict(root=str(reference.root),grammar_cache=str(repo/('.ken/rust-migration/m3-parsers/sdk-macos'if sys.platform=='darwin'else'.ken/rust-migration/m3-parsers/sdk-linux')),junit=str(out/'unused.xml'),result=str(out/'original-observations.json'),supplements=rows)
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
execution=subprocess.run([str(reference.python),'-c',script,str(out/'request.json')],cwd=reference.root,env=reference_env(reference,out/'environment'),capture_output=True,check=True,timeout=30)
raw=(out/'original-observations.json').read_text();value=json.loads(raw)
value.update(format='ken-import-supplements/1',owners=import_owner_hashes(repo),script=script,execution=dict(exit=execution.returncode,stdout=execution.stdout.decode(),stderr=execution.stderr.decode(),observations=raw),definitions=rows)
Path('crates/ken-core/tests/fixtures/import-alias-edges.json').write_text(json.dumps(value,indent=2)+'\n')
print(len(value['cases']),'independent original alias/config priority cases')
