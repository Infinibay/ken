### Task 1: Independent original resolution reference and structural targets

**Files:** Create `tools/rust_migration/import_reference.py`, `tests/rust_migration/test_import_reference.py`, `crates/ken-core/src/imports/{mod.rs,paths.rs}`, `crates/ken-core/tests/import_resolution.rs`, `crates/ken-core/tests/fixtures/import-reference.json`; export imports from lib.rs.

**Interfaces:** Original capture records ordered files, config bytes, pending module/source/language requests and observed final target/resolution. Public ImportRequest{module:String,source_path:String,language:Option<String>}, ImportResolution{target:Option<String>,resolution:Resolution}, Resolution::{Internal,Unresolved,External}, ImportError. Internal structural_target(module:&str,source:Option<&str>,files:&[String],suffixes:&BTreeMap<String,Vec<String>>)->Option<String>. `ImportCatalog::from_inputs(files:Vec<String>,configs:Option<BTreeMap<String,Vec<u8>>>)->Result<Self,ImportError>` constructs native catalogs; specialized resolve remains explicitly pending until Tasks2/3.

- [ ] Capture actual original tests/test_indexer.py resolution calls with owners and124parser/model histories reused. Record all test IDs/states, real raw requests/output and supplemental direct original ambiguity/no-root/Unicode cases; reference tests reject changed owners, missing cases and stale captures.
- [ ] Add Rust public-usage tests for generic dotted/suffix uniqueness, relative joins, exact/non-code path priority, all seven extension/index fallbacks and ESM rewrite. Run affected test: expect missing imports module/API RED.
- [ ] Implement data contracts, path normalization, JS matcher and precomputed Python suffix lookup; preserve bytes/whitespace/ambiguity rules from original. No DB access or generic guessed external success for pending languages.
- [ ] Run structural subset, focused capture tests, ken-core existing tests and fmt/clippy on both native systems. Expect complete captured structural results and original1066guard GREEN.
- [ ] Commit scoped changes as `feat(imports): preserve structural module resolution`.

