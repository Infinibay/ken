### Task 5: Native differential acceptance and review

**Files:** Create `crates/ken-core/examples/import_probe.rs`, `tools/rust_migration/{import_validate.py,import_evidence.py}`, `tests/rust_migration/{test_import_validate.py,test_import_evidence.py}`, `docs/validation/rust-migration-2026-10-23/m3-imports/`; update migration progress docs.

**Interfaces:** Strict bounded input-only probe accepts ordered file/config bytes and import requests, returns complete ordered ImportResolution or contextual errors. Native acquisition mode reads actual temporary project config files. Authentication pins the final closed M3b FILES manifest at execution time, validates immutable predecessor bytes and snapshots every consumed source/config/test input.

- [ ] Add RED comparator/protocol/receipt tests for missing/duplicate/reordered inputs, changed target/resolution, config order or bytes, lost original failures, injected expectations, missing platforms and resealed false passing gates.
- [ ] Implement native probe, isolated copied-binary process driver and semantic receipt replay. Record actual stdout/stderr/exit, sentinelPATH/loader evidence and Linux exec/connect audit; no expected values accepted by native requests.
- [ ] Run full affected native/tooling gates and one complete differential per actual platform, with actual config acquisition fixtures. Reuse unchanged earlier parser/source/model histories; verify1066originals intact.
- [ ] Replay authenticated evidence independently; expect all resealed mutations rejected and M3c-only acceptance. Compress raw histories, retain small source snapshots and exact gate inventories.
- [ ] Commit evidence, run one fresh whole-plan review and one TDD Important/Critical repair pass, archive complete ledger/rulings/minors/review before deleting own completed workspace. Continue common model and incremental indexing without confirmation pauses.

## Self-review

The catalog and ordered config boundary are fixed before specialized consumers;
all five Review Focus inputs have explicit task tests. No task conflates native
resolution with SQLite writes or claims global migration completion. Canonical
common-AST normalization remains its own producer/consumer boundary after import
resolution and before M3 indexing acceptance. The final M3b predecessor identity
is resolved only after that plan's required review repair closes, avoiding a pin
to provisional evidence. Existing no-confirmation/native authorization applies.

Closed M3b predecessor: `docs/validation/rust-migration-2026-10-23/m3-parsers-review`; FILES.json SHA256 `c1541177be2a0716ff52276d7cfe042ae4ff5acea75d3f4c90d4a3452ab48ff8`, repaired commit03400e2b. Its immutable proof is reused; no124parser-suite/model recapture.
