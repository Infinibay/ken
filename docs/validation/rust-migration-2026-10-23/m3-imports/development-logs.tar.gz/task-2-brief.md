### Task 2: Ordered config and JS/TS aliases

**Files:** Create `crates/ken-core/src/imports/{config.rs,aliases.rs}`; extend imports tests/reference fixtures.

**Interfaces:** ConfigValue owns ordered object values, UTF8 replacement/strict parsing policies and original JSONC cleanup. AliasResolver::from_inputs(files:&[String],configs:&BTreeMap<String,Vec<u8>>)->Result<Self,ImportError>; resolve(module:&str,source:&str)->Option<String>; is_internal_shape(module:&str,source:&str)->bool. Reads only supplied bytes and indexed config paths.

- [ ] Add original full-target tests for ordered overlapping aliases/workspaces, duplicate keys, nearest config ties and fallthrough, depth<3 extends cycles, parent baseUrl inheritance, malformed/invalid JSON and wrong shapes.
- [ ] Run JS/TS subset expecting explicit pending/missing aliases RED.
- [ ] Implement ordered JSON via serde visitor and string-aware original JSONC cleanup. Preserve first-position/last-value duplicate semantics, paths insertion order and stable nearest-first configs/packages.
- [ ] Run all current imports tests, focused tooling, existing ken-core regressions and fmt/clippy on both systems. Expect exact original target/classification/error boundaries and unchanged model dependencies.
- [ ] Commit as `feat(imports): resolve ordered JS and TS project aliases`.

