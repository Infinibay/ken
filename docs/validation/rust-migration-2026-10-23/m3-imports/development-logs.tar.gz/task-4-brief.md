### Task 4: Real project config acquisition

**Files:** Create `crates/ken-core/src/imports/project_inputs.rs`; extend imports public API and tests.

**Interfaces:** `ImportCatalog::from_project(root:Option<&Path>,files:Vec<String>)->Result<Self,ImportError>` reads only indexed config paths, with original UTF8/error tolerance, then delegates pure construction. None means no project configs. The filesystem adapter never chooses import targets.

- [ ] Write real temporary-project tests for indexed/unindexed configs, missing/unreadable files, JSONC UTF8 replacement versus PHP strict decoding, wrong shapes, optional root and config changes between separately constructed catalogs.
- [ ] Run new public caller tests: expect missing from_project RED.
- [ ] Implement config acquisition and contextual errors; keep resolution/persistence outside this owner.
- [ ] Run imports suite and relevant existing ken-core tests on Mac/Linux, fmt/clippy and1066guard. Expect same results as explicit-input catalogs and no hidden cache/fallback.
- [ ] Commit as `feat(imports): prepare resolution from indexed project configs`.

