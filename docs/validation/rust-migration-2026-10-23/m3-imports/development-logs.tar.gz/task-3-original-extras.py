from dataclasses import replace
from pathlib import Path
import hashlib,json,subprocess,sys,os
from tools.rust_migration.import_reference import SCRIPT,import_owner_hashes
from tools.rust_migration.reference import Reference,reference_env
repo=Path.cwd();ws=repo/'.superpowers/sdd/2026-10-23-rust-import-resolution';out=ws/'task-3-original-language';out.mkdir(exist_ok=True)
reference=replace(Reference.load(Path(os.environ.get('KEN_RUST_REFERENCE',repo/'.ken/rust-migration/m2-optional/reference-final-t9'))),python=Path(sys.executable).absolute())
rows=[]
def add(files,module,configs=None,source='src/main.ts',language='typescript'):
 rows.append(dict(files=[source,*[p for p in files if p!=source]],configs={k:v.encode().hex()for k,v in (configs or {}).items()},imports=[dict(module=module,source_path=source,language=language)]))
add(['src/a/util.rs'],'self::util::Value',source='src/a/main.rs',language='rust')
add(['src/util.rs'],'super::super::util::Value',source='src/a/b/main.rs',language='rust')
add([],'self::*',source='src/main.rs',language='rust')
add([],'crate::missing',source='src/main.rs',language='rust')
add(['Cargo.toml','pkg/Cargo.toml','src/util.rs','pkg/src/util/mod.rs'],'crate::util::{Foo,Bar}',source='pkg/src/main.rs',language='rust')
add(['go.mod','sub/go.mod','lib/value.go'],'example/lib',source='sub/main.go',language='go',configs={'go.mod':'module example\n','sub/go.mod':'module example\n'})
add(['go.mod','lib/a_test.go','lib/z.go','lib/b.go'],'example/lib',source='main.go',language='go',configs={'go.mod':'module example\n'})
add(['src/pkg/A.java'],'pkg.*',source='main.java',language='java')
add(['src/pkg/A.kt'],'pkg.*',source='main.kt',language='kotlin')
add(['src/foo/bar/A.kt'],'foo.bar.*',source='main.kt',language='kotlin')
add(['src/util.ts','src/util.rb'],'./util',source='src/main.rb',language='ruby')
add(['src/util.rb'],'util',source='src/main.rb',language='ruby')
add(['one/shared.hpp','two/shared.hpp'],'"shared.hpp"',source='src/main.cpp',language='cpp')
for raw,dirname in [('3','3'),('3e0','3.0'),('true','True'),('null','None')]:
 add(['composer.json',dirname+'/Value.php','other/Value.php'],'App\\Value',source='main.php',language='php',configs={'composer.json':'{"autoload":{"psr-4":{"App\\\\":'+raw+'}}}'})
add(['composer.json','one/Value.php','two/Value.php'],'App\\Value',source='main.php',language='php',configs={'composer.json':'{"autoload":{"psr-4":{"App\\\\":["one","two"]}}}'})
add(['composer.json','one/Value.php','two/Value.php'],'App\\Value',source='main.php',language='php',configs={'composer.json':'{"autoload":{"psr-4":{"App\\\\":"one"}},"autoload-dev":{"psr-4":{"App\\\\":"two"}}}'})
add(['Value.py','composer.json','lib/Value.php'],'Value',source='main.php',language='php',configs={'composer.json':'{"autoload":{"psr-4":{"":"lib"}}}'})
script='\n'.join('exit_code=0'if line.startswith('exit_code=pytest.main(')else line for line in SCRIPT.splitlines())+'\n'
request=dict(root=str(reference.root),grammar_cache=str(repo/('.ken/rust-migration/m3-parsers/sdk-macos'if sys.platform=='darwin'else'.ken/rust-migration/m3-parsers/sdk-linux')),junit=str(out/'unused.xml'),result=str(out/'original-observations.json'),supplements=rows)
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
execution=subprocess.run([str(reference.python),'-c',script,str(out/'request.json')],cwd=reference.root,env=reference_env(reference,out/'environment'),capture_output=True,check=True,timeout=30)
raw=(out/'original-observations.json').read_text();value=json.loads(raw)
value.update(format='ken-import-supplements/1',owners=import_owner_hashes(repo),script=script,execution=dict(exit=execution.returncode,stdout=execution.stdout.decode(),stderr=execution.stderr.decode(),observations=raw),definitions=rows)
Path(os.environ.get('KEN_IMPORT_EXTRA_DEST','crates/ken-core/tests/fixtures/import-language-edges.json')).write_text(json.dumps(value,indent=2)+'\n')
print(len(value['cases']),'independent original alias/config priority cases')
