"""Archive only closed development MCP evidence, never sealed reserve inputs."""
from pathlib import Path
import gzip
import hashlib
import json

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

w = Path.cwd()
out = w / 'output/analysis/bounded-symbol-export-v214'
out.mkdir(exist_ok=False)
payload = out / 'payload'
payload.mkdir()
grade = w / 'output/development/public-bounded-symbol-ranking-grade-v214'
summary = json.loads((grade / 'summary.json').read_text())
assert summary['bounded_symbol_quality_check'] and summary['actual_english_order_parity_with_closed213']
inputs = set(grade.iterdir())
for cohort in ['original', 'symbols']:
    root = w / 'output/development' / ('public-bounded-symbol-ranking-v214-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    assert reg['lock_sha256'] == sha(root / 'lock.json')
    assert len(reg['closed']) == 8
    inputs.update(p for p in root.rglob('*') if p.is_file())
    inputs.add(Path(lock['public_cases']))
    for repo, files in reg['closed'].items():
        for name, digest in files.items():
            assert sha(root / 'capture' / repo / name) == digest
inputs.update([w / 'output/frozen/bounded-symbol-ranking-v214/SOURCE-MANIFEST.json',
    w / 'output/analysis/symbol-ranking-v214-full-verification.json',
    w / 'output/analysis/symbol-product-parity-v214/summary.json',
    w / 'experiments/search-engine/public_default_mcp_run.py', Path(__file__)])
inputs.update(w / 'output/analysis' / name for name in [
    'freeze-bounded-symbol-ranking-v214.py', 'run-bounded-symbol-ranking-v214.py',
    'grade-bounded-symbol-ranking-v214.py', 'verify-symbol-product-parity-v214.py',
    'public-default-server-v195.py'])
logs = ['red', 'boundary-red', 'green', 'green-r1', 'green-r2', 'snapshot-red',
        'negation-red', 'mypy-r1', 'mypy-r2', 'mypy-final', 'full-tests', 'full-tests-r1']
inputs.update(Path('/private/tmp') / ('ken-symbol-ranking-v214-' + name + '.log') for name in logs)
inputs.add(Path('/private/tmp/ken-public-bounded-symbol-ranking-v214.log'))
records = []
for i, path in enumerate(sorted(inputs)):
    assert path.is_file(), path
    logical = path.relative_to(w).as_posix() if path.is_relative_to(w) else 'verification/' + path.name
    data = path.read_bytes()
    target = payload / (f'{i:03d}-' + path.name + '.gz')
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    records.append({'source': logical, 'source_sha256': sha(path), 'bytes': len(data),
        'payload': target.name, 'payload_sha256': sha(target)})
manifest = {'scope': 'V214 actual MCP400 after immutable213 replay; fixed exposed development400/English240; reserve CLOSED, no new external acceptance or trained weights.',
    'frozen_source_receipt': 'b9e86b7fe4e7a405f94c47a1f157b97765eed97f3581f356f927d738e0f79079',
    'parent_evidence': '../english-symbol-relations-2026-10-16-v207-v213/manifest.json',
    'files': records}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name in ['summary.json','costs.json']:
    (out / name).write_bytes((grade / name).read_bytes())
(out / 'verification.json').write_bytes((w / 'output/analysis/symbol-ranking-v214-full-verification.json').read_bytes())
(out / 'README.md').write_text('''# Actual MCP bounded symbol ranking V214

Both complete exposed development cohorts were captured before opening fixed
Gold. All400 calls use normal default MCP stdio; the source425-file freeze
is b9e86b7fe4e7a405f94c47a1f157b97765eed97f3581f356f927d738e0f79079.
Every native candidate pool is identical to201, and all240 English complete
orders exactly match closed213 BEFORE grading. Queries, references and English
language labels were not edited. The sealed reserve remains CLOSED.

| Fixed English development |201 top1|214 top1|Recall10, unchanged|
|---|---:|---:|---:|
|Original120|113/120 (94.17%)|110/120 (91.67%)|118/120 (98.33%)|
|New120|95/120 (79.17%)|108/120 (90.00%)|119/120 (99.17%)|

The >=108 requirement is met independently in EACH cohort. All400 bilingual
regression rows are retained: original189/200 top1,197/200 Recall10; new176/200
top1,195/200 Recall10. Spanish is not the acceptance target. These are exposed
development results, not an unseen population-accuracy estimate, not a private
reserve pass, and not a new Semble benchmark score.

## Source and mathematical contract

Nonexact symbol candidates receive (original-card logit + complete-owned-code
logit)/2 from the same published Ettin68M, max1024tokens. The extra executable
view is accepted only whole:<=64lines,<=12000chars,complete pair<=1024tokens.
Otherwise its score is the original-card score. No arbitrary prefix cut.
Stable syntax-relation, requested test-case and explicit code-operator
preferences follow. A requested path retains final priority. Unknown syntax
does not remove candidates. Exact lookups and aggregate class/module/file RRF
stay as201. See the207–213 evidence for isolated controls and failed approaches.

The relations observe direct source syntax only: explicit exception cause,
same-mapping/key previous-value record around assignment, and returned
flag-or-assigned-call. They are not interprocedural or execution proofs. Valid
delegates are retained. No labels, query IDs or repository names enter the
product policy. This small development improvement still needs external
generalization checks;90% on a repeatedly inspected set is not independent proof.

## CPU and memory

All actual ONNX providers were CPUExecutionProvider for reranking and contextual
retrieval,1024tokens, no Torch/Transformers/sentence_transformers imports.
Complete warm MCP English240 latency: p50 2418.77ms,p95 3734.28ms,max4885.30ms.
All400:p50 2582.89ms,p95 4023.92ms,max5185.41ms. Peak WHOLE-server RSS is
2003845120bytes (2.00GB decimal,1.87GiB). All observations and outliers remain.
Index preparation and explicit warmup are separate; full-process CPU totals,+warmup, per-repository file counts and RSS are in costs.json. No GPU is required.

The approximate1s/100files target remains unmet on several small repositories;
the model's fixed overhead is visible. Do not claim that scaling target passed,
that costs are statistically isolated from all machine activity, or that lower
RSS than201 proves a causal memory optimization. This run validates the actual
quality and measured CPU cost of the new ranking policy.

## Verification and reproduction

37 targeted tests use real parsed fixtures and miniature ONNX inference.
Full suite14998passed with10existing xfails; mypy360sourcefiles clean. The earlier
full-suite attempt was interrupted before a snapshot-provenance fix; only the
complete final log is counted. Source/input parity covers all1280symbol inputs
and128nonexact English orders. No existing failures are hidden or suppressed.

manifest.json records original logical paths, source SHA256, deterministic gzip
payload hashes and byte counts. Restore the recorded corpus/source/model pins,
the201 base plus complete SOURCE-WORKTREE.patch (including added modules), then
run the capture driver before the grader. Map external absolute input paths to
their restored byte-identical files. Prior207–213payloads retain all fixed exposed
references and the replay; no sealed input is required or included. No release.
'''.replace('totals,+warmup', 'totals,\nwarmup'))
print(json.dumps({'payloads':len(records),'gzip_bytes':sum(p.stat().st_size for p in payload.iterdir()),
                  'manifest_sha256':sha(out / 'manifest.json')}))
