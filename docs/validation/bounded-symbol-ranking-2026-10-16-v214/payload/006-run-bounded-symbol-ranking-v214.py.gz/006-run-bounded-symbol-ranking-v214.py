"""Capture both complete public cohorts before reading exposed references."""
import json
import os
from pathlib import Path
import subprocess

w = Path.cwd()
for cohort in ['original', 'symbols']:
    out = w / 'output/development' / ('public-bounded-symbol-ranking-v214-' + cohort)
    lock = json.loads((out / 'lock.json').read_text())
    env = os.environ | {'PYTHONPATH': str(Path(lock['engine_root']) / 'src'), 'PYTHONDONTWRITEBYTECODE': '1'}
    with (out / 'capture.log').open('w') as log:
        subprocess.run([str(w / '.venv-model-runtime/bin/python'), 'experiments/search-engine/public_default_mcp_run.py',
                        '--lock', str(out / 'lock.json'), '--output', str(out / 'capture')],
                       cwd=w, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    telemetry = list((out / 'capture').glob('*/server-telemetry.json'))
    assert len(telemetry) == 8
    for path in telemetry:
        assert json.loads(path.read_text())['max_tokens'] == 1024
    print(json.dumps({'cohort': cohort, 'all200closed_without_grading': True, 'actual_max_tokens': 1024}), flush=True)
