"""Verify production source inputs/requirements against closed213, no Gold."""
from pathlib import Path
import hashlib
import json
import sys
from tokenizers import Tokenizer

sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from requested_test_piece import requests_test_case
from explicit_code_terms import explicit_code_terms
from ken.retrieval.best_resources import default_resources
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog
from ken.retrieval.source_operations import OperationWitnesses
from ken.retrieval.symbol_ranking import complete_code_view
from ken.retrieval.symbol_requirements import requirements, is_test_case, prefer_operations, prefer_explicit_code_terms


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
root = w / 'output/development/bounded-operation-policies-v213'
reg = json.loads((root / 'registration.json').read_text())
assert reg['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
for name in ['predictions', 'witnesses', 'budgets']:
    assert sha(root / (name + '.jsonl')) == reg[name + '_sha256']
predictions = {row['id']: row for row in rows(root / 'predictions.jsonl')}
evidence = {row['id']: row for row in rows(root / 'witnesses.jsonl')}
budgets = {(row['id'], json.dumps(row['unit'], sort_keys=True)): row for row in rows(root / 'budgets.jsonl')}
scores = {row['id']: row for row in rows(w / 'output/development/current-symbol-scores-v207/scores.jsonl')}
views = {row['id']: row for repo in (w / 'output/development/current-executable-view-v209').iterdir()
         if repo.is_dir() for row in rows(repo / 'observations.jsonl')}
out = w / 'output/analysis/symbol-product-parity-v214'
out.mkdir(exist_ok=False)
source = Path('/Users/andres/.codex/worktrees/compact-default-output/ken/src')
before = {str(path.relative_to(source)): sha(path) for path in source.rglob('*.py')}
assets = default_resources().neural._prepare()
assets.verify()
tokenizer = Tokenizer.from_file(str(assets.tokenizer))
tokenizer.no_padding()
tokenizer.no_truncation()
checks = []
for repo in sorted({row['repo_id'] for row in predictions.values()}):
    selected = [row for row in predictions.values() if row['repo_id'] == repo and row['id'] in evidence]
    paths = {unit['path'] for row in selected for unit in evidence[row['id']]['units']}
    project = Path('/private/tmp/ken-public-default-v143/repos') / repo
    with project_connection(project) as conn:
        catalog = SourceCatalog(project, {key: ps for key, ps in owner_passages(conn).items() if key.path in paths})
        operations = OperationWitnesses(catalog)
        for row in selected:
            qid = row['id']
            prior = evidence[qid]
            request = SearchRequest(prior['query'])
            required = requirements(request)
            assert sorted(required.operations) == prior['requested'], qid
            assert required.test_case == requests_test_case(request.query), qid
            assert required.operators == explicit_code_terms(request.query), qid
            units = prior['units']
            code, facts, descriptions, entries = [], [], [], []
            scalar = scores[qid]['score_rows']
            for index, unit in enumerate(units):
                key = EntityKey(path=unit['path'], **unit['entity'])
                description = describe_owner(catalog.owners[key])
                descriptions.append(description)
                text = complete_code_view(description)
                used = text is not None and len(tokenizer.encode(request.query, text).ids) <= 1024
                old_budget = budgets[qid, json.dumps(unit, sort_keys=True)]
                assert used == old_budget['accepted_complete_code_view'], (qid, key)
                if used:
                    assert text == views[qid]['texts'][index], (qid, key)
                code.append(views[qid]['executable_scores'][index] if used else scalar[index]['neural_score'])
                observed = operations.for_owner(key)
                assert sorted(observed) == prior['observed'][index], (qid, key, observed, prior['observed'][index])
                facts.append(observed)
                entries.append(is_test_case(key, catalog))
            mean = [(record['neural_score']+extra)/2 for record, extra in zip(scalar, code, strict=True)]
            order = sorted(range(len(units)), key=lambda i: (-mean[i], scalar[i]['native_rank']))
            order = prefer_operations(required.operations, facts, order)
            if required.test_case:
                order.sort(key=lambda i: not entries[i])
            order = prefer_explicit_code_terms(request.query, [d.fields['executable'] for d in descriptions], order)
            named = requested_piece_path(request)
            if named:
                order.sort(key=lambda i: units[i]['path'] != named)
            assert [units[i] for i in order] == row['orders']['two_views_all_relations'], qid
            checks.append({'id': qid, 'units': len(units), 'input_requirements_witness_order_parity': True})
assert len(checks) == 128 and sum(row['units'] for row in checks) == 1280
assert before == {str(path.relative_to(source)): sha(path) for path in source.rglob('*.py')}
origins = {}
for name, module in tuple(sys.modules.items()):
    if (name == 'ken' or name.startswith('ken.')) and getattr(module, '__file__', None):
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(source), (name, path)
        origins[name] = sha(path)
(out / 'summary.json').write_text(json.dumps({'status': 'ALL1280source inputs requirements witnesses and128orders MATCH213',
    'source_py_sha256': before, 'producer_sha256': sha(Path(__file__)), 'checks': checks,
    'graph_sha256': assets.graph_sha256, 'tokenizer_sha256': assets.tokenizer_sha256, 'origins': origins,
    'not_fresh_neural_inference': True, 'not_end_to_end': True, 'reserve': 'CLOSED'}, indent=2))
print(json.dumps({'queries': len(checks), 'units': 1280, 'matches213': True}))
