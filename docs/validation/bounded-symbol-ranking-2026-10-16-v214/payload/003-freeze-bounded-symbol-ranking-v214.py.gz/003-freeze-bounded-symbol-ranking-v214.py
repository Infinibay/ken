"""Freeze only the ranking candidate; install/instruction work follows separately."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
clean = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
origin = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clean, text=True).strip()
assert origin == 'da41525c5e059662e3e52744dac11c4f3c12e1b5'
changed = set(subprocess.check_output(['git', 'diff', '--name-only', '--', 'src'], cwd=clean, text=True).splitlines())
assert changed == {'src/ken/retrieval/neural_reranker.py', 'src/ken/retrieval/piece_search.py'}
new_source = ['src/ken/retrieval/' + name + '.py' for name in ['source_operations', 'symbol_requirements', 'symbol_ranking']]
baseline = w / 'output/frozen/requested-test-role-v201'
for path in (baseline / 'src').rglob('*'):
    relative = path.relative_to(baseline).as_posix()
    if path.is_file() and relative not in changed:
        assert path.read_bytes() == (clean / relative).read_bytes(), relative
parity = w / 'output/analysis/symbol-product-parity-v214/summary.json'
proof = json.loads(parity.read_text())
assert proof['status'] == 'ALL1280source inputs requirements witnesses and128orders MATCH213'
assert proof['source_py_sha256'] == {str(path.relative_to(clean / 'src')): sha(path) for path in (clean / 'src').rglob('*.py')}
assert 'Success: no issues found in 360 source files' in Path('/private/tmp/ken-symbol-ranking-v214-mypy-final.log').read_text()
test_log = Path('/private/tmp/ken-symbol-ranking-v214-green-r2.log').read_text()
assert '[100%]' in test_log and 'FAILED' not in test_log and 'ERROR' not in test_log and test_log.count('.') == 37
frozen = w / 'output/frozen/bounded-symbol-ranking-v214'
frozen.mkdir(exist_ok=False)
shutil.copytree(clean / 'src', frozen / 'src', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
shutil.copyfile(clean / 'pyproject.toml', frozen / 'pyproject.toml')
patch = subprocess.check_output(['git', 'diff', '--', 'src'], cwd=clean)
for name in new_source:
    lines = (clean / name).read_text().splitlines(keepends=True)
    diff = ''.join(difflib.unified_diff([], lines, fromfile='/dev/null', tofile='b/' + name))
    patch += (f'diff --git a/{name} b/{name}\nnew file mode 100644\n' + diff).encode()
files = {path.relative_to(frozen).as_posix(): sha(path) for path in sorted(frozen.rglob('*')) if path.is_file()}
receipt = {'origin_commit': origin, 'source_state': 'Bounded equal-mean source view and explicit relation/test/operator preferences for nonexact symbols ONLY; current models1024/native pools/index/output unchanged',
    'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'files': files,
    'tree_sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
    'test_files': {name: sha(clean / name) for name in ['tests/retrieval/test_symbol_ranking.py', 'tests/retrieval/test_source_operations.py']},
    'verification': {str(path): sha(path) for path in [parity, Path('/private/tmp/ken-symbol-ranking-v214-green-r2.log'), Path('/private/tmp/ken-symbol-ranking-v214-mypy-final.log')]},
    'full_suite': 'Required separately before capture/promote; still running when this immutable source freeze was created'}
(frozen / 'SOURCE-MANIFEST.json').write_text(json.dumps(receipt, indent=2) + '\n')
digest = sha(frozen / 'SOURCE-MANIFEST.json')
producer = w / 'experiments/search-engine/public_default_mcp_run.py'
for cohort in ['original', 'symbols']:
    previous = w / 'output/development' / ('public-requested-test-role-v201-' + cohort) / 'lock.json'
    lock = json.loads(previous.read_text())
    assert sha(producer) == lock['producer_sha256']
    lock.update(scope='Actual normal MCP200 bounded-symbol ranking; fixed120English+80retained; >=108EnglishEACH,118/119Recall10. Exposeddevelopment only/reserveCLOSED/no fitting.', engine_root=str(frozen), source_receipt=digest)
    lock['variant_policy'].update(engine_root=str(frozen), source_receipt=digest, source_commit=origin, source_state=receipt['source_state'])
    out = w / 'output/development' / ('public-bounded-symbol-ranking-v214-' + cohort)
    out.mkdir(exist_ok=False)
    (out / 'lock.json').write_text(json.dumps(lock, indent=2) + '\n')
    (out / 'SOURCE-WORKTREE.patch').write_bytes(patch)
driver = w / 'output/analysis/run-bounded-symbol-ranking-v214.py'
assert not driver.exists()
driver.write_text((w / 'output/analysis/run-requested-test-role-v201.py').read_text().replace('public-requested-test-role-v201-', 'public-bounded-symbol-ranking-v214-'))
print(json.dumps({'files': len(files), 'source_receipt': digest, 'all400beforeGold': True, 'full_suite_required_before_capture': True}))
