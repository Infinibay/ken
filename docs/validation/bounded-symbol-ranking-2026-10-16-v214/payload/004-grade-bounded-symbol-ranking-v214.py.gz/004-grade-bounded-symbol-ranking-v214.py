"""Grade actual intent201 outputs after BOTH closures, with fixed exposed strict references."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from verifiable_grading import identity_hit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def canonical(unit):
    return json.dumps(unit, sort_keys=True)


w = Path.cwd()
out = w / 'output/development/public-bounded-symbol-ranking-grade-v214'
cases, answers, timings, processes, pins = {}, {}, [], [], {}
pool_changes = []
for cohort in ['original', 'symbols']:
    root = w / 'output/development' / ('public-bounded-symbol-ranking-v214-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status'] and reg['lock_sha256'] == sha(root / 'lock.json')
    pins[str(root / 'capture/registration.json')] = sha(root / 'capture/registration.json')
    cohort_name = 'original200' if cohort == 'original' else 'new_symbol200'
    public = rows(Path(lock['public_cases']))
    assert len(public) == 200 and not any('acceptable_units' in row for row in public)
    for case in public:
        assert case['id'] not in cases
        cases[case['id']] = case | {'cohort': cohort_name}
    for repo, files in reg['closed'].items():
        for name, digest in files.items():
            assert sha(root / 'capture' / repo / name) == digest
        telemetry = json.loads((root / 'capture' / repo / 'server-telemetry.json').read_text())
        assert telemetry['max_tokens'] == 1024
        assert telemetry['providers'] == telemetry['context_providers'] == ['CPUExecutionProvider']
        assert not telemetry['heavy_imports']
        current = rows(root / 'capture' / repo / 'answers.jsonl')
        baseline = {row['id']: row for row in rows(w / 'output/development' /
                    ('public-requested-test-role-v201-' + cohort) / 'capture' / repo / 'answers.jsonl')}
        for answer in current:
            query_id = answer['id']
            assert query_id not in answers and query_id in baseline
            if sorted(map(canonical, answer['units'])) != sorted(map(canonical, baseline[query_id]['units'])):
                raise AssertionError(('native pool changed', query_id))
            answers[query_id] = answer
        performance = json.loads((root / 'capture' / repo / 'performance.json').read_text())
        processes.append({'cohort': cohort_name, 'repo_id': repo, 'performance': performance})
        timings.extend(row | {'cohort': cohort_name, 'repo_id': repo} for row in performance['timings'])
assert len(cases) == len(answers) == len(timings) == 400 and set(cases) == set(answers)
replay_root = w / 'output/development/bounded-operation-policies-v213'
replay_reg = json.loads((replay_root / 'registration.json').read_text())
assert sha(replay_root / 'predictions.jsonl') == replay_reg['predictions_sha256']
replay = {row['id']: row for row in rows(replay_root / 'predictions.jsonl')}
assert len(replay) == 240
for query_id, closed in replay.items():
    assert answers[query_id]['units'] == closed['orders']['two_views_all_relations'], ('actual MCP mismatch vs213', query_id)

out.mkdir(exist_ok=False)
registration = {'scope': 'Actual normalMCP400bounded-symbol214; source425files; unchanged201native pools all400 and exact213English240orders verified BEFORE exposedGold. Reserve CLOSED, development not blind acceptance.',
                'producer_sha256': sha(Path(__file__)), 'capture_pins': pins,
                'status': 'ALL400source/CPU checks passed BEFORE exposed Gold', 'pool_changes':pool_changes, 'reserve': 'CLOSED'}
(out / 'registration.json').write_text(json.dumps(registration, indent=2))
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        path = Path(name)
        assert sha(path) == digest
        gold.update({row['id']: row for row in rows(path)})
assert set(gold) == set(cases)
outcomes = []
for query_id, case in cases.items():
    units = answers[query_id]['units']
    hit = lambda unit: bool(identity_hit({'unit': unit}, gold[query_id]['acceptable_units']))
    outcomes.append({name: case[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} |
                    {'top1': bool(units and hit(units[0])), 'recall10': any(map(hit, units))})
(out / 'outcomes.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in outcomes))
summary = {'all': {}, 'english': {}}
for name, selected in [('all', outcomes), ('english', [row for row in outcomes if row['language'] == 'en'])]:
    for dimension in ['cohort', 'target_kind', 'repo_id']:
        counts = defaultdict(lambda: {'n': 0, 'top1': 0, 'recall10': 0})
        for row in selected:
            count = counts[row[dimension]]
            count['n'] += 1
            count['top1'] += row['top1']
            count['recall10'] += row['recall10']
        summary[name][dimension] = dict(counts)
summary['recall_preserved'] = (all(summary['all']['cohort'][cohort]['recall10'] >= threshold for cohort, threshold in [('original200',197),('new_symbol200',195)]) and all(summary['english']['cohort'][cohort]['recall10'] >= threshold for cohort, threshold in [('original200',118),('new_symbol200',119)]))
summary['pool_changes'] = pool_changes
assert all(row['n'] == 120 for row in summary['english']['cohort'].values())
summary['english_goal_reached'] = all(row['top1'] >= 108 for row in summary['english']['cohort'].values())
summary['bounded_symbol_quality_check'] = summary['english_goal_reached'] and summary['recall_preserved'] and not pool_changes
summary['actual_english_order_parity_with_closed213'] = True
assert summary['bounded_symbol_quality_check']
costs = {}
for subset in ['all', 'english']:
    selected = [row for row in timings if subset == 'all' or cases[row['id']]['language'] == 'en']
    values = [row['ms'] for row in selected]
    costs[subset] = {'n': len(values), 'p50_ms': float(np.percentile(values, 50)),
                     'p95_ms': float(np.percentile(values, 95)), 'max_ms': max(values)}
costs['processes'] = []
for process in processes:
    data = process['performance']
    values = [row['ms'] for row in data['timings'] if cases[row['id']]['language'] == 'en']
    costs['processes'].append({'cohort': process['cohort'], 'repo_id': process['repo_id'],
        'indexed_files': data['indexed_files'], 'peak_rss_bytes': data['peak_rss_native'] * (1024 if data['rss_unit'] == 'KiB' else 1),
        'warmup_ms': data['warmup_ms'], 'cpu_total_ms': data['server_cpu_total_ms'],
        'english_p50_ms': float(np.percentile(values, 50)), 'english_p95_ms': float(np.percentile(values, 95))})
costs['peak_rss_bytes'] = max(process['peak_rss_bytes'] for process in costs['processes'])
costs['scope'] = 'ACTUAL complete MCP latency; prepared index and explicit separate warmup, all calls/outliers retained. RSSwhole server; CPUtotal includes process warmup.'
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
(out / 'costs.json').write_text(json.dumps(costs, indent=2))
registration['status'] = 'ALL400actualMCPbounded214 graded; English120each; reserve CLOSED'
(out / 'registration.json').write_text(json.dumps(registration, indent=2))
print(json.dumps({'all': summary['all']['cohort'], 'english': summary['english']['cohort'],
                  'english_goal_reached': summary['english_goal_reached'],
                  'bounded_symbol_quality_check': summary['bounded_symbol_quality_check'],
                  'costs': {name: costs[name] for name in ['all', 'english', 'peak_rss_bytes']}}), flush=True)
