"""Explain current English errors using authenticated numeric observations."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from ken.retrieval.best_resources import load_rank_models
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def key(unit):
    return json.dumps({name: unit.get(name) for name in
                      ['target_kind', 'path', 'entity', 'module_name']}, sort_keys=True)


def public_unit(result):
    return {'target_kind': result['piece_kind'], 'path': result['path'],
            'entity': result['entity'], 'module_name': None}


w = Path.cwd()
focus = w / 'output/analysis/english-ranking-v196'
selection = json.loads((focus / 'registration.json').read_text())
cases_path = Path(selection['cohorts']['symbols']['english_cases'])
assert sha(cases_path) == selection['cohorts']['symbols']['sha256']
cases = {row['id']: row for row in rows(cases_path)}
misses = {row['id']: row for row in json.loads((focus / 'current-english-misses.json').read_text())['misses']}
out = focus / 'numeric-audit'
out.mkdir(exist_ok=False)
model, _ = load_rank_models()
historic_root = w / 'output/development/native-symbol-evidence-v152'
historic_reg = json.loads((historic_root / 'registration.json').read_text())
assert historic_reg['status'] == 'ALL250native source observations closed without Gold'
current_root = w / 'output/development/token-budget-v193'
current_reg = json.loads((current_root / 'registration.json').read_text())
assert current_reg['status'] == 'ALL250token-budget observations closed without Gold'
native_root = w / 'output/development/code-domain-capture-v189'
native_reg = json.loads((native_root / 'registration.json').read_text())
assert native_reg['status'] == 'ALL400 fixed A186 predictions closed BEFORE grading'
observed = {}
comparisons = []
score_checks = []
for repo, pins in historic_reg['closed'].items():
    for name, digest in pins.items():
        assert sha(historic_root / repo / name) == digest
    historical = {row['id']: row for row in rows(historic_root / repo / 'observations.jsonl')}
    data = np.load(historic_root / repo / 'features.npz', allow_pickle=False)
    assert tuple(data['features']) == model.features and len(model.features) == 251
    assert sha(current_root / repo / 'observations.jsonl') == current_reg['closed'][repo]['observations.jsonl']
    current = {row['id']: row for row in rows(current_root / repo / 'observations.jsonl')}
    assert sha(native_root / repo / 'observations.jsonl') == native_reg['closed'][repo]['observations.jsonl']
    native = {row['id']: row for row in rows(native_root / repo / 'observations.jsonl')}
    for query_id in cases.keys() & current.keys():
        record = current[query_id]
        if record['exact_bypass']:
            observed[query_id] = {'exact_bypass': True}
            continue
        units = record['units']
        native_results = native[query_id]['public_response']['results']
        rank = {key(public_unit(result)): result['signals']['piece_rank'] for result in native_results}
        scores = {key(public_unit(result)): result['signals']['piece_score'] for result in native_results}
        assert set(rank) == set(map(key, units))
        indices = sorted(range(len(units)), key=lambda index: rank[key(units[index])])
        assert [rank[key(units[index])] for index in indices] == list(range(1, len(units) + 1))
        raw = record['modes']['original_1024']['scores']
        neural_order = sorted(indices, key=lambda index: (-raw[index], rank[key(units[index])]))
        neural_rank = {index: place for place, index in enumerate(neural_order, 1)}
        fusion = {index: .5 / (60 + rank[key(units[index])]) + .5 / (60 + neural_rank[index])
                  for index in indices}
        recomposed = sorted(indices, key=lambda index: (-fusion[index], rank[key(units[index])]))
        named = requested_piece_path(SearchRequest(record['query']))
        if named:
            recomposed.sort(key=lambda index: units[index]['path'] != named)
        assert [units[index] for index in recomposed] == units, query_id
        old = historical[query_id]
        assert record['expanded_query'] == old['expanded_query']
        matrix = data['x'][data['qid'] == query_id]
        assert matrix.shape == (len(old['units']), 251)
        assert np.array_equal(model.predict(matrix), old['native_scores']), query_id
        historical_indices = {key(unit): index for index, unit in enumerate(old['units'])}
        for unit in units:
            index = historical_indices[key(unit)]
            error = old['native_scores'][index] - scores[key(unit)]
            assert error == 0., (query_id, unit, error)
            score_checks.append(error)
        observed[query_id] = {'exact_bypass': False, 'native_order': [units[index] for index in indices]}
        if query_id not in misses:
            continue
        miss = misses[query_id]
        correct = miss['acceptable_present'] or miss['expected'][0]
        current_correct = next((index for index, unit in enumerate(units) if key(unit) == key(correct)), None)
        wrong = units[0]
        left = historical_indices[key(wrong)]
        right = historical_indices.get(key(correct))
        tree = model.explain_pair(matrix[left], matrix[right]) if right is not None else None
        result = {
            'id': query_id, 'query': record['query'], 'repo_id': repo,
            'category': miss['category'], 'wrong': wrong, 'correct': correct,
            'winner': {'native_rank': rank[key(wrong)], 'native_score': scores[key(wrong)],
                       'neural_rank': neural_rank[0], 'neural_score': raw[0], 'fusion_score': fusion[0]},
            'correct_in_current_top10': current_correct is not None,
            'correct_values': None if current_correct is None else {
                'native_rank': rank[key(units[current_correct])], 'native_score': scores[key(units[current_correct])],
                'neural_rank': neural_rank[current_correct], 'neural_score': raw[current_correct],
                'fusion_score': fusion[current_correct]},
            'fusion_exact_tie': current_correct is not None and fusion[0] == fusion[current_correct],
            'feature_names': list(model.features), 'wrong_features': matrix[left].tolist(),
            'correct_features': None if right is None else matrix[right].tolist(),
            'numeric_forest_explanation': tree,
            'historical_vector_limit': 'v152 source145 vectors, reproduced bit-exact with CURRENT bundled model and ALL current native top10 scores; same expanded query. Not a fresh vector recapture.',
        }
        (out / (query_id + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2))
        summary = {name: result[name] for name in ['id', 'category', 'winner', 'correct_values', 'fusion_exact_tie']}
        comparisons.append(summary)
        print(json.dumps(summary), flush=True)
assert set(observed) == set(cases) and len(comparisons) == 27
receipt = {'scope': 'English120 current172/D193 default1024symbol scores; EXPOSED diagnostic only',
           'producer_sha256': sha(__file__), 'selection_sha256': sha(focus / 'registration.json'),
           'model_fingerprint': model.fingerprint, 'feature_count': len(model.features),
           'queries': 120, 'exact_bypasses': sum(row['exact_bypass'] for row in observed.values()),
           'current_native_scores_compared': len(score_checks), 'max_score_difference': max(map(abs, score_checks)),
           'error_pairs': len(comparisons), 'fusion_exact_ties': sum(row['fusion_exact_tie'] for row in comparisons),
           'historical_vector_limitation': 'Explicit per-pair note; no unobserved claim that all historic feature inputs equal newly measured inputs.',
           'reserve': 'CLOSED', 'fit_or_model_changes': False, 'comparisons': comparisons}
(out / 'summary.json').write_text(json.dumps(receipt, indent=2))
