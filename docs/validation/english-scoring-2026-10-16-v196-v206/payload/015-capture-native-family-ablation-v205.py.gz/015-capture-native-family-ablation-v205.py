"""Diagnostic forest ablations, never a claim that zeroed features are deployable."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from ken.retrieval.best_resources import load_rank_models
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest
from ken.retrieval.reranker_fusion import fused_reranker_order


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
trace = w / 'output/development/english-native-trace-v196'
reg = json.loads((trace / 'registration.json').read_text())
assert reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
baseline = w / 'output/development/score-fusion-v197'
base_reg = json.loads((baseline / 'registration.json').read_text())
assert sha(baseline / 'predictions.jsonl') == base_reg['predictions_sha256']
out = w / 'output/development/native-family-ablation-v205'
out.mkdir(exist_ok=False)
families = {'without_callable_kind': ['expanded_kind_function', 'expanded_kind_method'],
            'without_proposal_rrf': ['rrf', 'rrf_relative', 'rrf_rank']}
families['without_both'] = families['without_callable_kind'] + families['without_proposal_rrf']
protocol = {
    'scope': 'Exposed English240 fixed native195 top10, same NN1024 and source/model weights. Diagnostic only; reserve CLOSED.',
    'hypothesis': 'Fresh tree paths repeatedly distinguish generic callable kind and original proposal rank, even when the question seeks behavior equally implementable by a function or method. RRF also reuses the resulting order. Measure source evidence left when these families are absent.',
    'families': families, 'variants': ['current_rrf'] + [family + '_' + policy for family in families for policy in ['native', 'rrf']],
    'intervention': 'Set ONLY the declared columns to zero across the fixed10 candidates, recompute same forest; stable source order ties. Reorder existing candidates natively or via unchanged rank fusion with identical published NN logits. No fitted threshold/weight, per-query labels or policy selection.',
    'limitation': 'Zero intervention can be outside training distribution; a positive result requires a redesigned/trained ranking contract, not silently corrupting observed features. Native candidate pool is held fixed, so this is not a normal full engine run.',
    'acceptance': '>=108/120EACH remains goal, fixed118/119Recall10, fixed references. Report all controls, no oracle.',
    'producer_sha256': sha(Path(__file__)), 'trace_sha256': sha(trace / 'registration.json'),
    'status': 'Registered BEFORE predictions and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
model, _ = load_rank_models()
changes = {}
for repo, pins in reg['closed'].items():
    for name, digest in pins.items():
        assert sha(trace / repo / name) == digest
    data = np.load(trace / repo / 'features.npz', allow_pickle=False)
    assert tuple(data['features']) == model.features
    for record in rows(trace / repo / 'observations.jsonl'):
        if record['exact_bypass']:
            continue
        matrix = data['x'][data['qid'] == record['id']][:10]
        assert np.array_equal(model.predict(matrix), record['native_scores'][:10])
        units = record['units'][:10]
        orders = {}
        for family, names in families.items():
            changed = matrix.copy()
            changed[:, [model.features.index(name) for name in names]] = 0.
            scores = model.predict(changed)
            native = sorted(range(len(units)), key=lambda i: (-record['exact'][i], -scores[i], i))
            neural = [record['native10_neural_scores'][i] for i in native]
            orders[family + '_native'] = native
            orders[family + '_rrf'] = [native[i] for i in fused_reranker_order(neural)]
        named = requested_piece_path(SearchRequest(record['query']))
        for name, order in orders.items():
            if named:
                order.sort(key=lambda i: units[i]['path'] != named)
            orders[name] = [units[i] for i in order]
        changes[record['id']] = orders
predictions = []
for row in rows(baseline / 'predictions.jsonl'):
    current = row['orders']['current_rrf']
    orders = {name: current for name in protocol['variants']} | changes.get(row['id'], {})
    canonical = lambda unit: json.dumps(unit, sort_keys=True)
    assert all(sorted(map(canonical, result)) == sorted(map(canonical, current)) for result in orders.values())
    predictions.append({key: value for key, value in row.items() if key != 'orders'} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold', predictions_sha256=sha(out / 'predictions.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants']}))
