"""Explain ordinal fusion from closed recent scalar scores, no old vectors."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def key(unit):
    return json.dumps({name: unit.get(name) for name in
                      ['target_kind', 'path', 'entity', 'module_name']}, sort_keys=True)


w = Path.cwd()
focus = w / 'output/analysis/english-ranking-v196'
scope = json.loads((focus / 'registration.json').read_text())
cases = Path(scope['cohorts']['symbols']['english_cases'])
assert sha(cases) == scope['cohorts']['symbols']['sha256']
cases = {row['id']: row for row in rows(cases)}
misses = json.loads((focus / 'current-english-misses.json').read_text())['misses']
prior = w / 'output/development/token-budget-v193'
prior_reg = json.loads((prior / 'registration.json').read_text())
native = w / 'output/development/code-domain-capture-v189'
native_reg = json.loads((native / 'registration.json').read_text())
observations, native_values = {}, {}
for repo, pins in prior_reg['closed'].items():
    assert sha(prior / repo / 'observations.jsonl') == pins['observations.jsonl']
    assert sha(native / repo / 'observations.jsonl') == native_reg['closed'][repo]['observations.jsonl']
    observations.update({row['id']: row for row in rows(prior / repo / 'observations.jsonl')})
    for row in rows(native / repo / 'observations.jsonl'):
        native_values[row['id']] = {
            key({'target_kind': result['piece_kind'], 'path': result['path'],
                 'entity': result['entity'], 'module_name': None}): result['signals']
            for result in row['public_response']['results'] if 'signals' in result}
result = []
for miss in misses:
    query_id = miss['id']
    old = observations[query_id]
    assert not old['exact_bypass'] and cases[query_id]['language'] == 'en'
    units = old['units']
    values = native_values[query_id]
    indices = sorted(range(len(units)), key=lambda index: values[key(units[index])]['piece_rank'])
    raw = old['modes']['original_1024']['scores']
    neural = sorted(indices, key=lambda index: (-raw[index], values[key(units[index])]['piece_rank']))
    neural_rank = {index: rank for rank, index in enumerate(neural, 1)}

    def describe(index):
        scalar = values[key(units[index])]
        native_term = .5 / (60 + scalar['piece_rank'])
        neural_term = .5 / (60 + neural_rank[index])
        return {'unit': units[index], 'native_rank': scalar['piece_rank'],
                'native_score': scalar['piece_score'], 'neural_rank': neural_rank[index],
                'neural_logit': raw[index], 'rrf_native': native_term,
                'rrf_neural': neural_term, 'rrf_total': native_term + neural_term}

    winner = describe(0)
    target = miss['acceptable_present']
    index = next((i for i, unit in enumerate(units) if target is not None and key(unit) == key(target)), None)
    correct = describe(index) if index is not None else None
    if correct is None:
        cause = 'not_in_native_top10'
    elif winner['rrf_total'] == correct['rrf_total']:
        cause = 'equal_rrf_native_order_breaks_tie'
    else:
        assert winner['rrf_total'] > correct['rrf_total'], query_id
        cause = 'greater_sum_of_reciprocal_ranks'
    row = {'id': query_id, 'query': old['query'], 'category': miss['category'],
           'winner': winner, 'correct': correct, 'ordinal_reason': cause,
           'lost_neural_top1': correct is not None and correct['neural_rank'] == 1,
           'native_margin_wrong_minus_correct': None if correct is None else winner['native_score'] - correct['native_score'],
           'neural_margin_correct_minus_wrong': None if correct is None else correct['neural_logit'] - winner['neural_logit']}
    result.append(row)
    if row['lost_neural_top1']:
        print(json.dumps(row), flush=True)
assert len(result) == 27 and sum(row['lost_neural_top1'] for row in result) == 13
summary = {'scope': 'English current172/A189 scalars+D1931024source, exposed diagnostic, no vector attribution',
           'producer_sha256': sha(Path(__file__)), 'english_scope_sha256': sha(focus / 'registration.json'),
           'counts': dict(Counter(row['ordinal_reason'] for row in result)),
           'lost13_counts': dict(Counter(row['ordinal_reason'] for row in result if row['lost_neural_top1'])),
           'score_note': 'Native numeric scores and neural logits are not calibrated probabilities; RRF uses only ranks and discards margin sizes.',
           'all_pairs': result}
(focus / 'current-fusion-math.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'all_pairs'}), flush=True)
