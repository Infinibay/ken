# Revisión independiente de traducción v194

Leí las **80 parejas** completas, sin seleccionar fallos. SHA del input verificado: `45b584ff7127c351a4f966135a76156c9b6156a582cdf16c2438931c257ca461`.

| Clasificación | Cantidad |
|---|---:|
| fiel | 27 |
| pérdida menor | 20 |
| cambio material | 15 |
| no traducida | 18 |

«Fiel» conserva las condiciones sustantivas aunque tenga gramática torpe. «Pérdida menor» debilita un término pero mantiene la lógica principal. «Cambio material» pierde o cambia una operación, condición o rol expreso. «No traducida» significa que el texto español quedó idéntico; las 18 de esta categoría conservan sus locators calificados, por lo que no se contabilizan como cambios materiales.

Cada fila del JSON contiene original y expanded completos, citas literales de ambos, fundamento individual y dimensiones afectadas. Se revisaron negación, precedencia, condiciones, cuantificadores, rol, valores e identificadores en todas las parejas.

## Cambios materiales

| ID | Original → expanded | Motivo |
|---|---|---|
| symdev-20261016-119 | «deduplicando URLs por URI antes de advertir» → «duplicating URLs by URI before warning» | Invierte la operación de deduplicación en duplicación. Primero/antes, varias ubicaciones y null si no hay resultados se conservan, pero una condición central ahora pide otra operación. |
| symdev-20261016-116 | «quita todos los guiones bajos del texto antes de convertirlo» → «removes all the bass scripts from the text before converting it» | Bass scripts no nombra los guiones bajos/underscores. Se conservan todos, antes de convertir, registro por tipo y error de ausencia; el objeto concreto que debe eliminarse queda perdido. |
| symdev-20261016-197 | «un carácter Unicode suplementario en UTF-8» → «an additional Unicode character in UTF-8» | Suplementario nombra una categoría Unicode concreta; additional sólo dice que hay otro carácter. Se pierden las restricciones de ese carácter, aunque UTF-8, bytes frente a unidades char y último char permanezcan. |
| symdev-20261016-177 | «en ambos órdenes de decorado» → «on both sets commands» | La condición de ensayar ambos órdenes de aplicación de decoradores desaparece en una frase sin ese significado. total_ordering, detección automática y métodos del usuario sí permanecen. |
| symdev-20261016-063 | «distinguiendo conjuntos dinámicos de estáticos» → «distinguishing dynamic static sets» | La oposición entre conjuntos dinámicos y estáticos pierde el enlace y pasa a dynamic static sets, categoría compuesta incoherente. Permanecen propiedades pendientes, marcar todas al terminar y comparación final/inicial de errores. |
| symdev-20261016-188 | «se marcan los que difieren al parsear con GFM sin modo pedante» → «are those that differ when parsing with GFM without pedantic mode» | Desaparece la operación de marcar ejemplos que difieren: la oración inglesa sólo deja are those that differ. Sí conserva origen GFM/extensiones, sin modo pedante y guardado JSON versionado. |
| symdev-20261016-032 | «desenvolviendo staticmethod y classmethod para guardar la marca pero devolviendo el descriptor original» → «developing staticmethod and classmethod to save the mark but returning the original descriptor» | Developing no conserva la operación de desenvolver/unwrap descriptores. Además class of accumulating degrada la distinción aplicar frente a acumular. Se mantienen nombres de descriptores y retorno del descriptor original. |
| symdev-20261016-065 | «considerar no evaluada una clave» → «consider not evaluating a key» | Cambia un estado de la clave (unevaluated) por una decisión de no evaluarla (not evaluating). Mantiene OR entre ausencia del mapa y entrada falsa, pero el significado del predicado ya no es equivalente. |
| symdev-20261016-174 | «asigna una cadena a un campo entero» → «assigns a string to an entire field» | Entero como tipo pasa a entire como totalidad del campo. Se pierde el requisito del tipo del campo, aunque ausencia de on_setattr, conversión, secuencia y entero bajo el umbral permanezcan. |
| symdev-20261016-111 | «se cachea la búsqueda de conversión por tipo probando primero fábricas y constructores String, después CharSequence y finalmente fábricas sin métodos deprecated» → «does the conversion search by type first search factories and String builders, then CharSequence and finally factories without pre-cated methods» | Omite el cacheo, cambia constructores por builders y destruye el criterio deprecated como pre-cated. Conserva orden String→CharSequence→última rama y marcador de ausencia, pero no todos los requisitos. |
| symdev-20261016-120 | «carga de propiedades desde una URL» → «uploading of properties from a URL» | Uploading cambia carga/lectura de propiedades desde una URL por subida, otra operación/dirección. Conserva desactivar caché y cerrar InputStream después de cargar. |
| symdev-20261016-161 | «la prueba de la moda» → «the fashion test» | Moda estadística se convierte en fashion. Conserva desempate por primer valor, datos categóricos no numéricos y defecto con datos vacíos, pero cambia el objeto explícito de la prueba. |
| symdev-20261016-026 | «empiezan con llaves, tilde o mayor, pero convierte los demás saltos en una secuencia de barra y n literal» → «start with keys, tilde or greater, but converts the other jumps into a bar sequence and n literal» | Llaves como delimitadores pasa a keys, y saltos/barra a jumps/bar, perdiendo marcadores literales y la distinción de saltos de línea. Conserva tilde, mayor y n, pero no una especificación fiel del formato. |
| symdev-20261016-175 | «clases de excepción generadas tanto por decorador como por fábrica» → «exceptional classes generated by both decorator and factory» | Exception classes cambia a exceptional classes, cualidad genérica que ya no exige clases de excepción. Conserva ambos mecanismos, instancias distintas con campos iguales y uso de str/args sólo para argumentos inicializables. |
| symdev-20261016-187 | «tras esperar el subproceso» → «after waiting for the thread» | Subproceso pasa a thread, entidad de ejecución diferente. La fábrica de prueba CLI real, tubería opcional, argumentos y comparación stdout/stderr se conservan, pero no la espera del subproceso. |

## Alcance y límites

No usé métricas léxicas para decidir la fidelidad ni consulté candidatos, scores, Gold, fuentes o modelos. Los controles automáticos verificaron únicamente hashes, integridad de los 80 IDs/orden y literalidad de citas. El registro autorizado declara reserva cerrada.

Esta es una revisión lingüística individual; no prueba equivalencia formal ni permite atribuir errores al ranking. No resuelve ambigüedades del original por inspección de código. Los fragmentos ingleses propuestos en el JSON son referencias de revisión: no se aplicaron al motor ni se cambió ninguna etiqueta o consulta.

Registro SHA256: `bc73b9b8b0cc32f473e4648dec067510796ae045e54859ffef236107ee04f673`. JSON SHA256: `3c9686550bbe26d56f1bf1aadb5dcec70d6e3e9a95044fa924abf107d55a5ac6`.
