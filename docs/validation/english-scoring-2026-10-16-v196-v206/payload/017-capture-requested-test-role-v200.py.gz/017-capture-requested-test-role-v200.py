"""Fixed-pool intent correction probe, with authentic source role and exact original scores."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from requested_test_source import requests_test_source
from score_fusion import score_fusion_order
from ken.retrieval.best_resources import load_rank_models
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.intent import interpret, requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.reranker_fusion import fused_reranker_order


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
trace = w / 'output/development/english-native-trace-v196'
reg = json.loads((trace / 'registration.json').read_text())
assert reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
closed = w / 'output/development/score-fusion-v197'
closed_reg = json.loads((closed / 'registration.json').read_text())
assert sha(closed / 'predictions.jsonl') == closed_reg['predictions_sha256']
cases = {}
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
for data in json.loads(scope_path.read_text())['cohorts'].values():
    path = Path(data['english_cases'])
    assert sha(path) == data['sha256']
    cases.update({row['id']: row for row in rows(path)})
out = w / 'output/development/requested-test-role-v200'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 fixed-pool intent correction probe, source195 and existing100owner traces. Reserve CLOSED. No source-code or models modified.',
    'hypothesis': 'Query requests test support or a passive tested object, but auto intent defaults to production and forest role_match strongly rewards production. Correct only source role and query_test features.',
    'variants': ['current_rrf', 'corrected_role_rrf', 'corrected_role_native', 'corrected_role_zmean'],
    'intervention': 'For symbols only, when original implementation intent becomes explicit tests according to fixed tested grammar: role_match actual passage role==test; expanded_query_test=1. All249otherfeatures fixed. Non-symbol and exact bypass unchanged. Same existing10 reordered; namedpath priority retained.',
    'acceptance': '>=108/120EACH, pools118/119. Full normal source pipeline recapture required before activation because upstream candidate pool could change.',
    'selection_sha256': sha(scope_path), 'trace_sha256': sha(trace / 'registration.json'),
    'helper_sha256': sha(w / 'experiments/search-engine/requested_test_source.py'),
    'producer_sha256': sha(Path(__file__)), 'status': 'Registered BEFORE orders and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
model, _ = load_rank_models()
feature_index = {name: index for index, name in enumerate(model.features)}
changed = {}
for repo, pins in reg['closed'].items():
    for name, digest in pins.items():
        assert sha(trace / repo / name) == digest
    data = np.load(trace / repo / 'features.npz', allow_pickle=False)
    assert tuple(data['features']) == model.features
    selected = [record for record in rows(trace / repo / 'observations.jsonl')
                if not record['exact_bypass'] and interpret(SearchRequest(record['query'])).purpose == 'implementation'
                and requests_test_source(record['query'])]
    if not selected:
        continue
    root = Path('/private/tmp/ken-public-default-v143/repos') / repo
    with project_connection(root) as connection:
        owners = owner_passages(connection)
        for record in selected:
            query_id = record['id']
            assert record['expanded_query'] == record['query']
            matrix = data['x'][data['qid'] == query_id][:10].copy()
            original = matrix.copy()
            assert np.array_equal(model.predict(original), record['native_scores'][:10])
            for index, unit in enumerate(record['units'][:10]):
                entity = EntityKey(path=unit['path'], **unit['entity'])
                passages = owners[entity]
                assert all(p.source_hash == record['source_hashes'][index] for p in passages)
                assert original[index, feature_index['role_match']] == float(passages[0].role == 'definition')
                matrix[index, feature_index['role_match']] = float(passages[0].role == 'test')
                matrix[index, feature_index['expanded_query_test']] = 1.
            changed[query_id] = (record, model.predict(matrix).tolist())
predictions, interventions = [], []
for baseline in rows(closed / 'predictions.jsonl'):
    query_id = baseline['id']
    units = baseline['orders']['current_rrf']
    orders = {name: units for name in protocol['variants']}
    if query_id in changed:
        record, native = changed[query_id]
        native_units = record['units'][:10]
        native_order = sorted(range(len(native)), key=lambda i: (-record['exact'][i], -native[i], i))
        neural = [record['native10_neural_scores'][i] for i in native_order]
        rrf = [native_order[i] for i in fused_reranker_order(neural)]
        standardized = [native_order[i] for i in score_fusion_order([native[i] for i in native_order], neural)]
        indices = {'corrected_role_rrf': rrf, 'corrected_role_native': native_order, 'corrected_role_zmean': standardized}
        named = requested_piece_path(SearchRequest(cases[query_id]['query']))
        for name, order in indices.items():
            if named:
                order.sort(key=lambda i: native_units[i]['path'] != named)
            orders[name] = [native_units[i] for i in order]
        interventions.append({'id': query_id, 'query': record['query'], 'native_before': record['native_scores'][:10],
                              'native_after': native, 'source_role_verified': True})
    canonical = lambda item: json.dumps(item, sort_keys=True)
    assert all(sorted(map(canonical, result)) == sorted(map(canonical, units)) for result in orders.values())
    predictions.append({key: value for key, value in baseline.items() if key != 'orders'} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
(out / 'interventions.json').write_text(json.dumps(interventions, indent=2))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold',
                predictions_sha256=sha(out / 'predictions.jsonl'), interventions_sha256=sha(out / 'interventions.json'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'changed_queries': len(changed), 'variants': protocol['variants']}))
