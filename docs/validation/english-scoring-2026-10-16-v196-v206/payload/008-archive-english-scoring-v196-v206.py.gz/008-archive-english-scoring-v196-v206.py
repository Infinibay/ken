"""Preserve closed English diagnostics plus the failed206guard; no sealed inputs."""
from pathlib import Path
import gzip
import hashlib
import json


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
out = w / 'output/analysis/english-scoring-export-v196-v206'
out.mkdir(exist_ok=False)
payload = out / 'payload'
payload.mkdir()
inputs = set()
directories = ['output/analysis/english-ranking-v196', 'output/development/english-native-trace-v196']
directories += ['output/development/' + name for name in [
    'score-fusion-v197', 'score-fusion-grade-v197', 'source-channel-controls-v199', 'source-channel-controls-grade-v199',
    'requested-test-role-v200', 'requested-test-role-grade-v200', 'explicit-code-operators-v202', 'explicit-code-operators-grade-v202',
    'requested-test-piece-v204', 'requested-test-piece-grade-v204', 'native-family-ablation-v205', 'native-family-ablation-grade-v205',
    'combined-symbol-policies-v206']]
for name in directories:
    path = w / name
    assert path.is_dir(), path
    inputs.update(p for p in path.rglob('*') if p.is_file())
for number, name in [(197, 'score-fusion'), (199, 'source-channel-controls'), (200, 'requested-test-role'),
                     (202, 'explicit-code-operators'), (204, 'requested-test-piece'), (205, 'native-family-ablation')]:
    reg = json.loads((w / f'output/development/{name}-v{number}/registration.json').read_text())
    assert reg['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
    assert sha(w / f'output/development/{name}-v{number}/predictions.jsonl') == reg['predictions_sha256']
assert json.loads((w / 'output/development/english-native-trace-v196/registration.json').read_text())['status'] == 'ALL150freshEnglishnative traces closed without Gold'
assert not (w / 'output/development/combined-symbol-policies-v206/predictions.jsonl').exists()
scripts = ['register-english-focus-v196.py', 'audit-english-fusion-v196.py', 'audit-current-fusion-math-v196.py',
           'capture-english-native-v196.py', 'audit-fresh-english-native-v198.py', 'code-domain-live-handoff-v189.json']
scripts += [prefix + name + f'-v{number}.py' for prefix in ['capture-', 'grade-'] for number, name in
            [(197, 'score-fusion'), (199, 'source-channel-controls'), (200, 'requested-test-role'),
             (202, 'explicit-code-operators'), (204, 'requested-test-piece'), (205, 'native-family-ablation')]]
scripts += ['capture-combined-symbol-policies-v206.py', 'english-reference-source-review-v203.json',
            'english-reference-source-review-v203.md', 'query-translation-review-v194.json', 'query-translation-review-v194.md']
inputs.update(w / 'output/analysis' / name for name in scripts)
helpers = ['score_fusion.py', 'test_score_fusion.py', 'requested_test_source.py', 'test_requested_test_source.py',
           'explicit_code_terms.py', 'test_explicit_code_terms.py', 'requested_test_piece.py', 'test_requested_test_piece.py']
inputs.update(w / 'experiments/search-engine' / name for name in helpers)
logs = ['ken-english-fusion-audit-v196.log', 'ken-current-fusion-math-v196.log', 'ken-english-native-trace-v196.log',
        'ken-fresh-native-audit-v198.log', 'ken-score-fusion-v197-red.log', 'ken-score-fusion-v197-green.log',
        'ken-test-source-intent-v200-red.log', 'ken-test-source-intent-v200-green.log', 'ken-requested-test-role-v200.log',
        'ken-explicit-code-terms-v202-red.log', 'ken-explicit-code-terms-v202-green.log', 'ken-explicit-code-operators-v202.log',
        'ken-requested-test-piece-v204-red.log', 'ken-requested-test-piece-v204-green.log', 'ken-requested-test-piece-v204-green-fixed.log',
        'ken-requested-test-piece-v204-java.log', 'ken-requested-test-piece-v204-capture.log',
        'ken-native-family-ablation-v205.log', 'ken-combined-symbol-policies-v206.log']
inputs.update(Path('/private/tmp') / name for name in logs)
inputs.add(Path(__file__))
records = []
for i, path in enumerate(sorted(inputs)):
    assert path.is_file(), path
    label = path.relative_to(w).as_posix() if path.is_relative_to(w) else 'verification/' + path.name
    data = path.read_bytes()
    target = payload / (f'{i:03d}-' + path.name + '.gz')
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    records.append({'source': label, 'source_sha256': sha(path), 'bytes': len(data),
                    'payload': target.name, 'payload_sha256': sha(target)})
manifest = {'scope': 'English exposed diagnostics196-205;206FAILEDbeforepredictions. No acceptance reserve, modelweights or benchmark-reference edits.',
            'files': records, 'failed_not_results': ['numeric-audit uses old152vectors and fails exactguard', '206normalMCP has no signals; KeyError'],
            'source195_receipt': 'da30f85d9d559663b6757ca4f9edebf0d323a2924c52bdc0a42a62e87a5291ef',
            'current201_receipt': 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5'}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
summaries = {}
for number, name in [(197, 'score-fusion'), (199, 'source-channel-controls'), (200, 'requested-test-role'),
                     (202, 'explicit-code-operators'), (204, 'requested-test-piece'), (205, 'native-family-ablation')]:
    summary = json.loads((w / f'output/development/{name}-grade-v{number}/summary.json').read_text())
    summaries[str(number)] = {key: {k: value[k] for k in ['cohorts', 'goal_reached']} for key, value in summary.items()}
(out / 'results.json').write_text(json.dumps(summaries, indent=2) + '\n')
for source, name in [(w / 'output/analysis/english-ranking-v196/fresh-numeric-audit-v198/summary.json', 'fresh-numeric-summary.json'),
                     (w / 'output/analysis/english-ranking-v196/current-fusion-math.json', 'fusion-math.json'),
                     (w / 'output/analysis/english-reference-source-review-v203.md', 'reference-review.md')]:
    (out / name).write_bytes(source.read_bytes())
(out / 'README.md').write_text('''# English scoring diagnostics196–206

The human narrowed the goal to English before these controls:120original and
120new queries, from fixed existing language metadata,>=108strict top1 in EACH
cohort. English Recall10 stays118/119. Exposed development is not independent
acceptance, and the reserve remains CLOSED. References were not changed.

Current production sourcecccea45b (intent201) measures113/95English top1 in
actual fullMCP. Source195before that correction measures113/93. All diagnostics
below, unless explicitly stated, use the unchanged195native10pools and original
published68M1024scores, never adapted weights. None reached108in the new cohort.

## Why the old audit was rejected

Old152feature vectors do not reproduce current native scores: query052
dynamicRef._callRef differs by0.002826042115771088. The failed exact check and
partial outputs are preserved. The guard was not weakened. Fresh196captured
150English symbols,128normal/22exact bypass, with all251native feature columns,
exact model predictions, exact current MCP orders and query/card-hash matching
before reuse of closed1024neural scores.198audits9800new-English rows and33
error-union cases:27RRF errors and20neural-only errors. Per-case payloads retain
all251values and every tree path/threshold/leaf difference for both candidates.
The trees group leaf deltas by first divergent split: interaction accounting,
not isolated causal feature importance or SHAP. These are195traces; six201intent
queries now have different native scores/pools and must not be labeled195data.

## Findings and isolated controls

RRF discards score margins. Six of27English final errors tie exactly and break
toward native order;20have a greater reciprocal-rank sum for the incorrect
candidate; one target is outside10. Fusion loses13neural top1 hits and gains6.
The six exact ties are among those13losses. Scores have different scales and
are not calibrated probabilities. Population-z equalmean improves new93to97,
but raw neural order already reaches100. Original113is retained by zmean.

Pure CodeRank implementation similarity reaches75new; contract59; mean68;
implementation+neural zmean94. Replacing the forest with one embedding channel
is not an improvement. Zeroing callable-kind or proposal-RRF families also
does not solve the problem: see all native/RRF outcomes in results.json. A large
local tree margin is not evidence that globally deleting that feature helps.
These ablations are diagnostics, not deployable feature corruption.

The200fixed-pool source-role probe gains2(113/95) but its initial grammar later
failed three existing production verb-test guards. Its helper remains research
only. The corrected201implementation is verified separately in actual400MCP
and committed with fullsuite/mypy/cost proof in requested-test-role201docs.

Explicit code operatorsAND/OR are dropped by normal stopword processing.202adds
a separate literal-operator preference without changing the index:113/94RRF,
110/101raw neural,113/98zmean. Only two queries trigger; ANDgains one. No pool
members are removed. This does not prove arbitrary behavioral constraints.

204distinguishes requested test entries from test helpers by canonical nesting
and conventional declaration evidence.9tests pass including a Java annotation
and a nested function namedtest. Results:113/95RRF,110/103neural,113/99zmean.
It does not claim a test runner will collect the declaration. All are isolated
replays: their gains cannot be added to201or202without a combined measurement.

206attempted that combination but correctly failed before producing predictions:
normal MCP responses do not contain debug signals. No scores were invented and
there is no206accuracy result. A next capture must authenticate reused card
scores and obtain actual debug scores for the six changed201queries first.

## Reference review and next information to investigate

203source review confirms the intended unique full matches in attrs172and
boltons156. In Ajv042, additionalItems.validateAdditionalItems AND
unevaluatedItems.code satisfy all literal conditions; the question omits the
distinguishing starting-position rule. This ambiguity is recorded separately;
fixed Gold and historical results remain intact. The reviewer disclosed an
accidental historic Ken snippet exposure for attrs, and no reserve was opened.

251term coverage is a bag of semantic maxima; it does not preserve argument
coupling, conditions or execution order. Attrs172needs kw_only=True AND
init=False on the SAME attribute, while the incorrect candidate assigns those
properties to different fields. Earlier lexical-scope cards expand descendants,
not enclosing object-literal metadata or cross-file imported type contracts.
Those are information hypotheses to test; no new effect is claimed here.
Generic clause/facet splitting was already tested and failed in181–184; do not
repeat it. W2original+docless code remains an earlier102/120English replay,
not an activated setting or a result that can be summed with new preferences.

Each compressed payload has compressed and original SHA256checks. manifest.json
maps each to its exact source path; restore into a separate research directory.
No reserve, modelweights, release, tag, version bump or PyPI publication.
''')
print(json.dumps({'files': len(records), 'payload_bytes': sum(p.stat().st_size for p in payload.iterdir()),
                  'manifest_sha256': sha(out / 'manifest.json')}))
