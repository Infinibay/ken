"""Record the user's explicit English-only scope without changing old reports."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

w = Path.cwd()
out = w / 'output/analysis/english-ranking-v196'
out.mkdir(exist_ok=False)
cohorts = {}
for name in ['original', 'symbols']:
    root = w / 'output/development' / ('public-qualified-locator-v172-' + name)
    lock = json.loads((root / 'lock.json').read_text())
    source = Path(lock['public_cases'])
    cases = [json.loads(line) for line in source.read_text().splitlines()]
    english = [case for case in cases if case['language'] == 'en']
    assert len(english) == 120
    path = out / (name + '-cases.jsonl')
    path.write_text(''.join(json.dumps(case, ensure_ascii=False) + '\n' for case in english))
    cohorts[name] = {
        'source_cases': str(source),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'english_cases': str(path),
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'n': 120, 'required_top1': 108,
        'baseline_recall10': 118 if name == 'original' else 119,
    }
registration = {
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'scope_change': 'EXPLICIT user request: focus>=90% strict top1 in English; other query languages deferred. Existing language metadata fixed before optimization. Not a retrospective claim of reaching90%.',
    'criterion': 'Same strict correct piece identity; >=108/120 EACH English cohort; preserve current pool membership and118/119English Recall10 (full197/195 remains same pools). Reserve CLOSED including public queries.',
    'cohorts': cohorts,
    'models': 'No further reranker training/model search. Improve Ken scoring/evidence and case-by-case explanations. Keep published68M; budget1024 requested.',
    'historical_baseline': {
        'English_original': {'public': 113, 'raw_symbols': 110, 'recall10': 118},
        'English_new': {'public': 93, 'raw_symbols': 100, 'scope_calls_raw': 101, 'W2_equalmean': 102, 'recall10': 119},
    },
    'all_reports_are_exposed_development': 'NOT independent acceptance; no reference/ID/query edits. Old all400 failures unchanged.',
}
(out / 'registration.json').write_text(json.dumps(registration, ensure_ascii=False, indent=2) + '\n')
new_ids = {row['id'] for row in map(json.loads, Path(cohorts['symbols']['english_cases']).read_text().splitlines())}
errors = json.loads((w / 'output/analysis/new200-errors-v181.json').read_text())
misses = [row for row in errors['misses'] if row['id'] in new_ids]
(out / 'current-english-misses.json').write_text(json.dumps({
    'scope': 'Current172 English only, exposed diagnostic, no source/label changes',
    'misses': misses,
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({
    'english120_public_misses': len(misses),
    'categories': dict(Counter(row['category'] for row in misses)),
    'fusion_lost_raw': sum(row['fusion_lost_raw_hit'] for row in misses),
}, ensure_ascii=False))

path = w / 'output/analysis/code-domain-live-handoff-v189.json'
handoff = json.loads(path.read_text())
handoff.update({
    'updated_utc': datetime.now(timezone.utc).isoformat(),
    'LATEST_USER_SCOPE': 'English>=90%top1 ONLY for now; all120ENoriginal and120ENnew fixed from existing language labels; require108each with118/119ENtop10. Spanish deferred. Original400reports unchanged; reserve CLOSED.',
    'english_contract': 'output/analysis/english-ranking-v196/registration.json',
    'english_baseline': 'Original113/120RRF110rawsymbols; new93RRF100raw101context102W2. Need108each. Do not claim90new.',
    'production': 'Installed wheel/source86faea unchanged512budget. CLEANsource uncommitted modifies ONLYneural_reranker.py,neural_assets.py andtest_neural_reranker.py todefault1024+param+declaredbounds;20runtime testsPASS. Fullsuite14967PASS10preexistingxfail521.96s, CLEANoriginsverified. Mypy session33960pending. No release.',
    'active_sessions': [33960],
    'main': '9311cedbe1e93b91f1e0b89c39c5af2c193fefad pushedorigin/main and safefforiginal63foreigntracked preserved. Cleanworktree has3own dirty files ONLY. 232payloadarchive6.5MB closed, manifest9c1bb04d4debc0c8038a4a9b0a8f0544e12ac671912e2f1d18cfb2524248c922.',
    'curation_agent': 'V194FINISHED80EStranslationreview15material,20minor,27faithful,18exactlocatorsunchanged. Spanish deferred byuser. DoNOTimplement bilingual196: no bilingual helper/protocol/capture was created.',
    'next': 'Finish1024default validation mypy+actualMCP400resource before integrate. Resume Ken English native scoring diagnostics: fresh native trace120ENnew including22exact bypass,98behavior; oldnative251matrices v152 exist but historical source145. Verify against currentnative scores/pools before reuse. Reportall251featurevaluesandtreebranchpaircomparisons on27Englishfinalerrors/20rawerrors (19recoverable,1absent). No rerankerweight changes/retraining.',
    'important_sources': {
        'native_capture_producer': 'output/analysis/capture-native-symbol-evidence-v152.py',
        'native250x100_arrays': 'output/development/native-symbol-evidence-v152/*/features.npz',
        'native_model_trace': 'src/ken/retrieval/ranking_trace.py RankingTrace.compare / NumericRanker.explain_pair',
        'symbol_policy': 'PieceReranker.rank bypasses piece forest for symbols; uses owner score. FinalRRF thenneural ranks. So audit owner251features, not piece262forest, for new English symbols.',
        'mcp400_queue': 'output/analysis/queue-qualified-locator-v172.py',
        'source_freeze': 'output/analysis/freeze-qualified-locator-v172.py',
    },
})
path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + '\n')
