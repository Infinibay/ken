from collections import defaultdict
from pathlib import Path
import pytest
from ken.parsers import detect_language
from ken.retrieval.model import EntityKey
from ken.retrieval.passages import extract_passages
from ken.retrieval.piece_catalog import SourceCatalog
from requested_test_piece import requests_test_case, is_test_case, prefer_requested_test_piece


@pytest.fixture
def catalog(tmp_path):
    path = 'tests/test_changes.py'
    source = b'''def test_change():
    def make_value():
        return 1
    def test_nested():
        return 2
    assert make_value() == 1

def make_expected():
    return 1

class TestChange:
    def test_value(self):
        assert True
'''
    (tmp_path / 'tests').mkdir()
    (tmp_path / path).write_bytes(source)
    language, parse = detect_language(Path(path))
    groups = defaultdict(list)
    for passage in extract_passages(source, parse(source, path), path=path, language=language):
        groups[passage.entity].append(passage)
    return SourceCatalog(tmp_path, groups)


@pytest.mark.parametrize('query', [
    'Which regression checks that a change succeeds?',
    'Find the change test that verifies the callback order.',
    'Where is a changed value tested with a custom comparator?',
])
def test_case_request_is_distinct_from_general_test_source(query):
    assert requests_test_case(query)


@pytest.mark.parametrize('query', [
    'Where does a change test helper build the expected value?',
    'Find a process-double factory used by the test process.',
    'Find the function that tests the input type.',
])
def test_support_and_production_requests_do_not_request_a_test_entry(query):
    assert not requests_test_case(query)


def test_test_entry_uses_canonical_nesting_instead_of_any_name_substring(catalog):
    keys = {key.qualname: key for key in catalog.owners}
    assert is_test_case(keys['test_change'], catalog)
    assert is_test_case(keys['TestChange.test_value'], catalog)
    assert not is_test_case(keys['test_change.make_value'], catalog)
    assert not is_test_case(keys['test_change.test_nested'], catalog)
    assert not is_test_case(keys['make_expected'], catalog)


def test_preference_preserves_membership_and_identity_and_applies_only_to_requested_kind(catalog):
    keys = {key.qualname: key for key in catalog.owners}
    selected = [keys['test_change.make_value'], keys['test_change'], keys['make_expected']]
    units = [{'target_kind': 'symbol', 'path': key.path, 'entity': key.to_dict(), 'module_name': None} for key in selected]
    assert prefer_requested_test_piece('Which regression checks the change?', units, catalog) == [1, 0, 2]
    assert prefer_requested_test_piece('Where does a change test helper construct a value?', units, catalog) == [0, 1, 2]
    assert prefer_requested_test_piece('Which regression checks the change?', units[:1], catalog) == [0]


def test_java_test_annotation_is_source_evidence_but_helper_name_is_insufficient(tmp_path):
    path = 'src/test/java/ChangeTests.java'
    source = b'''class ChangeTests {
    @Test
    void updatesValue() {
        assertEquals(1, makeValue());
    }
    int testHelper() {
        return 1;
    }
}'''
    target = tmp_path / path
    target.parent.mkdir(parents=True)
    target.write_bytes(source)
    language, parse = detect_language(Path(path))
    groups = defaultdict(list)
    for passage in extract_passages(source, parse(source, path), path=path, language=language):
        groups[passage.entity].append(passage)
    catalog = SourceCatalog(tmp_path, groups)
    keys = {key.qualname: key for key in catalog.owners}
    assert is_test_case(keys['ChangeTests.updatesValue'], catalog)
    assert not is_test_case(keys['ChangeTests.testHelper'], catalog)
