"""Combine separately tested pure symbol-order policies on actual201MCP pools."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from explicit_code_terms import explicit_code_terms, prefer_explicit_code_terms
from requested_test_piece import prefer_requested_test_piece
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
scope = json.loads(scope_path.read_text())
cases, answers = {}, {}
pins = {}
for cohort, selection in scope['cohorts'].items():
    path = Path(selection['english_cases'])
    assert sha(path) == selection['sha256']
    cases.update({row['id']: row | {'cohort': cohort} for row in rows(path)})
    root = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    reg = json.loads((root / 'capture/registration.json').read_text())
    assert reg['status'] == lock['closed_status']
    pins[cohort] = sha(root / 'capture/registration.json')
    for repo, files in reg['closed'].items():
        path = root / 'capture' / repo / 'answers.jsonl'
        assert sha(path) == files['answers.jsonl']
        answers.update({row['id']: row for row in rows(path) if row['id'] in cases})
assert len(cases) == len(answers) == 240 and set(cases) == set(answers)
out = w / 'output/development/combined-symbol-policies-v206'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 EXPOSED development on ACTUAL201 native pools and NN1024 raw scores; no model/input/inference changes. Reserve CLOSED.',
    'hypothesis': 'Separately measured source-role correction, requested test granularity and explicit operator signal may complement replacing ordinal fusion only for symbols; do not add their gains without measuring the combination.',
    'variants': ['current_rrf', 'neural_symbols_only', 'neural_test_piece', 'neural_test_piece_operator', 'rrf_test_piece_operator'],
    'policy': 'Actual201 answers stay fixed for non-symbols and unique exact bypass. Raw neural order preserves native ties; requested test-case preference then literal-operator preference. Always retain namedpath priority and all candidate identities. No fitted weights/IDs/names of repositories.',
    'acceptance': '>=108/120EACH;118/119Recall10; all refs unchanged. Results are pure policy replay, not full combined MCP latency/acceptance.',
    'producer_sha256': sha(Path(__file__)), 'selection_sha256': sha(scope_path), 'capture_pins': pins,
    'policy_sources': {name: sha(w / 'experiments/search-engine' / name) for name in ['requested_test_piece.py', 'explicit_code_terms.py']},
    'status': 'Registered BEFORE orders and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
predictions = []
for repo in sorted({row['repo_id'] for row in cases.values()}):
    selected = [case for case in cases.values() if case['repo_id'] == repo]
    symbol_cases = [case for case in selected if case['target_kind'] == 'symbol' and
                    answers[case['id']]['public_response']['profile_version'] != 'best-exact-source-v1']
    paths = {unit['path'] for case in symbol_cases for unit in answers[case['id']]['units']}
    catalog = None
    if paths:
        root = Path('/private/tmp/ken-public-default-v143/repos') / repo
        with project_connection(root) as connection:
            catalog = SourceCatalog(root, {key: ps for key, ps in owner_passages(connection).items() if key.path in paths})
    for case in selected:
        query_id = case['id']
        answer = answers[query_id]
        units = answer['units']
        orders = {name: units for name in protocol['variants']}
        if case in symbol_cases:
            assert catalog is not None
            results = answer['public_response']['results']
            assert len(results) == len(units)
            signals = [result['signals'] for result in results]
            assert sorted(signal['piece_rank'] for signal in signals) == list(range(1, len(units)+1))
            raw = sorted(range(len(units)), key=lambda i: (-signals[i]['neural_score'], signals[i]['piece_rank']))
            orders['neural_symbols_only'] = [units[i] for i in raw]
            test_order = prefer_requested_test_piece(case['query'], orders['neural_symbols_only'], catalog)
            orders['neural_test_piece'] = [orders['neural_symbols_only'][i] for i in test_order]
            for name, base in [('neural_test_piece_operator', orders['neural_test_piece']),
                               ('rrf_test_piece_operator', [units[i] for i in prefer_requested_test_piece(case['query'], units, catalog)])]:
                implementations = []
                if explicit_code_terms(case['query']):
                    for unit in base:
                        key = EntityKey(path=unit['path'], **unit['entity'])
                        implementations.append(describe_owner(catalog.owners[key]).fields['executable'])
                else:
                    implementations = [''] * len(base)
                order = prefer_explicit_code_terms(case['query'], implementations, list(range(len(base))))
                orders[name] = [base[i] for i in order]
            named = requested_piece_path(SearchRequest(case['query']))
            if named:
                for result in orders.values():
                    result.sort(key=lambda unit: unit['path'] != named)
        canonical = lambda unit: json.dumps(unit, sort_keys=True)
        assert all(sorted(map(canonical, result)) == sorted(map(canonical, units)) for result in orders.values())
        predictions.append({name: case[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold', predictions_sha256=sha(out / 'predictions.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants']}))
