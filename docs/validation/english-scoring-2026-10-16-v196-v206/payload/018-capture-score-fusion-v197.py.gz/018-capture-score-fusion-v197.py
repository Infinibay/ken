"""Fixed score fusion experiment; close all English orders without Gold."""
from pathlib import Path
import hashlib
import json
import sys
import time

sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from score_fusion import score_fusion_order
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def canonical(unit):
    return json.dumps(unit, sort_keys=True)


w = Path.cwd()
focus = w / 'output/analysis/english-ranking-v196'
trace = w / 'output/development/english-native-trace-v196'
selection = json.loads((focus / 'registration.json').read_text())
trace_reg = json.loads((trace / 'registration.json').read_text())
assert trace_reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
out = w / 'output/development/score-fusion-v197'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 EXPOSED development; reserve remains CLOSED; no fitting/model/source/candidate changes',
    'hypothesis': 'Ordinal RRF discards score margins and ties on swapped ranks. Equal-mean population-z scores may preserve comparative margin strength without learned weights.',
    'variants': ['current_rrf', 'native_symbols_only', 'neural_symbols_only', 'raw_equalmean', 'z_equalmean'],
    'formula': '0.5*native+0.5*neural, either raw or per-query centered population-SD units; constant source zero; ties stable native order',
    'controlled': 'Only ordering within existing symbols top10; exact bypass, named path priority, non-symbol outputs unchanged; published68M original1024 inputs/scores identical',
    'acceptance': '>=108/120 EACH English cohort, recall118/119 maintained; replay is diagnostic, not full MCP latency proof',
    'selection_sha256': sha(focus / 'registration.json'),
    'trace_sha256': sha(trace / 'registration.json'),
    'producer_sha256': sha(Path(__file__)),
    'fusion_source_sha256': sha(w / 'experiments/search-engine/score_fusion.py'),
    'status': 'Registered BEFORE variant orders and grading',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
observations = {}
for repo, pins in trace_reg['closed'].items():
    for name, digest in pins.items():
        assert sha(trace / repo / name) == digest
    observations.update({row['id']: row for row in rows(trace / repo / 'observations.jsonl')})
answers, cases = {}, {}
for cohort, data in selection['cohorts'].items():
    case_file = Path(data['english_cases'])
    assert sha(case_file) == data['sha256']
    for case in rows(case_file):
        cases[case['id']] = case | {'cohort': cohort}
    capture = w / 'output/development' / ('public-token-budget-v195-' + cohort) / 'capture'
    reg = json.loads((capture / 'registration.json').read_text())
    for repo, pins in reg['closed'].items():
        path = capture / repo / 'answers.jsonl'
        assert sha(path) == pins['answers.jsonl']
        for row in rows(path):
            if row['id'] in cases:
                answers[row['id']] = row
assert set(cases) == set(answers) and len(cases) == 240 and len(observations) == 150
predictions = []
timings = []
for query_id, case in cases.items():
    baseline = answers[query_id]['units']
    orders = {variant: baseline for variant in protocol['variants']}
    if case['target_kind'] == 'symbol':
        record = observations[query_id]
        if not record['exact_bypass']:
            assert record['verified_current_mcp_units'] == baseline
            units = record['units'][:10]
            native, neural = record['native_scores'][:10], record['native10_neural_scores']
            assert len(units) == len(native) == len(neural)
            indices = {
                'native_symbols_only': list(range(len(units))),
                'neural_symbols_only': sorted(range(len(units)), key=lambda i: (-neural[i], i)),
            }
            for name, standardize in [('raw_equalmean', False), ('z_equalmean', True)]:
                start = time.perf_counter_ns()
                indices[name] = score_fusion_order(native, neural, standardize=standardize)
                timings.append({'id': query_id, 'variant': name, 'ns': time.perf_counter_ns() - start})
            named = requested_piece_path(SearchRequest(case['query']))
            for name, order in indices.items():
                if named:
                    order.sort(key=lambda i: units[i]['path'] != named)
                orders[name] = [units[index] for index in order]
    for units in orders.values():
        assert sorted(map(canonical, units)) == sorted(map(canonical, baseline)), query_id
    predictions.append({name: case[name] for name in ['id', 'cohort', 'language', 'target_kind', 'repo_id']} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
(out / 'fusion-only-timings.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in timings))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold',
                predictions_sha256=sha(out / 'predictions.jsonl'),
                timing_sha256=sha(out / 'fusion-only-timings.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants'], 'reserve': 'CLOSED'}))
