"""Research fusion of source scores; no labels, learned weights or new models."""
from collections.abc import Sequence
import math


def _standardized(values: Sequence[float]) -> list[float]:
    scale = max(map(abs, values), default=0.)
    if not scale:
        return [0.] * len(values)
    scaled = [value / scale for value in values]
    mean = math.fsum(scaled) / len(scaled)
    centered = [value - mean for value in scaled]
    variance = math.fsum(value * value for value in centered) / len(centered)
    return [value / math.sqrt(variance) for value in centered] if variance else [0.] * len(values)


def score_fusion_order(native: Sequence[float], neural: Sequence[float], *,
                       standardize: bool = True) -> list[int]:
    """Combine actual margins, optionally in each query's population-SD units."""
    if len(native) != len(neural) or len(native) > 10:
        raise ValueError('same native top10 score membership required')
    if not all(math.isfinite(value) for value in (*native, *neural)):
        raise ValueError('finite source scores required')
    if not native:
        return []
    left = _standardized(native) if standardize else native
    right = _standardized(neural) if standardize else neural
    values = [.5 * a + .5 * b for a, b in zip(left, right, strict=True)]
    return sorted(range(len(values)), key=lambda index: (-values[index], index))
