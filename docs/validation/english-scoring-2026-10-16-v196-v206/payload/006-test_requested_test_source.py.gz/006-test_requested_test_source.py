"""General English intent examples, independent of development answer identities."""
import pytest
from requested_test_source import requests_test_source


@pytest.mark.parametrize('query', [
    'Where does a packet test helper construct the expected output?',
    'Where is an encoded value tested with a custom decoder?',
    'Where are malformed addresses tested against valid examples?',
    'Find a socket-double factory that collects messages for the test process.',
    'Which regression verifies constructor order?',
    'Find the retry tests that stop on failure.',
])
def test_request_can_name_test_support_or_a_passive_test(query):
    assert requests_test_source(query)


@pytest.mark.parametrize('query', [
    'Where does a function call test helpers before running?',
    'Where is the tested flag read by the parser?',
    'Which helper dispatches tests to a worker?',
    'Where does the protocol double the receive buffer?',
    'Find a process factory that passes a test argument to a production process.',
    'Find a mock class declaration.',
    'Where is a function tested with examples documented?',
])
def test_mentions_inside_behavior_do_not_change_requested_source(query):
    assert not requests_test_source(query)
