"""Research signal for explicitly named logical operators, without index changes.

Ordinary prose conjunctions do not express a code requirement. Uppercase or
code-quoted operator names do. Literal operator evidence only reorders existing
candidates; absence across the pool gives no authority to discard candidates.
"""
from collections.abc import Sequence
import re

_OPERATORS = frozenset({'and', 'or', 'not', 'in', 'is'})
_WORDS = re.compile(r'[A-Za-z_][A-Za-z_0-9]*')


def explicit_code_terms(query: str) -> frozenset[str]:
    words = {word.casefold() for word in _WORDS.findall(query) if word.isupper()}
    words.update(match.group(1).casefold() for match in re.finditer(r'`([A-Za-z]+)`', query))
    return frozenset(words & _OPERATORS)


def prefer_explicit_code_terms(query: str, implementations: Sequence[str], order: Sequence[int]) -> list[int]:
    if sorted(order) != list(range(len(implementations))):
        raise ValueError('candidate order must be a permutation')
    required = explicit_code_terms(query)
    if not required:
        return list(order)
    present = [{word.casefold() for word in _WORDS.findall(text)}
               | ({'and'} if '&&' in text else set())
               | ({'or'} if '||' in text else set()) for text in implementations]
    return sorted(order, key=lambda index: not required <= present[index])
