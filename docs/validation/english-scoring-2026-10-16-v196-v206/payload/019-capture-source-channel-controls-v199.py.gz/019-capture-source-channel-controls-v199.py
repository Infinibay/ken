"""Diagnostic source-channel controls: no new vectors, fitting or parameter search."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from score_fusion import score_fusion_order
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import SearchRequest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
trace = w / 'output/development/english-native-trace-v196'
reg = json.loads((trace / 'registration.json').read_text())
assert reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
closed = w / 'output/development/score-fusion-v197'
closed_reg = json.loads((closed / 'registration.json').read_text())
assert sha(closed / 'predictions.jsonl') == closed_reg['predictions_sha256']
cases = {}
focus = w / 'output/analysis/english-ranking-v196'
for data in json.loads((focus / 'registration.json').read_text())['cohorts'].values():
    path = Path(data['english_cases'])
    assert sha(path) == data['sha256']
    cases.update({row['id']: row for row in rows(path)})
out = w / 'output/development/source-channel-controls-v199'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'Diagnostic channel ablation only on exposed240English; not optimized production policy or independent validation. Same source195, same native10, published1024NN. Reserve CLOSED.',
    'hypothesis': 'Native forest first divergences heavily use proposal rank and source-view similarity. Measure unmodified source-view channels alone to locate useful information, without selecting query-specific winners.',
    'variants': ['current_rrf', 'code_implementation', 'code_contract', 'code_contract_implementation_mean', 'z_implementation_neural'],
    'fixed_scores': 'original CodeRank implementation cosine; original contract cosine; their equal arithmetic mean; equal mean population-z implementation cosine and NNlogit. No fitted weights or thresholds.',
    'acceptance': 'Report BOTH120English cohorts and unchanged118/119Recall10, >=108each remains goal. No max-across-variants or oracle reported as runtime.',
    'producer_sha256': sha(Path(__file__)), 'trace_sha256': sha(trace / 'registration.json'),
    'status': 'Registered BEFORE orders and grading',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
observations = {}
for repo, pins in reg['closed'].items():
    for name, digest in pins.items():
        assert sha(trace / repo / name) == digest
    data = np.load(trace / repo / 'features.npz', allow_pickle=False)
    features = list(data['features'])
    for record in rows(trace / repo / 'observations.jsonl'):
        if record['exact_bypass']:
            continue
        matrix = data['x'][data['qid'] == record['id']][:10]
        observations[record['id']] = (record, matrix[:, features.index('view_implementation_original_raw')].tolist(),
                                    matrix[:, features.index('view_contract_original_raw')].tolist())
predictions = []
for baseline in rows(closed / 'predictions.jsonl'):
    query_id = baseline['id']
    units = baseline['orders']['current_rrf']
    orders = {name: units for name in protocol['variants']}
    if query_id in observations:
        record, body, contract = observations[query_id]
        native_units = record['units'][:10]
        values = {
            'code_implementation': body, 'code_contract': contract,
            'code_contract_implementation_mean': [(a + b) * .5 for a, b in zip(body, contract, strict=True)],
        }
        indices = {name: sorted(range(len(scores)), key=lambda i: (-scores[i], i)) for name, scores in values.items()}
        indices['z_implementation_neural'] = score_fusion_order(body, record['native10_neural_scores'])
        named = requested_piece_path(SearchRequest(cases[query_id]['query']))
        for name, order in indices.items():
            if named:
                order.sort(key=lambda i: native_units[i]['path'] != named)
            orders[name] = [native_units[i] for i in order]
    canonical = lambda item: json.dumps(item, sort_keys=True)
    assert all(sorted(map(canonical, result)) == sorted(map(canonical, units)) for result in orders.values())
    predictions.append({key: value for key, value in baseline.items() if key != 'orders'} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in predictions))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold',
                predictions_sha256=sha(out / 'predictions.jsonl'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(predictions), 'variants': protocol['variants']}))
