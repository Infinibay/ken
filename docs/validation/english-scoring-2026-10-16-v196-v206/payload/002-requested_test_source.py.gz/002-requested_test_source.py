"""Research correction for English requested test support and passive test objects."""
import re
from ken.retrieval.intent import _OBJECT_BOUNDARIES, _requests_test_source


def requests_test_source(query: str) -> bool:
    """Read the requested object; a test mentioned in behavior is insufficient."""
    lower = query.casefold().strip()
    if _requests_test_source(lower):
        return True
    object_query = re.sub(r'^where\s+(?:does|do|is|are)\s+', 'find ', lower)
    if _requests_test_source(object_query):
        return True
    passive = re.match(r'^where\s+(?:is|are)\s+(?P<object>(?:[\w-]+\s+){1,8})'
                       r'tested\s+(?:with|against|using|by|for|when|on)\b', lower)
    if passive and not (_OBJECT_BOUNDARIES & set(passive['object'].split())):
        return True
    prefix = re.split(r'\b(?:that|which|where|whose)\b', object_query, maxsplit=1)[0]
    return bool(re.match(r'^(?:find|show|locate)\s+', object_query)
                and re.search(r'\b[\w]+-double\s+(?:factory|helper|fixture|builder)\b', prefix)
                and re.search(r'\btest(?:s|ing)?\b', lower))
