"""Fresh owner251 observations; stop before NN and verify actual MCP orders."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

import numpy as np
from ken.bench.source_receipts import verify_frozen_source
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.owner_ranking import EvidenceReranker
from ken.retrieval.piece_cards import build_card, card_text
from ken.retrieval.piece_catalog import SourceCatalog, SYMBOL_KINDS
from ken.retrieval.public import find_best
from ken.retrieval.reranker_fusion import fused_reranker_order


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def canonical(unit):
    return json.dumps(unit, sort_keys=True)


def origins():
    root = Path(os.environ['PYTHONPATH']).resolve()
    result = {}
    for name, module in tuple(sys.modules.items()):
        if (name == 'ken' or name.startswith('ken.')) and getattr(module, '__file__', None):
            path = Path(module.__file__).resolve()
            assert path.is_relative_to(root), path
            result[name] = {'path': str(path), 'sha256': sha(path)}
    return result


w = Path.cwd()
focus = w / 'output/analysis/english-ranking-v196'
selection = json.loads((focus / 'registration.json').read_text())
cases = []
for cohort in selection['cohorts'].values():
    case_file = Path(cohort['english_cases'])
    assert sha(case_file) == cohort['sha256']
    cases.extend(case for case in rows(case_file) if case['target_kind'] == 'symbol')
assert len(cases) == 150 and all(case['language'] == 'en' for case in cases)
frozen = w / 'output/frozen/token-budget-default-v195'
assert verify_frozen_source(frozen) == 'da30f85d9d559663b6757ca4f9edebf0d323a2924c52bdc0a42a62e87a5291ef'
# This capture runs AFTER complete MCP timing, so it cannot contend with it.
for cohort in ['original', 'symbols']:
    root = w / 'output/development' / ('public-token-budget-v195-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    assert json.loads((root / 'capture/registration.json').read_text())['status'] == lock['closed_status']
current_mcp = [w / 'output/development' / ('public-token-budget-v195-' + cohort) / 'capture'
               for cohort in ['original', 'symbols']]
current_regs = {str(root): json.loads((root / 'registration.json').read_text()) for root in current_mcp}
prior = w / 'output/development/token-budget-v193'
prior_reg = json.loads((prior / 'registration.json').read_text())
assert prior_reg['status'] == 'ALL250token-budget observations closed without Gold'
out = Path(sys.argv[1])
repo = sys.argv[2] if len(sys.argv) > 2 else None
out.mkdir(exist_ok=False)
if repo is None:
    record = {'scope': 'FRESH150English symbols owner251/current source195; NO Gold/fitting. Stops beforeNN; replay only with identical closed document hashes.',
              'producer_sha256': sha(__file__), 'selection_sha256': sha(focus / 'registration.json'),
              'source_receipt': verify_frozen_source(frozen),
              'mcp_registration_sha256': {str(root): sha(root / 'registration.json') for root in current_mcp},
              'nn_registration_sha256': sha(prior / 'registration.json'), 'closed': {}}
    (out / 'registration.json').write_text(json.dumps(record, indent=2))
    for repo in sorted({case['repo_id'] for case in cases}):
        with (out / (repo + '.log')).open('w') as log:
            subprocess.run([sys.executable, __file__, str(out / repo), repo], env=os.environ,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        record['closed'][repo] = {name: sha(out / repo / name)
                                 for name in ['observations.jsonl', 'features.npz', 'summary.json']}
        (out / 'registration.json').write_text(json.dumps(record, indent=2))
        print(json.dumps({'repo': repo, 'closed': True}), flush=True)
    record.update(status='ALL150freshEnglishnative traces closed without Gold', origins_at_close=origins())
    (out / 'registration.json').write_text(json.dumps(record, indent=2))
    raise SystemExit(0)

assert sha(prior / repo / 'observations.jsonl') == prior_reg['closed'][repo]['observations.jsonl']
previous = {row['id']: row for row in rows(prior / repo / 'observations.jsonl')}
answers = {}
for current_root in current_mcp:
    assert sha(current_root / repo / 'answers.jsonl') == current_regs[str(current_root)]['closed'][repo]['answers.jsonl']
    for row in rows(current_root / repo / 'answers.jsonl'):
        assert row['id'] not in answers
        answers[row['id']] = row
root = Path('/private/tmp/ken-public-default-v143/repos') / repo


class NativeClosed(Exception):
    pass


observation = {}
original_rank = EvidenceReranker.rank


class Observer:
    def record(self, **data):
        assert data['values'] is not None
        candidates = data['candidates']
        indices = {candidate.entity: index for index, candidate in enumerate(candidates)}
        matches = [match for match in data['matches'] if match.entity.kind in SYMBOL_KINDS][:100]
        selected = [indices[match.entity] for match in matches]
        values = data['values'][selected].copy()
        assert np.array_equal(data['model'].predict(values), [match.score for match in matches])
        observation.update(
            values=values, feature_names=data['model'].features, model_fingerprint=data['model'].fingerprint,
            expanded_query=data['expanded'], candidate_count=len(candidates),
            units=[{'target_kind': 'symbol', 'path': match.entity.path,
                    'entity': match.entity.to_dict(), 'module_name': None} for match in matches],
            native_scores=[match.score for match in matches],
            source_hashes=[match.source_hash for match in matches],
            exact=[match.signals.get('exact', 0.) for match in matches],
        )
        raise NativeClosed


observer = Observer()


def rank_with_observation(self, request, candidates, descriptions, **kwargs):
    kwargs['trace'] = observer
    return original_rank(self, request, candidates, descriptions, **kwargs)


EvidenceReranker.rank = rank_with_observation
records, matrices, query_ids = [], [], []
feature_names = None
with project_connection(root) as connection:
    catalog = SourceCatalog(root, owner_passages(connection))
    for case in [case for case in cases if case['repo_id'] == repo]:
        query_id = case['id']
        old = previous[query_id]
        if old['exact_bypass']:
            records.append({'id': query_id, 'exact_bypass': True, 'actual_units': answers[query_id]['units']})
            continue
        observation.clear()
        start = time.perf_counter()
        try:
            find_best(connection, root, case['query'], scope='symbols', piece_kind='symbol')
        except NativeClosed:
            pass
        assert 'values' in observation, query_id
        values = observation.pop('values')
        current_features = observation.pop('feature_names')
        assert feature_names is None or feature_names == current_features
        feature_names = current_features
        assert len(feature_names) == 251
        assert old['expanded_query'] == observation['expanded_query']
        native_units = observation['units'][:10]
        assert set(map(canonical, native_units)) == set(map(canonical, answers[query_id]['units'])), query_id
        old_indices = {canonical(unit): index for index, unit in enumerate(old['units'])}
        texts = []
        scores = []
        for unit in native_units:
            entity = EntityKey(path=unit['path'], **unit['entity'])
            text = card_text(build_card(entity, 'symbol', [entity], old['expanded_query'], catalog))
            index = old_indices[canonical(unit)]
            assert hashlib.sha256(text.encode()).hexdigest() == old['modes']['original_1024']['input_hashes'][index]
            texts.append(text)
            scores.append(old['modes']['original_1024']['scores'][index])
        order = fused_reranker_order(scores)
        named = requested_piece_path(SearchRequest(case['query']))
        if named:
            order.sort(key=lambda index: native_units[index]['path'] != named)
        assert [native_units[index] for index in order] == answers[query_id]['units'], query_id
        matrices.append(values)
        query_ids.extend([query_id] * len(values))
        records.append({'id': query_id, 'query': case['query'], 'repo_id': repo,
                        'exact_bypass': False, **observation,
                        'verified_current_mcp_units': answers[query_id]['units'],
                        'native10_neural_scores': scores,
                        'native10_input_hashes': [hashlib.sha256(text.encode()).hexdigest() for text in texts],
                        'observer_ms_not_full_search': (time.perf_counter() - start) * 1000})
        print(json.dumps({'id': query_id, 'rows': len(values), 'current_mcp_order_exact': True}), flush=True)
assert matrices and feature_names is not None
assert not any(name in sys.modules for name in ['torch', 'transformers', 'sentence_transformers'])
np.savez_compressed(out / 'features.npz', x=np.concatenate(matrices), qid=np.array(query_ids), features=np.array(feature_names))
(out / 'observations.jsonl').write_text(''.join(json.dumps(record) + '\n' for record in records))
(out / 'summary.json').write_text(json.dumps({
    'queries': len(records), 'exact_bypasses': sum(record['exact_bypass'] for record in records),
    'model_fingerprints': sorted({record['model_fingerprint'] for record in records if not record['exact_bypass']}),
    'features': len(feature_names), 'rows': len(query_ids), 'origins': origins(),
    'peak_rss_native_observer_only': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'note': 'Native observer stops before NN; cannot use its time/RSS as full MCP cost. NNscore reuse authenticated by complete query/document hashes; all current MCPorders reproduce.',
}, indent=2))
