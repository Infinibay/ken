"""Explain current and neural-only English errors from fresh authenticated251vectors."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from ken.retrieval.best_resources import load_rank_models
from verifiable_grading import identity_hit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def canonical(unit):
    return json.dumps(unit, sort_keys=True)


w = Path.cwd()
trace = w / 'output/development/english-native-trace-v196'
reg = json.loads((trace / 'registration.json').read_text())
assert reg['status'] == 'ALL150freshEnglishnative traces closed without Gold'
focus = w / 'output/analysis/english-ranking-v196'
scope = json.loads((focus / 'registration.json').read_text())
case_file = Path(scope['cohorts']['symbols']['english_cases'])
assert sha(case_file) == scope['cohorts']['symbols']['sha256']
cases = {row['id']: row for row in rows(case_file)}
manifest = json.loads((w / 'output/development/score-calibration-v147/fit-manifest.json').read_text())
gold = {}
for cohort in manifest['cohorts']:
    for name, digest in cohort['exposed_gold_pins'].items():
        path = Path(name)
        assert sha(path) == digest
        gold.update({row['id']: row for row in rows(path)})
out = focus / 'fresh-numeric-audit-v198'
out.mkdir(exist_ok=False)
model, _ = load_rank_models()
summaries = []
verified_rows = 0
for repo, pins in reg['closed'].items():
    for name, digest in pins.items():
        assert sha(trace / repo / name) == digest
    data = np.load(trace / repo / 'features.npz', allow_pickle=False)
    assert tuple(data['features']) == model.features and len(model.features) == 251
    for record in rows(trace / repo / 'observations.jsonl'):
        query_id = record['id']
        if query_id not in cases or record['exact_bypass']:
            continue
        matrix = data['x'][data['qid'] == query_id]
        assert np.array_equal(model.predict(matrix), record['native_scores'])
        verified_rows += len(matrix)
        units = record['units']
        hit = lambda unit: bool(identity_hit({'unit': unit}, gold[query_id]['acceptable_units']))
        first = record['verified_current_mcp_units'][0]
        raw = record['native10_neural_scores']
        neural_order = sorted(range(len(raw)), key=lambda i: (-raw[i], i))
        current_hit, neural_hit = hit(first), hit(units[neural_order[0]])
        if current_hit and neural_hit:
            continue
        target_index = next((i for i, unit in enumerate(units) if hit(unit)), None)
        current_index = next(i for i, unit in enumerate(units) if canonical(unit) == canonical(first))
        results = {}
        for name, index in [('current', current_index), ('neural_only', neural_order[0])]:
            tree = model.explain_pair(matrix[index], matrix[target_index]) if target_index is not None else None
            results[name] = {
                'wrong_or_winner': units[index], 'top1_correct': hit(units[index]),
                'native_rank': index + 1, 'native_score': record['native_scores'][index],
                'neural_rank': neural_order.index(index) + 1,
                'neural_logit': raw[index],
                'feature_values': dict(zip(model.features, matrix[index].tolist(), strict=True)),
                'numeric_forest_explanation': tree,
            }
        correct = None if target_index is None else {
            'unit': units[target_index], 'native_rank': target_index + 1,
            'native_score': record['native_scores'][target_index],
            'neural_rank': neural_order.index(target_index) + 1 if target_index < len(raw) else None,
            'neural_logit': raw[target_index] if target_index < len(raw) else None,
            'feature_values': dict(zip(model.features, matrix[target_index].tolist(), strict=True)),
        }
        full = {'id': query_id, 'query': record['query'], 'repo_id': repo,
                'expanded_query': record['expanded_query'], 'current_hit': current_hit,
                'neural_hit': neural_hit, 'correct': correct, 'comparisons': results,
                'feature_origin': 'FRESH195source trace196, all current MCP orders exact; original published1024NN scores reused only after exact query/card hashes',
                'warning': 'Tree deltas group by first divergent split. Interaction accounting; not causal feature importance. Development references exposed; no labels changed.'}
        (out / (query_id + '.json')).write_text(json.dumps(full, ensure_ascii=False, indent=2))
        short = {name: full[name] for name in ['id', 'query', 'repo_id', 'current_hit', 'neural_hit']}
        short['correct'] = None if correct is None else {k: v for k, v in correct.items() if k != 'feature_values'}
        short['comparisons'] = {}
        for name, result in results.items():
            tree = result['numeric_forest_explanation']
            short['comparisons'][name] = {k: v for k, v in result.items() if k not in ['feature_values', 'numeric_forest_explanation']}
            short['comparisons'][name]['native_margin'] = None if tree is None else tree['margin']
            short['comparisons'][name]['branch_margin'] = [] if tree is None else sorted(tree['branch_margin_by_feature'].items(), key=lambda item: -abs(item[1]))[:12]
        summaries.append(short)
        print(json.dumps(short), flush=True)
assert sum(not row['current_hit'] for row in summaries) == 27
assert sum(not row['neural_hit'] for row in summaries) == 20
receipt = {'source_trace_sha256': sha(trace / 'registration.json'), 'producer_sha256': sha(Path(__file__)),
           'model_fingerprint': model.fingerprint, 'feature_count': len(model.features),
           'verified_native_rows': verified_rows, 'errors_union': len(summaries),
           'current_errors': 27, 'neural_only_errors': 20, 'reserve': 'CLOSED',
           'pairs': summaries}
(out / 'summary.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
