"""Isolate requested test-piece granularity on fixed240English symbol pools."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from requested_test_piece import requests_test_case, is_test_case, prefer_requested_test_piece
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest
from ken.retrieval.piece_catalog import SourceCatalog


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
closed = w / 'output/development/score-fusion-v197'
reg = json.loads((closed / 'registration.json').read_text())
assert reg['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
assert sha(closed / 'predictions.jsonl') == reg['predictions_sha256']
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
cases = {}
for data in json.loads(scope_path.read_text())['cohorts'].values():
    path = Path(data['english_cases'])
    assert sha(path) == data['sha256']
    cases.update({row['id']: row for row in rows(path)})
predictions = rows(closed / 'predictions.jsonl')
out = w / 'output/development/requested-test-piece-v204'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 exposed development ONLY. Test-piece preference independent of numeric role correction201: native195scores/NN1024/current pools fixed. Query interpretation uses tested201grammar. Reserve CLOSED.',
    'hypothesis': 'A regression/test-case question can rank an inner helper or an ordinary implementation first. Binary source role from test path does not communicate the required test entry granularity.',
    'variants': ['current_rrf', 'test_piece_rrf', 'test_piece_neural', 'test_piece_zmean'],
    'intervention': 'Stable preference for source-conventional test entry only when a test/regression or passive tested object is requested; explicit test helpers/factories stay support searches. Python test-prefixed callable outside other callables; Java known test annotation on declaration. No JS guess and no assertion of runtime collection. Missing entry means unchanged order; no candidates removed.',
    'acceptance': '>=108/120EACH English cohort; same118/119Recall10. Non-symbol outputs unchanged; namedpath priority retained. No Gold edits.',
    'producer_sha256': sha(Path(__file__)), 'helper_sha256': sha(w / 'experiments/search-engine/requested_test_piece.py'),
    'selection_sha256': sha(scope_path), 'baseline_sha256': sha(closed / 'registration.json'),
    'intent_source_sha256': sha(w / 'output/frozen/requested-test-role-v201/src/ken/retrieval/intent.py'),
    'status': 'Registered BEFORE orders and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
results = {row['id']: {'current_rrf': row['orders']['current_rrf'],
                     'test_piece_rrf': row['orders']['current_rrf'],
                     'test_piece_neural': row['orders']['neural_symbols_only'],
                     'test_piece_zmean': row['orders']['z_equalmean']} for row in predictions}
diagnostics = []
for repo in sorted({row['repo_id'] for row in predictions}):
    selected = [row for row in predictions if row['repo_id'] == repo and row['target_kind'] == 'symbol'
                and requests_test_case(cases[row['id']]['query'])]
    if not selected:
        continue
    paths = {unit['path'] for row in selected for unit in row['orders']['current_rrf']}
    root = Path('/private/tmp/ken-public-default-v143/repos') / repo
    with project_connection(root) as connection:
        owners = {key: value for key, value in owner_passages(connection).items() if key.path in paths}
        catalog = SourceCatalog(root, owners)
        for row in selected:
            query_id = row['id']
            query = cases[query_id]['query']
            choices = results[query_id]
            baseline = choices['current_rrf']
            flags = [is_test_case(EntityKey(path=unit['path'], **unit['entity']), catalog) for unit in baseline]
            for name in ['test_piece_rrf', 'test_piece_neural', 'test_piece_zmean']:
                units = choices[name]
                order = prefer_requested_test_piece(query, units, catalog)
                named = requested_piece_path(SearchRequest(query))
                if named:
                    order.sort(key=lambda i: units[i]['path'] != named)
                choices[name] = [units[i] for i in order]
            diagnostics.append({'id': query_id, 'query': query, 'baseline_units': baseline,
                                'source_entry_flags': flags,
                                'source_hashes': [catalog.hashes[unit['path']] for unit in baseline]})
closed_predictions = []
for row in predictions:
    orders = results[row['id']]
    canonical = lambda item: json.dumps(item, sort_keys=True)
    assert all(sorted(map(canonical, units)) == sorted(map(canonical, orders['current_rrf'])) for units in orders.values())
    closed_predictions.append({key: value for key, value in row.items() if key != 'orders'} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in closed_predictions))
(out / 'source-diagnostics.json').write_text(json.dumps(diagnostics, indent=2))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold',
                predictions_sha256=sha(out / 'predictions.jsonl'), source_diagnostics_sha256=sha(out / 'source-diagnostics.json'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(closed_predictions), 'queries_requesting_test_entry': len(diagnostics)}))
