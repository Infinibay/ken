"""Isolate a literal code-operator signal on the unchanged240English candidate pools."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd() / 'experiments/search-engine'))
from explicit_code_terms import explicit_code_terms, prefer_explicit_code_terms
from ken.retrieval.candidates import owner_passages
from ken.retrieval.connections import project_connection
from ken.retrieval.description import describe_owner
from ken.retrieval.intent import requested_piece_path
from ken.retrieval.model import EntityKey, SearchRequest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


w = Path.cwd()
closed = w / 'output/development/score-fusion-v197'
reg = json.loads((closed / 'registration.json').read_text())
assert reg['status'] == 'ALL240English variant orders CLOSED before exposed Gold'
assert sha(closed / 'predictions.jsonl') == reg['predictions_sha256']
scope_path = w / 'output/analysis/english-ranking-v196/registration.json'
cases = {}
for data in json.loads(scope_path.read_text())['cohorts'].values():
    path = Path(data['english_cases'])
    assert sha(path) == data['sha256']
    cases.update({row['id']: row for row in rows(path)})
predictions = rows(closed / 'predictions.jsonl')
out = w / 'output/development/explicit-code-operators-v202'
out.mkdir(exist_ok=False)
protocol = {
    'scope': 'English240 EXPOSED development only; fixed candidates/source195, published1024NN; reserve CLOSED',
    'hypothesis': 'AND and OR are discarded as stopwords even when explicitly naming a code operation. A small literal operator requirement can distinguish fine operations without training or model changes.',
    'variants': ['current_rrf', 'explicit_operator_rrf', 'explicit_operator_neural', 'explicit_operator_zmean'],
    'intervention': 'Detect explicitly uppercase or code-quoted logical and/or/not/in/is. Stable preference for candidates whose own executable source contains ALL requested literal operators. No items discarded; ordinary prose conjunctions do not trigger. No match or all match preserves ordering. Namedpath priority unchanged. No correction to intent200/201 in this independent probe.',
    'limitation': 'Literal presence is a source signal, not a proof of implementing the requested behavior. Primary-owned source only, existing lexical executable projection, no child code borrowing. Research only until full pipeline tested.',
    'producer_sha256': sha(Path(__file__)), 'helper_sha256': sha(w / 'experiments/search-engine/explicit_code_terms.py'),
    'selection_sha256': sha(scope_path), 'baseline_sha256': sha(closed / 'registration.json'),
    'acceptance': '>=108/120EACH, unchanged118/119Recall10; no reference edits or per-query policy',
    'status': 'Registered BEFORE predictions and Gold',
}
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
texts, details = {}, []
for repo in sorted({row['repo_id'] for row in predictions}):
    selected = [row for row in predictions if row['repo_id'] == repo and row['target_kind'] == 'symbol'
                and explicit_code_terms(cases[row['id']]['query'])]
    if not selected:
        continue
    with project_connection(Path('/private/tmp/ken-public-default-v143/repos') / repo) as connection:
        owners = owner_passages(connection)
        for row in selected:
            units = row['orders']['current_rrf']
            body = []
            for unit in units:
                key = EntityKey(path=unit['path'], **unit['entity'])
                description = describe_owner(owners[key])
                assert description.source_hash == hashlib.sha256((Path('/private/tmp/ken-public-default-v143/repos') / repo / key.path).read_bytes()).hexdigest()
                body.append(description.fields['executable'])
            texts[row['id']] = body
            details.append({'id': row['id'], 'query': cases[row['id']]['query'],
                            'operators': sorted(explicit_code_terms(cases[row['id']]['query'])),
                            'source_hashes': [describe_owner(owners[EntityKey(path=u['path'], **u['entity'])]).source_hash for u in units]})
closed_predictions = []
for row in predictions:
    query_id = row['id']
    baseline = row['orders']['current_rrf']
    orders = {'current_rrf': baseline}
    for name, previous in [('explicit_operator_rrf', 'current_rrf'), ('explicit_operator_neural', 'neural_symbols_only'),
                           ('explicit_operator_zmean', 'z_equalmean')]:
        current = row['orders'][previous]
        if query_id in texts:
            canonical = lambda unit: json.dumps(unit, sort_keys=True)
            lookup = {canonical(unit): index for index, unit in enumerate(baseline)}
            order = [lookup[canonical(unit)] for unit in current]
            order = prefer_explicit_code_terms(cases[query_id]['query'], texts[query_id], order)
            named = requested_piece_path(SearchRequest(cases[query_id]['query']))
            if named:
                order.sort(key=lambda i: baseline[i]['path'] != named)
            current = [baseline[i] for i in order]
        orders[name] = current
        canonical = lambda unit: json.dumps(unit, sort_keys=True)
        assert sorted(map(canonical, current)) == sorted(map(canonical, baseline))
    closed_predictions.append({key: value for key, value in row.items() if key != 'orders'} | {'orders': orders})
(out / 'predictions.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in closed_predictions))
(out / 'source-requirements.json').write_text(json.dumps(details, indent=2))
protocol.update(status='ALL240English variant orders CLOSED before exposed Gold',
                predictions_sha256=sha(out / 'predictions.jsonl'), source_requirements_sha256=sha(out / 'source-requirements.json'))
(out / 'registration.json').write_text(json.dumps(protocol, indent=2))
print(json.dumps({'closed': len(closed_predictions), 'queries_with_explicit_operators': len(texts), 'variants': protocol['variants']}))
