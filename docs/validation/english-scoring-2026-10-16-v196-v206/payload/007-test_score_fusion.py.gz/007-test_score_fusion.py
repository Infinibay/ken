"""Score fusion retains margins, with explicit scale and membership contracts."""
import pytest
from score_fusion import score_fusion_order


def test_normalization_prevents_a_large_native_scale_from_hiding_neural_separation():
    native = [100., 90., 0.]
    neural = [0., 3., -3.]
    assert score_fusion_order(native, neural, standardize=False) == [0, 1, 2]
    assert score_fusion_order(native, neural) == [1, 0, 2]


def test_normalized_order_is_invariant_to_positive_affine_score_units():
    assert score_fusion_order([30., 27., 0.], [1000., 1300., 700.]) == [1, 0, 2]


def test_a_constant_source_contributes_no_discrimination():
    assert score_fusion_order([7., 7., 7.], [-1., 3., 0.]) == [1, 2, 0]
    assert score_fusion_order([7., 7., 7.], [1., 1., 1.]) == [0, 1, 2]


def test_agreement_preserves_dominance_and_top10_membership():
    assert score_fusion_order([0., 1., 2.], [0., 1., 2.]) == [2, 1, 0]
    assert score_fusion_order([], []) == []
    assert score_fusion_order([1.], [3.]) == [0]


@pytest.mark.parametrize('native,neural', [([1.], []), ([1.] * 11, [2.] * 11),
                                         ([float('nan')], [1.]), ([1.], [float('inf')])])
def test_invalid_or_out_of_contract_scores_fail(native, neural):
    with pytest.raises(ValueError):
        score_fusion_order(native, neural)


def test_normalization_handles_large_finite_scores_without_overflow():
    assert score_fusion_order([1e308, 1e308, 1e308], [-1e308, 1e308, 0.]) == [1, 2, 0]
