"""Isolate the tested intent correction for the complete, unchanged public MCP runner."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
clean = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
origin = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clean, text=True).strip()
assert origin == '1a71e4e239782974c91a0036523c6b6b08506001'
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=clean, text=True).splitlines())
assert changed == {'src/ken/retrieval/intent.py', 'tests/retrieval/test_intent.py'}
baseline = w / 'output/frozen/token-budget-default-v195'
for path in (baseline / 'src').rglob('*'):
    if path.is_file() and path.relative_to(baseline / 'src').as_posix() != 'ken/retrieval/intent.py':
        assert path.read_bytes() == (clean / 'src' / path.relative_to(baseline / 'src')).read_bytes(), path
assert 'Success: no issues found in 357 source files' in Path('/private/tmp/ken-test-source-product-v201-mypy-retry.log').read_text()
test_log = Path('/private/tmp/ken-test-source-product-v201-green-fixed.log').read_text()
assert '[100%]' in test_log and 'FAILED' not in test_log and 'ERROR' not in test_log and test_log.count('.') >= 394
frozen = w / 'output/frozen/requested-test-role-v201'
frozen.mkdir(exist_ok=False)
shutil.copytree(clean / 'src', frozen / 'src', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
shutil.copyfile(clean / 'pyproject.toml', frozen / 'pyproject.toml')
files = {path.relative_to(frozen).as_posix(): sha(path) for path in sorted(frozen.rglob('*')) if path.is_file()}
patch = subprocess.check_output(['git', 'diff', '--', 'src'], cwd=clean)
receipt = {'origin_commit': origin, 'source_state': 'Only requested test-role grammar correction; published models,1024,all other source unchanged',
           'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'files': files,
           'tree_sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
           'test_files': {'tests/retrieval/test_intent.py': sha(clean / 'tests/retrieval/test_intent.py')},
           'verification': {str(path): sha(path) for path in [Path('/private/tmp/ken-test-source-product-v201-green-fixed.log'),
                                                           Path('/private/tmp/ken-test-source-product-v201-mypy-retry.log')]}}
(frozen / 'SOURCE-MANIFEST.json').write_text(json.dumps(receipt, indent=2) + '\n')
digest = sha(frozen / 'SOURCE-MANIFEST.json')
producer = w / 'experiments/search-engine/public_default_mcp_run.py'
launcher = w / 'output/analysis/public-default-server-v195.py'
for cohort in ['original', 'symbols']:
    previous = w / 'output/development' / ('public-token-budget-v195-' + cohort) / 'lock.json'
    lock = json.loads(previous.read_text())
    assert sha(producer) == lock['producer_sha256']
    lock.update(scope='Actual default MCP200 intent-role correction ONLY; focusEnglish120same metadata; other80 retained only for source/pool regression. No reserve/no fitting.',
                engine_root=str(frozen), source_receipt=digest, server_launcher=str(launcher))
    lock['variant_policy'].update(engine_root=str(frozen), source_receipt=digest, source_commit=origin,
                                 source_state=receipt['source_state'])
    out = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    out.mkdir(exist_ok=False)
    (out / 'lock.json').write_text(json.dumps(lock, indent=2) + '\n')
    (out / 'SOURCE-WORKTREE.patch').write_bytes(patch)
driver = w / 'output/analysis/run-requested-test-role-v201.py'
assert not driver.exists()
driver.write_text((w / 'output/analysis/run-token-budget-default-v195.py').read_text().replace('public-token-budget-v195-', 'public-requested-test-role-v201-'))
print(json.dumps({'frozen_source_files': len(files), 'source_receipt': digest, 'all400run_before_grading': True}))
