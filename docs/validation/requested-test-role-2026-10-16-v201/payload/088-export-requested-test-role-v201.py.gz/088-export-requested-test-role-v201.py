"""Preserve the isolated intent correction and real400MCP proof, without reserve data."""
from pathlib import Path
import gzip
import hashlib
import json


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
assert '14983 passed, 10 xfailed' in Path('/private/tmp/ken-test-source-product-v201-full-suite.log').read_text()
origins = json.loads(Path('/private/tmp/ken-test-source-product-v201-full-suite-origins.json').read_text())
assert origins['pytest_exit_code'] == 0 and not origins['unexpected']
assert 'Success: no issues found in 357 source files' in Path('/private/tmp/ken-test-source-product-v201-mypy-retry.log').read_text()
out = w / 'output/analysis/requested-test-role-export-v201'
out.mkdir(exist_ok=False)
archive = out / 'payload'
archive.mkdir()
inputs = []
for cohort in ['original', 'symbols']:
    root = w / 'output/development' / ('public-requested-test-role-v201-' + cohort)
    lock = json.loads((root / 'lock.json').read_text())
    assert json.loads((root / 'capture/registration.json').read_text())['status'] == lock['closed_status']
    inputs += [root / 'lock.json', root / 'capture/registration.json', root / 'SOURCE-WORKTREE.patch', root / 'capture.log']
    for repo in ['ajv', 'attrs', 'boltons', 'commons-csv', 'junit5', 'marked', 'packaging', 'pytest']:
        inputs += [root / 'capture' / repo / name for name in
                   ['answers.jsonl', 'performance.json', 'server-telemetry.json', 'compact-example.txt']]
grade = w / 'output/development/public-requested-test-role-grade-v201'
assert json.loads((grade / 'summary.json').read_text())['intent_correction_quality_check']
inputs += list(grade.glob('*'))
inputs += [w / 'output/analysis' / name for name in
           ['freeze-requested-test-role-v201.py', 'run-requested-test-role-v201.py',
            'public-default-server-v195.py', 'grade-requested-test-role-v201.py']]
inputs += [Path('/private/tmp') / name for name in
           ['ken-test-source-product-v201-red.log', 'ken-test-source-product-v201-green.log',
            'ken-test-source-product-v201-green-fixed.log', 'ken-test-source-product-v201-mypy.log',
            'ken-test-source-product-v201-mypy-retry.log', 'ken-run-clean-suite-v201.py',
            'ken-test-source-product-v201-full-suite.log', 'ken-test-source-product-v201-full-suite-origins.json']]
inputs += [Path(__file__), w / 'output/frozen/requested-test-role-v201/SOURCE-MANIFEST.json']
records = []
for i, path in enumerate(inputs):
    assert path.is_file(), path
    data = path.read_bytes()
    label = str(path.relative_to(w)) if path.is_relative_to(w) else 'verification/' + path.name
    target = archive / (f'{i:03d}-' + path.name + '.gz')
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    records.append({'source': label, 'source_sha256': sha(path), 'bytes': len(data),
                    'payload': target.name, 'payload_sha256': sha(target)})
(out / 'manifest.json').write_text(json.dumps({'scope': 'Actual intent201 fullMCP400 and test proof; no reserve files',
    'source_receipt_sha256': 'a11fe27ffae0eb87f214cb441f909b7d4f108474867529184001129f82863ff5', 'files': records}, indent=2) + '\n')
for name in ['summary.json', 'costs.json']:
    (out / name).write_bytes((grade / name).read_bytes())
(out / 'README.md').write_text('''# Requested source role: test support and passive test questions

Ken now retains explicit requests for test helpers, test doubles used by tests,
and passive questions about where something is tested. The old grammar handled
only an initial test/regression noun after find/show/which. A missing test-source
intent let the numeric forest reward production definitions in these searches.
The correction stays in intent.py; explicit public purpose still overrides it.
The same question uses the same models,1024capacity,card source and final fusion.

| Actual complete MCP cohort | Before top1 | After top1 | Top10 |
| --- | --- | --- | --- |
| Original200 |191 |191 |197 |
| New symbols200 |159 |161 |195 |
| English original120 |113 |113 |118 |
| English new120 |93 |95 |119 |

The two gained cases request an inline-lexer test helper and a CLI process
double. No earlier top1 or top10 hit was lost. Six native candidate pools change;
their identities are retained in summary.json, not concealed as fixed-pool
replay. Both full200captures closed before grading against unchanged references.
The English goal remains>=108/120EACH cohort.95/120 does not meet it; this is a
measured incremental improvement. All400 are exposed development; reserve CLOSED.

English240 actual complete MCP prepared-index latency: median1904.59ms,
p953222.43ms, maximum4492.28ms. All400 median2139.67ms,p953730.73ms,
maximum4644.25ms. Peak whole-server RSS2144960512bytes (2.14GB decimal).
CPUExecutionProvider is verified for both contextual and neural models in
all16servers; no torch/transformers/sentence_transformers imports. Separate
warmup and all outliers are retained. These measurements support the3–5s CPU
envelope on the evaluated queries, not a claim of speedup from changing grammar.

The first expanded grammar failed three existing verb-test guards; a test-run
input object also needed distinction from a test request. Those failures are
preserved. The final grammar only extends where-does questions for explicit
test-support nouns and where-is questions for test objects/passives. No source
name, repository, query ID or expected answer is present in the product code.

Verification:394retrieval tests passed including16new guards;14983passed and
10existingxfail in the full suite (505.44s); mypy357source files clean with a
fresh explicit cache (the earlier shared-cache invocation failed internally and
is retained).354real Ken module imports all originate in the clean worktree.
Source422files is pinned by receipt in manifest.json and reconstructable from
commit1a71e4e2 plus the preserved source patch. Each compressed payload has both
compressed and decompressed SHA256 checks. No release/tag/version bump/PyPI.

Review: responsibility stays with query intent; source kind/identity and
negative behavior mentions keep their previous contract. The loop covers only
two bounded prefixes and existing noun grammar. No dependency, forest weight,
encoder, neural weight, source evidence projection or output format change.
''')
print(json.dumps({'files': len(records), 'payload_bytes': sum(p.stat().st_size for p in archive.iterdir()),
                  'manifest_sha256': sha(out / 'manifest.json')}))
