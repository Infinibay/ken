from pathlib import Path
import hashlib,json,sys
import pytest
root=Path('/Users/andres/.codex/worktrees/compact-default-output/ken/src').resolve()
result=pytest.main(['-p','no:cacheprovider'])
origins={};unexpected={}
for name,module in tuple(sys.modules.items()):
 if (name=='ken' or name.startswith('ken.')) and getattr(module,'__file__',None):
  p=Path(module.__file__).resolve()
  if not p.is_relative_to(root):unexpected[name]=str(p)
  if p.is_file():origins[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
Path('/private/tmp/ken-test-source-product-v201-full-suite-origins.json').write_text(json.dumps({'pytest_exit_code':int(result),'origins':origins,'unexpected':unexpected},indent=2))
assert not unexpected,unexpected
raise SystemExit(result)
