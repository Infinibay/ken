"""Freeze the tested 1024-token default for actual unchanged MCP transport."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

w = Path.cwd()
clean = Path('/Users/andres/.codex/worktrees/compact-default-output/ken')
origin = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clean, text=True).strip()
assert origin == '9311cedbe1e93b91f1e0b89c39c5af2c193fefad'
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=clean, text=True).splitlines())
assert changed == {'src/ken/retrieval/neural_reranker.py', 'src/ken/retrieval/neural_assets.py', 'tests/retrieval/test_neural_reranker.py'}
suite = Path('/private/tmp/ken-token-budget-v195-full-suite-retry.log').read_text()
assert '14967 passed, 10 xfailed' in suite
origins = json.loads(Path('/private/tmp/ken-token-budget-v195-full-suite-origins.json').read_text())
assert origins['pytest_exit_code'] == 0 and not origins['unexpected']
assert 'Success: no issues found in 357 source files' in Path('/private/tmp/ken-token-budget-v195-mypy.log').read_text()
frozen = w / 'output/frozen/token-budget-default-v195'
frozen.mkdir(exist_ok=False)
shutil.copytree(clean / 'src', frozen / 'src', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
shutil.copyfile(clean / 'pyproject.toml', frozen / 'pyproject.toml')
files = {path.relative_to(frozen).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in sorted(frozen.rglob('*')) if path.is_file()}
patch = subprocess.check_output(['git', 'diff', '--', 'src'], cwd=clean)
receipt = {'origin_commit': origin, 'source_state': 'Tested isolated1024default; same weights/embeddings/fusion, not yet promoted',
           'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'files': files,
           'tree_sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()}
(frozen / 'SOURCE-MANIFEST.json').write_text(json.dumps(receipt, indent=2) + '\n')
digest = hashlib.sha256((frozen / 'SOURCE-MANIFEST.json').read_bytes()).hexdigest()
previous_launcher = w / 'experiments/search-engine/public_default_server.py'
launcher = w / 'output/analysis/public-default-server-v195.py'
assert not launcher.exists()
source = previous_launcher.read_text()
needle = "'providers':providers,'context_providers':context,"
assert source.count(needle) == 1
source = source.replace(needle, needle + "'max_tokens':models.neural._max_tokens if default_resources.cache_info().currsize else None,")
launcher.write_text(source)
producer = w / 'experiments/search-engine/public_default_mcp_run.py'
for cohort in ['original', 'symbols']:
    prior = w / 'output/development' / ('public-qualified-locator-v172-' + cohort) / 'lock.json'
    lock = json.loads(prior.read_text())
    assert hashlib.sha256(producer.read_bytes()).hexdigest() == lock['producer_sha256']
    lock.update(scope='Actual default MCP200 with1024token budget ONLY; same models/source cards/native scores/fusion; no private inputs',
                engine_root=str(frozen), source_receipt=digest, server_launcher=str(launcher))
    lock['input_pins'].pop(str(previous_launcher), None)
    lock['input_pins'][str(launcher)] = hashlib.sha256(launcher.read_bytes()).hexdigest()
    lock['variant_policy'].update(engine_root=str(frozen), source_receipt=digest, source_commit=origin,
                                 source_state=receipt['source_state'], neural_tokens=1024)
    out = w / 'output/development' / ('public-token-budget-v195-' + cohort)
    out.mkdir(exist_ok=False)
    (out / 'lock.json').write_text(json.dumps(lock, indent=2) + '\n')
    (out / 'SOURCE-WORKTREE.patch').write_bytes(patch)
    print(json.dumps({'cohort': cohort, 'source_receipt': digest, 'lock_sha256': hashlib.sha256((out / 'lock.json').read_bytes()).hexdigest()}))
print(json.dumps({'frozen_source_files': len(files), 'source_receipt': digest}))
