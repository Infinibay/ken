"""Preserve actual1024MCP evidence and verification, never any sealed reserve."""
from pathlib import Path
import gzip
import hashlib
import json


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


w = Path.cwd()
out = w / 'output/analysis/token-budget-default-export-v195-r1'
out.mkdir(exist_ok=False)
archive = out / 'payload'
archive.mkdir()
inputs = []
for cohort in ['original', 'symbols']:
    root = w / 'output/development' / ('public-token-budget-v195-' + cohort)
    inputs += [root / 'lock.json', root / 'capture/registration.json', root / 'SOURCE-WORKTREE.patch']
    for repo in ['ajv', 'attrs', 'boltons', 'commons-csv', 'junit5', 'marked', 'packaging', 'pytest']:
        inputs += [root / 'capture' / repo / name for name in
                   ['answers.jsonl', 'performance.json', 'server-telemetry.json', 'compact-example.txt']]
for name in ['summary.json', 'costs.json', 'outcomes.jsonl', 'registration.json']:
    inputs.append(w / 'output/development/public-token-budget-grade-v195' / name)
inputs += [w / 'output/analysis' / name for name in
           ['freeze-token-budget-default-v195.py', 'run-token-budget-default-v195.py',
            'public-default-server-v195.py', 'grade-token-budget-default-v195.py']]
inputs += [Path('/private/tmp') / name for name in
           ['ken-token-budget-v195-red.log', 'ken-token-budget-v195-green-fixed.log',
            'ken-token-budget-v195-full-suite-retry.log', 'ken-token-budget-v195-full-suite-origins.json',
            'ken-run-clean-suite-v195.py', 'ken-token-budget-v195-mypy.log']]
inputs += [Path(__file__)]
inputs += [w / 'output/frozen/token-budget-default-v195/SOURCE-MANIFEST.json']
records = []
for i, path in enumerate(inputs):
    assert path.is_file(), path
    data = path.read_bytes()
    label = str(path.relative_to(w)) if path.is_relative_to(w) else 'verification/' + path.name
    target = archive / (f'{i:03d}-' + path.name + '.gz')
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    records.append({'source': label, 'source_sha256': sha(path), 'bytes': len(data),
                    'payload': target.name, 'payload_sha256': sha(target)})
manifest = {'scope': 'Actual fullMCP400source195/1024budget and test proof; no sealed reserve files',
            'source_receipt_sha256': 'da30f85d9d559663b6757ca4f9edebf0d323a2924c52bdc0a42a62e87a5291ef',
            'files': records}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name in ['summary.json', 'costs.json']:
    (out / name).write_bytes((w / 'output/development/public-token-budget-grade-v195' / name).read_bytes())
(out / 'README.md').write_text('''# Default neural token budget: 1024

The reranker client accepts a configurable token budget and defaults to1024,
as requested. The published Ettin68M weights, CPU batch1/thread4 settings,
source-card selection, embeddings and final ranking policy remain fixed.
The client rejects budgets above a declared model/tokenizer limit before
creating an ONNX session.2048 is supported when the pinned model allows it.

This changes capacity, not search accuracy. Actual complete MCP runs on the
same400 exposed development queries reproduce the512-budget answers and pools:

| Cohort | All queries top1/top10 | English top1/top10 |
| --- | --- | --- |
| Original |191/197 of200 |113/118 of120 |
| New symbols |159/195 of200 |93/119 of120 |

The current English objective is at least108/120 strict correct pieces in
EACH cohort. The new cohort does not meet it. The independent reserve remains
closed; these exposed development numbers are not independent acceptance.

Actual complete MCP English240 prepared-index latency: median1886.48ms,
p953120.45ms, maximum4004.57ms. All400: median2107.30ms, p953545.92ms,
maximum4597.67ms. Explicit model warmup is recorded separately. All calls and
outliers are retained. CPUExecutionProvider is verified for context and neural
models in all16 processes; no torch/transformers/sentence_transformers imports.
Peak server RSS across both full cohorts was2160279552bytes (2.16GB decimal),
including index and resident models. Per-process timings, file counts and RSS
are in costs.json. This is a measurement of1024, not a controlled CPU speedup
claim versus512. Both1024 and2048 previously had identical effective inputs on
these short cards; retaining2048 would not expose more source in this set.

Verification:20actual miniatureONNX runtime tests; full suite14967passed,
10existingxfail; mypy357source files clean. All loaded Ken modules came from
the clean worktree. The old512-capacity test remains with explicit512 config.
Source snapshot422files is bound by receipt in manifest.json; the patch and
normal MCP producers/outputs are preserved in compressed payloads. Each payload
is independently checked against its original SHA256 after decompression.

Review: token capacity belongs to ONNXReranker, and default_reranker only forwards
configuration. No dependency or model-weight change, no scoring-rule change,
no reference/acceptance edits. Lazy preparation and empty-pool behavior are
preserved. Real long-query/document tests cover1024 and2048 capacity and errors.
No release, tag, version bump or PyPI publication is part of this change.
''')
print(json.dumps({'export': str(out), 'files': len(records), 'payload_bytes': sum(p.stat().st_size for p in archive.iterdir()),
                  'manifest_sha256': sha(out / 'manifest.json')}))
